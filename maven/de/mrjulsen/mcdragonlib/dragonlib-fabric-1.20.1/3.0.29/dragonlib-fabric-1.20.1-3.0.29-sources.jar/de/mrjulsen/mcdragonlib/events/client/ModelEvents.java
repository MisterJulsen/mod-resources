package de.mrjulsen.mcdragonlib.events.client;

import java.util.function.Predicate;
import net.minecraft.class_1087;
import net.minecraft.class_1088;
import net.minecraft.class_1091;
import net.minecraft.class_1100;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_773;
import net.minecraft.class_7923;
import org.jetbrains.annotations.Nullable;

import dev.architectury.event.Event;
import dev.architectury.event.EventFactory;

public interface ModelEvents {

    /**
     * Registers models that the game would not load on its own because nothing references them from a block state
     * or item model file. They are baked like any other model and can be fetched through
     * {@code ModelUtils.getModel(ModelResourceLocation)}.
     */
    Event<AdditionalModels> ADDITIONAL_MODELS = EventFactory.createLoop();

    /**
     * Replaces baked top-level models, i.e. block state variants and {@code inventory} item models. Models that
     * are only loaded as part of another model are not covered by this event.
     * <p>
     * Listeners provide the models they want to replace, they are not handed every model in the game:
     *
     * <pre>{@code
     * ModelEvents.MODIFY_MODELS.register(models ->
     *      models.replaceBlock(MY_BLOCK.get(), (original, context) -> new MyWrapper(original)));
     * }</pre>
     */
    Event<ModifyModels> MODIFY_MODELS = EventFactory.createLoop();



    @FunctionalInterface
    interface AdditionalModels {
        void registerAdditionalModels(AdditionalModelsRegistry registry);

        @FunctionalInterface
        interface AdditionalModelsRegistry {
            void register(class_2960 model);
        }
    }

    @FunctionalInterface
    interface ModifyModels {
        void collectModels(ModelModifier modifier);

        interface ModelModifier {
            void replace(class_2960 location, ModelReplacer replacer);
            void replaceIf(Predicate<class_2960> filter, ModelReplacer replacer);

            default void replaceBlock(class_2248 block, ModelReplacer replacer) {
                for (class_2680 state : block.method_9595().method_11662()) {
                    replace(class_773.method_3340(state), replacer);
                }
            }

            default void replaceState(class_2680 state, ModelReplacer replacer) {
                replace(class_773.method_3340(state), replacer);
            }

            default void replaceItem(class_1792 item, ModelReplacer replacer) {
                replace(new class_1091(class_7923.field_41178.method_10221(item), "inventory"), replacer);
            }

            default void replaceNamespace(String namespace, ModelReplacer replacer) {
                for (class_2248 block : class_7923.field_41175) {
                    if (class_7923.field_41175.method_10221(block).method_12836().equals(namespace)) {
                        replaceBlock(block, replacer);
                    }
                }
                for (class_1792 item : class_7923.field_41178) {
                    if (class_7923.field_41178.method_10221(item).method_12836().equals(namespace)) {
                        replaceItem(item, replacer);
                    }
                }
            }
        }

        @FunctionalInterface
        interface ModelReplacer {
            class_1087 replace(@Nullable class_1087 originalModel, Context context);
        }

        interface Context {
            class_1088 getModelBakery();
            class_2960 getModelLocation();
            class_1100 getUnbakedModel();
        }
    }
}
