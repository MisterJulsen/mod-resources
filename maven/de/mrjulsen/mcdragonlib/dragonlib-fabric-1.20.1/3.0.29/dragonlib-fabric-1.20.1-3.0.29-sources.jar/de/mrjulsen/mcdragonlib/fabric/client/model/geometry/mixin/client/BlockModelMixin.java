package de.mrjulsen.mcdragonlib.fabric.client.model.geometry.mixin.client;

import java.util.List;
import java.util.function.Function;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_1100;
import net.minecraft.class_2960;
import net.minecraft.class_3665;
import net.minecraft.class_4590;
import net.minecraft.class_4730;
import net.minecraft.class_7775;
import net.minecraft.class_793;
import net.minecraft.class_799;
import net.minecraft.class_806;
import de.mrjulsen.mcdragonlib.fabric.client.model.geometry.VisibilityData;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import de.mrjulsen.mcdragonlib.fabric.client.model.geometry.IUnbakedGeometry;
import de.mrjulsen.mcdragonlib.fabric.client.model.geometry.extensions.BlockModelExtensions;

@Mixin(class_793.class)
public class BlockModelMixin implements BlockModelExtensions {
	@Shadow
	@Final
	private List<class_799> overrides;

	@Shadow
	@Nullable
    protected class_793 parent;

	@Unique
	private IUnbakedGeometry<?> dragonlib$customModel;

	@Unique
	@Nullable
	private class_4590 dragonlib$rootTransform;

	@Unique
	private final VisibilityData dragonlib$visibilityData = new VisibilityData();

	@Inject(
			method = "bake(Lnet/minecraft/client/resources/model/ModelBaker;Lnet/minecraft/client/renderer/block/model/BlockModel;Ljava/util/function/Function;Lnet/minecraft/client/resources/model/ModelState;Lnet/minecraft/resources/ResourceLocation;Z)Lnet/minecraft/client/resources/model/BakedModel;",
			at = @At("HEAD"),
			cancellable = true
	)
	public void dragonlib$handleCustomModels(class_7775 modelBaker, class_793 ownerModel, Function<class_4730, class_1058> spriteGetter, class_3665 modelTransform, class_2960 modelLocation, boolean guiLight3d, CallbackInfoReturnable<class_1087> cir) {
		IUnbakedGeometry<?> geometry = dragonlib$getCustomGeometry();
		if (geometry != null) {
			class_806 overrides = dragonlib$getOverrides(modelBaker, ownerModel, spriteGetter);
			cir.setReturnValue(geometry.bake(
					(class_793) (Object) this, modelBaker, spriteGetter, modelTransform, overrides, modelLocation, guiLight3d
			));
		}
	}

	@Inject(method = "resolveParents", at = @At("HEAD"))
	private void dragonlib$handleCustomResolveParents(Function<class_2960, class_1100> function, CallbackInfo ci) {
		if (dragonlib$getCustomGeometry() != null)
			dragonlib$getCustomGeometry().resolveParents(function, (class_793) dragonlib$self());
	}

	@Override
	public class_806 dragonlib$getOverrides(class_7775 p_250138_, class_793 p_251800_, Function<class_4730, class_1058> spriteGetter) {
		return this.overrides.isEmpty() ? class_806.field_4292 : new class_806(p_250138_, p_251800_, this.overrides/*, spriteGetter*/);
	}

	@Override
	public void dragonlib$setCustomGeometry(IUnbakedGeometry<?> geometry) {
		this.dragonlib$customModel = geometry;
	}

	@Override
	public IUnbakedGeometry<?> dragonlib$getCustomGeometry() {
		return this.parent != null && dragonlib$customModel == null ? ((BlockModelExtensions)(Object)this.parent).dragonlib$getCustomGeometry() : dragonlib$customModel;
	}

	@Override
	public VisibilityData dragonlib$getVisibilityData() {
		return this.dragonlib$visibilityData;
	}

	@Override
	public boolean dragonlib$isComponentVisible(String part, boolean fallback) {
		return dragonlib$selfParent() != null && !dragonlib$visibilityData.hasCustomVisibility(part) ?
				dragonlib$selfParent().dragonlib$isComponentVisible(part, fallback) :
				dragonlib$visibilityData.isVisible(part, fallback);
	}

	@Override
	public class_4590 dragonlib$getRootTransform() {
		if (dragonlib$rootTransform != null)
			return dragonlib$rootTransform;
		return dragonlib$selfParent() != null ? dragonlib$selfParent().dragonlib$getRootTransform() : class_4590.method_22931();
	}

	@Override
	public void dragonlib$setRootTransform(class_4590 rootTransform) {
		this.dragonlib$rootTransform = rootTransform;
	}

	@Unique
	private BlockModelExtensions dragonlib$self() {
		return (BlockModelExtensions)(Object)this;
	}

	@Unique
	private BlockModelExtensions dragonlib$selfParent() {
		return (BlockModelExtensions)(Object)(((BlockModelAccessor)(Object) dragonlib$self()).dragonlib$getParent());
	}
}
