/*
 * DragonLib 3 - 1.20.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.client.gui.v2.window;

import java.nio.file.Path;
import java.util.List;
import java.util.function.Function;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;

import de.mrjulsen.mcdragonlib.util.TextUtils;

/**
 * Bridge between Minecraft's Screen and the v2 GUI: forwards input, rendering and ticks to a
 * {@link DLWindowManager} and remembers the screen it was opened from.
 * <p>Usually there is no need to subclass this, see {@link #open(Function)}.</p>
 */
public class DLScreen extends class_437 {

    private final DLWindowManager manager = new DLWindowManager();
    private final Function<DLWindowManager, DLWindow> initialWindow;
    private final class_437 previousScreen;
    private boolean initialized;

    /**
     * @param initialWindow builds the window to open as soon as the screen is initialized; may be null
     *                      for a screen whose windows are opened later
     */
    public DLScreen(Function<DLWindowManager, DLWindow> initialWindow) {
        super(TextUtils.empty());
        this.initialWindow = initialWindow;
        this.previousScreen = class_310.method_1551().field_1755;
        this.manager.setCloseHandler(m -> class_310.method_1551().method_1507(m.showPreviousScreenOnClose.get() ? previousScreen : null));
    }

    /**
     * Opens a new screen with a single window on it. The usual entry point into a v2 GUI.
     */
    public static void open(Function<DLWindowManager, DLWindow> window) {
        class_310.method_1551().method_1507(new DLScreen(window));
    }

    public DLWindowManager getWindowManager() {
        return manager;
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        manager.resize(field_22789, field_22790);
        if (!initialized) {
            initialized = true;
            if (initialWindow != null) {
                manager.openWindow(initialWindow.apply(manager));
            }
        }
    }

    @Override
    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        method_25420(guiGraphics);
        manager.render(guiGraphics, class_310.method_1551().field_1772, partialTick, mouseX, mouseY);
    }

    @Override
    public void method_25393() {
        super.method_25393();
        manager.tick();
    }

    @Override
    public void method_16014(double mouseX, double mouseY) {
        manager.mouseMoved(mouseX, mouseY);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        return manager.mousePressed(mouseX, mouseY, button) || super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        return manager.mouseReleased(mouseX, mouseY, button) || super.method_25406(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double dragX, double dragY) {
        return manager.mouseDragged(mouseX, mouseY, button, dragX, dragY) || super.method_25403(mouseX, mouseY, button, dragX, dragY);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double delta) {
        return manager.mouseScrolled(mouseX, mouseY, 0, delta) || super.method_25401(mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (manager.keyPressed(keyCode, scanCode, modifiers)) {
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_ESCAPE && manager.escapePressed()) {
            return true;
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_16803(int keyCode, int scanCode, int modifiers) {
        return manager.keyReleased(keyCode, scanCode, modifiers) || super.method_16803(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_25400(char codePoint, int modifiers) {
        return manager.charTyped(codePoint, modifiers) || super.method_25400(codePoint, modifiers);
    }

    @Override
    public void method_29638(List<Path> paths) {
        if (!manager.filesDropped(paths)) {
            super.method_29638(paths);
        }
    }

    @Override
    public void method_25419() {
        manager.onClosed();
        super.method_25419();
    }

    @Override
    public boolean method_25421() {
        return manager.isPauseScreen();
    }
}
