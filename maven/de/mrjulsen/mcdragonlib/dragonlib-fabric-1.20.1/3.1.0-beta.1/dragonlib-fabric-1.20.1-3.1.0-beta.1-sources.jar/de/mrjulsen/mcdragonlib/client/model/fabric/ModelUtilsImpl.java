/*
 * DragonLib 3 - 1.20.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.client.model.fabric;

import net.minecraft.class_1087;
import net.minecraft.class_1091;
import net.minecraft.class_2960;
import net.minecraft.class_310;

public class ModelUtilsImpl {

    public static class_1087 getModel(class_2960 location) {
        return class_310.method_1551().method_1554().getModel(location);
    }

    public static class_1087 getModel(class_1091 location) {
        return class_310.method_1551().method_1554().method_4742(location);
    }
}
