/*
 * DragonLib 3 - 1.20.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.block;

import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;

public abstract class DLTickableBlockEntity<E extends DLTickableBlockEntity<E>> extends DLSyncedBlockEntity {

    protected DLTickableBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state) {
        super(type, pos, state);
    }    
    
    public static <T extends class_2586> void globalTick(class_1937 level, class_2338 pos, class_2680 state, T blockEntity) {
        if (blockEntity instanceof DLTickableBlockEntity<?> instance) {
            instance.tick(level, pos, state);
        }
    }

    public abstract void tick(class_1937 level, class_2338 pos, class_2680 state);
}
