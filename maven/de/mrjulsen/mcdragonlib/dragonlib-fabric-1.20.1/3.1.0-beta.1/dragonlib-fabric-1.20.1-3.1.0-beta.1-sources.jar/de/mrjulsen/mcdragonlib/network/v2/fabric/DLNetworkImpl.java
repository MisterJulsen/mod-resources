/*
 * DragonLib 3 - 1.20.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.network.v2.fabric;

import de.mrjulsen.mcdragonlib.mixin.common.ServerGamePacketListenerAccessor;
import de.mrjulsen.mcdragonlib.network.v2.DLNetwork;
import de.mrjulsen.mcdragonlib.network.v2.NetworkFlow;
import de.mrjulsen.mcdragonlib.network.v2.PacketContext;
import dev.architectury.utils.Env;
import dev.architectury.utils.EnvExecutor;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1657;
import net.minecraft.class_2535;
import net.minecraft.class_2540;
import net.minecraft.class_2596;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.server.MinecraftServer;

public class DLNetworkImpl {

    public static void registerChannel(class_2960 channelId, String protocolVersion) {
        ServerPlayNetworking.registerGlobalReceiver(channelId, (server, player, handler, buf, sender) ->
            DLNetwork.receive(channelId, buf, serverContext(server, player, handler)));
        EnvExecutor.runInEnv(Env.CLIENT, () -> () -> ClientNetworkImpl.registerChannel(channelId));
    }

    public static class_2596<?> toPacket(class_2960 channelId, NetworkFlow flow, class_2540 frame) {
        if (flow == NetworkFlow.SERVERBOUND) {
            return toServerboundPacket(channelId, frame);
        }
        return ServerPlayNetworking.createS2CPacket(channelId, frame);
    }

    @Environment(EnvType.CLIENT)
    private static class_2596<?> toServerboundPacket(class_2960 channelId, class_2540 frame) {
        return ClientPlayNetworking.createC2SPacket(channelId, frame);
    }

    static PacketContext serverContext(MinecraftServer server, class_3222 player, class_3244 handler) {
        class_2535 connection = ((ServerGamePacketListenerAccessor) handler).dragonlib$getConnection();
        return new PacketContext() {
            @Override
            public Env getEnvironment() {
                return Env.SERVER;
            }

            @Override
            public NetworkFlow getFlow() {
                return NetworkFlow.SERVERBOUND;
            }

            @Override
            public class_2535 getConnection() {
                return connection;
            }

            @Override
            public class_1657 getPlayer() {
                return player;
            }

            @Override
            public void queue(Runnable task) {
                server.execute(task);
            }
        };
    }
}
