/*
 * DragonLib 3 - 1.20.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.client.ber;

import de.mrjulsen.mcdragonlib.block.IBERInstance;
import de.mrjulsen.mcdragonlib.client.util.RenderUtils;
import net.minecraft.class_2586;
import net.minecraft.class_5614;

public class StaticBlockEntityRenderer<T extends class_2586 & IBERInstance<T>> extends RotatableBlockEntityRenderer<T> {


    public StaticBlockEntityRenderer(class_5614.class_5615 context) {
        super(context);
    }

    @Override
    protected void renderBlock(BERGraphics<T> graphics, float partialTick) {
        RenderUtils.initRenderEngine();
        graphics.blockEntity().getRenderer().render(graphics, partialTick);
    }

}
