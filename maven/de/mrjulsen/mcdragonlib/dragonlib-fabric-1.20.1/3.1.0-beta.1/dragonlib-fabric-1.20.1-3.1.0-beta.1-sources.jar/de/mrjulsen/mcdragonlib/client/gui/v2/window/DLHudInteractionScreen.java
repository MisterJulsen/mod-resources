/*
 * DragonLib 3 - 1.20.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.client.gui.v2.window;

import de.mrjulsen.mcdragonlib.DragonLib;
import de.mrjulsen.mcdragonlib.util.TextUtils;
import java.nio.file.Path;
import java.util.List;
import net.minecraft.class_437;

public final class DLHudInteractionScreen extends class_437 {
    public DLHudInteractionScreen() {
        super(TextUtils.EMPTY);
    }

    @Override
    public void method_16014(double mouseX, double mouseY) {
        DLHudManager.getWindowManager().mouseMoved(mouseX, mouseY);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        return (DLHudManager.isReady() && DLHudManager.getWindowManager().mousePressed(mouseX, mouseY, button)) || super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        return (DLHudManager.isReady() && DLHudManager.getWindowManager().mouseReleased(mouseX, mouseY, button)) || super.method_25406(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double dragX, double dragY) {
        return (DLHudManager.isReady() && DLHudManager.getWindowManager().mouseDragged(mouseX, mouseY, button, dragX, dragY)) || super.method_25403(mouseX, mouseY, button, dragX, dragY);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double delta) {
        return (DLHudManager.isReady() && DLHudManager.getWindowManager().mouseScrolled(mouseX, mouseY, 0, delta)) || super.method_25401(mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (DLHudManager.isReady() && DLHudManager.getWindowManager().keyPressed(keyCode, scanCode, modifiers)) {
            return true;
        }
        if (DLHudManager.KEY_OVERLAY_SETTINGS.method_1417(keyCode, scanCode)) {
            method_25419();
            return true;
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_16803(int keyCode, int scanCode, int modifiers) {
        return (DLHudManager.isReady() && DLHudManager.getWindowManager().keyReleased(keyCode, scanCode, modifiers)) || super.method_16803(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_25400(char codePoint, int modifiers) {
        return (DLHudManager.isReady() && DLHudManager.getWindowManager().charTyped(codePoint, modifiers)) || super.method_25400(codePoint, modifiers);
    }

    @Override
    public void method_29638(List<Path> paths) {
        if (!DLHudManager.isReady() || !DLHudManager.getWindowManager().filesDropped(paths)) {
            super.method_29638(paths);
        }
    }

    @Override
    public void method_25432() {
        super.method_25432();
        DLWindowManager manager = DLHudManager.getWindowManager();
        manager.closeAllPopups();
        manager.focus(null);
        manager.router().clearState();
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
