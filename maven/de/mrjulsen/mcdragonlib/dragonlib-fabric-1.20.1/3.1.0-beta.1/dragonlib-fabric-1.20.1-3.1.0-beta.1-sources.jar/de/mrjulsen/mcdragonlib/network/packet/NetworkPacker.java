/*
 * DragonLib 3 - 1.20.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.network.packet;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import net.minecraft.class_2487;
import net.minecraft.class_2540;
import net.minecraft.class_2596;
import net.minecraft.class_2960;
import de.mrjulsen.mcdragonlib.network.DLNetworkManager;
import de.mrjulsen.mcdragonlib.network.NetworkPacketContext;
import de.mrjulsen.mcdragonlib.network.NetworkSide;
import io.netty.buffer.Unpooled;

/**
 * @deprecated Splitting and reassembling is handled by {@code de.mrjulsen.mcdragonlib.net.transport}.
 */
@Deprecated
public class NetworkPacker {

    public static List<class_2596<?>> pack(class_2960 channelId, PacketHeaderInfo info, NetworkSide side, class_2487 rawData) {
        final int headerSize = SegmentedPacketHeaderInfo.getSize(info);
        
        class_2540 buf = new class_2540(Unpooled.buffer());
        buf.method_10794(rawData);

        int maxSize = (side == NetworkSide.C2S ? 32767 : 1048576) - 20 - headerSize;        
        int partSize = maxSize - 4;
        int parts = (int)Math.ceil(buf.readableBytes() / (float) partSize);
        List<class_2596<?>> packets = new ArrayList<>(parts);

        if (buf.readableBytes() <= maxSize) {
            class_2540 stateBuf = new class_2540(Unpooled.buffer(1));
            SegmentedPacketHeaderInfo header = new SegmentedPacketHeaderInfo(info, SegmentType.SINGLE, parts, 0);
            header.writeBufferHeader(stateBuf);
            class_2540 packetBuffer = new class_2540(Unpooled.wrappedBuffer(stateBuf, buf));
            
            packets.add(DLNetworkManager.toPacket(channelId, side, packetBuffer));
        } else {
            for (int i = 0; i < parts; i++) {
                class_2540 packetBuffer = new class_2540(Unpooled.buffer());
                SegmentedPacketHeaderInfo header;
                if (i == 0) {
                    header = new SegmentedPacketHeaderInfo(info, SegmentType.START, parts, i);
                } else if (i == parts - 1) {
                    header = new SegmentedPacketHeaderInfo(info, SegmentType.END, parts, i);
                } else {
                    header = new SegmentedPacketHeaderInfo(info, SegmentType.PART, parts, i);
                }
                header.writeBufferHeader(packetBuffer);
                int next = Math.min(buf.readableBytes(), partSize);
                packetBuffer.writeBytes(buf.retainedSlice(buf.readerIndex(), next));
                buf.skipBytes(next);
                
                packets.add(DLNetworkManager.toPacket(channelId, side, packetBuffer));
            }
            buf.retain();
        }
        
        return packets;
    }


    private static final Map<NetworkReceiverData.Key, NetworkReceiverData> chunks = new ConcurrentHashMap<>();

    public static void cleanUp(SegmentedPacketHeaderInfo info, NetworkSide side) {
        NetworkReceiverData.Key key = new NetworkReceiverData.Key(info.type(), side);
        NetworkReceiverData  data = chunks.remove(key);
        if (data != null) {
            data.close();
        }
    }

    public static void unpack(SegmentedPacketHeaderInfo info, NetworkSide side, class_2540 buf, NetworkPacketContext context, Consumer<class_2540> finishCallback) {
        NetworkReceiverData.Key key = new NetworkReceiverData.Key(info.type(), side);
        NetworkReceiverData data = null;
        switch (info.segment()) {
            case START:
                data = new NetworkReceiverData(key, info);
                if (chunks.put(key, data) != null) {
                    DLNetworkManager.LOGGER.warn("Received invalid START packet for SplitPacketTransformer with packet id " + key.info().name() + " for side " + side);
                }
                buf.retain();
                data.add(new NetworkReceiverData.Chunk(info.partNumber(), buf));
                break;
            case PART:
                if ((data = chunks.get(key)) == null) {
                    DLNetworkManager.LOGGER.warn("Received invalid PART packet for SplitPacketTransformer with packet id " + key.info().name() + " for side " + side);
                } else if (!data.getKey().equals(key)) {
                    DLNetworkManager.LOGGER.warn("Received invalid PART packet for SplitPacketTransformer with packet id " + key.info().name() + " for side " + side + ", id in cache is " + data.getKey().info().name());
                    data.close();
                    chunks.remove(key);
                } else {
                    buf.retain();
                    data.add(new NetworkReceiverData.Chunk(info.partNumber(), buf));
                }
                break;
            case END:
                if ((data = chunks.get(key)) == null) {
                    DLNetworkManager.LOGGER.warn("Received invalid END packet for SplitPacketTransformer with packet id " + key.info().name() + " for side " + side);
                } else if (!data.getKey().equals(key)) {
                    DLNetworkManager.LOGGER.warn("Received invalid END packet for SplitPacketTransformer with packet id " + key.info().name() + " for side " + side + ", id in cache is " + data.getKey().info().name());
                } else {
                    buf.retain();
                    data.add(new NetworkReceiverData.Chunk(info.partNumber(), buf));
                }
                if (data.chunksCount() != info.expectedParts()) {
                    DLNetworkManager.LOGGER.warn("Received invalid END packet for SplitPacketTransformer with packet id " + key.info().name() + " for side " + side + " with size " + data.chunksCount() + ", parts expected is " + info.expectedParts());
                } else {
                    class_2540 byteBuf = data.mergeData();
                    finishCallback.accept(byteBuf);
                }
                data.close();
                chunks.remove(key);
                break;
            case SINGLE:
                finishCallback.accept(buf);
                break;
            default:
                throw new IllegalStateException("Illegal split packet header!");
        }
    }
    
}
