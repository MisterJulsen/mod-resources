/*
 * DragonLib 3 - 1.20.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.client.gui.v2.text.style;

import java.util.function.Predicate;
import net.minecraft.class_124;
import net.minecraft.class_2583;

public record VanillaStyleEffect(class_124 format, Predicate<class_2583> test) implements IStyleEffect {

    @Override
    public class_124 formatting() {
        return format;
    }

    @Override
    public class_2583 applyVanilla(class_2583 style) {
        return style.method_27706(format);
    }

    @Override
    public boolean matchesVanilla(class_2583 style) {
        return test.test(style);
    }
}
