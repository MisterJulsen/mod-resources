/*
 * DragonLib 3 - 1.20.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.fabric.client.model.geometry;

import net.minecraft.class_3665;
import net.minecraft.class_4590;

public final class SimpleModelState implements class_3665 {
	private final class_4590 transformation;
	private final boolean uvLocked;

	public SimpleModelState(class_4590 transformation, boolean uvLocked) {
		this.transformation = transformation;
		this.uvLocked = uvLocked;
	}

	public SimpleModelState(class_4590 transformation) {
		this(transformation, false);
	}

	@Override
	public class_4590 method_3509() {
		return transformation;
	}

	@Override
	public boolean method_3512() {
		return uvLocked;
	}
}

