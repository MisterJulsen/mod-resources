/*
 * DragonLib 3 - 1.20.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.client.gui.widgets.richtext;

import de.mrjulsen.mcdragonlib.mixin.client.FontAccessor;
import de.mrjulsen.mcdragonlib.util.TextUtils;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_377;
import org.apache.commons.lang3.mutable.MutableFloat;

public class TextSegment {

    private static final String NBT_TEXT = "Text";
    private static final String NBT_STYLE = "Style";

    public record ImmutableTextSegment(String text, TextStyle style) {}

    private StringBuilder text;
    private TextStyle style;

    public TextSegment(StringBuilder text, TextStyle style) {
        this.text = text;
        this.style = style;
    }
    public StringBuilder stringBuilder() {
        return text;
    }
    public String text() {
        return text.toString();
    }
    public TextStyle style() {
        return style;
    }

    public int charLength() {
        return stringBuilder().length();
    }

    public int length() {
        return stringBuilder().codePointCount(0, text.length());
    }

    public int codePointLength() {
        return stringBuilder().codePointCount(0, text.length());
    }

    public boolean isEmpty() {
        return stringBuilder().isEmpty();
    }

    public TextSegment copy() {
        return new TextSegment(new StringBuilder(this.text), this.style.copy());
    }

    public class_2487 toNbt() {
        class_2487 nbt = new class_2487();
        nbt.method_10582(NBT_TEXT, text.toString());
        nbt.method_10566(NBT_STYLE, style.toNbt());
        return nbt;
    }

    public static TextSegment fromNbt(class_2487 nbt) {
        return new TextSegment(new StringBuilder(nbt.method_10558(NBT_TEXT)), TextStyle.fromNbt(nbt.method_10562(NBT_STYLE)));
    }

    public class_2561 toComponent() {
        return TextUtils.text(text()).method_27696(style().toStyle());
    }

    public static TextSegment fromComponent(class_2561 component) {
        return new TextSegment(new StringBuilder(component.getString()), TextStyle.fromStyle(component.method_10866()));
    }

    public float width() {
        if (text == null || text.length() == 0) {
            return 0.0F;
        }

        MutableFloat mutableFloat = new MutableFloat();
        FontAccessor accessor = (FontAccessor) style().font();
        class_377 fontSet = accessor.dragonlib$invokeGetFontSet(class_2583.field_24359);
        iterate(this, 0, (idx, style, c) -> {
            mutableFloat.add(fontSet.method_2011(c, accessor.dragonlib$filterFishyGlyphs()).method_16798(style().bold()));
            return true;
        }, length());
        return mutableFloat.floatValue() * style().scale();
    }

    public ImmutableTextSegment copyImmutable() {
        return copyImmutable(0, length());
    }

    public ImmutableTextSegment copyImmutable(int codePointStartIndex, int codePointEndIndex) {
        if (codePointStartIndex < 0 || codePointEndIndex > length() || codePointStartIndex > codePointEndIndex) {
            throw new IndexOutOfBoundsException("Cannot copy immutable part from code point index " + codePointStartIndex + " to " + codePointEndIndex + " for segment with code point length " + length());
        }
        String originalString = stringBuilder().toString();
        int charStartIndex = originalString.offsetByCodePoints(0, codePointStartIndex);
        int charEndIndex = originalString.offsetByCodePoints(0, codePointEndIndex);
        return new ImmutableTextSegment(originalString.substring(charStartIndex, charEndIndex), style().copy());
    }

    @FunctionalInterface
    public interface CharCallback {
        boolean accept(int codePointIndexInIteration, TextStyle style, int codePoint);
    }

    private static final int REPLACEMENT_CHAR_CODEPOINT = 0xFFFD;

    public static boolean iterate2(TextSegment segment, int skip, CharCallback sink, int count) {
        final StringBuilder sb = segment.stringBuilder();
        final int charLength = sb.length();

        if (skip < 0 || count <= 0) {
            return true;
        }

        int currentCodePointIndex = 0;
        int iteratedCodePoints = 0;
        int charIdx = 0;

        while (charIdx < charLength && iteratedCodePoints < count) {
            int codePoint = sb.codePointAt(charIdx);
            int charsForThisCodePoint = Character.charCount(codePoint);

            if (currentCodePointIndex >= skip) {
                if (!sink.accept(iteratedCodePoints, segment.style(), codePoint)) {
                    return false;
                }
                iteratedCodePoints++;
            }

            currentCodePointIndex++;
            charIdx += charsForThisCodePoint;
        }
        return true;
    }

    public static boolean iterate(TextSegment segment, int skipCodePoints, CharCallback sink, int countCodePoints) {
        final StringBuilder sb = segment.stringBuilder();
        final int charLength = sb.length();

        if (skipCodePoints < 0 || countCodePoints <= 0) {
            return true;
        }

        int currentOverallCodePointIndex = 0;
        int iteratedCodePointsInThisCall = 0;
        int charIdx = 0;

        while (charIdx < charLength && iteratedCodePointsInThisCall < countCodePoints) {
            int codePoint = sb.codePointAt(charIdx);
            int charsForThisCodePoint = Character.charCount(codePoint);

            if (currentOverallCodePointIndex >= skipCodePoints) {
                if (!sink.accept(iteratedCodePointsInThisCall, segment.style(), codePoint)) {
                    return false;
                }
                iteratedCodePointsInThisCall++;
            }

            currentOverallCodePointIndex++;
            charIdx += charsForThisCodePoint;
        }
        return true;
    }
}
