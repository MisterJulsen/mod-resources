/*
 * DragonLib 3 - 1.20.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.client.util;

import java.util.function.UnaryOperator;
import net.minecraft.class_1921;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

public class ClippingBufferSource implements class_4597 {

    private final ClippingVertexConsumer consumer = new ClippingVertexConsumer();
    private class_4597 source;
    private UnaryOperator<class_1921> renderTypeMapper;

    public ClippingBufferSource setup(class_4597 source, Matrix4f pose, Matrix3f normal, float minX, float minY, float maxX, float maxY) {
        this.source = source;
        this.consumer.setup(pose, normal, minX, minY, maxX, maxY);
        return this;
    }

    public ClippingBufferSource setRenderTypeMapper(UnaryOperator<class_1921> mapper) {
        this.renderTypeMapper = mapper;
        return this;
    }

    @Override
    public class_4588 getBuffer(class_1921 renderType) {
        class_1921 type = renderTypeMapper == null ? renderType : renderTypeMapper.apply(renderType);
        return consumer.setDelegate(source.getBuffer(type));
    }
}
