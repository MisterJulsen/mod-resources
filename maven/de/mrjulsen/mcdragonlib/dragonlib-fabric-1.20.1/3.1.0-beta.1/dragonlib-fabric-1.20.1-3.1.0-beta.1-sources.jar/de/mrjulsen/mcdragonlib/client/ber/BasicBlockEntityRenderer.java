/*
 * DragonLib 3 - 1.20.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.client.ber;

import net.minecraft.class_2586;
import net.minecraft.class_327;
import net.minecraft.class_5614;

public abstract class BasicBlockEntityRenderer<T extends class_2586> extends SafeBlockEntityRenderer<T> {
    
    protected final class_327 font;

    public BasicBlockEntityRenderer(class_5614.class_5615 context) {
        super(context);
        this.font = context.method_32143();
    }

    @Override
    protected final void renderSafe(BERGraphics<T> graphics, float partialTick) {        
        graphics.poseStack().method_22903();
        graphics.poseStack().method_22904(0.5D, 0, 0.5F);
        graphics.poseStack().method_46416(-0.5f, 1, -0.5f);
        graphics.poseStack().method_22905(0.0625f, -0.0625f, 0.0625f);

        renderBlock(graphics, partialTick);

        graphics.poseStack().method_22909();
        
    }

    protected abstract void renderBlock(BERGraphics<T> graphics, float partialTick);
}
