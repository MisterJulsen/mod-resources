/*
 * DragonLib 3 - 1.20.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.network;

import java.util.Objects;
import net.minecraft.class_2535;
import net.minecraft.class_2596;
import net.minecraft.class_3222;
import org.jetbrains.annotations.Nullable;

import de.mrjulsen.mcdragonlib.internal.ClientWrapper;
import de.mrjulsen.mcdragonlib.network.v2.PacketTarget;

/**
 * @deprecated Use {@link PacketTarget}.
 */
@Deprecated
public sealed interface NetworkDirection permits NetworkDirection.C2S, NetworkDirection.S2C {
    
    @FunctionalInterface
    public static non-sealed interface C2S extends NetworkDirection {
        @Override
        default NetworkSide getDirection() {
            return NetworkSide.C2S;
        }
    }
    
    @FunctionalInterface
    public static non-sealed interface S2C extends NetworkDirection {        
        @Override
        default NetworkSide getDirection() {
            return NetworkSide.S2C;
        }
    }

    public static final C2S C2S = (packet) -> { throw new IllegalStateException("Please create your own and new instance of NetworkDirection."); };
    public static final S2C S2C = (packet) -> { throw new IllegalStateException("Please create your own and new instance of NetworkDirection."); };

    void send(class_2596<?> packet);
    NetworkSide getDirection();

    /**
     * Returns the connection this instance sends over, if it knows one.
     *
     * <p>The instances handed out by {@link #toPlayer(class_3222)} and {@link #toServer()} do.
     * A hand written implementation does not, in which case the networking layer falls back to
     * routing purely through {@link #send(class_2596)}.
     *
     * @return the connection, or {@code null} if this instance only knows how to send
     */
    @Nullable
    default class_2535 getConnection() {
        return null;
    }
    

    public static S2C toPlayer(class_3222 player) {
        Objects.requireNonNull(player, "Unable to send packet to a 'null' player!");
        return new S2C() {
            @Override
            public void send(class_2596<?> packet) {
                player.field_13987.method_14364(packet);
            }

            @Override
            public class_2535 getConnection() {
                return PacketTarget.connectionOf(player);
            }
        };
    }
    
    public static C2S toServer() {
        return ClientWrapper.toServer();
    }

    public static <N extends NetworkDirection> N forContext(N current, NetworkPacketContext context) {
        if (current instanceof S2C) {
            return (N)NetworkDirection.toPlayer((class_3222)context.getPlayer());
        } else if (current instanceof C2S) {
            return (N)NetworkDirection.toServer();
        }
        return null;
    }



    
}
