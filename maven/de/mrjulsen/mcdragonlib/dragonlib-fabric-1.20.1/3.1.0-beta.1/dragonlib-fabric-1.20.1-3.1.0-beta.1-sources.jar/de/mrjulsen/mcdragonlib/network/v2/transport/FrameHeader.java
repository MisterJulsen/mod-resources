/*
 * DragonLib 3 - 1.20.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.network.v2.transport;

import java.nio.charset.StandardCharsets;
import net.minecraft.class_2540;

/**
 * The fixed part every DragonLib frame starts with.
 *
 * <p>Only the fields a given {@link FrameType} needs are written, so a follow-up frame costs three
 * bytes. The opening frame carries the packet name, which makes a message self describing: adding
 * or removing packets never shifts what an existing one is called, and an unknown packet shows up
 * in the log by name instead of as a number. The transfer id distinguishes messages that overlap
 * on the same connection; the total size lets the receiver reject an oversized message before
 * allocating anything for it.
 *
 * @param protocolVersion the wire revision the sender used
 * @param type the role this frame plays within its message
 * @param transferId identifies the message on its connection, unused for {@link FrameType#SINGLE}
 * @param packetName the registered packet this message belongs to, only present on the opening frame
 * @param totalSize the payload size of the whole message, only present on {@link FrameType#FIRST}
 */
public record FrameHeader(byte protocolVersion, FrameType type, int transferId, String packetName, int totalSize) {

    /** The wire revision this build speaks. */
    public static final byte PROTOCOL_VERSION = 1;

    /** The longest a packet name may be, in characters. */
    public static final int MAX_PACKET_NAME_LENGTH = 128;

    private static final int UNUSED = -1;
    private static final String NO_NAME = "";

    /**
     * Returns the largest number of bytes a header for the given packet can occupy.
     *
     * @param packetName the packet the message belongs to
     * @return the worst case header size in bytes
     */
    public static int maxHeaderBytes(String packetName) {
        int nameBytes = packetName.getBytes(StandardCharsets.UTF_8).length;
        return 1 + 1 + 5 + 5 + 5 + nameBytes;
    }

    /**
     * Creates a header for a message that fits into one frame.
     *
     * @param packetName the registered packet the message belongs to
     * @return a header for a single-frame message
     */
    public static FrameHeader single(String packetName) {
        return new FrameHeader(PROTOCOL_VERSION, FrameType.SINGLE, UNUSED, packetName, UNUSED);
    }

    /**
     * Creates the opening header of a split message.
     *
     * @param transferId identifies the message on its connection
     * @param packetName the registered packet the message belongs to
     * @param totalSize the payload size of the whole message
     * @return a header for the first frame
     */
    public static FrameHeader first(int transferId, String packetName, int totalSize) {
        return new FrameHeader(PROTOCOL_VERSION, FrameType.FIRST, transferId, packetName, totalSize);
    }

    /**
     * Creates a continuation or closing header of a split message.
     *
     * @param type either {@link FrameType#MIDDLE} or {@link FrameType#LAST}
     * @param transferId identifies the message on its connection
     * @return a header for a follow-up frame
     */
    public static FrameHeader continuation(FrameType type, int transferId) {
        return new FrameHeader(PROTOCOL_VERSION, type, transferId, NO_NAME, UNUSED);
    }

    /**
     * Writes this header to the start of a frame buffer.
     *
     * @param buf the buffer to write to
     */
    public void write(class_2540 buf) {
        buf.writeByte(protocolVersion);
        buf.writeByte(type.getId());
        switch (type) {
            case SINGLE -> buf.method_10788(packetName, MAX_PACKET_NAME_LENGTH);
            case FIRST -> {
                buf.method_10804(transferId);
                buf.method_10788(packetName, MAX_PACKET_NAME_LENGTH);
                buf.method_10804(totalSize);
            }
            case MIDDLE, LAST -> buf.method_10804(transferId);
        }
    }

    /**
     * Reads a header from the start of a received frame, leaving the reader positioned at the payload.
     *
     * @param buf the received frame
     * @return the decoded header
     * @throws TransportException if the frame is malformed or uses an unsupported wire revision
     */
    public static FrameHeader read(class_2540 buf) {
        if (buf.readableBytes() < 2) {
            throw new TransportException("Frame is too short to contain a header.");
        }
        byte version = buf.readByte();
        if (version != PROTOCOL_VERSION) {
            throw new TransportException("Unsupported protocol version " + version + ", expected " + PROTOCOL_VERSION + ".");
        }
        FrameType type;
        try {
            type = FrameType.byId(buf.readByte());
        } catch (IllegalArgumentException e) {
            throw new TransportException(e.getMessage());
        }
        return switch (type) {
            case SINGLE -> new FrameHeader(version, type, UNUSED, readName(buf), UNUSED);
            case FIRST -> {
                int transferId = buf.method_10816();
                String packetName = readName(buf);
                int totalSize = buf.method_10816();
                yield new FrameHeader(version, type, transferId, packetName, totalSize);
            }
            case MIDDLE, LAST -> new FrameHeader(version, type, buf.method_10816(), NO_NAME, UNUSED);
        };
    }

    private static String readName(class_2540 buf) {
        try {
            return buf.method_10800(MAX_PACKET_NAME_LENGTH);
        } catch (Exception e) {
            throw new TransportException("Frame carries no readable packet name.", e);
        }
    }
}
