/*
 * DragonLib 3 - 1.20.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.network.v2;

import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import de.mrjulsen.mcdragonlib.mixin.common.ServerGamePacketListenerAccessor;
import de.mrjulsen.mcdragonlib.network.v2.internal.ClientNetworkHooks;
import net.minecraft.class_243;
import net.minecraft.class_2535;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;

/**
 * Where a packet is sent.
 *
 * <p>A target resolves to one or more connections at the moment it is used, so a target created
 * ahead of time still works after a reconnect. Exchanges that expect a response need a target
 * that resolves to exactly one connection.
 */
public interface PacketTarget {

    /**
     * Returns the direction packets sent to this target travel in.
     *
     * @return the flow of this target
     */
    NetworkFlow getFlow();

    /**
     * Resolves the connections this target currently covers.
     *
     * @return the connections to send to, possibly empty
     */
    Collection<class_2535> getConnections();

    /**
     * Resolves this target to the single connection an exchange needs.
     *
     * @return the only connection this target covers
     * @throws IllegalStateException if the target covers no or more than one connection
     */
    default class_2535 requireSingleConnection() {
        Collection<class_2535> connections = getConnections();
        if (connections.size() != 1) {
            throw new IllegalStateException("This packet expects a response and therefore needs exactly one recipient, but the target resolved to " + connections.size() + ".");
        }
        return connections.iterator().next();
    }

    /**
     * Targets the server the client is currently connected to.
     *
     * @return a target for the current server connection
     */
    static PacketTarget server() {
        return new PacketTarget() {
            @Override
            public NetworkFlow getFlow() {
                return NetworkFlow.SERVERBOUND;
            }

            @Override
            public Collection<class_2535> getConnections() {
                class_2535 connection = ClientNetworkHooks.getServerConnection();
                return connection == null ? List.of() : List.of(connection);
            }
        };
    }

    /**
     * Targets a single player.
     *
     * @param player the recipient
     * @return a target for that player
     */
    static PacketTarget player(class_3222 player) {
        Objects.requireNonNull(player, "player");
        return new PacketTarget() {
            @Override
            public NetworkFlow getFlow() {
                return NetworkFlow.CLIENTBOUND;
            }

            @Override
            public Collection<class_2535> getConnections() {
                class_2535 connection = connectionOf(player);
                return connection == null ? List.of() : List.of(connection);
            }
        };
    }

    /**
     * Returns the connection a player is attached to.
     *
     * @param player the player to look up
     * @return the player's connection, or {@code null} if there is none
     */
    static class_2535 connectionOf(class_3222 player) {
        if (player.field_13987 == null) {
            return null;
        }
        return ((ServerGamePacketListenerAccessor) player.field_13987).dragonlib$getConnection();
    }

    /**
     * Targets a fixed group of players.
     *
     * @param players the recipients
     * @return a target for those players
     */
    static PacketTarget players(Collection<class_3222> players) {
        Objects.requireNonNull(players, "players");
        return of(NetworkFlow.CLIENTBOUND, () -> players);
    }

    /**
     * Targets every player currently on the server.
     *
     * @param server the server whose players to reach
     * @return a target for all online players
     */
    static PacketTarget all(MinecraftServer server) {
        Objects.requireNonNull(server, "server");
        return of(NetworkFlow.CLIENTBOUND, () -> server.method_3760().method_14571());
    }

    /**
     * Targets every player in one level.
     *
     * @param level the level whose players to reach
     * @return a target for the players of that level
     */
    static PacketTarget level(class_3218 level) {
        Objects.requireNonNull(level, "level");
        return of(NetworkFlow.CLIENTBOUND, level::method_18456);
    }

    /**
     * Targets every player within a radius of a position.
     *
     * @param level the level to search in
     * @param center the position to measure from
     * @param radius the maximum distance in blocks
     * @return a target for the players in range
     */
    static PacketTarget near(class_3218 level, class_243 center, double radius) {
        Objects.requireNonNull(level, "level");
        Objects.requireNonNull(center, "center");
        double radiusSqr = radius * radius;
        return of(NetworkFlow.CLIENTBOUND, () -> level.method_18456().stream()
            .filter(player -> player.method_19538().method_1025(center) <= radiusSqr)
            .collect(Collectors.toList()));
    }

    /**
     * Targets one connection directly, which is mainly useful for replying to a received packet.
     *
     * @param connection the connection to send over
     * @param flow the direction packets take on that connection
     * @return a target for that connection
     */
    static PacketTarget connection(class_2535 connection, NetworkFlow flow) {
        Objects.requireNonNull(connection, "connection");
        Objects.requireNonNull(flow, "flow");
        return new PacketTarget() {
            @Override
            public NetworkFlow getFlow() {
                return flow;
            }

            @Override
            public Collection<class_2535> getConnections() {
                return connection.method_10758() ? List.of(connection) : List.of();
            }
        };
    }

    private static PacketTarget of(NetworkFlow flow, java.util.function.Supplier<Collection<class_3222>> players) {
        return new PacketTarget() {
            @Override
            public NetworkFlow getFlow() {
                return flow;
            }

            @Override
            public Collection<class_2535> getConnections() {
                return players.get().stream()
                    .map(PacketTarget::connectionOf)
                    .filter(connection -> connection != null && connection.method_10758())
                    .collect(Collectors.toList());
            }
        };
    }
}
