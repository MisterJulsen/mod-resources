/*
 * DragonLib 3 - 1.20.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.client.gui.v2.text.markup;

import java.util.Optional;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_5250;
import net.minecraft.class_5251;
import net.minecraft.class_5348;
import de.mrjulsen.mcdragonlib.client.gui.v2.text.document.TextDocument;
import de.mrjulsen.mcdragonlib.client.gui.v2.text.style.StyleFlag;
import de.mrjulsen.mcdragonlib.client.gui.v2.text.style.TextStyle;

public final class ComponentText {

    private ComponentText() {
    }

    public static String fromComponent(class_5348 text) {
        return fromComponent(text, ComponentTextParser.SECTION);
    }

    public static String fromComponent(class_5348 text, ComponentTextParser parser) {
        StringBuilder builder = new StringBuilder();
        class_2583[] previous = { null };

        text.method_27658((style, content) -> {
            if (!style.equals(previous[0])) {
                appendStyle(builder, style, parser, previous[0] == null);
                previous[0] = style;
            }
            builder.append(content);
            return Optional.empty();
        }, class_2583.field_24360);

        return builder.toString();
    }

    public static class_5250 toComponent(String text) {
        return toComponent(text, ComponentTextParser.SECTION);
    }

    public static class_5250 toComponent(String text, ComponentTextParser parser) {
        class_5250 root = class_2561.method_43473();
        String[] lines = TextDocument.normalizeLineEndings(text).split("\n", -1);

        for (int line = 0; line < lines.length; line++) {
            if (line > 0) {
                root.method_10852(class_2561.method_43470("\n"));
            }
            appendLine(root, lines[line], parser);
        }
        return root;
    }

    private static void appendLine(class_5250 root, String line, ComponentTextParser parser) {
        parser.scan(line, (from, to, style, code) -> {
            if (code || from >= to) {
                return;
            }
            root.method_10852(class_2561.method_43470(line.substring(from, to)).method_10862(toVanillaStyle(style)));
        });
    }

    public static class_2583 toVanillaStyle(TextStyle style) {
        class_2583 vanilla = class_2583.field_24360;
        if (style.color() != TextStyle.DEFAULT.color()) {
            vanilla = vanilla.method_27703(class_5251.method_27717(style.color() & 0xFFFFFF));
        }
        return style.applyTo(vanilla);
    }

    private static void appendStyle(StringBuilder builder, class_2583 style, ComponentTextParser parser, boolean first) {
        if (!first) {
            builder.append(parser.code(class_124.field_1070.method_36145()));
        }

        class_5251 color = style.method_10973();
        if (color != null) {
            builder.append(parser.colorCode(color.method_27716()));
        }
        for (StyleFlag flag : StyleFlag.all()) {
            class_124 formatting = flag.effect().formatting();
            if (formatting != null && flag.effect().matchesVanilla(style)) {
                builder.append(parser.code(formatting.method_36145()));
            }
        }
    }

    public static boolean isPlain(class_2583 style) {
        if (style.method_10973() != null) {
            return false;
        }
        for (StyleFlag flag : StyleFlag.all()) {
            if (flag.effect().matchesVanilla(style)) {
                return false;
            }
        }
        return true;
    }
}
