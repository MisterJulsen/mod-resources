/*
 * DragonLib 3 - 1.20.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.internal;

import de.mrjulsen.mcdragonlib.client.gui.v2.window.DLHudManager;
import de.mrjulsen.mcdragonlib.client.gui.v2.window.DLScreen;
import de.mrjulsen.mcdragonlib.client.gui.v2.window.DLWindow;
import de.mrjulsen.mcdragonlib.menu.PlayerInventoryContainerMenu;
import de.mrjulsen.mcdragonlib.util.TextUtils;
import dev.architectury.platform.Platform;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1814;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2464;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3908;
import net.minecraft.class_3914;
import net.minecraft.class_3965;
import net.minecraft.class_4970;
import net.minecraft.class_747;

public class DragonLibBlock extends class_2237 {

    public DragonLibBlock(class_4970.class_2251 properties) {
        super(properties);
    }

    public static class DragonLibItem extends class_1747 {
        public DragonLibItem(class_2248 pBlock, class_1793 pProperties) {
            super(pBlock, pProperties.method_7894(class_1814.field_8904));            
        }
    }

    @Override
    public class_2586 method_10123(class_2338 arg0, class_2680 arg1) {
        return new DragonLibBlockEntity(arg0, arg1);
    }

    @Override
    public class_2464 method_9604(class_2680 pState) {
        return class_2464.field_11458;
    }

    public class_1269 method_9534(class_2680 pState, class_1937 pLevel, class_2338 pPos, class_1657 pPlayer, class_1268 pHand, class_3965 pHit) {
        if (!Platform.isDevelopmentEnvironment()) {
            return class_1269.field_5811;
        }

        if (pLevel.field_9236) {
            if (pPlayer.method_5715()) {
                DLScreen.open(mgr -> new TestGui());
            } else {
                //DLOverlayManager.addOverlay(mgr -> new TimeWindow(mgr));
                //DLWindow.openWindow(mgr -> new DLTestWindow(mgr));
            }
            return class_1269.field_5812;
        } else {
            //pPlayer.openMenu(pState.getMenuProvider(pLevel, pPos));
            return class_1269.field_21466;
        }
    }

    public class_3908 method_17454(class_2680 pState, class_1937 pLevel, class_2338 pPos) {
        return new class_747((containerId, inv, player) -> {
            return new PlayerInventoryContainerMenu.Base(containerId, inv, class_3914.method_17392(pLevel, pPos));
        }, TextUtils.text(""));
    }
    
}