/*
 * DragonLib 3 - 1.20.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.network.v2;

import org.jetbrains.annotations.Nullable;

import dev.architectury.utils.Env;
import net.minecraft.class_1657;
import net.minecraft.class_2535;
import net.minecraft.class_3222;

/**
 * What a handler knows about the packet it is handling.
 *
 * <p>Handlers run wherever their {@link ExecutionMode} puts them, so the context is the only
 * reliable way back to the game thread and to the peer the packet came from.
 */
public interface PacketContext {

    /**
     * Returns the side this handler is running on.
     *
     * @return the local environment
     */
    Env getEnvironment();

    /**
     * Returns the direction the received message travelled in.
     *
     * @return the flow the message arrived with
     */
    NetworkFlow getFlow();

    /**
     * Returns the connection the message arrived on.
     *
     * @return the originating connection
     */
    class_2535 getConnection();

    /**
     * Returns the player on the other end.
     *
     * @return the sending player on the server, the local player on the client, or {@code null}
     *         if there is none
     */
    @Nullable
    class_1657 getPlayer();

    /**
     * Returns the player that sent the message when running on the server.
     *
     * @return the sender, or {@code null} when running on the client
     */
    @Nullable
    default class_3222 getSender() {
        class_1657 player = getPlayer();
        return player instanceof class_3222 serverPlayer ? serverPlayer : null;
    }

    /**
     * Runs a task on the game thread.
     *
     * @param task the work to perform
     */
    void queue(Runnable task);

    /**
     * Returns whether the connection this message came from is still usable.
     *
     * @return {@code true} while the peer is still connected
     */
    default boolean isConnected() {
        return getConnection().method_10758();
    }

    /**
     * Returns a target pointing back at the sender of this message.
     *
     * @return a target for the originating connection
     */
    default PacketTarget reply() {
        return PacketTarget.connection(getConnection(), getFlow().opposite());
    }
}
