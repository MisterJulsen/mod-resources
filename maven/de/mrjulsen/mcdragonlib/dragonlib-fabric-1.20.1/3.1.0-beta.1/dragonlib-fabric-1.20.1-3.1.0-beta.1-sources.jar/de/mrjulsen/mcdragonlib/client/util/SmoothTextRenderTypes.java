/*
 * DragonLib 3 - 1.20.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.client.util;

import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Optional;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_4668;
import net.minecraft.class_5944;
import org.jetbrains.annotations.ApiStatus;

import de.mrjulsen.mcdragonlib.DragonLib;
import de.mrjulsen.mcdragonlib.client.compat.shader.ShaderCompat;
import de.mrjulsen.mcdragonlib.config.ModClientConfig;

@ApiStatus.Experimental
public final class SmoothTextRenderTypes {

    public static final class_2960 SHADER_ID = new class_2960(DragonLib.MODID, "rendertype_smooth_text");
    public static final class_2960 INTENSITY_SHADER_ID = new class_2960(DragonLib.MODID, "rendertype_smooth_text_intensity");

    private static final Map<class_1921, class_1921> TYPES = new IdentityHashMap<>();
    private static class_5944 shader;
    private static class_5944 intensityShader;
    private static final class_4668.class_5942 SHADER_STATE = new class_4668.class_5942(() -> shader);
    private static final class_4668.class_5942 INTENSITY_SHADER_STATE = new class_4668.class_5942(() -> intensityShader);

    private SmoothTextRenderTypes() {}

    @ApiStatus.Internal
    public static void setShader(class_5944 instance) {
        shader = instance;
    }

    @ApiStatus.Internal
    public static void setIntensityShader(class_5944 instance) {
        intensityShader = instance;
    }

    @ApiStatus.Internal
    public static void onShaderLoadFailed(class_2960 id, Throwable error) {
        shader = null;
        intensityShader = null;
        DragonLib.LOGGER.error("Unable to load the shader '" + id + "'. Smooth text rendering is disabled.", error);
    }

    public static boolean isEnabled() {
        if (shader == null || intensityShader == null) {
            return false;
        }
        return switch (ModClientConfig.getSmoothTextModeSafe()) {
            case ON -> true;
            case OFF -> false;
            default -> !ShaderCompat.isShaderPackActive();
        };
    }

    public static class_1921 getFor(class_1921 type) {
        return TYPES.computeIfAbsent(type, SmoothTextRenderTypes::createVariant);
    }

    private static class_1921 createVariant(class_1921 type) {
        if (!(type instanceof class_1921.class_4687 composite)) {
            return type;
        }
        class_1921.class_4688 state = composite.method_35784();
        class_4668.class_5942 shaderState;
        if (state.field_29461 == class_4668.field_29427) {
            shaderState = SHADER_STATE;
        } else if (state.field_29461 == class_4668.field_33628) {
            shaderState = INTENSITY_SHADER_STATE;
        } else {
            return type;
        }
        Optional<class_2960> texture = state.field_21406.method_23564();
        if (texture.isEmpty()) {
            return type;
        }
        return class_1921.method_24049("dragonlib_smooth_" + (shaderState == SHADER_STATE ? "text_" : "text_intensity_") + texture.get(), type.method_23031(), type.method_23033(), type.method_22722(), false, true,
            class_1921.class_4688.method_23598()
                .method_34578(shaderState)
                .method_34577(new class_4668.class_4683(texture.get(), false, false))
                .method_23615(state.field_21407)
                .method_23604(state.field_21411)
                .method_23608(state.field_21413)
                .method_23607(state.field_21416)
                .method_23616(state.field_21419)
                .method_23617(false));
    }
}
