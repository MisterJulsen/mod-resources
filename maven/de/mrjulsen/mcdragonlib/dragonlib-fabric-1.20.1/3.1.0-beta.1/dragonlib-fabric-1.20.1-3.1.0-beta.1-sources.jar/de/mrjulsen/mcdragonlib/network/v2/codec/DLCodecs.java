/*
 * DragonLib 3 - 1.20.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.network.v2.codec;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.function.IntFunction;
import java.util.function.Supplier;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_4208;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import com.mojang.serialization.Codec;

import de.mrjulsen.mcdragonlib.data.INBTSerializable;

/**
 * Ready-made {@link DLStreamCodec} instances for common value types, plus bridges to the
 * serialization mechanisms Minecraft and DragonLib already use.
 */
public final class DLCodecs {

    private static final String WRAPPED_VALUE_KEY = "Value";

    private DLCodecs() {}

    /** Codec for a single boolean. */
    public static final DLStreamCodec<Boolean> BOOL = DLStreamCodec.of((buf, value) -> buf.writeBoolean(value), buf -> buf.readBoolean());
    /** Codec for a single byte. */
    public static final DLStreamCodec<Byte> BYTE = DLStreamCodec.of((buf, value) -> buf.writeByte(value), buf -> buf.readByte());
    /** Codec for a single short. */
    public static final DLStreamCodec<Short> SHORT = DLStreamCodec.of((buf, value) -> buf.writeShort(value), buf -> buf.readShort());
    /** Codec for a fixed-width integer. */
    public static final DLStreamCodec<Integer> INT = DLStreamCodec.of((buf, value) -> buf.writeInt(value), buf -> buf.readInt());
    /** Codec for a variable-length integer, which is shorter for small values. */
    public static final DLStreamCodec<Integer> VAR_INT = DLStreamCodec.of((buf, value) -> buf.method_10804(value), buf -> buf.method_10816());
    /** Codec for a fixed-width long. */
    public static final DLStreamCodec<Long> LONG = DLStreamCodec.of((buf, value) -> buf.writeLong(value), buf -> buf.readLong());
    /** Codec for a variable-length long, which is shorter for small values. */
    public static final DLStreamCodec<Long> VAR_LONG = DLStreamCodec.of((buf, value) -> buf.method_10791(value), buf -> buf.method_10792());
    /** Codec for a single float. */
    public static final DLStreamCodec<Float> FLOAT = DLStreamCodec.of((buf, value) -> buf.writeFloat(value), buf -> buf.readFloat());
    /** Codec for a single double. */
    public static final DLStreamCodec<Double> DOUBLE = DLStreamCodec.of((buf, value) -> buf.writeDouble(value), buf -> buf.readDouble());
    /** Codec for a string of up to 32767 characters. */
    public static final DLStreamCodec<String> STRING = string(32767);
    /** Codec for a raw byte array. */
    public static final DLStreamCodec<byte[]> BYTE_ARRAY = DLStreamCodec.of((buf, value) -> buf.method_10813(value), buf -> buf.method_10795());
    /** Codec for a UUID. */
    public static final DLStreamCodec<UUID> UUID_CODEC = DLStreamCodec.of((buf, value) -> buf.method_10797(value), buf -> buf.method_10790());
    /** Codec for a resource location. */
    public static final DLStreamCodec<class_2960> RESOURCE_LOCATION = DLStreamCodec.of((buf, value) -> buf.method_10812(value), buf -> buf.method_10810());
    /** Codec for a compound tag of unrestricted size. */
    public static final DLStreamCodec<class_2487> NBT = DLStreamCodec.of((buf, value) -> buf.method_10794(value), buf -> buf.method_30617());
    /** Codec for an item stack. */
    public static final DLStreamCodec<class_1799> ITEM_STACK = DLStreamCodec.of((buf, value) -> buf.method_10793(value), buf -> buf.method_10819());
    /** Codec for a block position. */
    public static final DLStreamCodec<class_2338> BLOCK_POS = DLStreamCodec.of((buf, value) -> buf.method_10807(value), buf -> buf.method_10811());
    /** Codec for a dimension key. */
    public static final DLStreamCodec<class_5321<class_1937>> DIMENSION = DLStreamCodec.of(
        (buf, value) -> buf.method_10812(value.method_29177()),
        buf -> class_5321.method_29179(class_7924.field_41223, buf.method_10810())
    );
    /** Codec for a position including its dimension. */
    public static final DLStreamCodec<class_4208> GLOBAL_POS = DLStreamCodec.of(
        (buf, value) -> {
            buf.method_10812(value.method_19442().method_29177());
            buf.method_10807(value.method_19446());
        },
        buf -> class_4208.method_19443(class_5321.method_29179(class_7924.field_41223, buf.method_10810()), buf.method_10811())
    );
    /** Codec for a text component. */
    public static final DLStreamCodec<class_2561> COMPONENT = DLStreamCodec.of((buf, value) -> buf.method_10805(value), buf -> buf.method_10808());
    /** Codec for a three-dimensional vector. */
    public static final DLStreamCodec<class_243> VEC3 = DLStreamCodec.of(
        (buf, value) -> {
            buf.writeDouble(value.field_1352);
            buf.writeDouble(value.field_1351);
            buf.writeDouble(value.field_1350);
        },
        buf -> new class_243(buf.readDouble(), buf.readDouble(), buf.readDouble())
    );

    /**
     * Creates a codec for a string with a decoding length limit.
     *
     * @param maxLength the highest accepted character count
     * @return a codec for a bounded string
     */
    public static DLStreamCodec<String> string(int maxLength) {
        return DLStreamCodec.of((buf, value) -> buf.method_10788(value, maxLength), buf -> buf.method_10800(maxLength));
    }

    /**
     * Creates a codec for a byte array with a decoding length limit.
     *
     * @param maxLength the highest accepted byte count
     * @return a codec for a bounded byte array
     */
    public static DLStreamCodec<byte[]> byteArray(int maxLength) {
        return DLStreamCodec.of((buf, value) -> buf.method_10813(value), buf -> buf.method_10803(maxLength));
    }

    /**
     * Creates a codec writing an enum constant by ordinal.
     *
     * <p>This is the compact option but it ties the wire format to the declaration order: inserting
     * a constant anywhere but at the end silently shifts every constant after it. Prefer
     * {@link #enumByName(Class)} unless the enum is fixed or the size really matters.
     *
     * @param type the enum class
     * @param <E> the enum type
     * @return a codec writing the position of the constant
     */
    public static <E extends Enum<E>> DLStreamCodec<E> enumByOrdinal(Class<E> type) {
        Objects.requireNonNull(type, "type");
        E[] constants = type.getEnumConstants();
        return DLStreamCodec.of(
            (buf, value) -> buf.method_10804(value.ordinal()),
            buf -> {
                int ordinal = buf.method_10816();
                if (ordinal < 0 || ordinal >= constants.length) {
                    throw new IllegalStateException("Unknown ordinal " + ordinal + " for enum " + type.getSimpleName() + ".");
                }
                return constants[ordinal];
            }
        );
    }

    /**
     * Creates a codec writing an enum constant by name, which survives reordering and insertion of
     * constants.
     *
     * @param type the enum class
     * @param <E> the enum type
     * @return a codec writing the name of the constant
     */
    public static <E extends Enum<E>> DLStreamCodec<E> enumByName(Class<E> type) {
        Objects.requireNonNull(type, "type");
        return DLStreamCodec.of(
            (buf, value) -> buf.method_10814(value.name()),
            buf -> Enum.valueOf(type, buf.method_19772())
        );
    }

    /**
     * Creates a codec for a set of enum constants.
     *
     * @param type the enum class
     * @param elementCodec how a single constant is written, normally {@link #enumByName(Class)} or
     *        {@link #enumByOrdinal(Class)}
     * @param <E> the enum type
     * @return a codec for an enum set
     */
    public static <E extends Enum<E>> DLStreamCodec<EnumSet<E>> enumSet(Class<E> type, DLStreamCodec<E> elementCodec) {
        Objects.requireNonNull(type, "type");
        return elementCodec.collection(size -> EnumSet.noneOf(type));
    }

    /**
     * Creates a codec for a map, preserving iteration order on the receiving side.
     *
     * @param keyCodec codec for the keys
     * @param valueCodec codec for the values
     * @param <K> the key type
     * @param <V> the value type
     * @return a codec for an unbounded map
     */
    public static <K, V> DLStreamCodec<Map<K, V>> map(DLStreamCodec<K> keyCodec, DLStreamCodec<V> valueCodec) {
        return map(keyCodec, valueCodec, size -> new LinkedHashMap<>(), Integer.MAX_VALUE);
    }

    /**
     * Creates a codec for a map with a decoding size limit.
     *
     * @param keyCodec codec for the keys
     * @param valueCodec codec for the values
     * @param factory creates the target map for a known entry count
     * @param maxSize the highest accepted entry count
     * @param <K> the key type
     * @param <V> the value type
     * @param <M> the map type
     * @return a codec for a bounded map
     */
    public static <K, V, M extends Map<K, V>> DLStreamCodec<M> map(DLStreamCodec<K> keyCodec, DLStreamCodec<V> valueCodec, IntFunction<M> factory, int maxSize) {
        Objects.requireNonNull(keyCodec, "keyCodec");
        Objects.requireNonNull(valueCodec, "valueCodec");
        Objects.requireNonNull(factory, "factory");
        return DLStreamCodec.of(
            (buf, value) -> {
                buf.method_10804(value.size());
                for (Map.Entry<K, V> entry : value.entrySet()) {
                    keyCodec.encode(buf, entry.getKey());
                    valueCodec.encode(buf, entry.getValue());
                }
            },
            buf -> {
                int size = buf.method_10816();
                if (size < 0 || size > maxSize) {
                    throw new IllegalStateException("Map size " + size + " exceeds the allowed maximum of " + maxSize + ".");
                }
                M values = factory.apply(size);
                for (int i = 0; i < size; i++) {
                    values.put(keyCodec.decode(buf), valueCodec.decode(buf));
                }
                return values;
            }
        );
    }

    /**
     * Creates a map codec backed by a plain hash map.
     *
     * @param keyCodec codec for the keys
     * @param valueCodec codec for the values
     * @param <K> the key type
     * @param <V> the value type
     * @return a codec for an unordered map
     */
    public static <K, V> DLStreamCodec<Map<K, V>> hashMap(DLStreamCodec<K> keyCodec, DLStreamCodec<V> valueCodec) {
        return map(keyCodec, valueCodec, size -> new HashMap<>(), Integer.MAX_VALUE);
    }

    /**
     * Adapts an existing data-fixer codec by routing it through NBT.
     *
     * <p>This builds an intermediate tag per value, so it is a convenience for types that already
     * have a {@code Codec} rather than the preferred choice for large or frequent payloads.
     *
     * @param codec the codec to adapt
     * @param <T> the value type
     * @return a stream codec delegating to the given codec
     */
    public static <T> DLStreamCodec<T> fromCodec(Codec<T> codec) {
        Objects.requireNonNull(codec, "codec");
        return DLStreamCodec.of(
            (buf, value) -> {
                class_2520 tag = codec.encodeStart(class_2509.field_11560, value)
                    .getOrThrow(false, error -> { throw new IllegalStateException("Could not encode value: " + error); });
                class_2487 wrapper = new class_2487();
                wrapper.method_10566(WRAPPED_VALUE_KEY, tag);
                buf.method_10794(wrapper);
            },
            buf -> {
                class_2487 wrapper = buf.method_30617();
                if (wrapper == null) {
                    throw new IllegalStateException("Missing payload for codec-backed value.");
                }
                return codec.parse(class_2509.field_11560, wrapper.method_10580(WRAPPED_VALUE_KEY))
                    .getOrThrow(false, error -> { throw new IllegalStateException("Could not decode value: " + error); });
            }
        );
    }

    /**
     * Adapts a type that serializes itself to a compound tag.
     *
     * @param factory creates a blank instance before deserialization
     * @param <T> the value type
     * @return a stream codec delegating to the type's own NBT methods
     */
    public static <T extends INBTSerializable> DLStreamCodec<T> fromNbtSerializable(Supplier<T> factory) {
        Objects.requireNonNull(factory, "factory");
        return DLStreamCodec.of(
            (buf, value) -> buf.method_10794(value.serializeNbt()),
            buf -> {
                T value = Objects.requireNonNull(factory.get(), "factory returned null");
                class_2487 nbt = buf.method_30617();
                value.deserializeNbt(nbt == null ? new class_2487() : nbt);
                return value;
            }
        );
    }
}
