/*
 * DragonLib 3 - 1.20.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.mixin;

import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_377;
import net.minecraft.class_382;
import net.minecraft.class_4588;
import net.minecraft.class_5225;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

/**
 * Kept for compatibility with mods built against older DragonLib versions.
 * @deprecated Use {@link de.mrjulsen.mcdragonlib.mixin.client.FontAccessor} instead.
 */
@Deprecated(forRemoval = true)
@Mixin(class_327.class)
public interface FontAccessor {

    @Invoker("getFontSet")
    public class_377 dragonlib$invokeGetFontSet(class_2960 pFontLocation);

    @Accessor("splitter")
    class_5225 dragonlib$getSplitter();

    @Accessor("filterFishyGlyphs")
    boolean dragonlib$filterFishyGlyphs();

    @Invoker("renderChar")
    void dragonlib$renderChar(class_382 glyph, boolean bold, boolean italic, float boldOffset, float x, float y, Matrix4f matrix, class_4588 buffer, float red, float green, float blue, float alpha, int packedLight);
}
