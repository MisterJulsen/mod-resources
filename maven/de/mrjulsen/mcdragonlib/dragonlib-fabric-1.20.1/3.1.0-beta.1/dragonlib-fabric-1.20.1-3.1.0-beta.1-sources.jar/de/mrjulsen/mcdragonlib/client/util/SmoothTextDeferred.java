/*
 * DragonLib 3 - 1.20.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.client.util;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import net.minecraft.class_1921;
import net.minecraft.class_1937;
import net.minecraft.class_287;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import org.jetbrains.annotations.ApiStatus;
import org.joml.Matrix4f;

import com.mojang.blaze3d.systems.RenderSystem;
import de.mrjulsen.mcdragonlib.DragonLib;
import de.mrjulsen.mcdragonlib.client.ber.BERGraphics;

@ApiStatus.Internal
public final class SmoothTextDeferred {

    private static final DeferredSource SOURCE = new DeferredSource();
    private static Matrix4f modelViewMatrix;
    private static boolean renderingLevel = false;
    private static boolean deferralLogged = false;

    private SmoothTextDeferred() {}

    public static boolean shouldDefer(DLGraphics graphics) {
        if (!renderingLevel || !(graphics instanceof BERGraphics<?> berGraphics) || berGraphics.blockEntity() == null) {
            return false;
        }
        class_1937 level = berGraphics.blockEntity().method_10997();
        boolean defer = level != null && level != class_310.method_1551().field_1687;
        if (defer && !deferralLogged) {
            deferralLogged = true;
            DragonLib.LOGGER.info("Smooth text of block entities in {} is drawn late in the frame.", level.getClass().getName());
        }
        return defer;
    }

    public static class_4597 source() {
        if (modelViewMatrix == null) {
            modelViewMatrix = new Matrix4f(RenderSystem.getModelViewMatrix());
        }
        return SOURCE;
    }

    public static void draw() {
        if (SOURCE.isEmpty()) {
            modelViewMatrix = null;
            return;
        }
        class_4587 modelViewStack = RenderSystem.getModelViewStack();
        modelViewStack.method_22903();
        if (modelViewMatrix != null) {
            modelViewStack.method_23760().method_23761().set(modelViewMatrix);
        }
        RenderSystem.applyModelViewMatrix();
        try {
            SOURCE.draw();
        } finally {
            modelViewStack.method_22909();
            RenderSystem.applyModelViewMatrix();
            modelViewMatrix = null;
        }
    }

    public static void beginLevelRendering() {
        SOURCE.discard();
        modelViewMatrix = null;
        renderingLevel = true;
    }

    public static void endLevelRendering() {
        renderingLevel = false;
        SOURCE.discard();
        modelViewMatrix = null;
    }

    private static final class DeferredSource implements class_4597 {

        private final Map<class_1921, class_287> builders = new LinkedHashMap<>();
        private final Set<class_1921> started = new LinkedHashSet<>();

        @Override
        public class_4588 getBuffer(class_1921 type) {
            class_287 builder = builders.computeIfAbsent(type, t -> new class_287(t.method_22722()));
            if (started.add(type)) {
                builder.method_1328(type.method_23033(), type.method_23031());
            }
            return builder;
        }

        boolean isEmpty() {
            return started.isEmpty();
        }

        void draw() {
            for (class_1921 type : started) {
                type.method_23012(builders.get(type), RenderSystem.getVertexSorting());
            }
            started.clear();
        }

        void discard() {
            for (class_1921 type : started) {
                class_287 builder = builders.get(type);
                if (builder.method_22893()) {
                    builder.method_1326().method_43585();
                }
            }
            started.clear();
        }
    }
}
