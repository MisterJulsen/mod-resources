/*
 * DragonLib 3 - 1.20.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.client.model;

import java.util.LinkedList;
import java.util.List;
import net.minecraft.class_1091;
import net.minecraft.class_2769;
import net.minecraft.class_2960;

public abstract class ModelResourceLocationBuilder {

    private final class_2960 location;

    public ModelResourceLocationBuilder(class_2960 location) {
        this.location = location;
    }

    public class_2960 getLocation() {
        return location;
    }

    public abstract class_1091 build();


    public static class Base extends ModelResourceLocationBuilder {

        public Base(class_2960 location) {
            super(location);
        }

        @Override
        public class_1091 build() {
            return new class_1091(getLocation(), "");
        }
    }

    public static class BlockState extends ModelResourceLocationBuilder {

        private final List<String> properties = new LinkedList<>();

        public BlockState(class_2960 location) {
            super(location);
        }

        public <T extends Comparable<T>> BlockState with(class_2769<T> property, T value) {
            this.properties.add(property.method_11899() + "=" + property.method_11901(value));
            return this;
        }

        @Override
        public class_1091 build() {
            return new class_1091(getLocation(), String.join(",", this.properties));
        }
    }

    public static class Inventory extends ModelResourceLocationBuilder {

        public Inventory(class_2960 location) {
            super(location);
        }

        @Override
        public class_1091 build() {
            return new class_1091(getLocation(), "inventory");
        }
    }
}
