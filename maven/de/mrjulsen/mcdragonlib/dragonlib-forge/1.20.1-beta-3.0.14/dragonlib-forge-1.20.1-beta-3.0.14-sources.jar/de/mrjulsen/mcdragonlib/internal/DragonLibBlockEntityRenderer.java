package de.mrjulsen.mcdragonlib.internal;

import org.joml.Vector3f;

import de.mrjulsen.mcdragonlib.client.ber.BERGraphics;
import de.mrjulsen.mcdragonlib.client.ber.BERLabel;
import de.mrjulsen.mcdragonlib.client.ber.BasicBlockEntityRenderer;
import de.mrjulsen.mcdragonlib.client.ber.BERLabel.EScrollMode;
import de.mrjulsen.mcdragonlib.client.model.mesh.BasicMesh;
import de.mrjulsen.mcdragonlib.client.model.mesh.Mesh;
import de.mrjulsen.mcdragonlib.client.util.DLTexture;
import de.mrjulsen.mcdragonlib.client.util.RenderUtils;
import de.mrjulsen.mcdragonlib.data.ETextAlignment;
import de.mrjulsen.mcdragonlib.util.DLColor;
import de.mrjulsen.mcdragonlib.util.DLUtils;
import de.mrjulsen.mcdragonlib.util.TextUtils;
import net.minecraft.ChatFormatting;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider.Context;
import net.minecraft.core.Direction;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Blocks;

public class DragonLibBlockEntityRenderer extends BasicBlockEntityRenderer<DragonLibBlockEntity> {
    private final BERLabel label = new BERLabel();
    private final Mesh model;

    public DragonLibBlockEntityRenderer(Context context) {
        super(context);
        label.text.set(TextUtils.text("DragonLib ").m_130940_(ChatFormatting.GOLD).m_7220_(TextUtils.text("🐉").m_130940_(ChatFormatting.RED)));
        label.y.set(11f);
        label.fullBackground.set(false);
        label.horizontalScrollingSpeed.set(8f);
        label.horizontalAlign.set(ETextAlignment.LEFT);
        label.horizontalMaxScale.set(0.5f);
        label.horizontalMinScale.set(0.5f);
        label.verticalMaxScale.set(0.5f);
        label.verticalMinScale.set(0.5f);
        label.horizontalScrollMode.set(EScrollMode.ALWAYS);

        model = BasicMesh.fromBlock(Blocks.f_50528_.m_49966_(), RandomSource.m_216327_());
    }


    @Override
    protected void renderBlock(BERGraphics<DragonLibBlockEntity> graphics, float partialTick) {
        graphics.poseStack().m_85836_();
        graphics.poseStack().m_252880_(0, 0, 16.01f);
        model.render(graphics, graphics.packedLight(), true);
        RenderUtils.drawString(graphics, font, 0, 0, "Salz", DLColor.WHITE, ETextAlignment.LEFT, false);
        RenderUtils.renderTexture(DLUtils.resourceLocation("textures/block/crafting_table_front.png"), graphics, new Vector3f(), 1, 1, Direction.EAST,true);
        label.render(graphics);
        graphics.poseStack().m_85849_();
    }
}
