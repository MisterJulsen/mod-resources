package de.mrjulsen.mcdragonlib.client.util;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.MultiBufferSource.BufferSource;
import net.minecraft.resources.ResourceLocation;

public record DLGuiGraphics(GuiGraphics graphics, PoseStack poseStack, Font defaultFont, float partialTick) {

    public BufferSource bufferSource() {
        return  graphics().m_280091_();
    }

    public VertexConsumer vertexConsumer(ResourceLocation textureLocation) {
        return graphics().m_280091_().m_6299_(RenderType.m_110497_(textureLocation));
    }

    public VertexConsumer vertexConsumer() {
        return graphics().m_280091_().m_6299_(RenderType.m_110497_(RenderUtils.BLANK_TEXTURE_LOCATION));
    }
}
