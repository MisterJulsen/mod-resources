package de.mrjulsen.mcdragonlib.commands;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import de.mrjulsen.mcdragonlib.DragonLib;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.Commands.CommandSelection;

public class DebugCommand {

    private static final String CMD_NAME = DragonLib.MODID;
    
    private static final String SUB_DEBUG = "debug";
    private static final String SUB_NETWORK = "network";
    
    @SuppressWarnings("all")
    public static void register(CommandDispatcher<CommandSourceStack> dispatcher, CommandSelection selection) {        
        
        LiteralArgumentBuilder<CommandSourceStack> builder = Commands.m_82127_(CMD_NAME)
            .then(Commands.m_82127_(SUB_DEBUG)
                .requires(x -> x.m_6761_(4))
                .then(Commands.m_82127_(SUB_NETWORK)
                )
            )
        ;

        dispatcher.register(builder);
    }
}