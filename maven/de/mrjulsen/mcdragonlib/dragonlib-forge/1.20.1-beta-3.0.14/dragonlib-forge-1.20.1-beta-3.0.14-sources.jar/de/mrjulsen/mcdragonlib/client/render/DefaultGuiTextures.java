package de.mrjulsen.mcdragonlib.client.render;

import java.io.IOException;
import java.util.function.Supplier;

import com.google.common.base.Suppliers;

import de.mrjulsen.mcdragonlib.DragonLib;
import de.mrjulsen.mcdragonlib.client.atlas.GLGuiTextureData;
import de.mrjulsen.mcdragonlib.client.atlas.GLGuiTextureData.AbstractSprite;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;

public class DefaultGuiTextures {

    public static final DefaultGuiTextures VANILLA_BUTTON = new DefaultGuiTextures(new ResourceLocation(DragonLib.MODID, "textures/gui/vanilla_buttons.png"));
    public static final DefaultGuiTextures DRAGONLIB_UI = new DefaultGuiTextures(new ResourceLocation(DragonLib.MODID, "textures/gui/ui2.png"));
    public static final DefaultGuiTextures VANILLA_TEXTBOX = new DefaultGuiTextures(new ResourceLocation(DragonLib.MODID, "textures/gui/vanilla_textbox.png"));
    public static final DefaultGuiTextures VANILLA_SCROLLBAR = new DefaultGuiTextures(new ResourceLocation(DragonLib.MODID, "textures/gui/vanilla_scrollbar.png"));

    public static final String SPRITE_NAME_WINDOW_ROUNDED = "window_rounded";
    
    private final ResourceLocation location;
    private final Supplier<GLGuiTextureData> metadata = Suppliers.memoize(() -> {
        return Minecraft.m_91087_().m_91098_().m_213713_(location())
            .map(r -> {
                try {
                    return r.m_215509_().m_214059_(GLGuiTextureData.SERIALIZER).map(t -> {
                        t.setTextureLocation(location());
                        return t;
                    }).orElse(GLGuiTextureData.EMPTY);
                } catch (IOException e) {
                    return GLGuiTextureData.EMPTY;
                }
            })
            .orElse(GLGuiTextureData.EMPTY);
    });

    public DefaultGuiTextures(ResourceLocation location) {
        this.location = location;
    }

    public ResourceLocation location() {
        return location;
    }

    public GLGuiTextureData metadata() {
        return metadata.get();
    }

    public AbstractSprite getSprite(String spriteName) {
        return metadata().getSprite(spriteName);
    } 
}
