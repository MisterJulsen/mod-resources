package de.mrjulsen.mcdragonlib.util.collision;

import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.VoxelShape;

import java.util.Optional;

import org.joml.Vector3f;
import net.minecraft.world.phys.Vec3;

public class VoxelShapeRayShape implements IRayTraceShape {
    private final VoxelShape shape;
    private final BlockPos pos;

    public VoxelShapeRayShape(VoxelShape shape, BlockPos pos) {
        this.shape = shape;
        this.pos = pos;
    }

    @Override
    public Optional<Vector3f> intersects(Vector3f rayOrigin, Vector3f rayDirection) {
        Vec3 start = new Vec3(rayOrigin.x(), rayOrigin.y(), rayOrigin.z());
        Vec3 end = start.m_82549_(new Vec3(rayDirection.x(), rayDirection.y(), rayDirection.z()).m_82490_(100)); // max ray length

        BlockHitResult result = shape.m_83220_(start, end, pos);
        if (result == null) {
            return Optional.empty();
        }
        return Optional.ofNullable(result.m_82450_().m_252839_());
    }
}

