package de.mrjulsen.mcdragonlib.client.ber;

import com.mojang.math.Axis;

import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.core.Direction;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

public abstract class RotatableBlockEntityRenderer<T extends BlockEntity> extends SafeBlockEntityRenderer<T> {
    
    protected final Font font;

    public RotatableBlockEntityRenderer(BlockEntityRendererProvider.Context context) {
        super(context);
        this.font = context.m_173586_();
    }

    @Override
    protected final void renderSafe(BERGraphics<T> graphics, float partialTick) {
        BlockState blockState = graphics.blockEntity().m_58900_();
        
        graphics.poseStack().m_85836_();
        graphics.poseStack().m_85837_(0.5D, 0, 0.5F);
        graphics.poseStack().m_252781_(Axis.f_252436_.m_252977_(
            blockState.m_61143_(HorizontalDirectionalBlock.f_54117_) == Direction.EAST || blockState.m_61143_(HorizontalDirectionalBlock.f_54117_) == Direction.WEST
                ? blockState.m_61143_(HorizontalDirectionalBlock.f_54117_).m_122424_().m_122435_()
                : blockState.m_61143_(HorizontalDirectionalBlock.f_54117_).m_122435_()
        ));
        graphics.poseStack().m_252880_(-0.5f, 1, -0.5f);
        graphics.poseStack().m_85841_(0.0625f, -0.0625f, 0.0625f);

        renderBlock(graphics, partialTick);

        graphics.poseStack().m_85849_();
        
    }

    protected abstract void renderBlock(BERGraphics<T> graphics, float partialTick);
}
