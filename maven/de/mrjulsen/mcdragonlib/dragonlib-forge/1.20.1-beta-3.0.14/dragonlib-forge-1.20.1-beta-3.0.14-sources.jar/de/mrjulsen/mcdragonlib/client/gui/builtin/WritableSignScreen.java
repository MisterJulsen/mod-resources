package de.mrjulsen.mcdragonlib.client.gui.builtin;

import java.util.Arrays;
import java.util.function.Function;
import java.util.stream.IntStream;

import org.joml.Vector3f;

import com.mojang.blaze3d.platform.Lighting;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;

import de.mrjulsen.mcdragonlib.DragonLib;
import de.mrjulsen.mcdragonlib.block.DLWritableSignBlockEntity;
import de.mrjulsen.mcdragonlib.network.NetworkDirection;
import de.mrjulsen.mcdragonlib.network.builtin.WritableSignPacketData;
import de.mrjulsen.mcdragonlib.util.TextUtils;
import de.mrjulsen.mcdragonlib.util.math.MathUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.font.TextFieldHelper;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.block.BlockRenderDispatcher;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec2;

public class WritableSignScreen extends Screen {

    public static final int DEFAULT_LINE_HEIGHT = 10;

    protected final DLWritableSignBlockEntity sign;
    protected final BlockState blockState;
    protected final WritableSignConfig config;
    protected final ConfiguredLine[] messages;
    protected final int lineCount;

    protected int blinkFrame;
    protected int selectedLine;
    protected TextFieldHelper signTextField;

    // Controls
    protected Button btnDone;

    public WritableSignScreen(DLWritableSignBlockEntity pSign) {
        this(pSign, pSign.getRenderConfig(), pSign.m_58900_().m_60734_().m_49966_(), getMessages(pSign, pSign.getRenderConfig()));
    }

    protected WritableSignScreen(DLWritableSignBlockEntity pSign, WritableSignConfig config, BlockState state, ConfiguredLine[] messages) {
        super(TextUtils.translate("sign.edit"));

        this.config = config;
        this.blockState = state;
        this.sign = pSign;
        
        this.messages = messages;
        this.lineCount = this.messages.length;

    }

    protected static ConfiguredLine[] getMessages(DLWritableSignBlockEntity pSign, WritableSignConfig config) {
        return IntStream.range(0, config.lineData.length).mapToObj((i) -> {
            return new ConfiguredLine(pSign.getText(i), config.lineData[i]);
        }).toArray((length) -> {
            return new ConfiguredLine[length];
        });
    }

    protected void m_7856_() {
        this.btnDone = Button.m_253074_(CommonComponents.f_130655_, (p_169820_) -> {
            this.onDone();
        }).m_252987_(this.f_96543_ / 2 - 100, this.f_96544_ / 4 + 120, 200, 20).m_253136_();

        this.signTextField = new TextFieldHelper(() -> {
            return this.messages[this.selectedLine].text;
        }, (text) -> {
            this.messages[this.selectedLine].text = text;
            this.sign.setText(text, selectedLine);
        }, TextFieldHelper.m_95153_(this.f_96541_), TextFieldHelper.m_95182_(this.f_96541_), (text) -> {
            return text == null || this.f_96541_.f_91062_.m_92895_(text) <= config.lineData[this.selectedLine].maxLineWidth() * config.scale();
        });
    }

    public void m_7861_() {
        DragonLib.UPDATE_SIGN_TEXT.send(NetworkDirection.toServer(), new WritableSignPacketData(this.sign.m_58899_(), Arrays.stream(messages).map(x -> x.text).toArray(String[]::new)));
    }

    public void m_86600_() {
        ++this.blinkFrame;
        if (!this.sign.m_58903_().m_155262_(this.sign.m_58900_())) {
            this.onDone();
        }

    }

    protected void onDone() {
        DragonLib.UPDATE_SIGN_TEXT.send(NetworkDirection.toServer(), new WritableSignPacketData(this.sign.m_58899_(), Arrays.stream(messages).map(x -> x.text).toArray(String[]::new)));
        this.f_96541_.m_91152_(null);
    }

    public boolean m_5534_(char pCodePoint, int pModifiers) {
        this.signTextField.m_95143_(pCodePoint);
        return true;
    }

    public void m_7379_() {
        this.onDone();
    }

    public boolean m_7933_(int pKeyCode, int pScanCode, int pModifiers) {
        if (pKeyCode == 265) {
            this.selectedLine = this.selectedLine - 1 & lineCount - 1;
            this.signTextField.m_95193_();
            return true;
        } else if (pKeyCode != 264 && pKeyCode != 257 && pKeyCode != 335) {
            return this.signTextField.m_95145_(pKeyCode) ? true : super.m_7933_(pKeyCode, pScanCode, pModifiers);
        } else {
            this.selectedLine = this.selectedLine + 1 & lineCount - 1;
            this.signTextField.m_95193_();
            return true;
        }
    }

    protected void renderSignBackground(GuiGraphics graphics) {
        MultiBufferSource.BufferSource bufferSource = this.f_96541_.m_91269_().m_110104_();
        PoseStack poseStack = graphics.m_280168_();
        graphics.m_280168_().m_252880_((float)this.f_96543_ / 2.0F + config.scale / 2 + config.xCenterOffset * config.scale, config.y + config.scale / 2, 100);
        poseStack.m_85841_(-config.scale, -config.scale, -1);
        poseStack.m_252781_(Axis.f_252436_.m_252977_(config.yRot()));

        BlockRenderDispatcher blockRenderer = Minecraft.m_91087_().m_91289_();
        blockRenderer.m_110912_(blockState, graphics.m_280168_(), bufferSource, 15728880, OverlayTexture.f_118083_);
    }

    private void renderSignText(GuiGraphics pGuiGraphics) {
        boolean flag = this.blinkFrame / 6 % 2 == 0;
        int cursorPos = this.signTextField.m_95194_();
        int selectionPos = this.signTextField.m_95197_();

        for (int line = 0; line < this.messages.length; ++line) {
            pGuiGraphics.m_280168_().m_85836_();
            ConfiguredLine configuredLine = this.messages[line];
            
            Vector3f vector3f = config.screenTextScale(f_96547_, config.scale(), configuredLine);
            pGuiGraphics.m_280168_().m_252880_((float)this.f_96543_ / 2.0F + configuredLine.data.xOffset() * config.scale(), config.y + configuredLine.data.yOffset() * config.scale - (int)(WritableSignScreen.DEFAULT_LINE_HEIGHT / 2 * config.lineData()[0].lineHeightScale()) + config.getLineHeightsUntil(line) + config.getLineOffset(line, vector3f.y), 105);
            pGuiGraphics.m_280168_().m_85841_(vector3f.x(), vector3f.y(), vector3f.z());

            if (configuredLine != null) {
                if (this.f_96547_.m_92718_()) {
                    configuredLine.text = this.f_96547_.m_92801_(configuredLine.text);
                }

                int xCenter = -this.f_96547_.m_92895_(configuredLine.text) / 2;
                pGuiGraphics.m_280056_(this.f_96547_, configuredLine.text, xCenter, 0, configuredLine.data.color(), false);
                if (line == this.selectedLine && cursorPos >= 0 && flag) {
                    int l1 = this.f_96547_.m_92895_(configuredLine.text.substring(0, Math.max(Math.min(cursorPos, configuredLine.text.length()), 0)));
                    int i2 = l1 - this.f_96547_.m_92895_(configuredLine.text) / 2;
                    if (cursorPos >= configuredLine.text.length()) {
                        pGuiGraphics.m_280056_(this.f_96547_, "_", i2, 0, configuredLine.data.color(), false);
                    }
                }
            }
            pGuiGraphics.m_280168_().m_85849_();
        }

        for (int lineHighlight = 0; lineHighlight < this.messages.length; ++lineHighlight) {
            ConfiguredLine configuredLineH = this.messages[lineHighlight];
            pGuiGraphics.m_280168_().m_85836_();
            Vector3f vector3f = config.screenTextScale(f_96547_, config.scale(), configuredLineH);
            pGuiGraphics.m_280168_().m_252880_((float)this.f_96543_ / 2.0F + configuredLineH.data.xOffset() * config.scale(), config.y + configuredLineH.data.yOffset() * config.scale - (int)(WritableSignScreen.DEFAULT_LINE_HEIGHT / 2 * config.lineData()[0].lineHeightScale()) + config.getLineHeightsUntil(lineHighlight + 1) - config.halfLineHeight(lineHighlight) + config.getHalfLineHeightScales(lineHighlight, vector3f.y), 105);
            pGuiGraphics.m_280168_().m_85841_(vector3f.x(), vector3f.y(), vector3f.z());

            float lineScale = config.lineData()[lineHighlight].lineHeightScale();

            if (configuredLineH != null && lineHighlight == this.selectedLine && cursorPos >= 0) {
                int l3 = this.f_96547_.m_92895_(configuredLineH.text.substring(0, Math.max(Math.min(cursorPos, configuredLineH.text.length()), 0)));
                int i4 = l3 - this.f_96547_.m_92895_(configuredLineH.text) / 2;
                if (flag && cursorPos < configuredLineH.text.length()) {
                    pGuiGraphics.m_280509_(i4, -(int)(DEFAULT_LINE_HEIGHT * (lineScale + 1) * 0.5F), i4 + 1, -(int)(DEFAULT_LINE_HEIGHT * (lineScale - 1) * 0.5F), -16777216 | configuredLineH.data.color());
                }

                if (selectionPos != cursorPos) {
                    int j4 = Math.min(cursorPos, selectionPos);
                    int j2 = Math.max(cursorPos, selectionPos);
                    int k2 = this.f_96547_.m_92895_(configuredLineH.text.substring(0, j4)) - this.f_96547_.m_92895_(configuredLineH.text) / 2;
                    int l2 = this.f_96547_.m_92895_(configuredLineH.text.substring(0, j2)) - this.f_96547_.m_92895_(configuredLineH.text) / 2;
                    int i3 = Math.min(k2, l2);
                    int j3 = Math.max(k2, l2);
                    pGuiGraphics.m_285944_(RenderType.m_285783_(), i3, -(int)(DEFAULT_LINE_HEIGHT * (lineScale + 1) * 0.5F), j3, -(int)(DEFAULT_LINE_HEIGHT * (lineScale - 1) * 0.5F), -16776961);
                }
            }
            pGuiGraphics.m_280168_().m_85849_();
        }

    }
    public void renderSign(GuiGraphics graphics) {
        graphics.m_280168_().m_166856_();
        graphics.m_280168_().m_85836_();
        graphics.m_280168_().m_85836_();
        this.renderSignBackground(graphics);
        graphics.m_280168_().m_85849_();
        this.renderSignText(graphics);
        graphics.m_280168_().m_85849_();
    }

    @Override
    public void m_88315_(GuiGraphics graphics, int pMouseX, int pMouseY, float pPartialTick) {
        Lighting.m_84930_();
        this.m_280273_(graphics);
        graphics.m_280653_(this.f_96547_, this.f_96539_, this.f_96543_ / 2, 40, 16777215);
        this.renderSign(graphics);
        Lighting.m_84931_();
        super.m_88315_(graphics, pMouseX, pMouseY, pPartialTick);
    }

    public static record WritableSignConfig(ConfiguredLineData[] lineData, boolean renderBack, float xCenterOffset, float y, float scale, float yRot, float berX, float berY, float berZ, Function<BlockState, Float> blockEntityRendererRotation, int berColor) {
        public static final int DEFAULT_SCALE = 96;

        public int getLineHeightsUntil(int index) {
            return (int)IntStream.range(0, index).mapToLong(x -> (int)(lineData()[x].lineHeightScale() * WritableSignScreen.DEFAULT_LINE_HEIGHT)).sum();
        }
    
        public int getLineOffset(int index, float currentScaleY) {
            float halfLineHeight = halfLineHeight(index);
            return (int)(halfLineHeight - (WritableSignScreen.DEFAULT_LINE_HEIGHT * 0.5F * currentScaleY));
        }
        
        public float lineHeight(int index) {
            return lineData()[index].lineHeightScale() * WritableSignScreen.DEFAULT_LINE_HEIGHT;
        }
    
        public float halfLineHeight(int index) {
            return lineData()[index].lineHeightScale() * WritableSignScreen.DEFAULT_LINE_HEIGHT * 0.5F;
        }
    
        public float getHalfLineHeightScales(int index, float currentScaleY) {
            return halfLineHeight(index) * currentScaleY;
        }
    
        public Vector3f screenTextScale(Font font, float scale, ConfiguredLine line) {
            float scaleX = (float)MathUtils.getScale(font.m_92895_(line.text), line.data.maxLineWidth() * scale, line.data.minScale().f_82470_, line.data.maxScale().f_82470_);            
            float scaleY = (float)MathUtils.getScale(font.m_92895_(line.text), line.data.maxLineWidth() * scale, line.data.minScale().f_82471_, line.data.maxScale().f_82471_);            
            return new Vector3f(scaleX, scaleY, 1);
        }

        public Vector3f berTextScale(String text, Font font, float scale, ConfiguredLineData data) {
            float scaleX = (float)MathUtils.getScale(font.m_92895_(text) * scale, data.maxLineWidth(), data.minScale().f_82470_, data.maxScale().f_82470_);            
            float scaleY = (float)MathUtils.getScale(font.m_92895_(text) * scale, data.maxLineWidth(), data.minScale().f_82471_, data.maxScale().f_82471_);            
            return new Vector3f(scaleX, scaleY, 1);
        }
    }

    public static record ConfiguredLineData(float xOffset, float yOffset, Vec2 minScale, Vec2 maxScale, float maxLineWidth, float lineHeightScale, int color) {}
    protected static class ConfiguredLine {
        public String text;
        public final ConfiguredLineData data;

        public ConfiguredLine(String text, ConfiguredLineData data) {
            this.text = text;
            this.data = data;
        }
    }
}
