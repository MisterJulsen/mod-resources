package de.mrjulsen.mcdragonlib.client.render;

import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.blaze3d.systems.RenderSystem;

import de.mrjulsen.mcdragonlib.client.util.DLGuiGraphics;
import de.mrjulsen.mcdragonlib.client.util.GuiUtils;
import de.mrjulsen.mcdragonlib.client.util.GuiUtils.TextureFillMode;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.phys.Vec2;

public class MapImage {
    
    private final Level world;
    private final BlockPos pos;
    private final int yLevel;

    private final int areaWidth, areaHeight;
    private final Vec2 centerPosOnMap;
    private final boolean sameLayer;

    private int scale;

    private DynamicTexture texture;

    public MapImage(Level world, BlockPos pos, int yLevel, int width, int height, boolean sameLayer, int scale) {
        this.world = world;
        this.pos = pos;
        this.yLevel = yLevel;
        this.areaWidth = width;
        this.areaHeight = height;
        this.sameLayer = sameLayer;
        this.scale = scale;
        this.centerPosOnMap = new Vec2(areaWidth / 2, areaHeight / 2);
    }

    public void bindTexture() {
        if (this.texture == null)
            this.texture = new DynamicTexture(this.createImage());
        RenderSystem.setShaderTexture(0, this.texture.m_117963_());
    }

    public void render(DLGuiGraphics graphics, int x, int y) {
        bindTexture();
        GuiUtils.drawTexture(this.texture.m_117963_(), graphics, x, y, areaWidth * scale, areaHeight * scale, 0, 0, areaWidth, areaHeight, TextureFillMode.STRETCH, areaWidth, areaHeight);
    }

    public int getWidth() {
        return areaWidth;
    }

    public int getHeight() {
        return areaHeight;
    }

    public void setScale(int scale) {
        this.scale = scale;
    }

    public int getScale() {
        return scale;
    }

    public int getScaledWidth() {
        return getWidth() * getScale();
    }

    public int getScaledHeight() {
        return getHeight() * getScale();
    }

    public Vec2 getCenterPosOnMap() {
        return centerPosOnMap;
    }

    public void dispose() {
        if (this.texture != null) {
            this.texture.close();
            this.texture = null;
        }
    }

    private NativeImage createImage() {
        NativeImage image = new NativeImage(NativeImage.Format.RGBA, areaWidth, areaHeight, false);
        int rWidth = areaWidth / 2;
        int rHeight = areaHeight / 2;
        int minX = pos.m_123341_() - rWidth;
        int minZ = pos.m_123343_() - rHeight;

        for (int x = 0; x < areaWidth; x++) {
            for (int z = 0; z < areaHeight; z++) {
                BlockPos pos;
                int northY, westY;
                if (this.shouldDrawAtSameLayer()) {
                    pos = this.getFirstBlockGoingDown(minX + x, this.yLevel + 1, minZ + z, 5);
                    northY = this.getFirstBlockGoingDown(minX + x, this.yLevel + 1, minZ + z - 1, 6).m_123342_();
                    westY = this.getFirstBlockGoingDown(minX + x - 1, this.yLevel + 1, minZ + z, 6).m_123342_();
                } else {
                    pos = this.world.m_5452_(Heightmap.Types.WORLD_SURFACE, new BlockPos(minX + x, 0, minZ + z))
                            .m_7495_();
                    northY = this.world.m_6924_(Heightmap.Types.WORLD_SURFACE, pos.m_123341_(), pos.m_123343_() - 1) - 1;
                    westY = this.world.m_6924_(Heightmap.Types.WORLD_SURFACE, pos.m_123341_() - 1, pos.m_123343_()) - 1;
                }

                BlockState state = this.world.m_8055_(pos);
                MapColor color = state.m_284242_(this.world, pos);
                // Apparently blocks can return null map color #66
                int rgb = color == null ? MapColor.f_283808_.f_283871_ : color.f_283871_;

                int red = ((rgb >> 16) & 255);
                int green = ((rgb >> 8) & 255);
                int blue = (rgb & 255);

                if ((pos.m_123342_() > northY && northY >= 0) || (pos.m_123342_() > westY && westY >= 0)) {
                    if (red == 0 && green == 0 && blue == 0) {
                        red = 3;
                        green = 3;
                        blue = 3;
                    } else {
                        if (red > 0 && red < 3)
                            red = 3;
                        if (green > 0 && green < 3)
                            green = 3;
                        if (blue > 0 && blue < 3)
                            blue = 3;
                        red = Math.min((int) (red / 0.7), 255);
                        green = Math.min((int) (green / 0.7), 255);
                        blue = Math.min((int) (blue / 0.7), 255);
                    }
                }
                if ((pos.m_123342_() < northY && northY >= 0) || (pos.m_123342_() < westY && westY >= 0)) {
                    red = Math.max((int) (red * 0.7), 0);
                    green = Math.max((int) (green * 0.7), 0);
                    blue = Math.max((int) (blue * 0.7), 0);
                }

                image.m_84988_(x, z, (255 << 24) | (blue << 16) | (green << 8) | red);
            }
        }

        return image;
    }

    private BlockPos getFirstBlockGoingDown(int x, int y, int z, int maxTries) {
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos(x, y, z);
        int tries = 0;
        while (this.world.m_46859_(pos) && ++tries < maxTries)
            pos.m_142448_(pos.m_123342_() - 1);

        return pos;
    }

    private boolean shouldDrawAtSameLayer() {
        return sameLayer || this.world.m_6042_().f_63856_();
    }
}
