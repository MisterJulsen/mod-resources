package de.mrjulsen.mcdragonlib.client.util;

import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import com.mojang.blaze3d.vertex.PoseStack;

import net.minecraft.client.Minecraft;
import net.minecraft.core.SectionPos;

public final class ClientUtils {
    private ClientUtils() {}
    
    public static void setSectionDirty(SectionPos pos) {
        Minecraft.m_91087_().execute(() -> {            
            Minecraft.m_91087_().f_91060_.m_109770_(pos.m_123341_(), pos.m_123342_(), pos.m_123343_());
        });
    }

    public static void resetTranslation(PoseStack poseStack) {
        PoseStack.Pose currentPose = poseStack.m_85850_();
        Matrix4f matrix = currentPose.m_252922_();
        matrix.m30(0);
        matrix.m31(0);
        matrix.m32(0);
    }

    public static void resetRotation(PoseStack poseStack) {
        PoseStack.Pose currentPose = poseStack.m_85850_();
        Matrix4f matrix = currentPose.m_252922_();
    
        Vector3f translation = new Vector3f();
        matrix.getTranslation(translation);
        Vector3f scale = new Vector3f();
        matrix.getScale(scale);
        
        matrix.identity();
        matrix.translate(translation);
        matrix.scale(scale);
    }
    
    public static void resetScale(PoseStack poseStack) {
        PoseStack.Pose currentPose = poseStack.m_85850_();
        Matrix4f matrix = currentPose.m_252922_();

        Vector3f translation = new Vector3f();
        matrix.getTranslation(translation);
        Quaternionf rotation = new Quaternionf();
        matrix.getUnnormalizedRotation(rotation);

        matrix.identity();
        matrix.translate(translation);
        matrix.rotate(rotation);
    }
}
