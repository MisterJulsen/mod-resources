package de.mrjulsen.mcdragonlib.block;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;

public abstract class DLSyncedBlockEntity extends BlockEntity {

	public DLSyncedBlockEntity(BlockEntityType<?> type, BlockPos pos, BlockState state) {
		super(type, pos, state);
	}

	@Override
	public CompoundTag m_5995_() {
		return this.m_187480_();
	}

	@Override
	public ClientboundBlockEntityDataPacket m_58483_() {
		return ClientboundBlockEntityDataPacket.m_195640_(this);
	}

	// Special handling for client update packets
	public void readClient(CompoundTag tag) {
		m_142466_(tag);
	}

	// Special handling for client update packets
	public CompoundTag writeClient(CompoundTag tag) {
		m_183515_(tag);
		return tag;
	}

	public void sendData() {
		if (f_58857_ instanceof ServerLevel serverLevel) {			
			serverLevel.m_7726_().m_8450_(m_58899_());
		}
	}

	public void notifyUpdate() {
		m_6596_();
		sendData();
	}

	public LevelChunk containedChunk() {
		return f_58857_.m_46745_(f_58858_);
	}
}
