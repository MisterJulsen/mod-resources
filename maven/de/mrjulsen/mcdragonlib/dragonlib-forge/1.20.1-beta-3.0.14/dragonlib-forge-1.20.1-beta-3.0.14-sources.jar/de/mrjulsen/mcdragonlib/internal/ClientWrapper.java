package de.mrjulsen.mcdragonlib.internal;

import de.mrjulsen.mcdragonlib.network.NetworkDirection.C2S;
import net.minecraft.client.Minecraft;
import net.minecraft.world.level.Level;

public class ClientWrapper {

    public static Level getClientLevel() {
        return Minecraft.m_91087_().f_91073_;
    }

    public static C2S toServer() {
        return packet -> {
            if (Minecraft.m_91087_().m_91403_() != null) {
                Minecraft.m_91087_().m_91403_().m_104955_(packet);
            } else {
                throw new IllegalStateException("Unable to send packet to the server while not in game!");
            }
        };
    }
}
