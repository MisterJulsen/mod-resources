package de.mrjulsen.mcdragonlib.data;

import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;

public class ReadOnlyCompoundTag {
    private final CompoundTag delegate;

    public ReadOnlyCompoundTag(CompoundTag delegate) {
        this.delegate = delegate;
    }

    public Set<String> getAllKeys() {
        return delegate.m_128431_();
    }

    public Optional<Byte> getByte(String key) {
        return delegate.m_128425_(key, 99)
                ? Optional.of(delegate.m_128445_(key))
                : Optional.empty();
    }

    public Optional<Short> getShort(String key) {
        return delegate.m_128425_(key, 99)
                ? Optional.of(delegate.m_128448_(key))
                : Optional.empty();
    }

    public Optional<Integer> getInt(String key) {
        return delegate.m_128425_(key, 99)
                ? Optional.of(delegate.m_128451_(key))
                : Optional.empty();
    }

    public Optional<Long> getLong(String key) {
        return delegate.m_128425_(key, 99)
                ? Optional.of(delegate.m_128454_(key))
                : Optional.empty();
    }

    public Optional<Float> getFloat(String key) {
        return delegate.m_128425_(key, 99)
                ? Optional.of(delegate.m_128457_(key))
                : Optional.empty();
    }

    public Optional<Double> getDouble(String key) {
        return delegate.m_128425_(key, 99)
                ? Optional.of(delegate.m_128459_(key))
                : Optional.empty();
    }

    public Optional<String> getString(String key) {
        return delegate.m_128425_(key, 8)
                ? Optional.of(delegate.m_128461_(key))
                : Optional.empty();
    }

    public Optional<byte[]> getByteArray(String key) {
        return delegate.m_128425_(key, 7)
                ? Optional.of(delegate.m_128463_(key))
                : Optional.empty();
    }

    public Optional<int[]> getIntArray(String key) {
        return delegate.m_128425_(key, 11)
                ? Optional.of(delegate.m_128465_(key))
                : Optional.empty();
    }

    public Optional<long[]> getLongArray(String key) {
        return delegate.m_128425_(key, 12)
                ? Optional.of(delegate.m_128467_(key))
                : Optional.empty();
    }

    public Optional<UUID> getUUID(String key) {
        return delegate.m_128403_(key)
                ? Optional.of(delegate.m_128342_(key))
                : Optional.empty();
    }

    public Optional<Boolean> getBoolean(String key) {
        return delegate.m_128425_(key, 99)
                ? Optional.of(delegate.m_128471_(key))
                : Optional.empty();
    }

    public Optional<ReadOnlyCompoundTag> getCompound(String key) {
        return delegate.m_128425_(key, 10)
                ? Optional.of(new ReadOnlyCompoundTag(delegate.m_128469_(key)))
                : Optional.empty();
    }

    public Optional<ListTag> getList(String key, int tagType) {
        return delegate.m_128435_(key) == 9
                ? Optional.of(delegate.m_128437_(key, tagType))
                : Optional.empty();
    }

    public boolean isEmpty() {
        return delegate.m_128456_();
    }

    @Override
    public String toString() {
        return delegate.toString();
    }
}

