package de.mrjulsen.mcdragonlib.client.gui.widgets.base;

import java.nio.file.Path;
import java.util.List;

import org.jetbrains.annotations.Nullable;

import de.mrjulsen.mcdragonlib.client.util.DLGuiGraphics;
import de.mrjulsen.mcdragonlib.util.TextUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.MenuAccess;
import net.minecraft.world.inventory.AbstractContainerMenu;

public class DLScreen<M extends AbstractContainerMenu> extends Screen implements MenuAccess<M> {

    private final DLWindowManager root;
    private final M menu;
    
    public <T extends DLWindow> DLScreen(@Nullable M menu, WindowBuilder<T> window) {
        super(TextUtils.empty());
        final Screen previousScreen = Minecraft.m_91087_().f_91080_;
        this.menu = menu;
        this.root = new DLWindowManager(menu, window, f_96543_, f_96544_, (mgr) -> {
            Minecraft.m_91087_().m_91152_(mgr.shouldShowPreviousScreenOnClose() ? previousScreen : null);
        });
    }

    public DLWindowManager getWindowManager() {
        return root;
    }

    public boolean supportsMenus() {
        return menu != null;
    }

    @Override
    protected void m_7856_() {
        super.m_7856_();
        root.updateLayout(f_96543_, f_96544_);
    }

    @Override
    public void m_88315_(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        super.m_88315_(guiGraphics, mouseX, mouseY, partialTick);
        m_280273_(guiGraphics);
        DLGuiGraphics graphics = new DLGuiGraphics(guiGraphics, guiGraphics.m_280168_(), Minecraft.m_91087_().f_91062_, partialTick);
        root.render(graphics, mouseX, mouseY);
    }

    @Override
    public void m_86600_() {
        super.m_86600_();
        root.tick();
    }

    @Override
    public boolean m_6375_(double mouseX, double mouseY, int button) {
        return root.mouseClicked(mouseX, mouseY, button) || super.m_6375_(mouseX, mouseY, button);
    }

    @Override
    public void m_94757_(double mouseX, double mouseY) {
        boolean b = root.mouseMoved(mouseX, mouseY);
        if (!b) {
            super.m_94757_(mouseX, mouseY);
        }
    }

    @Override
    public boolean m_6348_(double mouseX, double mouseY, int button) {
        return root.mouseReleased(mouseX, mouseY, button) || super.m_6348_(mouseX, mouseY, button);
    }

    public boolean onScroll(double mouseX, double mouseY, double scrollX, double scrollY) {
        return root.mouseScrolled(mouseX, mouseY, scrollX, scrollY) || super.m_6050_(mouseX, mouseY, scrollY);
    }

    @Override
    public boolean m_7979_(double mouseX, double mouseY, int button, double dragX, double dragY) {
        return root.mouseDragged(mouseX, mouseY, button, dragX, dragY) || super.m_7979_(mouseX, mouseY, button, dragX, dragY);
    }

    @Override
    public boolean m_7933_(int keyCode, int scanCode, int modifiers) {
        return root.keyPressed(keyCode, scanCode, modifiers) || super.m_7933_(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean m_7920_(int keyCode, int scanCode, int modifiers) {
        return root.keyReleased(keyCode, scanCode, modifiers) || super.m_7920_(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean m_5534_(char codePoint, int modifiers) {
        return root.charTyped(codePoint, modifiers) || super.m_5534_(codePoint, modifiers);
    }

    @Override
    public void m_7400_(List<Path> paths) {
        boolean b = root.onFilesDrop(paths);
        if (!b) {
            super.m_7400_(paths);
        }
    }

    @Override
    public void m_7379_() {
        root.onClose();
        super.m_7379_();
    }

    @Override
    public boolean m_7043_() {
        return root.isPauseScreen();
    }

    @Override
    public M m_6262_() {
        return menu;
    }
}
