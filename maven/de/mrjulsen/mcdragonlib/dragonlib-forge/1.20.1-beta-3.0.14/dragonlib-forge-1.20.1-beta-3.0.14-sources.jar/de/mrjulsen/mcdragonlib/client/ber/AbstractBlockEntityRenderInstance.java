package de.mrjulsen.mcdragonlib.client.ber;

import net.minecraft.world.level.block.entity.BlockEntity;

public abstract class AbstractBlockEntityRenderInstance<T extends BlockEntity> implements IBlockEntityRendererInstance<T> {

    public AbstractBlockEntityRenderInstance(T blockEntity) {
        preinit(blockEntity);
        update(blockEntity.m_58904_(), blockEntity.m_58899_(), blockEntity.m_58900_(), blockEntity, null);
    }

    protected void preinit(T blockEntity) {}

}