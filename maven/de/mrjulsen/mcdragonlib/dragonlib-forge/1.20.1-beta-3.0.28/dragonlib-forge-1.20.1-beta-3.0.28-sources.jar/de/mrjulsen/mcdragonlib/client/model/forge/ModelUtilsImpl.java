package de.mrjulsen.mcdragonlib.client.model.forge;

import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.client.resources.model.ModelResourceLocation;
import net.minecraft.resources.ResourceLocation;

public class ModelUtilsImpl {

    public static BakedModel getModel(ResourceLocation location) {
        return Minecraft.m_91087_().m_91304_().getModel(location);
    }

    public static BakedModel getModel(ModelResourceLocation location) {
        return Minecraft.m_91087_().m_91304_().m_119422_(location);
    }
}
