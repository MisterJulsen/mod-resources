package de.mrjulsen.mcdragonlib.internal;

import de.mrjulsen.mcdragonlib.client.DLOverlayManager;
import de.mrjulsen.mcdragonlib.client.gui.widgets.base.DLWindow;
import de.mrjulsen.mcdragonlib.data.DLStatus;
import de.mrjulsen.mcdragonlib.menu.PlayerInventoryContainerMenu;
import de.mrjulsen.mcdragonlib.network.NetworkDirection;
import de.mrjulsen.mcdragonlib.util.TextUtils;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

public class DragonLibBlock extends BaseEntityBlock {

    public DragonLibBlock(BlockBehaviour.Properties properties) {
        super(properties);
    }

    public static class DragonLibItem extends BlockItem {
        public DragonLibItem(Block pBlock, net.minecraft.world.item.Item.Properties pProperties) {
            super(pBlock, pProperties.m_41497_(Rarity.EPIC));            
        }
    }

    @Override
    public BlockEntity m_142194_(BlockPos arg0, BlockState arg1) {
        return new DragonLibBlockEntity(arg0, arg1);
    }
    
    @Override
    public RenderShape m_7514_(BlockState pState) {
        return RenderShape.MODEL;
    }

    

    public InteractionResult m_6227_(BlockState pState, Level pLevel, BlockPos pPos, Player pPlayer, InteractionHand pHand, BlockHitResult pHit) {
        if (pLevel.f_46443_) {
            /*
            NetworkTest.SEND_AND_RECEIVE.send(NetworkDirection.toServer(), new NetworkTest.TestData(DLStatus.OK, "Salzingen Hbf"), (response) -> {
                if (response.getStatus().isError()) {
                    System.out.println("ERROR: " + response.getStatus().message());
                }
                System.out.println("RESPONSE: " + response.txt);
            }, () -> {
                System.out.println("ERROR callback");
            });

             */
            //DLWindow.openWindow(mgr -> new DLTestWindow(mgr));
            //DLOverlayManager.addOverlay(mgr -> new TimeWindow(mgr));
            return InteractionResult.SUCCESS;
        } else {

            //pPlayer.openMenu(pState.getMenuProvider(pLevel, pPos));
            return InteractionResult.CONSUME;
        }
    }

    public MenuProvider m_7246_(BlockState pState, Level pLevel, BlockPos pPos) {
        return new SimpleMenuProvider((containerId, inv, player) -> {
            return new PlayerInventoryContainerMenu.Base(containerId, inv, ContainerLevelAccess.m_39289_(pLevel, pPos));
        }, TextUtils.text(""));
    }
    
}