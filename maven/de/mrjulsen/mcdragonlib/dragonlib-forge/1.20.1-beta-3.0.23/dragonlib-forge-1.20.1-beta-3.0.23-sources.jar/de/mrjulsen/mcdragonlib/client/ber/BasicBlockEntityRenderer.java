package de.mrjulsen.mcdragonlib.client.ber;

import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.world.level.block.entity.BlockEntity;

public abstract class BasicBlockEntityRenderer<T extends BlockEntity> extends SafeBlockEntityRenderer<T> {
    
    protected final Font font;

    public BasicBlockEntityRenderer(BlockEntityRendererProvider.Context context) {
        super(context);
        this.font = context.m_173586_();
    }

    @Override
    protected final void renderSafe(BERGraphics<T> graphics, float partialTick) {        
        graphics.poseStack().m_85836_();
        graphics.poseStack().m_85837_(0.5D, 0, 0.5F);
        graphics.poseStack().m_252880_(-0.5f, 1, -0.5f);
        graphics.poseStack().m_85841_(0.0625f, -0.0625f, 0.0625f);

        renderBlock(graphics, partialTick);

        graphics.poseStack().m_85849_();
        
    }

    protected abstract void renderBlock(BERGraphics<T> graphics, float partialTick);
}
