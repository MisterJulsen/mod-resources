package de.mrjulsen.mcdragonlib.client.atlas;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import de.mrjulsen.mcdragonlib.client.atlas.GLGuiTextureData.AbstractSprite;
import de.mrjulsen.mcdragonlib.client.gui.widgets.util.ScaleType;
import net.minecraft.server.packs.metadata.MetadataSectionSerializer;
import net.minecraft.util.GsonHelper;

import java.util.HashMap;
import java.util.Map;

@Deprecated(forRemoval = true)
public class GLGuiTextureDataSerializer implements MetadataSectionSerializer<GLGuiTextureData> {

	@Deprecated(forRemoval = true)
	@Override
	public GLGuiTextureData m_6322_(JsonObject json) {
		Map<String, AbstractSprite> result = new HashMap<>();
		
		JsonArray textureSizeJson = GsonHelper.m_13933_(json, "texture_size");
		int[] textureSize = new int[2];
		for (int i = 0; i < textureSize.length; i++) {
			textureSize[i] = GsonHelper.m_13897_(textureSizeJson.get(i), "texture_size[" + i + "]");
		}

		JsonObject sprites = GsonHelper.m_13930_(json, "sprites");
		for (Map.Entry<String, JsonElement> entry : sprites.entrySet()) {
			String key = entry.getKey();
			JsonObject innerObject = GsonHelper.m_13918_(entry.getValue(), key);

			String typeString = GsonHelper.m_13906_(innerObject, "type");
			ScaleType type = ScaleType.getByName(typeString);
			
			AbstractSprite sprite = GLGuiTextureData.EMPTY_SPRITE;
			switch (type) {
				case STRETCH -> {
					JsonArray uvArrayJson = GsonHelper.m_13832_(innerObject, "uv", new JsonArray(2));
					int[] uvArray = new int[2];
					for (int i = 0; i < uvArray.length; i++) {
						uvArray[i] = GsonHelper.m_13897_(uvArrayJson.get(i), "uv[" + i + "]");
					}

					JsonArray sizeArrayJson = GsonHelper.m_13832_(innerObject, "size", new JsonArray(2));
					int[] sizeArray = new int[2];
					for (int i = 0; i < sizeArray.length; i++) {
						sizeArray[i] = GsonHelper.m_13897_(sizeArrayJson.get(i), "size[" + i + "]");
					}
					sprite = new GLGuiTextureData.StretchedSprite(uvArray, sizeArray);
				}
				case TILE -> {
					JsonArray uvArrayJson = GsonHelper.m_13832_(innerObject, "uv", new JsonArray(2));
					int[] uvArray = new int[2];
					for (int i = 0; i < uvArray.length; i++) {
						uvArray[i] = GsonHelper.m_13897_(uvArrayJson.get(i), "uv[" + i + "]");
					}

					JsonArray sizeArrayJson = GsonHelper.m_13832_(innerObject, "size", new JsonArray(2));
					int[] sizeArray = new int[2];
					for (int i = 0; i < sizeArray.length; i++) {
						sizeArray[i] = GsonHelper.m_13897_(sizeArrayJson.get(i), "size[" + i + "]");
					}
					sprite = new GLGuiTextureData.TiledSprite(uvArray, sizeArray);
				}
				case NINE_SLICE -> {
					JsonArray uvArrayJson = GsonHelper.m_13832_(innerObject, "uv", new JsonArray(2));
					int[] uvArray = new int[2];
					for (int i = 0; i < uvArray.length; i++) {
						uvArray[i] = GsonHelper.m_13897_(uvArrayJson.get(i), "uv[" + i + "]");
					}

					JsonArray sizeArrayJson = GsonHelper.m_13832_(innerObject, "size", new JsonArray(2));
					int[] sizeArray = new int[2];
					for (int i = 0; i < sizeArray.length; i++) {
						sizeArray[i] = GsonHelper.m_13897_(sizeArrayJson.get(i), "size[" + i + "]");
					}

					JsonArray borderArrayJson = GsonHelper.m_13832_(innerObject, "border", new JsonArray(4));
					int[] borderArray = new int[4];
					for (int i = 0; i < borderArray.length; i++) {
						borderArray[i] = GsonHelper.m_13897_(borderArrayJson.get(i), "border[" + i + "]");
					}
					
					boolean tiledContent = GsonHelper.m_13855_(innerObject, "tiled_content", false);
					boolean tiledBorder = GsonHelper.m_13855_(innerObject, "tiled_border", false);
					sprite = new GLGuiTextureData.NineSlicedSprite(uvArray, sizeArray, borderArray, tiledBorder, tiledContent);
				}
			};
			result.put(key, sprite);
		}
		return new GLGuiTextureData(result, textureSize);
	}

	@Deprecated(forRemoval = true)
	@Override
	public String m_7991_() {
		return "dragonlib-gui";
	}
}
