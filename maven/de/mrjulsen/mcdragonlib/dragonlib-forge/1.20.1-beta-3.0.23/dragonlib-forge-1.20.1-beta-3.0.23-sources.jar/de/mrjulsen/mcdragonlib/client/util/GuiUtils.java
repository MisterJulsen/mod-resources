package de.mrjulsen.mcdragonlib.client.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import com.mojang.blaze3d.platform.Lighting;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.math.Axis;

import de.mrjulsen.mcdragonlib.client.gui.widgets.util.EAlign;
import de.mrjulsen.mcdragonlib.client.model.ModelContext;
import de.mrjulsen.mcdragonlib.client.model.mesh.BasicMesh;
import de.mrjulsen.mcdragonlib.client.model.mesh.DLModel;
import de.mrjulsen.mcdragonlib.client.model.mesh.Mesh;
import de.mrjulsen.mcdragonlib.client.model.mesh.DLModel.ModelType;
import de.mrjulsen.mcdragonlib.data.ETextAlignment;
import de.mrjulsen.mcdragonlib.data.ITranslatableEnum;
import de.mrjulsen.mcdragonlib.util.DLColor;
import de.mrjulsen.mcdragonlib.util.TextUtils;
import de.mrjulsen.mcdragonlib.util.math.Rectangle;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.locale.Language;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Utility class providing a collection of static helper methods for GUI rendering
 * and common in-GUI operations used by DragonLib's client code.
 *
 * <p>Responsibilities include:
 * - Screen / mouse coordinate helpers
 * - Scissor (clipping) helpers
 * - Texture binding and drawing (including tiled drawing)
 * - Color and tint helpers
 * - Rendering helpers for items, entities, blocks and models into GUI contexts
 * - Basic shape and text drawing helpers
 *
 * <p>All methods in this class are stateless and operate on provided graphics
 * contexts or global Minecraft client state.
 */
public class GuiUtils {

    /**
     * Specifies how a texture should be filled into a rectangular area.
     * STRETCH scales the source region to fit the destination area.
     * TILE repeats the source region to fill the destination area.
     */
    public static enum TextureFillMode {
        STRETCH,
        TILE
    }
    

    /**
     * Returns the current mouse X coordinate in GUI-scaled pixels.
     *
     * @return mouse X position relative to the GUI scale
     */
    public static double mouseXOnScreen() {
        return Minecraft.m_91087_().f_91067_.m_91589_() * (double)Minecraft.m_91087_().m_91268_().m_85445_() / (double)Minecraft.m_91087_().m_91268_().m_85443_();
    }

    /**
     * Returns the current mouse Y coordinate in GUI-scaled pixels.
     *
     * @return mouse Y position relative to the GUI scale
     */
    public static double mouseYOnScreen() {
        return Minecraft.m_91087_().f_91067_.m_91594_() * (double)Minecraft.m_91087_().m_91268_().m_85446_() / (double)Minecraft.m_91087_().m_91268_().m_85444_();
    }

    /**
     * Returns the current GUI-scaled screen width.
     *
     * @return width in GUI-scaled pixels
     */
    public static double getScreenWidth() {
        return Minecraft.m_91087_().m_91268_().m_85445_();
    }

    /**
     * Returns the current GUI-scaled screen height.
     *
     * @return height in GUI-scaled pixels
     */
    public static double getScreenHeight() {
        return Minecraft.m_91087_().m_91268_().m_85446_();
    }

    /**
     * Enables OpenGL scissor test (clipping) for the specified rectangular area.
     *
     * @param graphics the DLGuiGraphics context (not modified)
     * @param area the rectangle in GUI coordinates to enable scissor for
     */
    public static void enableScissor(DLGuiGraphics graphics, Rectangle area) {
        enableScissor(graphics, (int)area.x(), (int)area.y(), (int)area.width(), (int)area.height());
    }

    /**
     * Enables OpenGL scissor test (clipping) for the specified rectangular area.
     *
     * @param graphics the DLGuiGraphics context (not modified)
     * @param x left coordinate in GUI pixels
     * @param y top coordinate in GUI pixels
     * @param w width in GUI pixels
     * @param h height in GUI pixels
     */
    public static void enableScissor(DLGuiGraphics graphics, int x, int y, int w, int h) {
        int scale = (int)Minecraft.m_91087_().m_91268_().m_85449_();    
        RenderSystem.enableScissor(x * scale, Minecraft.m_91087_().m_91268_().m_85442_() - (y + h) * scale, w * scale, h * scale);   
    }

    /**
     * Disables any previously enabled scissor (clipping) region.
     *
     * @param graphics the DLGuiGraphics context (not modified)
     */
    public static void disableScissor(DLGuiGraphics graphics) {
        RenderSystem.disableScissor();
    }

    /**
     * Plays the standard UI button click sound at default pitch and volume.
     */
    public static void playButtonSound() {
        Minecraft.m_91087_().m_91106_().m_120367_(SimpleSoundInstance.m_263171_(SoundEvents.f_12490_, 1.0F));
    }

    /**
     * Converts a FormattedText instance to a visual-order FormattedCharSequence.
     *
     * @param text the formatted text to convert
     * @return a FormattedCharSequence suitable for rendering
     */
    public static FormattedCharSequence toFormattedCharSequence(FormattedText text) {
        return text instanceof Component ? ((Component)text).m_7532_() : Language.m_128107_().m_5536_(text);
    }
    
    
    /**
     * Splits a collection of formatted texts into visual-order char sequences
     * using the provided font and maximum line width.
     *
     * @param font font used for measuring and splitting
     * @param components collection of formatted texts to split
     * @param maxWidth maximum width in pixels for each resulting line
     * @param <T> a type extending FormattedText
     * @return list of resulting FormattedCharSequence lines
     */
    public static <T extends FormattedText> List<FormattedCharSequence> splitToFormattedCharSequences(Font font, Collection<T> components, int maxWidth) {
        List<FormattedCharSequence> lines = new ArrayList<>(components.size());
        for (T component : components) {
            lines.addAll(font.m_92923_(component, maxWidth));
        }
        return lines;
    }
    
    /**
     * Splits a collection of formatted texts into FormattedText line objects
     * using the provided font and maximum line width.
     *
     * @param font font used for measuring and splitting
     * @param components collection of formatted texts to split
     * @param maxWidth maximum width in pixels for each resulting line
     * @param <T> a type extending FormattedText
     * @return list of resulting FormattedText lines
     */
    public static <T extends FormattedText> List<FormattedText> splitText(Font font, Collection<T> components, int maxWidth) {
        List<FormattedText> lines = new ArrayList<>(components.size());
        for (T component : components) {
            lines.addAll(font.m_92865_().m_92414_(component, maxWidth, Style.f_131099_));
        }
        return lines;
    }

    /**
     * Draws a tooltip comprised of multiple formatted text lines at the specified location.
     *
     * @param graphics DLGuiGraphics wrapper used for rendering
     * @param font font used to render tooltip text
     * @param x x coordinate where tooltip should be shown
     * @param y y coordinate where tooltip should be shown
     * @param lines list of formatted text lines to display
     * @param maxWidth maximum width for tooltip text wrapping
     */
    public static void drawTooltip(DLGuiGraphics graphics, Font font, int x, int y, List<? extends FormattedText> lines, int maxWidth) {
        graphics.graphics().m_280245_(font, splitToFormattedCharSequences(font, lines, maxWidth), x, y);
    }

    /**
     * Draws a tooltip at a position adjusted directly from the raw input (useful for mouse-based tooltips).
     *
     * @param graphics DLGuiGraphics wrapper used for rendering
     * @param font font used to render the tooltip
     * @param x raw x coordinate (will be offset internally)
     * @param y raw y coordinate (will be offset internally)
     * @param lines tooltip lines
     * @param maxWidth maximum width for tooltip text wrapping
     */
    public static void drawTooltipDirectlyAt(DLGuiGraphics graphics, Font font, int x, int y, List<? extends FormattedText> lines, int maxWidth) {
        drawTooltip(graphics, font, x - 8, y - 16, lines, maxWidth);
    }

    /**
     * Builds a descriptive tooltip for a translatable enum class, including
     * the enum description and each enum constant's name and description.
     *
     * @param enumClass the enum class to describe (must implement ITranslatableEnum)
     * @param maxWidth maximum width to consider when splitting lines (unused by current implementation but kept for API compatibility)
     * @param <T> enum type
     * @return list of Components representing the tooltip lines
     */
    public static <T extends Enum<T> & ITranslatableEnum> List<Component> getEnumTooltipData(Class<T> enumClass, int maxWidth) {
        List<Component> c = new ArrayList<>();
        T enumValue = enumClass.getEnumConstants()[0];
        c.add(enumValue.getEnumDescriptionTranslation());
        c.add(TextUtils.text(" "));
        for (T t : enumClass.getEnumConstants()) {
            c.add(TextUtils.text("> ").m_130940_(ChatFormatting.BOLD).m_7220_(t.getValueTranslation()).m_130940_(ChatFormatting.BOLD));
            c.add(t.getValueDescriptionTranslation().m_130940_(ChatFormatting.GRAY));
        }
        return c;
    }



    /**
     * Binds the given ResourceLocation as the active texture for subsequent draw calls.
     *
     * @param texture the texture resource location to bind
     */
    public static void setTexture(ResourceLocation texture) {
        RenderSystem.setShaderTexture(0, texture);
    }

    /**
     * Binds the given OpenGL texture id as the active texture for subsequent draw calls.
     *
     * @param textureId the OpenGL texture id
     */
    public static void setTexture(int textureId) {
        RenderSystem.setShaderTexture(0, textureId);
    }

    /**
     * Sets the current shader color/tint from a DLColor instance.
     *
     * @param color color used to set the shader color (including alpha)
     */
    public static void setTint(DLColor color) {
        float a = color.getAlphaF();
        float r = color.getRedF();
        float g = color.getGreenF();
        float b = color.getBlueF();
        RenderSystem.setShaderColor(r, g, b, a);
    }

    /**
     * Resets the shader color/tint to opaque white (no tint).
     */
    public static void resetTint() {
        RenderSystem.setShaderColor(1, 1, 1, 1);
    }

    /**
     * Renders a texture repeatedly (tiled) to fill the specified area.
     *
     * @param graphics DLGuiGraphics context used for matrix access
     * @param bindTexture a Runnable that binds the appropriate texture when executed
     * @param x destination x coordinate
     * @param y destination y coordinate
     * @param w destination width
     * @param h destination height
     * @param u source texture u coordinate
     * @param v source texture v coordinate
     * @param uW source width in texture pixels
     * @param vH source height in texture pixels
     * @param texWidth full texture atlas width (for UV normalization)
     * @param texHeight full texture atlas height (for UV normalization)
     */
    public static void renderTiledTexture(DLGuiGraphics graphics, Runnable bindTexture, int x, int y, int w, int h, float u, float v, float uW, float vH, int texWidth, int texHeight) {
        RenderSystem.setShader(GameRenderer::m_172817_);
        bindTexture.run();

        float minU = u / texWidth;
        float minV = v / texHeight;
        float maxU = (u + uW) / texWidth;
        float maxV = (v + vH) / texHeight;
        float uSpan = maxU - minU;
        float vSpan = maxV - minV;

        Matrix4f matrix = graphics.poseStack().m_85850_().m_252922_();
        Tesselator tess = Tesselator.m_85913_();
        BufferBuilder buffer = tess.m_85915_();
        buffer.m_166779_(VertexFormat.Mode.QUADS, DefaultVertexFormat.f_85817_);

        int fullXTiles = w / (int)uW;
        int fullYTiles = h / (int)vH;
        float restX = w % uW;
        float restY = h % vH;

        float offsetY = 0f;
        for (int yTile = 0; yTile <= fullYTiles; yTile++) {
            float tileHeight = (yTile < fullYTiles) ? vH : restY;
            if (tileHeight <= 0) break;

            float offsetX = 0f;
            for (int xTile = 0; xTile <= fullXTiles; xTile++) {
                float tileWidth = (xTile < fullXTiles) ? uW : restX;
                if (tileWidth <= 0) break;

                float u0 = minU;
                float v0 = minV;
                float u1 = minU + uSpan * (tileWidth / uW);
                float v1 = minV + vSpan * (tileHeight / vH);

                float quadX0 = x + offsetX;
                float quadY0 = y + offsetY;
                float quadX1 = quadX0 + tileWidth;
                float quadY1 = quadY0 + tileHeight;

                buffer.m_252986_(matrix, quadX0, quadY1, 0).m_7421_(u0, v1).m_5752_();
                buffer.m_252986_(matrix, quadX1, quadY1, 0).m_7421_(u1, v1).m_5752_();
                buffer.m_252986_(matrix, quadX1, quadY0, 0).m_7421_(u1, v0).m_5752_();
                buffer.m_252986_(matrix, quadX0, quadY0, 0).m_7421_(u0, v0).m_5752_();

                offsetX += tileWidth;
            }
            offsetY += tileHeight;
        }

        tess.m_85914_();
    }

    /**
     * Draws a texture resource at specified destination area. Supports STRETCH and TILE fill modes.
     *
     * @param texture texture resource to draw
     * @param graphics DLGuiGraphics wrapper used for rendering
     * @param x destination x
     * @param y destination y
     * @param w destination width
     * @param h destination height
     * @param u source u in texture
     * @param v source v in texture
     * @param uW source width in texture pixels
     * @param vH source height in texture pixels
     * @param mode fill mode (STRETCH or TILE)
     */
    public static void drawTexture(ResourceLocation texture, DLGuiGraphics graphics, int x, int y, int w, int h, int u, int v, int uW, int vH, TextureFillMode mode) {
        drawTexture(texture, graphics, x, y, w, h, u, v, uW, vH, mode, 256, 256);
    }

    /**
     * Draws a texture resource at specified destination area with an explicit texture atlas size.
     *
     * @param texture texture resource to draw
     * @param graphics DLGuiGraphics wrapper used for rendering
     * @param x destination x
     * @param y destination y
     * @param w destination width
     * @param h destination height
     * @param u source u in texture
     * @param v source v in texture
     * @param uW source width in texture pixels
     * @param vH source height in texture pixels
     * @param mode fill mode (STRETCH or TILE)
     * @param textureWidth full texture atlas width for UV calculation
     * @param textureHeight full texture atlas height for UV calculation
     */
    public static void drawTexture(ResourceLocation texture, DLGuiGraphics graphics, int x, int y, int w, int h, int u, int v, int uW, int vH, TextureFillMode mode, int textureWidth, int textureHeight) {
        switch (mode) {
            case TILE -> renderTiledTexture(graphics, () -> RenderSystem.setShaderTexture(0, texture), x, y, w, h, u, v, uW, vH, textureWidth, textureHeight);
            default -> graphics.graphics().m_280411_(texture, x, y, w, h, u, v, uW, vH, textureWidth, textureHeight);
        }
    }

    /**
     * Draws a texture by OpenGL texture id, supporting tiled and stretched modes.
     *
     * @param textureId OpenGL texture id to bind
     * @param graphics DLGuiGraphics wrapper used for rendering
     * @param x destination x
     * @param y destination y
     * @param w destination width
     * @param h destination height
     * @param u source u in texture
     * @param v source v in texture
     * @param uW source width in texture pixels
     * @param vH source height in texture pixels
     * @param mode fill mode (STRETCH or TILE)
     * @param textureWidth full texture atlas width for UV calculation
     * @param textureHeight full texture atlas height for UV calculation
     */
    public static void drawTexture(int textureId, DLGuiGraphics graphics, int x, int y, int w, int h, int u, int v, int uW, int vH, TextureFillMode mode, int textureWidth, int textureHeight) {
        switch (mode) {
            case TILE -> renderTiledTexture(graphics, () -> RenderSystem.setShaderTexture(0, textureId), x, y, w, h, u, v, uW, vH, textureWidth, textureHeight);
            default -> blit(graphics.graphics(), textureId, x, y, w, h, u, v, uW, vH, textureWidth, textureHeight);
        }
        
    }

    /**
     * Draws a DLTexture wrapper which may either use a ResourceLocation or a texture id.
     *
     * @param texture DLTexture wrapper
     * @param graphics DLGuiGraphics wrapper used for rendering
     * @param x destination x
     * @param y destination y
     * @param w destination width
     * @param h destination height
     * @param u source u in texture
     * @param v source v in texture
     * @param uW source width in texture pixels
     * @param vH source height in texture pixels
     * @param mode fill mode (STRETCH or TILE)
     */
    public static void drawTexture(DLTexture texture, DLGuiGraphics graphics, int x, int y, int w, int h, int u, int v, int uW, int vH, TextureFillMode mode) {
        if (texture.usesTextureId() || texture.getTexture().isEmpty()) {
            drawTexture(texture.getTextureId(), graphics, x, y, w, h, u, v, uW, vH, mode, texture.width(), texture.height());
        } else {            
            drawTexture(texture.getTexture().get(), graphics, x, y, w, h, u, v, uW, vH, mode, texture.width(), texture.height());
        }
    }
    
    /**
     * Convenience overload that draws the entire DLTexture to the destination rectangle
     * using STRETCH mode.
     *
     * @param texture DLTexture wrapper
     * @param graphics DLGuiGraphics wrapper used for rendering
     * @param x destination x
     * @param y destination y
     * @param w destination width (also used as source width)
     * @param h destination height (also used as source height)
     * @param u source u in texture
     * @param v source v in texture
     */
    public static void drawTexture(DLTexture texture, DLGuiGraphics graphics, int x, int y, int w, int h, int u, int v) {
        drawTexture(texture, graphics, x, y, w, h, u, v, w, h, TextureFillMode.STRETCH);
    }
    
    /**
     * Convenience overload that draws the entire DLTexture to the destination rectangle
     * using STRETCH mode and source region equal to destination size.
     *
     * @param texture DLTexture wrapper
     * @param graphics DLGuiGraphics wrapper used for rendering
     * @param x destination x
     * @param y destination y
     * @param w destination width
     * @param h destination height
     */
    public static void drawTexture(DLTexture texture, DLGuiGraphics graphics, int x, int y, int w, int h) {
        drawTexture(texture, graphics, x, y, w, h, 0, 0, w, h, TextureFillMode.STRETCH);
    }


    /* COPY OF: GuiGraphics */
    private static void innerBlit(PoseStack pose, int textureId, int pX1, int pX2, int pY1, int pY2, int pBlitOffset, float pMinU, float pMaxU, float pMinV, float pMaxV) {
        RenderSystem.setShaderTexture(0, textureId);
        RenderSystem.setShader(GameRenderer::m_172817_);
        Matrix4f matrix4f = pose.m_85850_().m_252922_();
        BufferBuilder bufferbuilder = Tesselator.m_85913_().m_85915_();
        bufferbuilder.m_166779_(VertexFormat.Mode.QUADS, DefaultVertexFormat.f_85817_);
        bufferbuilder.m_252986_(matrix4f, (float)pX1, (float)pY1, (float)pBlitOffset).m_7421_(pMinU, pMinV).m_5752_();
        bufferbuilder.m_252986_(matrix4f, (float)pX1, (float)pY2, (float)pBlitOffset).m_7421_(pMinU, pMaxV).m_5752_();
        bufferbuilder.m_252986_(matrix4f, (float)pX2, (float)pY2, (float)pBlitOffset).m_7421_(pMaxU, pMaxV).m_5752_();
        bufferbuilder.m_252986_(matrix4f, (float)pX2, (float)pY1, (float)pBlitOffset).m_7421_(pMaxU, pMinV).m_5752_();
        BufferUploader.m_231202_(bufferbuilder.m_231175_());
    }
    
    private static void blit(GuiGraphics graphics, int textureId, int pX, int pY, int pWidth, int pHeight, float pUOffset, float pVOffset, int pUWidth, int pVHeight, int pTextureWidth, int pTextureHeight) {
        blit(graphics, textureId, pX, pX + pWidth, pY, pY + pHeight, 0, pUWidth, pVHeight, pUOffset, pVOffset, pTextureWidth, pTextureHeight);
    }

    private static void blit(GuiGraphics graphics, int textureId, int pX1, int pX2, int pY1, int pY2, int pBlitOffset, int pUWidth, int pVHeight, float pUOffset, float pVOffset, int pTextureWidth, int pTextureHeight) {
        innerBlit(graphics.m_280168_(), textureId, pX1, pX2, pY1, pY2, pBlitOffset, (pUOffset + 0.0F) / (float)pTextureWidth, (pUOffset + (float)pUWidth) / (float)pTextureWidth, (pVOffset + 0.0F) / (float)pTextureHeight, (pVOffset + (float)pVHeight) / (float)pTextureHeight);
    }
    /* END */


    /**
     * Fills a rectangle area with the provided color.
     *
     * @param graphics DLGuiGraphics used for rendering
     * @param area rectangle to fill
     * @param color color to fill with (including alpha)
     */
    public static void fill(DLGuiGraphics graphics, Rectangle area, DLColor color) {
        fill(graphics, (int)area.x(), (int)area.y(), (int)area.width(), (int)area.height(), color);
    }

    /**
     * Fills a rectangle area with the provided color.
     *
     * @param graphics DLGuiGraphics used for rendering
     * @param x left coordinate
     * @param y top coordinate
     * @param w width
     * @param h height
     * @param color color to fill with (including alpha)
     */
    public static void fill(DLGuiGraphics graphics, int x, int y, int w, int h, DLColor color) {
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        graphics.graphics().m_280509_(x, y, x + w, y + h, color.getAsARGB());
        RenderSystem.disableBlend();
    }

    /**
     * Fills a rectangle with a gradient between two colors aligned according to the given alignment.
     *
     * @param graphics DLGuiGraphics used for rendering
     * @param area rectangle to fill
     * @param colorA first color
     * @param colorB second color
     * @param align alignment determining vertex color order
     */
    public static void fillGradient(DLGuiGraphics graphics, Rectangle area, DLColor colorA, DLColor colorB, EAlign align) {
        fillGradient(graphics, (int)area.x(), (int)area.y(), (int)area.width(), (int)area.height(), colorA, colorB, align);
    }

    /**
     * Fills a rectangle with a gradient between two colors aligned according to the given alignment.
     *
     * @param graphics DLGuiGraphics used for rendering
     * @param x left coordinate
     * @param y top coordinate
     * @param w width
     * @param h height
     * @param colorA first color
     * @param colorB second color
     * @param align alignment determining vertex color order
     */
    public static void fillGradient(DLGuiGraphics graphics, int x, int y, int w, int h, DLColor colorA, DLColor colorB, EAlign align) {
        DLColor[] vertexColors = new DLColor[4];
        for (int i = 0; i < vertexColors.length; i++) {
            vertexColors[(align.getOrder() + i) % vertexColors.length] = (i < 2 ? colorA : colorB);
        }

        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(GameRenderer::m_172811_);

        Tesselator tessellator = Tesselator.m_85913_();
        BufferBuilder buffer = tessellator.m_85915_();
        buffer.m_166779_(VertexFormat.Mode.QUADS, DefaultVertexFormat.f_85815_);
        buffer.m_252986_(graphics.poseStack().m_85850_().m_252922_(), x + w, y, 0).m_193479_(vertexColors[0].getAsARGB()).m_5752_();
        buffer.m_252986_(graphics.poseStack().m_85850_().m_252922_(), x, y, 0).m_193479_(vertexColors[1].getAsARGB()).m_5752_();
        buffer.m_252986_(graphics.poseStack().m_85850_().m_252922_(), x, y + h, 0).m_193479_(vertexColors[2].getAsARGB()).m_5752_();
        buffer.m_252986_(graphics.poseStack().m_85850_().m_252922_(), x + w, y + h, 0).m_193479_(vertexColors[3].getAsARGB()).m_5752_();
        tessellator.m_85914_();

        RenderSystem.disableBlend();
    }

    /**
     * Draws a filled box with a solid fill color and a border color.
     *
     * @param graphics DLGuiGraphics used for rendering
     * @param area rectangle describing the box
     * @param fillColor interior fill color
     * @param borderColor outline color
     */
    public static void drawBox(DLGuiGraphics graphics, Rectangle area, DLColor fillColor, DLColor borderColor) {
        drawBox(graphics, (int)area.x(), (int)area.y(), (int)area.width(), (int)area.height(), fillColor, borderColor);
    }

    /**
     * Draws a filled box with a solid fill color and a border color.
     *
     * @param graphics DLGuiGraphics used for rendering
     * @param x left coordinate
     * @param y top coordinate
     * @param w width
     * @param h height
     * @param fillColor interior fill color
     * @param borderColor outline color
     */
    public static void drawBox(DLGuiGraphics graphics, int x, int y, int w, int h, DLColor fillColor, DLColor borderColor) {
        fill(graphics, x, y, w, h, fillColor);
        fill(graphics, x, y, w, 1, borderColor);
        fill(graphics, x, y + h - 1, w, 1, borderColor);
        fill(graphics, x, y + 1, 1, h - 2, borderColor);
        fill(graphics, x + w - 1, y + 1, 1, h - 2, borderColor);
    }

    /**
     * Draws a string with the specified alignment and optional drop shadow.
     *
     * @param graphics DLGuiGraphics used for rendering
     * @param font font used to render text
     * @param x x coordinate for the text anchor
     * @param y y coordinate for the text baseline
     * @param text plain string to render
     * @param color color to use for text
     * @param alignment left / center / right alignment mode
     * @param dropShadow whether to render a drop shadow
     */
    public static void drawString(DLGuiGraphics graphics, Font font, int x, int y, String text, DLColor color, ETextAlignment alignment, boolean dropShadow) {
        drawString(graphics, font, x, y, TextUtils.text(text), color, alignment, dropShadow);
    }

    /**
     * Draws a formatted text with the specified alignment and optional drop shadow.
     *
     * @param graphics DLGuiGraphics used for rendering
     * @param font font used to render text
     * @param x x coordinate for the text anchor
     * @param y y coordinate for the text baseline
     * @param text formatted text to render
     * @param color color to use for text
     * @param alignment left / center / right alignment mode
     * @param dropShadow whether to render a drop shadow
     */
    public static void drawString(DLGuiGraphics graphics, Font font, int x, int y, FormattedText text, DLColor color, ETextAlignment alignment, boolean dropShadow) {
        int width = font.m_92852_(text);
        int offset = 0;
        switch (alignment) {
            default:
            case LEFT:
                break;
            case CENTER:
                offset = -width / 2;
                break;
            case RIGHT:
                offset = -width;
                break;
        }

        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);
        graphics.graphics().m_280649_(font, toFormattedCharSequence(text), x + offset, y, color.getAsARGB(), dropShadow);
    }

    /**
     * Renders an item stack into the GUI at default scale and with decorations.
     *
     * @param graphics DLGuiGraphics used for rendering
     * @param stack item stack to render
     * @param x x coordinate
     * @param y y coordinate
     */
    public static void renderItem(DLGuiGraphics graphics, ItemStack stack, int x, int y) {
        renderItem(graphics, stack, x, y, 1, true);
    }

    /**
     * Renders an item stack into the GUI with custom scale and optional decorations.
     *
     * @param graphics DLGuiGraphics used for rendering
     * @param stack item stack to render
     * @param x x coordinate
     * @param y y coordinate
     * @param scale uniform scale factor to apply
     * @param drawDecorations whether to draw stack count, durability, etc.
     */
    public static void renderItem(DLGuiGraphics graphics, ItemStack stack, int x, int y, float scale, boolean drawDecorations) {
        graphics.poseStack().m_85836_();
        graphics.poseStack().m_252880_(x, y, 0);
        graphics.poseStack().m_85841_(scale, scale, 1);        
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);
        graphics.graphics().m_280480_(stack, 0, 0);
        if (drawDecorations) {
            graphics.graphics().m_280370_(Minecraft.m_91087_().f_91062_, stack, 0, 0);
        }
        graphics.poseStack().m_85849_();
    }
    

    /**
     * Renders only the item decorations (count, text overlays) for the specified item stack.
     *
     * @param graphics DLGuiGraphics used for rendering
     * @param stack the item stack whose decorations to render
     * @param x x coordinate
     * @param y y coordinate
     * @param scale uniform scale factor to apply to decoration rendering
     * @param text optional overlay text to render (may be null or empty)
     */
    public static void renderItemDecoration(DLGuiGraphics graphics, ItemStack stack, int x, int y, float scale, String text) {
        graphics.poseStack().m_85836_();
        graphics.poseStack().m_252880_(x, y, 0);
        graphics.poseStack().m_85841_(scale, scale, 1);        
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);
        graphics.graphics().m_280302_(Minecraft.m_91087_().f_91062_, stack, 0, 0, text);
        graphics.poseStack().m_85849_();
    }

    /**
     * Renders a living entity into GUI space at default brightness.
     *
     * @param graphics DLGuiGraphics used for rendering
     * @param x x coordinate
     * @param y y coordinate
     * @param entity entity instance to render
     */
    public static void renderEntity(DLGuiGraphics graphics, int x, int y, LivingEntity entity) {
        renderEntity(graphics, x, y, 1, entity, LightTexture.f_173040_);
    }

    /**
     * Renders a living entity into GUI space with a custom scale and brightness.
     *
     * @param graphics DLGuiGraphics used for rendering
     * @param x x coordinate
     * @param y y coordinate
     * @param scale uniform scale factor to apply to the entity rendering
     * @param entity entity instance to render
     * @param light packed light coordinate controlling brightness
     */
    public static void renderEntity(DLGuiGraphics graphics, int x, int y, float scale, LivingEntity entity, int light) {
        renderEntity(graphics, x, y, scale, entity, new Matrix4f(), new Quaternionf(), light);
    }

    /**
     * Renders a living entity into GUI space applying a transformation matrix and optional camera orientation override.
     *
     * <p>This overload allows fine-grained control of the transform and camera orientation used
     * when rendering the entity for UI previews.
     *
     * @param graphics DLGuiGraphics used for rendering
     * @param x x coordinate
     * @param y y coordinate
     * @param scale uniform scale factor
     * @param entity entity instance to render
     * @param transformation additional model transformation matrix to apply
     * @param cameraOrientation optional quaternion representing camera orientation (may be null)
     * @param light packed light to use for rendering
     */
    @SuppressWarnings("deprecation")
    public static void renderEntity(DLGuiGraphics graphics, int x, int y, float scale, LivingEntity entity, Matrix4f transformation, @Nullable Quaternionf cameraOrientation, int light) {
        float s = 16 * scale;
        graphics.poseStack().m_85836_();
        graphics.poseStack().m_85837_((double)x, (double)y, 16 * (scale + 1));
        graphics.poseStack().m_252931_((new Matrix4f()).scaling(s, s, -s));
        graphics.poseStack().m_252931_(transformation);
        Lighting.m_166384_();
        EntityRenderDispatcher entityRenderDispatcher = Minecraft.m_91087_().m_91290_();
        if (cameraOrientation != null) {
            cameraOrientation.conjugate();
            entityRenderDispatcher.m_252923_(cameraOrientation);
        }

        entityRenderDispatcher.m_114468_(false);
        RenderSystem.runAsFancy(() -> {
            entityRenderDispatcher.m_114384_(entity, 0.0, 0.0, 0.0, 0.0F, 1.0F, graphics.poseStack(), graphics.graphics().m_280091_(), light);
        });
        graphics.graphics().m_280262_();
        entityRenderDispatcher.m_114468_(true);
        graphics.poseStack().m_85849_();
        Lighting.m_84931_();
    }
    

    /**
     * Renders an entity that rotates following the mouse position (default scale).
     *
     * @param graphics DLGuiGraphics used for rendering
     * @param x x coordinate
     * @param y y coordinate
     * @param entity entity to render
     */
    public static void renderEntityFollowingMouse(DLGuiGraphics graphics, int x, int y, LivingEntity entity) {
        renderEntityFollowingMouse(graphics, x, y, 1, entity);
    }

    /**
     * Renders an entity that rotates following the mouse position.
     *
     * @param graphics DLGuiGraphics used for rendering
     * @param x x coordinate
     * @param y y coordinate
     * @param scale uniform scale factor
     * @param entity entity to render
     */
    public static void renderEntityFollowingMouse(DLGuiGraphics graphics, int x, int y, float scale, LivingEntity entity) {
        renderEntityFollowingMouse(graphics, x, y, scale, (float)Minecraft.m_91087_().f_91067_.m_91589_(), (float)Minecraft.m_91087_().f_91067_.m_91594_(), entity, LightTexture.f_173040_);
    }

    /**
     * Renders an entity that rotates following a given screen-space mouse coordinate.
     *
     * @param graphics DLGuiGraphics used for rendering
     * @param x x coordinate
     * @param y y coordinate
     * @param scale uniform scale factor
     * @param screenMouseX mouse X in screen coordinates used to compute rotation
     * @param screenMouseY mouse Y in screen coordinates used to compute rotation
     * @param entity entity to render
     * @param light packed light for rendering
     */
    public static void renderEntityFollowingMouse(DLGuiGraphics graphics, int x, int y, float scale, float screenMouseX, float screenMouseY, LivingEntity entity, int light) {
        Matrix4f transformation = graphics.poseStack().m_85850_().m_252922_();
        float aX = (float)Math.atan((double)((transformation.m30() + x - screenMouseX) / 40.0F));
        float aY = (float)Math.atan((double)((transformation.m31() + y - (screenMouseY + entity.m_20192_() * (16 * scale))) / 40.0F));
        renderEntityFollowingAngle(graphics, x, y, scale, aX, aY, entity, light);
    }

    /**
     * Renders an entity rotated according to precomputed angle components.
     *
     * @param graphics DLGuiGraphics used for rendering
     * @param x x coordinate
     * @param y y coordinate
     * @param scale uniform scale factor
     * @param angleXComponent X-angle influence component
     * @param angleYComponent Y-angle influence component
     * @param entity entity to render
     * @param light packed light for rendering
     */
    public static void renderEntityFollowingAngle(DLGuiGraphics graphics, int x, int y, float scale, float angleXComponent, float angleYComponent, LivingEntity entity, int light) {
        Quaternionf quaternionf = (new Quaternionf()).rotateZ((float)Math.PI);
        Quaternionf quaternionf1 = (new Quaternionf()).rotateX(angleYComponent * 20.0F * 0.017453292F);
        quaternionf.mul(quaternionf1);
        float f2 = entity.f_20883_;
        float f3 = entity.m_146908_();
        float f4 = entity.m_146909_();
        float f5 = entity.f_20886_;
        float f6 = entity.f_20885_;
        entity.f_20883_ = 180.0F + angleXComponent * 20.0F;
        entity.m_146922_(180.0F + angleXComponent * 40.0F);
        entity.m_146926_(-angleYComponent * 20.0F);
        entity.f_20885_ = entity.m_146908_();
        entity.f_20886_ = entity.m_146908_();        
        Matrix4f matrix = new Matrix4f().rotate(quaternionf);
        renderEntity(graphics, x, y, scale, entity, matrix, quaternionf1, light);
        entity.f_20883_ = f2;
        entity.m_146922_(f3);
        entity.m_146926_(f4);
        entity.f_20886_ = f5;
        entity.f_20885_ = f6;
    }
    

    /**
     * Renders a block state as a simple flat model in GUI space using a generated mesh.
     *
     * @param graphics DLGuiGraphics used for rendering
     * @param x x coordinate
     * @param y y coordinate
     * @param state block state to render
     * @param renderType render layer to use when rendering the model
     */
    public static void renderBlockState(DLGuiGraphics graphics, int x, int y, BlockState state, RenderType renderType) {
        renderBlockState(graphics, x, y, 1, state, renderType, new Matrix4f(), LightTexture.f_173040_);
    }

    /**
     * Renders a block state as a simple flat model in GUI space with custom scale and lighting.
     *
     * @param graphics DLGuiGraphics used for rendering
     * @param x x coordinate
     * @param y y coordinate
     * @param scale uniform scale factor
     * @param state block state to render
     * @param renderType render layer to use when rendering the model
     * @param light packed light for rendering
     */
    public static void renderBlockState(DLGuiGraphics graphics, int x, int y, float scale, BlockState state, RenderType renderType, int light) {
        renderBlockState(graphics, x, y, scale, state, renderType, new Matrix4f(), light);
    }

    /**
     * Renders a block state as a simple flat model in GUI space with transformation control.
     *
     * @param graphics DLGuiGraphics used for rendering
     * @param x x coordinate
     * @param y y coordinate
     * @param scale uniform scale factor
     * @param state block state to render
     * @param renderType render layer to use when rendering the model
     * @param transformation additional matrix to apply to the model
     * @param light packed light for rendering
     */
    public static void renderBlockState(DLGuiGraphics graphics, int x, int y, float scale, BlockState state, RenderType renderType, Matrix4f transformation, int light) {
        DLModel model = new DLModel() {
            @Override
            protected Mesh getMesh(ModelType type, BakedModel originalModel, BlockState state, RandomSource random, ModelContext context) {
                Mesh mesh = BasicMesh.fromBlock(state, random);
                mesh.rotate(Axis.f_252403_.m_252977_(180), new Vector3f(0.5f));
                return mesh;
            }
        };
        renderModel(graphics, x, y, scale, model, state, renderType, transformation, light);
    }
    

    /**
     * Renders a DLModel for a given block state at the default scale.
     *
     * @param graphics DLGuiGraphics used for rendering
     * @param x x coordinate
     * @param y y coordinate
     * @param model model instance to render
     * @param state block state to provide to the model
     * @param renderType render layer to use
     */
    public static void renderModel(DLGuiGraphics graphics, int x, int y, DLModel model, BlockState state, RenderType renderType) {
        renderModel(graphics, x, y, 1, model, state, renderType, new Matrix4f(), LightTexture.f_173040_);
    }

    /**
     * Renders a DLModel for a given block state with custom scale and lighting.
     *
     * @param graphics DLGuiGraphics used for rendering
     * @param x x coordinate
     * @param y y coordinate
     * @param scale uniform scale factor
     * @param model model instance to render
     * @param state block state to provide to the model
     * @param renderType render layer to use
     * @param light packed light for rendering
     */
    public static void renderModel(DLGuiGraphics graphics, int x, int y, float scale, DLModel model, BlockState state, RenderType renderType, int light) {
        renderModel(graphics, x, y, scale, model, state, renderType, new Matrix4f(), light);
    }

    /**
     * Renders a DLModel for a given block state with full transformation control and lighting.
     *
     * @param graphics DLGuiGraphics used for rendering
     * @param x x coordinate
     * @param y y coordinate
     * @param scale uniform scale factor
     * @param model model instance to render
     * @param state block state to provide to the model
     * @param renderType render layer to use
     * @param transformation additional transformation to apply
     * @param light packed light for rendering
     */
    public static void renderModel(DLGuiGraphics graphics, int x, int y, float scale, DLModel model, BlockState state, RenderType renderType, Matrix4f transformation, int light) {
        float s = scale * 16;
        Lighting.m_84930_();
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(true);
        PoseStack stack = graphics.poseStack();
        stack.m_85836_();
        stack.m_85841_(1, 1, -1);
        stack.m_85837_((double)x, (double)y, 16 * (scale + 1));
        stack.m_252931_((new Matrix4f()).scaling((float)s, (float)s, (float)(s)));
        stack.m_252931_(transformation);
        MultiBufferSource.BufferSource buffersource = Minecraft.m_91087_().m_91269_().m_110104_();
        model.render(graphics.poseStack().m_85850_(), buffersource.m_6299_(renderType), ModelType.BLOCK, state, ModelContext.EMPTY, DLColor.WHITE, LightTexture.f_173040_, 0);
        buffersource.m_109911_();
        stack.m_85849_();
        Lighting.m_84931_();
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);
    }
}
