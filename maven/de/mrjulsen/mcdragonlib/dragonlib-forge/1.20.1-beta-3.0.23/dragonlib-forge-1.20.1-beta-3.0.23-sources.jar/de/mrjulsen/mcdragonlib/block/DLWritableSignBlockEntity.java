package de.mrjulsen.mcdragonlib.block;

import java.util.Arrays;

import de.mrjulsen.mcdragonlib.client.gui.builtin.WritableSignScreen;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;

public abstract class DLWritableSignBlockEntity extends DLSyncedBlockEntity {
    private String[] lines = null;

    protected DLWritableSignBlockEntity(BlockEntityType<?> type, BlockPos pos, BlockState state) {
        super(type, pos, state);
    }

    public abstract WritableSignScreen.WritableSignConfig getRenderConfig();

    private void initTextArray() {
        if (this.lines == null) {
            this.lines = new String[this.getRenderConfig().lineData().length];
            Arrays.fill(lines, "");
        }
    }   
    
    public void setText(String text, int line) {
        if (line < 0 || line > this.getRenderConfig().lineData().length)
            return;

        initTextArray();

        this.lines[line] = text;
        this.notifyUpdate();
    }

    public void setTexts(String[] messages) {
        initTextArray();
        this.lines = messages;
        this.notifyUpdate();
    }

    public String getText(int line) {
        initTextArray();        
        return this.lines == null ? null : this.lines[line];
    }

    @Override
    public void m_142466_(CompoundTag compound) {
        super.m_142466_(compound);
        this.lines = new String[this.getRenderConfig().lineData().length];
        for (int i = 0; i < this.getRenderConfig().lineData().length; i++) {
            this.lines[i] = compound.m_128461_("line" + i);
        }
    }

    @Override
    protected void m_183515_(CompoundTag tag) {
        super.m_183515_(tag);
        if (this.lines != null) {
            for (int i = 0; i < this.getRenderConfig().lineData().length; i++) {
                tag.m_128359_("line" + i, this.lines[i]);
            }
        }
    }
}
