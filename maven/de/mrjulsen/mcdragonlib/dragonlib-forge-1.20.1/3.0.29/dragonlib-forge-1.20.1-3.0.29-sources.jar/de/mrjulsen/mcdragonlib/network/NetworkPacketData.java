package de.mrjulsen.mcdragonlib.network;

import de.mrjulsen.mcdragonlib.data.INBTSerializable;
import de.mrjulsen.mcdragonlib.data.DLStatus;
import net.minecraft.FieldsAreNonnullByDefault;
import net.minecraft.MethodsReturnNonnullByDefault;
import net.minecraft.nbt.CompoundTag;

import java.util.function.Function;

@FieldsAreNonnullByDefault
@MethodsReturnNonnullByDefault
public abstract class NetworkPacketData implements INBTSerializable {

    static final Function<DLStatus, NetworkPacketData> DEFAULT_INSTANCE = (status) -> new NetworkPacketData(status) {
        @Override
        protected void write(CompoundTag nbt) {}

        @Override
        protected void read(CompoundTag nbt) {}
    };
    
    private static final String NBT_STATUS = "Status";
    private static final String NBT_DATA = "Data";

    private DLStatus status = DLStatus.EMPTY;

    public NetworkPacketData(DLStatus status) {
        this.status = status;
    }

    public final DLStatus getStatus() {
        return status;
    }
    
    final void setStatus(DLStatus status) {
        this.status = status;
    }

    @Override
    public final CompoundTag serializeNbt() {
        CompoundTag nbt = new CompoundTag();
        nbt.m_128365_(NBT_STATUS, status.toNbt());
        CompoundTag data = new CompoundTag();
        write(data);
        nbt.m_128365_(NBT_DATA, data);
        return nbt;
    }

    @Override
    public final void deserializeNbt(CompoundTag nbt) {
        this.status = DLStatus.fromNbt(nbt.m_128469_(NBT_STATUS));
        read(nbt.m_128469_(NBT_DATA));
    }


    protected abstract void write(CompoundTag nbt);
    protected abstract void read(CompoundTag nbt);



    static final class Empty extends NetworkPacketData {
        public Empty(DLStatus result) {
            super(DLStatus.OK);
        }

        @Override
        protected void write(CompoundTag nbt) {
        }

        @Override
        protected void read(CompoundTag nbt) {
        }        
    }
}
