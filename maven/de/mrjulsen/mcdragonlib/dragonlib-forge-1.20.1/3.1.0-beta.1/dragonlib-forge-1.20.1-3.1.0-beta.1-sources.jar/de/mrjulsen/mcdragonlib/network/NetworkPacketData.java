/*
 * DragonLib 3 - 1.20.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.network;

import de.mrjulsen.mcdragonlib.data.INBTSerializable;
import de.mrjulsen.mcdragonlib.data.DLStatus;
import de.mrjulsen.mcdragonlib.network.v2.codec.DLStreamCodec;
import net.minecraft.FieldsAreNonnullByDefault;
import net.minecraft.MethodsReturnNonnullByDefault;
import net.minecraft.nbt.CompoundTag;

import java.util.function.Function;

/**
 * @deprecated Use {@link DLStreamCodec} to describe a payload.
 */
@Deprecated
@FieldsAreNonnullByDefault
@MethodsReturnNonnullByDefault
public abstract class NetworkPacketData implements INBTSerializable {

    static final Function<DLStatus, NetworkPacketData> DEFAULT_INSTANCE = (status) -> new NetworkPacketData(status) {
        @Override
        protected void write(CompoundTag nbt) {}

        @Override
        protected void read(CompoundTag nbt) {}
    };
    
    private static final String NBT_STATUS = "Status";
    private static final String NBT_DATA = "Data";

    private DLStatus status = DLStatus.EMPTY;

    public NetworkPacketData(DLStatus status) {
        this.status = status;
    }

    public final DLStatus getStatus() {
        return status;
    }
    
    final void setStatus(DLStatus status) {
        this.status = status;
    }

    @Override
    public final CompoundTag serializeNbt() {
        CompoundTag nbt = new CompoundTag();
        nbt.m_128365_(NBT_STATUS, status.toNbt());
        CompoundTag data = new CompoundTag();
        write(data);
        nbt.m_128365_(NBT_DATA, data);
        return nbt;
    }

    @Override
    public final void deserializeNbt(CompoundTag nbt) {
        this.status = DLStatus.fromNbt(nbt.m_128469_(NBT_STATUS));
        read(nbt.m_128469_(NBT_DATA));
    }


    protected abstract void write(CompoundTag nbt);
    protected abstract void read(CompoundTag nbt);



    public static final class Empty extends NetworkPacketData {
        public Empty(DLStatus result) {
            super(result);
        }

        @Override
        protected void write(CompoundTag nbt) {
        }

        @Override
        protected void read(CompoundTag nbt) {
        }        
    }
}
