/*
 * DragonLib 3 - 1.20.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.client.model.mesh;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import org.jetbrains.annotations.Nullable;

import com.google.common.collect.ListMultimap;
import com.google.common.collect.MultimapBuilder.ListMultimapBuilder;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;

import de.mrjulsen.mcdragonlib.client.model.DLBlockModelRegistry;
import de.mrjulsen.mcdragonlib.client.model.IDynamicBakedModel;
import de.mrjulsen.mcdragonlib.client.model.ModelCacheKey;
import de.mrjulsen.mcdragonlib.client.model.ModelContext;
import de.mrjulsen.mcdragonlib.util.DLColor;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.core.Direction;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.state.BlockState;

public abstract class DLModel {

    public static enum ModelType {
        BLOCK(false),
        ITEM(true);

        final boolean isItem;

        private ModelType(boolean b) {
            this.isItem = b;
        }

        public static ModelType isItem(boolean b) {
            return b ? ITEM : BLOCK;
        }
    }

    private final Map<ModelCacheKey, Map<DirectionKey, ListMultimap<RenderType, BakedQuad>>> cachedBlockQuads = new ConcurrentHashMap<>();
    private final Set<RenderType> knownRenderTypes = new HashSet<>();
    private volatile List<RenderType> renderTypes = null;

    /**
     * Creates the key for the cache of this model. This method is not called for item models.
     * @param state
     * @param random
     * @param contex
     * @return
     */
    protected ModelCacheKey createCacheKey(BlockState state, RandomSource random, ModelContext contex) {
        return new ModelCacheKey(contex, state);
    }

    protected boolean invalidateCacheFor(ModelType type, BlockState state, RandomSource random, ModelContext context) {
        return false;
    }

    public void clearCache() {
        cachedBlockQuads.clear();
        synchronized (knownRenderTypes) {
            knownRenderTypes.clear();
            renderTypes = null;
        }
    }

    public void clearCache(ModelCacheKey key) {
        cachedBlockQuads.remove(key);
    }

    /**
     * Enabled or disables ambient occlusion for this model.
     * 
     * @return {@code true} if ambient occlusion should be used, {@code false}
     *         otherwise. If the model's default behaviour should be kept, return
     *         {@code null}.
     */
    public @Nullable Boolean useAmbientOcclusion() {
        return null;
    }

    protected abstract Mesh getMesh(ModelType type, BakedModel originalModel, BlockState state, RandomSource random, ModelContext context);


    private static class DirectionKey {
        private static final HashMap<Direction, DirectionKey> keys;
        static {
            keys = new HashMap<>(Direction.values().length + 1);
            for (Direction dir : Direction.values()) {
                keys.put(dir, new DirectionKey());
            }
            keys.put(null, new DirectionKey());
        }

        private DirectionKey() {
        }

        public static DirectionKey of(Direction direction) {
            return keys.get(direction);
        }
    }

    public final List<BakedQuad> getQuads(ModelType type, BakedModel originalModel, BlockState state, RandomSource random, RenderType renderType, Direction cullface, ModelContext context) {
        boolean isItem = type == ModelType.ITEM;
        ModelCacheKey key = !isItem ? createCacheKey(state, random, context) : new ModelCacheKey(context);

        if (invalidateCacheFor(type, state, random, context)) {
            cachedBlockQuads.remove(key);
        }

        Map<DirectionKey, ListMultimap<RenderType, BakedQuad>> quadsByCullface = cachedBlockQuads.get(key);
        if (quadsByCullface == null) {
            quadsByCullface = buildQuads(type, originalModel, state, random, key.context());
            Map<DirectionKey, ListMultimap<RenderType, BakedQuad>> existing = cachedBlockQuads.putIfAbsent(key, quadsByCullface);
            if (existing != null) {
                quadsByCullface = existing;
            }
        }

        ListMultimap<RenderType, BakedQuad> quadsByRenderType = quadsByCullface.get(DirectionKey.of(cullface));
        if (quadsByRenderType == null) {
            return List.of();
        }

        if (isItem) {
            return new ArrayList<>(quadsByRenderType.values());
        }

        if (!quadsByRenderType.containsKey(renderType)) {
            return List.of();
        }
        return quadsByRenderType.get(renderType);
    }

    private Map<DirectionKey, ListMultimap<RenderType, BakedQuad>> buildQuads(ModelType type, BakedModel originalModel, BlockState state, RandomSource random, ModelContext context) {
        Mesh mesh = getMesh(type, originalModel, state, random, context);

        Map<DirectionKey, ListMultimap<RenderType, BakedQuad>> map = new HashMap<>(6);
        for (Face face : mesh.getFaces()) {
            DirectionKey cullfaceKey = DirectionKey.of(face.getCullface());
            ListMultimap<RenderType, BakedQuad> mm = map.computeIfAbsent(cullfaceKey,
                    x -> ListMultimapBuilder.hashKeys(RenderType.m_110506_().size())
                            .arrayListValues().build());
            mm.putAll(face.getRenderType(), face.build());
        }

        synchronized (knownRenderTypes) {
            boolean changed = false;
            for (ListMultimap<RenderType, BakedQuad> mm : map.values()) {
                changed |= knownRenderTypes.addAll(mm.keySet());
            }
            if (changed || renderTypes == null) {
                renderTypes = List.copyOf(knownRenderTypes);
            }
        }
        return map;
    }

    public final List<RenderType> getSupportedRenderTypes() {
        List<RenderType> types = renderTypes;
        return cachedBlockQuads.isEmpty() || types == null ? RenderType.m_110506_() : types;
    }





    public static BakedModel getModel(BlockState state) {
        return Minecraft.m_91087_().m_91304_().m_119430_().m_110893_(state);
    }

    public static boolean hasDynamicModel(BlockState state) {
        BakedModel model = getModel(state);
        return model instanceof IDynamicBakedModel;
    }

    public static Optional<DLModel> of(BlockState state) {
        if (!hasDynamicModel(state)) return Optional.empty();
        return Optional.ofNullable(((IDynamicBakedModel)getModel(state)).getModel());
    }

    public static void renderModel(PoseStack.Pose pose, VertexConsumer consumer, @Nullable BlockState state, ModelContext context) {
        of(state).ifPresent(x -> x.render(pose, consumer, state, context));
    }

    public static void renderModel(PoseStack.Pose pose, VertexConsumer consumer, ModelType type, @Nullable BlockState state, ModelContext context, DLColor color, int packedLight, int packedOverlay) {
        of(state).ifPresent(x -> x.render(pose, consumer, type, state, context, color, packedLight, packedOverlay));
    }

    public void render(PoseStack.Pose pose, VertexConsumer consumer, @Nullable BlockState state, ModelContext context) {
        render(pose, consumer, ModelType.BLOCK, state, context, DLColor.WHITE, 0, 0);
    }

    public void render(PoseStack.Pose pose, VertexConsumer consumer, ModelType type, @Nullable BlockState state, ModelContext context, DLColor color, int packedLight, int packedOverlay) {
        RandomSource randomSource = RandomSource.m_216327_();
        long seed = 42L;
        BakedModel originalModel = DLBlockModelRegistry.getOriginalModel(type, state);
        for (RenderType renderType : getSupportedRenderTypes()) {
            for (Direction direction : Direction.values()) {
                randomSource.m_188584_(seed);
                renderQuadList(pose, consumer, color, getQuads(type, originalModel, state, randomSource, renderType, direction, context), packedLight, packedOverlay);
            }
            randomSource.m_188584_(seed);
            renderQuadList(pose, consumer, color, getQuads(type, originalModel, state, randomSource, renderType, null, context), packedLight, packedOverlay);
        }
        
    }

    private static void renderQuadList(PoseStack.Pose pose, VertexConsumer consumer, DLColor color, List<BakedQuad> quads, int packedLight, int packedOverlay) {
        BakedQuad bakedQuad;
        float r;
        float g;
        float b;
        for (Iterator<BakedQuad> iterator = quads.iterator(); iterator.hasNext(); consumer.m_85987_(pose, bakedQuad, r, g, b, packedLight, packedOverlay)) {
            bakedQuad = (BakedQuad)iterator.next();
            if (bakedQuad.m_111304_()) {
                r = Mth.m_14036_(color.getRedF(), 0.0F, 1.0F);
                g = Mth.m_14036_(color.getGreenF(), 0.0F, 1.0F);
                b = Mth.m_14036_(color.getBlueF(), 0.0F, 1.0F);
            } else {
                r = 1.0F;
                g = 1.0F;
                b = 1.0F;
            }
        }

    }
}
