/*
 * DragonLib 3 - 1.20.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.client.render;

import java.util.Arrays;

import de.mrjulsen.mcdragonlib.DragonLib;
import de.mrjulsen.mcdragonlib.client.util.DLTexture;
import de.mrjulsen.mcdragonlib.client.util.DLSprite;
import de.mrjulsen.mcdragonlib.client.util.DLGuiGraphics;
import de.mrjulsen.mcdragonlib.client.util.GuiUtils;
import net.minecraft.resources.ResourceLocation;

public enum GuiIcons {
    EMPTY("empty", 0, 0),
    CHECK("check", 1, 0),
    CROSS("cross", 2, 0),
    WARN("warn", 3, 0),
    CHECKMARK("checkmark", 4, 0),
    BULLET("bullet", 5, 0),
    ARROW_DOWN("arrow_down", 6, 0),
    ARROW_UP("arrow_up", 7, 0),
    ARROW_LEFT("arrow_left", 8, 0),
    ARROW_RIGHT("arrow_right", 9, 0),
    X("x", 10, 0),
    BULLET_S("bullet_s", 11, 0),
    CHECK_S("check_s", 12, 0),


    OPEN_ARROW_DOWN("open_arrow_down", 6, 1),
    OPEN_ARROW_UP("open_arrow_up", 7, 1),
    OPEN_ARROW_LEFT("open_arrow_left", 8, 1),
    OPEN_ARROW_RIGHT("open_arrow_right", 9, 1);
    
    private String id;
    private int u;
    private int v;

    public static final int ICON_SIZE = 16;
    public static final DLTexture ICON_TEXTURE = new DLTexture(new ResourceLocation(DragonLib.MODID, "textures/gui/icons.png"), 256, 256);

    GuiIcons(String id, int u, int v) {
        this.id = id;
        this.u = u;
        this.v = v;
    }

    public String getId() {
        return id;
    }

    public int getUMultiplier() {
        return u;
    }

    public int getVMultiplier() {
        return v;
    }

    public int getU() {
        return u * ICON_SIZE;
    }

    public int getV() {
        return v * ICON_SIZE;
    }

    public static GuiIcons getByStringId(String id) {
        return Arrays.stream(values()).filter(x -> x.getId().equals(id)).findFirst().orElse(GuiIcons.EMPTY);
    }

    public void render(de.mrjulsen.mcdragonlib.client.gui.v2.render.DLGuiGraphics graphics, int x, int y) {
        de.mrjulsen.mcdragonlib.client.gui.v2.render.GuiUtils.texture(graphics, GuiIcons.ICON_TEXTURE, x, y, ICON_SIZE, ICON_SIZE, getU(), getV(), ICON_SIZE, ICON_SIZE);
    }

    @Deprecated
    public void render(DLGuiGraphics graphics, int x, int y) {
        GuiUtils.drawTexture(GuiIcons.ICON_TEXTURE, graphics, x, y, ICON_SIZE, ICON_SIZE, getU(), getV());
    }

    public DLSprite getAsSprite(int renderWidth, int renderHeight) {
        return new DLSprite(ICON_TEXTURE, renderWidth, renderHeight, getU(), getV(), ICON_SIZE, ICON_SIZE);
    }
}
