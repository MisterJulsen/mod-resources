/*
 * DragonLib 3 - 1.20.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.client.gui.v2.text.markup;

import java.util.Optional;

import de.mrjulsen.mcdragonlib.client.gui.v2.text.document.TextDocument;
import de.mrjulsen.mcdragonlib.client.gui.v2.text.style.StyleFlag;
import de.mrjulsen.mcdragonlib.client.gui.v2.text.style.TextStyle;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.network.chat.TextColor;

public final class ComponentText {

    private ComponentText() {
    }

    public static String fromComponent(FormattedText text) {
        return fromComponent(text, ComponentTextParser.SECTION);
    }

    public static String fromComponent(FormattedText text, ComponentTextParser parser) {
        StringBuilder builder = new StringBuilder();
        Style[] previous = { null };

        text.m_7451_((style, content) -> {
            if (!style.equals(previous[0])) {
                appendStyle(builder, style, parser, previous[0] == null);
                previous[0] = style;
            }
            builder.append(content);
            return Optional.empty();
        }, Style.f_131099_);

        return builder.toString();
    }

    public static MutableComponent toComponent(String text) {
        return toComponent(text, ComponentTextParser.SECTION);
    }

    public static MutableComponent toComponent(String text, ComponentTextParser parser) {
        MutableComponent root = Component.m_237119_();
        String[] lines = TextDocument.normalizeLineEndings(text).split("\n", -1);

        for (int line = 0; line < lines.length; line++) {
            if (line > 0) {
                root.m_7220_(Component.m_237113_("\n"));
            }
            appendLine(root, lines[line], parser);
        }
        return root;
    }

    private static void appendLine(MutableComponent root, String line, ComponentTextParser parser) {
        parser.scan(line, (from, to, style, code) -> {
            if (code || from >= to) {
                return;
            }
            root.m_7220_(Component.m_237113_(line.substring(from, to)).m_6270_(toVanillaStyle(style)));
        });
    }

    public static Style toVanillaStyle(TextStyle style) {
        Style vanilla = Style.f_131099_;
        if (style.color() != TextStyle.DEFAULT.color()) {
            vanilla = vanilla.m_131148_(TextColor.m_131266_(style.color() & 0xFFFFFF));
        }
        return style.applyTo(vanilla);
    }

    private static void appendStyle(StringBuilder builder, Style style, ComponentTextParser parser, boolean first) {
        if (!first) {
            builder.append(parser.code(ChatFormatting.RESET.m_178510_()));
        }

        TextColor color = style.m_131135_();
        if (color != null) {
            builder.append(parser.colorCode(color.m_131265_()));
        }
        for (StyleFlag flag : StyleFlag.all()) {
            ChatFormatting formatting = flag.effect().formatting();
            if (formatting != null && flag.effect().matchesVanilla(style)) {
                builder.append(parser.code(formatting.m_178510_()));
            }
        }
    }

    public static boolean isPlain(Style style) {
        if (style.m_131135_() != null) {
            return false;
        }
        for (StyleFlag flag : StyleFlag.all()) {
            if (flag.effect().matchesVanilla(style)) {
                return false;
            }
        }
        return true;
    }
}
