/*
 * DragonLib 3 - 1.20.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.block;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;

public abstract class DLSyncedBlockEntity extends BlockEntity {

	public DLSyncedBlockEntity(BlockEntityType<?> type, BlockPos pos, BlockState state) {
		super(type, pos, state);
	}

	@Override
	public CompoundTag m_5995_() {
		return this.m_187480_();
	}

	@Override
	public ClientboundBlockEntityDataPacket m_58483_() {
		return ClientboundBlockEntityDataPacket.m_195640_(this);
	}

	// Special handling for client update packets
	public void readClient(CompoundTag tag) {
		m_142466_(tag);
	}

	// Special handling for client update packets
	public CompoundTag writeClient(CompoundTag tag) {
		m_183515_(tag);
		return tag;
	}

	public void sendData() {
		if (f_58857_ instanceof ServerLevel serverLevel) {			
			serverLevel.m_7726_().m_8450_(m_58899_());
		}
	}

	public void notifyUpdate() {
		m_6596_();
		sendData();
	}

	public LevelChunk containedChunk() {
		return f_58857_.m_46745_(f_58858_);
	}
}
