/*
 * DragonLib 3 - 1.20.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.client.util;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

import org.jetbrains.annotations.ApiStatus;
import org.joml.Matrix4f;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;

import de.mrjulsen.mcdragonlib.DragonLib;
import de.mrjulsen.mcdragonlib.client.ber.BERGraphics;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.world.level.Level;

@ApiStatus.Internal
public final class SmoothTextDeferred {

    private static final DeferredSource SOURCE = new DeferredSource();
    private static Matrix4f modelViewMatrix;
    private static boolean renderingLevel = false;
    private static boolean deferralLogged = false;

    private SmoothTextDeferred() {}

    public static boolean shouldDefer(DLGraphics graphics) {
        if (!renderingLevel || !(graphics instanceof BERGraphics<?> berGraphics) || berGraphics.blockEntity() == null) {
            return false;
        }
        Level level = berGraphics.blockEntity().m_58904_();
        boolean defer = level != null && level != Minecraft.m_91087_().f_91073_;
        if (defer && !deferralLogged) {
            deferralLogged = true;
            DragonLib.LOGGER.info("Smooth text of block entities in {} is drawn late in the frame.", level.getClass().getName());
        }
        return defer;
    }

    public static MultiBufferSource source() {
        if (modelViewMatrix == null) {
            modelViewMatrix = new Matrix4f(RenderSystem.getModelViewMatrix());
        }
        return SOURCE;
    }

    public static void draw() {
        if (SOURCE.isEmpty()) {
            modelViewMatrix = null;
            return;
        }
        PoseStack modelViewStack = RenderSystem.getModelViewStack();
        modelViewStack.m_85836_();
        if (modelViewMatrix != null) {
            modelViewStack.m_85850_().m_252922_().set(modelViewMatrix);
        }
        RenderSystem.applyModelViewMatrix();
        try {
            SOURCE.draw();
        } finally {
            modelViewStack.m_85849_();
            RenderSystem.applyModelViewMatrix();
            modelViewMatrix = null;
        }
    }

    public static void beginLevelRendering() {
        SOURCE.discard();
        modelViewMatrix = null;
        renderingLevel = true;
    }

    public static void endLevelRendering() {
        renderingLevel = false;
        SOURCE.discard();
        modelViewMatrix = null;
    }

    private static final class DeferredSource implements MultiBufferSource {

        private final Map<RenderType, BufferBuilder> builders = new LinkedHashMap<>();
        private final Set<RenderType> started = new LinkedHashSet<>();

        @Override
        public VertexConsumer m_6299_(RenderType type) {
            BufferBuilder builder = builders.computeIfAbsent(type, t -> new BufferBuilder(t.m_110507_()));
            if (started.add(type)) {
                builder.m_166779_(type.m_173186_(), type.m_110508_());
            }
            return builder;
        }

        boolean isEmpty() {
            return started.isEmpty();
        }

        void draw() {
            for (RenderType type : started) {
                type.m_276775_(builders.get(type), RenderSystem.getVertexSorting());
            }
            started.clear();
        }

        void discard() {
            for (RenderType type : started) {
                BufferBuilder builder = builders.get(type);
                if (builder.m_85732_()) {
                    builder.m_231175_().m_231200_();
                }
            }
            started.clear();
        }
    }
}
