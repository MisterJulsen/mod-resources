/*
 * DragonLib 3 - 1.20.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.client.util;

import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Optional;

import org.jetbrains.annotations.ApiStatus;

import de.mrjulsen.mcdragonlib.DragonLib;
import de.mrjulsen.mcdragonlib.client.compat.shader.ShaderCompat;
import de.mrjulsen.mcdragonlib.config.ModClientConfig;
import net.minecraft.client.renderer.RenderStateShard;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.ShaderInstance;
import net.minecraft.resources.ResourceLocation;

@ApiStatus.Experimental
public final class SmoothTextRenderTypes {

    public static final ResourceLocation SHADER_ID = new ResourceLocation(DragonLib.MODID, "rendertype_smooth_text");
    public static final ResourceLocation INTENSITY_SHADER_ID = new ResourceLocation(DragonLib.MODID, "rendertype_smooth_text_intensity");

    private static final Map<RenderType, RenderType> TYPES = new IdentityHashMap<>();
    private static ShaderInstance shader;
    private static ShaderInstance intensityShader;
    private static final RenderStateShard.ShaderStateShard SHADER_STATE = new RenderStateShard.ShaderStateShard(() -> shader);
    private static final RenderStateShard.ShaderStateShard INTENSITY_SHADER_STATE = new RenderStateShard.ShaderStateShard(() -> intensityShader);

    private SmoothTextRenderTypes() {}

    @ApiStatus.Internal
    public static void setShader(ShaderInstance instance) {
        shader = instance;
    }

    @ApiStatus.Internal
    public static void setIntensityShader(ShaderInstance instance) {
        intensityShader = instance;
    }

    @ApiStatus.Internal
    public static void onShaderLoadFailed(ResourceLocation id, Throwable error) {
        shader = null;
        intensityShader = null;
        DragonLib.LOGGER.error("Unable to load the shader '" + id + "'. Smooth text rendering is disabled.", error);
    }

    public static boolean isEnabled() {
        if (shader == null || intensityShader == null) {
            return false;
        }
        return switch (ModClientConfig.getSmoothTextModeSafe()) {
            case ON -> true;
            case OFF -> false;
            default -> !ShaderCompat.isShaderPackActive();
        };
    }

    public static RenderType getFor(RenderType type) {
        return TYPES.computeIfAbsent(type, SmoothTextRenderTypes::createVariant);
    }

    private static RenderType createVariant(RenderType type) {
        if (!(type instanceof RenderType.CompositeRenderType composite)) {
            return type;
        }
        RenderType.CompositeState state = composite.m_173265_();
        RenderStateShard.ShaderStateShard shaderState;
        if (state.f_173274_ == RenderStateShard.f_173086_) {
            shaderState = SHADER_STATE;
        } else if (state.f_173274_ == RenderStateShard.f_173087_) {
            shaderState = INTENSITY_SHADER_STATE;
        } else {
            return type;
        }
        Optional<ResourceLocation> texture = state.f_110576_.m_142706_();
        if (texture.isEmpty()) {
            return type;
        }
        return RenderType.m_173215_("dragonlib_smooth_" + (shaderState == SHADER_STATE ? "text_" : "text_intensity_") + texture.get(), type.m_110508_(), type.m_173186_(), type.m_110507_(), false, true,
            RenderType.CompositeState.m_110628_()
                .m_173292_(shaderState)
                .m_173290_(new RenderStateShard.TextureStateShard(texture.get(), false, false))
                .m_110685_(state.f_110577_)
                .m_110663_(state.f_110581_)
                .m_110671_(state.f_110583_)
                .m_110669_(state.f_110586_)
                .m_110687_(state.f_110589_)
                .m_110691_(false));
    }
}
