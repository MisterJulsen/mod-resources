/*
 * DragonLib 3 - 1.20.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.client.gui.v2.window;

import java.nio.file.Path;
import java.util.List;
import java.util.function.Function;

import org.lwjgl.glfw.GLFW;

import de.mrjulsen.mcdragonlib.util.TextUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;

/**
 * Bridge between Minecraft's Screen and the v2 GUI: forwards input, rendering and ticks to a
 * {@link DLWindowManager} and remembers the screen it was opened from.
 * <p>Usually there is no need to subclass this, see {@link #open(Function)}.</p>
 */
public class DLScreen extends Screen {

    private final DLWindowManager manager = new DLWindowManager();
    private final Function<DLWindowManager, DLWindow> initialWindow;
    private final Screen previousScreen;
    private boolean initialized;

    /**
     * @param initialWindow builds the window to open as soon as the screen is initialized; may be null
     *                      for a screen whose windows are opened later
     */
    public DLScreen(Function<DLWindowManager, DLWindow> initialWindow) {
        super(TextUtils.empty());
        this.initialWindow = initialWindow;
        this.previousScreen = Minecraft.m_91087_().f_91080_;
        this.manager.setCloseHandler(m -> Minecraft.m_91087_().m_91152_(m.showPreviousScreenOnClose.get() ? previousScreen : null));
    }

    /**
     * Opens a new screen with a single window on it. The usual entry point into a v2 GUI.
     */
    public static void open(Function<DLWindowManager, DLWindow> window) {
        Minecraft.m_91087_().m_91152_(new DLScreen(window));
    }

    public DLWindowManager getWindowManager() {
        return manager;
    }

    @Override
    protected void m_7856_() {
        super.m_7856_();
        manager.resize(f_96543_, f_96544_);
        if (!initialized) {
            initialized = true;
            if (initialWindow != null) {
                manager.openWindow(initialWindow.apply(manager));
            }
        }
    }

    @Override
    public void m_88315_(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        m_280273_(guiGraphics);
        manager.render(guiGraphics, Minecraft.m_91087_().f_91062_, partialTick, mouseX, mouseY);
    }

    @Override
    public void m_86600_() {
        super.m_86600_();
        manager.tick();
    }

    @Override
    public void m_94757_(double mouseX, double mouseY) {
        manager.mouseMoved(mouseX, mouseY);
    }

    @Override
    public boolean m_6375_(double mouseX, double mouseY, int button) {
        return manager.mousePressed(mouseX, mouseY, button) || super.m_6375_(mouseX, mouseY, button);
    }

    @Override
    public boolean m_6348_(double mouseX, double mouseY, int button) {
        return manager.mouseReleased(mouseX, mouseY, button) || super.m_6348_(mouseX, mouseY, button);
    }

    @Override
    public boolean m_7979_(double mouseX, double mouseY, int button, double dragX, double dragY) {
        return manager.mouseDragged(mouseX, mouseY, button, dragX, dragY) || super.m_7979_(mouseX, mouseY, button, dragX, dragY);
    }

    @Override
    public boolean m_6050_(double mouseX, double mouseY, double delta) {
        return manager.mouseScrolled(mouseX, mouseY, 0, delta) || super.m_6050_(mouseX, mouseY, delta);
    }

    @Override
    public boolean m_7933_(int keyCode, int scanCode, int modifiers) {
        if (manager.keyPressed(keyCode, scanCode, modifiers)) {
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_ESCAPE && manager.escapePressed()) {
            return true;
        }
        return super.m_7933_(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean m_7920_(int keyCode, int scanCode, int modifiers) {
        return manager.keyReleased(keyCode, scanCode, modifiers) || super.m_7920_(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean m_5534_(char codePoint, int modifiers) {
        return manager.charTyped(codePoint, modifiers) || super.m_5534_(codePoint, modifiers);
    }

    @Override
    public void m_7400_(List<Path> paths) {
        if (!manager.filesDropped(paths)) {
            super.m_7400_(paths);
        }
    }

    @Override
    public void m_7379_() {
        manager.onClosed();
        super.m_7379_();
    }

    @Override
    public boolean m_7043_() {
        return manager.isPauseScreen();
    }
}
