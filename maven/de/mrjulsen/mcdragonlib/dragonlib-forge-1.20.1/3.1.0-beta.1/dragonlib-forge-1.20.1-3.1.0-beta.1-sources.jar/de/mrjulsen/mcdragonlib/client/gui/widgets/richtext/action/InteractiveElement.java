/*
 * DragonLib 3 - 1.20.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.client.gui.widgets.richtext.action;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.network.chat.Component;

public class InteractiveElement {

    public static interface IInteraction {
        boolean highlightOnHover();
    }

    public record ClickAction(String actionName, String value) implements IInteraction {

        public static final String OPEN_URL = "open_url";
        public static final String COPY_TO_CLIPBAORD = "copy_to_clipboard";
        @Override
        public boolean highlightOnHover() {
            return true;
        }
    }

    public record HoverAction(Component text) implements IInteraction {
        @Override
        public boolean highlightOnHover() {
            return false;
        }
    }

    public int start;
    public int end;

    public Map<Class<? extends IInteraction>, IInteraction> interactions = new HashMap<>();

    public InteractiveElement(int start, int end) {
        this.start = start;
        this.end = end;
    }
    
    public <T extends IInteraction> InteractiveElement withAction(T action) {
        interactions.put(action.getClass(), action);
        return this;
    }

    public <T extends IInteraction> boolean hasActionFromType(Class<T> type) {
        return interactions.containsKey(type);
    }

    public <T extends IInteraction> T getActionFromType(Class<T> type) {  
        return (T)interactions.get(type);
    }

    public boolean shouldHighlightOnHover() {
        for (IInteraction el : interactions.values()) {
            if (el.highlightOnHover()) return true;
        }
        return false;
    }

    public void copyFrom(InteractiveElement other) {
        interactions.putAll(other.interactions);
    }

    public boolean contains(int codePointIndex) {
        return codePointIndex >= start && codePointIndex < end;
    }

    public boolean intersects(int otherStart, int otherEnd) {
        return Math.max(this.start, otherStart) < Math.min(this.end, otherEnd);
    }

    public int length() {
        return end - start;
    }
}
