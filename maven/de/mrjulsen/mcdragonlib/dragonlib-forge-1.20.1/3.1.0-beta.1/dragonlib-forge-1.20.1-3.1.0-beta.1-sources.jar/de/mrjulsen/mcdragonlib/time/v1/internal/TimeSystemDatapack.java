/*
 * DragonLib 3 - 1.20.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.time.v1.internal;

import java.io.Reader;
import java.util.Optional;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import de.mrjulsen.mcdragonlib.DragonLib;
import de.mrjulsen.mcdragonlib.time.v1.TimeSystem;
import de.mrjulsen.mcdragonlib.util.DLUtils;
import dev.architectury.registry.ReloadListenerRegistry;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.PackType;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.SimplePreparableReloadListener;
import net.minecraft.util.GsonHelper;
import net.minecraft.util.profiling.ProfilerFiller;

/**
 * Loads the time system from {@code data/dragonlib/config/time_system.json}.
 * <p>Example:</p>
 * <pre>{@code
 * {
 *   "ticks_per_day": 24000,   // optional, default 24000
 *   "daytime_offset": 6000,   // optional, ticks the clock shows at tick 0, default ticks_per_day / 4 (06:00)
 *   "zones": [   // optional, uncovered parts run at 20 ticks per second
 *     { "start_tick": 0, "end_tick": 12000, "tps": 20 },
 *     { "start_tick": 12000, "end_tick": 24000, "tps": 40 }
 *   ]
 * }
 * }</pre>
 */
public final class TimeSystemDatapack extends SimplePreparableReloadListener<Optional<TimeSystem>> {

    public static final ResourceLocation LOCATION = DLUtils.resourceLocation(DragonLib.MODID, "config/time_system.json");

    private TimeSystemDatapack() {}

    public static void register() {
        ReloadListenerRegistry.register(PackType.SERVER_DATA, new TimeSystemDatapack());
    }

    @Override
    protected Optional<TimeSystem> m_5944_(ResourceManager resourceManager, ProfilerFiller profiler) {
        Optional<Resource> resource = resourceManager.m_213713_(LOCATION);
        if (resource.isEmpty()) {
            return Optional.empty();
        }
        try (Reader reader = resource.get().m_215508_()) {
            return Optional.of(parse(GsonHelper.m_13859_(reader)));
        } catch (Exception e) {
            DragonLib.LOGGER.error("The time system in {} is invalid and was ignored.", LOCATION, e);
            return Optional.empty();
        }
    }

    @Override
    protected void apply(Optional<TimeSystem> system, ResourceManager resourceManager, ProfilerFiller profiler) {
        TimeSystemState.setDatapack(system.orElse(null));
        system.ifPresent(s -> DragonLib.LOGGER.info("Loaded the time system from a datapack: {}", s));
    }

    static TimeSystem parse(JsonObject json) {
        long ticksPerDay = GsonHelper.m_13828_(json, "ticks_per_day", TimeSystem.VANILLA_TICKS_PER_DAY);
        TimeSystem.Builder builder = TimeSystem.builder(ticksPerDay).clockOffset(GsonHelper.m_144742_(json, "daytime_offset", ticksPerDay / 4.0));
        if (json.has("zones")) {
            for (JsonElement element : GsonHelper.m_13933_(json, "zones")) {
                JsonObject zone = GsonHelper.m_13918_(element, "zone");
                builder.section(GsonHelper.m_13921_(zone, "start_tick"), GsonHelper.m_13921_(zone, "end_tick"), GsonHelper.m_144784_(zone, "tps"));
            }
        }
        return builder.build();
    }
}
