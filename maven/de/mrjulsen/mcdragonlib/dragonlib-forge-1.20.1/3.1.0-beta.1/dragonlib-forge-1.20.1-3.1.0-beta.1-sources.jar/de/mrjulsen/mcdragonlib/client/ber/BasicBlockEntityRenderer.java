/*
 * DragonLib 3 - 1.20.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.client.ber;

import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.world.level.block.entity.BlockEntity;

public abstract class BasicBlockEntityRenderer<T extends BlockEntity> extends SafeBlockEntityRenderer<T> {
    
    protected final Font font;

    public BasicBlockEntityRenderer(BlockEntityRendererProvider.Context context) {
        super(context);
        this.font = context.m_173586_();
    }

    @Override
    protected final void renderSafe(BERGraphics<T> graphics, float partialTick) {        
        graphics.poseStack().m_85836_();
        graphics.poseStack().m_85837_(0.5D, 0, 0.5F);
        graphics.poseStack().m_252880_(-0.5f, 1, -0.5f);
        graphics.poseStack().m_85841_(0.0625f, -0.0625f, 0.0625f);

        renderBlock(graphics, partialTick);

        graphics.poseStack().m_85849_();
        
    }

    protected abstract void renderBlock(BERGraphics<T> graphics, float partialTick);
}
