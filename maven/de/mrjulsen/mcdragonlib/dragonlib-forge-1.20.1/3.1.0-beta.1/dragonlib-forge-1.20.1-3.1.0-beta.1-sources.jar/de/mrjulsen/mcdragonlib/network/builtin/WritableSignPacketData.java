/*
 * DragonLib 3 - 1.20.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.network.builtin;

import de.mrjulsen.mcdragonlib.block.DLWritableSignBlockEntity;
import de.mrjulsen.mcdragonlib.data.DLStatus;
import de.mrjulsen.mcdragonlib.network.NetworkPacketContext;
import de.mrjulsen.mcdragonlib.network.NetworkPacketData;
import de.mrjulsen.mcdragonlib.util.NbtUtils;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerPlayer;

public class WritableSignPacketData extends NetworkPacketData {

    private static final String NBT_POS = "Pos";
    private static final String NBT_MESSAGES = "Messages";

    private String[] messages;
    private BlockPos pos;

    public WritableSignPacketData(DLStatus status) {
        super(status);
    }

    public WritableSignPacketData(BlockPos pos, String[] messages) {
        super(DLStatus.OK);
        this.pos = pos;
        this.messages = messages;
    }
    

    @Override
    protected void write(CompoundTag nbt) {
        NbtUtils.putNbtPos(nbt, NBT_POS, pos);
        ListTag msgs = new ListTag();
        for (String msg : messages) {
            msgs.add(StringTag.m_129297_(msg));
        }
        nbt.m_128365_(NBT_MESSAGES, msgs);
    }

    @Override
    protected void read(CompoundTag nbt) {
        this.pos = NbtUtils.getNbtBlockPos(nbt, NBT_POS);
        this.messages = nbt.m_128437_(NBT_MESSAGES, Tag.f_178201_).stream().map(x -> ((StringTag)x).m_7916_()).toArray(String[]::new);
    }

    public static void handler(WritableSignPacketData packet, NetworkPacketContext context) {
        context.queue(() -> {
            ServerPlayer sender = (ServerPlayer)context.getPlayer();
            if (sender.m_9236_().m_7702_(packet.pos) instanceof DLWritableSignBlockEntity blockEntity) {
                blockEntity.setTexts(packet.messages);
            }
        });
    }
}

