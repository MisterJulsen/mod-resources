/*
 * DragonLib 3 - 1.20.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.client.gui.widgets.richtext;

import de.mrjulsen.mcdragonlib.mixin.client.FontAccessor;
import de.mrjulsen.mcdragonlib.util.TextUtils;
import net.minecraft.client.gui.font.FontSet;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import org.apache.commons.lang3.mutable.MutableFloat;

public class TextSegment {

    private static final String NBT_TEXT = "Text";
    private static final String NBT_STYLE = "Style";

    public record ImmutableTextSegment(String text, TextStyle style) {}

    private StringBuilder text;
    private TextStyle style;

    public TextSegment(StringBuilder text, TextStyle style) {
        this.text = text;
        this.style = style;
    }
    public StringBuilder stringBuilder() {
        return text;
    }
    public String text() {
        return text.toString();
    }
    public TextStyle style() {
        return style;
    }

    public int charLength() {
        return stringBuilder().length();
    }

    public int length() {
        return stringBuilder().codePointCount(0, text.length());
    }

    public int codePointLength() {
        return stringBuilder().codePointCount(0, text.length());
    }

    public boolean isEmpty() {
        return stringBuilder().isEmpty();
    }

    public TextSegment copy() {
        return new TextSegment(new StringBuilder(this.text), this.style.copy());
    }

    public CompoundTag toNbt() {
        CompoundTag nbt = new CompoundTag();
        nbt.m_128359_(NBT_TEXT, text.toString());
        nbt.m_128365_(NBT_STYLE, style.toNbt());
        return nbt;
    }

    public static TextSegment fromNbt(CompoundTag nbt) {
        return new TextSegment(new StringBuilder(nbt.m_128461_(NBT_TEXT)), TextStyle.fromNbt(nbt.m_128469_(NBT_STYLE)));
    }

    public Component toComponent() {
        return TextUtils.text(text()).m_130948_(style().toStyle());
    }

    public static TextSegment fromComponent(Component component) {
        return new TextSegment(new StringBuilder(component.getString()), TextStyle.fromStyle(component.m_7383_()));
    }

    public float width() {
        if (text == null || text.length() == 0) {
            return 0.0F;
        }

        MutableFloat mutableFloat = new MutableFloat();
        FontAccessor accessor = (FontAccessor) style().font();
        FontSet fontSet = accessor.dragonlib$invokeGetFontSet(Style.f_131100_);
        iterate(this, 0, (idx, style, c) -> {
            mutableFloat.add(fontSet.m_243128_(c, accessor.dragonlib$filterFishyGlyphs()).m_83827_(style().bold()));
            return true;
        }, length());
        return mutableFloat.floatValue() * style().scale();
    }

    public ImmutableTextSegment copyImmutable() {
        return copyImmutable(0, length());
    }

    public ImmutableTextSegment copyImmutable(int codePointStartIndex, int codePointEndIndex) {
        if (codePointStartIndex < 0 || codePointEndIndex > length() || codePointStartIndex > codePointEndIndex) {
            throw new IndexOutOfBoundsException("Cannot copy immutable part from code point index " + codePointStartIndex + " to " + codePointEndIndex + " for segment with code point length " + length());
        }
        String originalString = stringBuilder().toString();
        int charStartIndex = originalString.offsetByCodePoints(0, codePointStartIndex);
        int charEndIndex = originalString.offsetByCodePoints(0, codePointEndIndex);
        return new ImmutableTextSegment(originalString.substring(charStartIndex, charEndIndex), style().copy());
    }

    @FunctionalInterface
    public interface CharCallback {
        boolean accept(int codePointIndexInIteration, TextStyle style, int codePoint);
    }

    private static final int REPLACEMENT_CHAR_CODEPOINT = 0xFFFD;

    public static boolean iterate2(TextSegment segment, int skip, CharCallback sink, int count) {
        final StringBuilder sb = segment.stringBuilder();
        final int charLength = sb.length();

        if (skip < 0 || count <= 0) {
            return true;
        }

        int currentCodePointIndex = 0;
        int iteratedCodePoints = 0;
        int charIdx = 0;

        while (charIdx < charLength && iteratedCodePoints < count) {
            int codePoint = sb.codePointAt(charIdx);
            int charsForThisCodePoint = Character.charCount(codePoint);

            if (currentCodePointIndex >= skip) {
                if (!sink.accept(iteratedCodePoints, segment.style(), codePoint)) {
                    return false;
                }
                iteratedCodePoints++;
            }

            currentCodePointIndex++;
            charIdx += charsForThisCodePoint;
        }
        return true;
    }

    public static boolean iterate(TextSegment segment, int skipCodePoints, CharCallback sink, int countCodePoints) {
        final StringBuilder sb = segment.stringBuilder();
        final int charLength = sb.length();

        if (skipCodePoints < 0 || countCodePoints <= 0) {
            return true;
        }

        int currentOverallCodePointIndex = 0;
        int iteratedCodePointsInThisCall = 0;
        int charIdx = 0;

        while (charIdx < charLength && iteratedCodePointsInThisCall < countCodePoints) {
            int codePoint = sb.codePointAt(charIdx);
            int charsForThisCodePoint = Character.charCount(codePoint);

            if (currentOverallCodePointIndex >= skipCodePoints) {
                if (!sink.accept(iteratedCodePointsInThisCall, segment.style(), codePoint)) {
                    return false;
                }
                iteratedCodePointsInThisCall++;
            }

            currentOverallCodePointIndex++;
            charIdx += charsForThisCodePoint;
        }
        return true;
    }
}
