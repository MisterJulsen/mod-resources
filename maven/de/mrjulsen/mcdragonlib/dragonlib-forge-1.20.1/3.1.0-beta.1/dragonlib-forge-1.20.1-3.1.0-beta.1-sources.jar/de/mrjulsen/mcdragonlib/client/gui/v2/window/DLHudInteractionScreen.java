/*
 * DragonLib 3 - 1.20.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.client.gui.v2.window;

import de.mrjulsen.mcdragonlib.DragonLib;
import de.mrjulsen.mcdragonlib.util.TextUtils;
import net.minecraft.client.gui.screens.Screen;

import java.nio.file.Path;
import java.util.List;

public final class DLHudInteractionScreen extends Screen {
    public DLHudInteractionScreen() {
        super(TextUtils.EMPTY);
    }

    @Override
    public void m_94757_(double mouseX, double mouseY) {
        DLHudManager.getWindowManager().mouseMoved(mouseX, mouseY);
    }

    @Override
    public boolean m_6375_(double mouseX, double mouseY, int button) {
        return (DLHudManager.isReady() && DLHudManager.getWindowManager().mousePressed(mouseX, mouseY, button)) || super.m_6375_(mouseX, mouseY, button);
    }

    @Override
    public boolean m_6348_(double mouseX, double mouseY, int button) {
        return (DLHudManager.isReady() && DLHudManager.getWindowManager().mouseReleased(mouseX, mouseY, button)) || super.m_6348_(mouseX, mouseY, button);
    }

    @Override
    public boolean m_7979_(double mouseX, double mouseY, int button, double dragX, double dragY) {
        return (DLHudManager.isReady() && DLHudManager.getWindowManager().mouseDragged(mouseX, mouseY, button, dragX, dragY)) || super.m_7979_(mouseX, mouseY, button, dragX, dragY);
    }

    @Override
    public boolean m_6050_(double mouseX, double mouseY, double delta) {
        return (DLHudManager.isReady() && DLHudManager.getWindowManager().mouseScrolled(mouseX, mouseY, 0, delta)) || super.m_6050_(mouseX, mouseY, delta);
    }

    @Override
    public boolean m_7933_(int keyCode, int scanCode, int modifiers) {
        if (DLHudManager.isReady() && DLHudManager.getWindowManager().keyPressed(keyCode, scanCode, modifiers)) {
            return true;
        }
        if (DLHudManager.KEY_OVERLAY_SETTINGS.m_90832_(keyCode, scanCode)) {
            m_7379_();
            return true;
        }
        return super.m_7933_(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean m_7920_(int keyCode, int scanCode, int modifiers) {
        return (DLHudManager.isReady() && DLHudManager.getWindowManager().keyReleased(keyCode, scanCode, modifiers)) || super.m_7920_(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean m_5534_(char codePoint, int modifiers) {
        return (DLHudManager.isReady() && DLHudManager.getWindowManager().charTyped(codePoint, modifiers)) || super.m_5534_(codePoint, modifiers);
    }

    @Override
    public void m_7400_(List<Path> paths) {
        if (!DLHudManager.isReady() || !DLHudManager.getWindowManager().filesDropped(paths)) {
            super.m_7400_(paths);
        }
    }

    @Override
    public void m_7861_() {
        super.m_7861_();
        DLWindowManager manager = DLHudManager.getWindowManager();
        manager.closeAllPopups();
        manager.focus(null);
        manager.router().clearState();
    }

    @Override
    public boolean m_7043_() {
        return false;
    }
}
