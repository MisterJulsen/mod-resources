/*
 * DragonLib 3 - 1.20.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.client.gui.widgets.richtext.autocomplete;

import de.mrjulsen.mcdragonlib.client.gui.widgets.base.DLWindowManager;
import de.mrjulsen.mcdragonlib.client.gui.widgets.components.DLRichTextEditBox;
import de.mrjulsen.mcdragonlib.util.math.Point;

@FunctionalInterface
@Deprecated
public interface IAutocompletionManager<T> {

    /**
     * Called multiple times when a new window is opened or the suggestions change (e.g. due to modified text).
     * @param window The current {@link DLAutocompleteWindow} instance.
     * @param textBox The textbox for which autocompletion should be used.
     */
    void configureWindow(DLAutocompleteWindow<T> window, DLRichTextEditBox textBox);
    
    /**
     * Creates a new autocomplete popup window.
     * @param windowManager The {@link DLWindowManager} for window management.
     * @param textBox The textbox for which autocompletion should be used.
     * @return The new autocomplete window instance.
     */
    default DLAutocompleteWindow<T> createWindow(DLWindowManager windowManager, DLRichTextEditBox textBox) {
        DLAutocompleteWindow<T> win = new DLAutocompleteWindow<>(windowManager, textBox);
        Point pos = textBox.toScreenCoordinates();
        win.setPosition(pos.x(), pos.y() + textBox.height());
        return win;
    }
    
    /**
     * Run additional tasks after the autocomplete has been closed.
     * @param window The current {@link DLAutocompleteWindow} instance.
     * @param textBox The textbox for which autocompletion should be used.
     */
    default void closeWindow(DLAutocompleteWindow<T> window, DLRichTextEditBox textBox) {
    }
}
