/*
 * DragonLib 3 - 1.20.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.menu;

import de.mrjulsen.mcdragonlib.DragonLib;
import de.mrjulsen.mcdragonlib.internal.ModMenuTypes;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

public abstract class PlayerInventoryContainerMenu extends AbstractContainerMenu {

    public final ContainerLevelAccess access;

    public PlayerInventoryContainerMenu(MenuType<?> type, int containerId, Inventory inv) {
        this(type, containerId, inv, ContainerLevelAccess.f_39287_);
    }

    public PlayerInventoryContainerMenu(MenuType<?> type, int containerId, Inventory inv, final ContainerLevelAccess access) {
        super(type, containerId);
        this.access = access;

        addPlayerInventory(inv);
        addPlayerHotbar(inv);
    }
    
    protected void addPlayerInventory(Inventory playerInventory) {
        for (int i = 0; i < 3; ++i) {
            for (int l = 0; l < 9; ++l) {
                this.m_38897_(new Slot(playerInventory, l + i * 9 + 9, 0, 0));
            }
        }
    }

    protected void addPlayerHotbar(Inventory playerInventory) {
        for (int i = 0; i < 9; ++i) {
            this.m_38897_(new Slot(playerInventory, i, 0, 0));
        }
    }



    public static class Base extends PlayerInventoryContainerMenu {
        public Base(int containerId, Inventory inv) {
            this(containerId, inv, ContainerLevelAccess.f_39287_);
        }        

        public Base(int containerId, Inventory inv, final ContainerLevelAccess access) {
            super(ModMenuTypes.PLAYER_INVENTORY.get(), containerId, inv, access);
        }        

        @Override
        public boolean m_6875_(Player player) {
            return m_38889_(this.access, player, DragonLib.DRAGON_BLOCK.get());
        }
        
        @Override
        public ItemStack m_7648_(Player player, int index) {
            ItemStack itemstack = ItemStack.f_41583_;
            Slot slot = this.f_38839_.get(index);

            if (slot != null && slot.m_6657_()) {
                ItemStack stackInSlot = slot.m_7993_();
                itemstack = stackInSlot.m_41777_();

                if (index < 9) {
                    if (!this.m_38903_(stackInSlot, 9, 36, false)) {
                        return ItemStack.f_41583_;
                    }
                }
                
                else if (index < 36) {
                    if (!this.m_38903_(stackInSlot, 0, 9, false)) {
                        return ItemStack.f_41583_;
                    }
                }

                if (stackInSlot.m_41619_()) {
                    slot.m_269060_(ItemStack.f_41583_);
                } else {
                    slot.m_6654_();
                }

                if (stackInSlot.m_41613_() == itemstack.m_41613_()) {
                    return ItemStack.f_41583_;
                }

                slot.m_142406_(player, stackInSlot);
            }

            return itemstack;
        }
        
    }
}
