package de.mrjulsen.mcdragonlib.util.registry;

import java.util.function.Function;
import net.minecraft.class_2487;
import net.minecraft.class_2960;
import com.google.common.base.Supplier;

import de.mrjulsen.mcdragonlib.util.DLUtils;

public final record DLStaticRegistryObject<T>(class_2960 id, Supplier<T> factory) {

    public static final String NBT_ID = "Id";

    public class_2487 wrap(T data) {
        class_2487 tag = new class_2487();
        tag.method_10582(NBT_ID, id.toString());
        return tag;
    }
    
    public static <T> T load(class_2487 tag, Function<class_2960, DLStaticRegistryObject<T>> registryGetter) {
        class_2960 typeId = DLUtils.resourceLocation(tag.method_10558(NBT_ID));
        DLStaticRegistryObject<T> type = registryGetter.apply(typeId);
        if (type == null) return null;
        return type.get();
    }

    public T get() {
        return factory.get();
    }
}

