package de.mrjulsen.mcdragonlib.fabric.client.model.geometry.mixin.client;

import net.minecraft.class_793;
import net.minecraft.class_796;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_793.class)
public interface BlockModelAccessor {

	@Accessor("FACE_BAKERY")
	public static class_796 dragonlib$getFaceBakery() {
		throw new AssertionError();
	}

	@Accessor("parent")
	class_793 dragonlib$getParent();
}
