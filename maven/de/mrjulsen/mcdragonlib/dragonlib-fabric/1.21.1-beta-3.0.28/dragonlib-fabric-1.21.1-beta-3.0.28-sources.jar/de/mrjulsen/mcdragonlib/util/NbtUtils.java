package de.mrjulsen.mcdragonlib.util;

import org.joml.Vector3d;
import org.joml.Vector3dc;
import org.joml.Vector3f;
import org.joml.Vector3fc;
import org.joml.Vector3i;
import org.joml.Vector3ic;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;
import net.minecraft.class_1923;
import net.minecraft.class_2338;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_4076;

/**
 * Utility methods for writing and reading common geometric types to/from CompoundTag.
 *
 * <p>Keys used: "X", "Y", "Z" for component storage.
 */
public final class NbtUtils {
    private NbtUtils() {}

    public static final String NBT_X = "X";
    public static final String NBT_Y = "Y";
    public static final String NBT_Z = "Z";

    private static void putIntPos(class_2487 compound, String name, int x, int y, int z) {
        class_2487 nbt = new class_2487();
        nbt.method_10569(NBT_X, x);
        nbt.method_10569(NBT_Y, y);
        nbt.method_10569(NBT_Z, z);
        compound.method_10566(name, nbt);
    }

    private static void putDoublePos(class_2487 compound, String name, double x, double y, double z) {
        class_2487 nbt = new class_2487();
        nbt.method_10549(NBT_X, x);
        nbt.method_10549(NBT_Y, y);
        nbt.method_10549(NBT_Z, z);
        compound.method_10566(name, nbt);
    }
    
    /**
     * Store a Vec3i-style position into a compound under {@code name}.
     */
    public static void putNbtPos(class_2487 compound, String name, class_2382 pos) {
        putIntPos(compound, name, pos.method_10263(), pos.method_10264(), pos.method_10260());
    }
    
    /**
     * Store a JOML Vector3ic (integer) into NBT.
     */
    public static void putNbtVector3i(class_2487 compound, String name, Vector3ic pos) {
        putIntPos(compound, name, pos.x(), pos.y(), pos.z());
    }
    
    /**
     * Store a Vec3 (double) into NBT.
     */
    public static void putNbtVec(class_2487 compound, String name, class_243 pos) {
        putDoublePos(compound, name, pos.method_10216(), pos.method_10214(), pos.method_10215());
    }
    
    /**
     * Store a JOML Vector3fc (float) into NBT (stored as doubles).
     */
    public static void putNbtVector3f(class_2487 compound, String name, Vector3fc pos) {
        putDoublePos(compound, name, pos.x(), pos.y(), pos.z());
    }
    
    /**
     * Store a JOML Vector3dc (double) into NBT.
     */
    public static void putNbtVector3d(class_2487 compound, String name, Vector3dc pos) {
        putDoublePos(compound, name, pos.x(), pos.y(), pos.z());
    }

    /**
     * Read a BlockPos previously stored under {@code name}.
     */
    public static class_2338 getNbtBlockPos(class_2487 compound, String name) {
        class_2487 nbt = compound.method_10562(name);
        return new class_2338(nbt.method_10550(NBT_X), nbt.method_10550(NBT_Y), nbt.method_10550(NBT_Z));
    }

    /**
     * Read a SectionPos previously stored under {@code name}.
     */
    public static class_4076 getNbtSectionPos(class_2487 compound, String name) {
        class_2487 nbt = compound.method_10562(name);
        return class_4076.method_18676(nbt.method_10550(NBT_X), nbt.method_10550(NBT_Y), nbt.method_10550(NBT_Z));
    }

    /**
     * Read a Vec3i from NBT.
     */
    public static class_2382 getNbtVec3i(class_2487 compound, String name) {
        class_2487 nbt = compound.method_10562(name);
        return new class_2382(nbt.method_10550(NBT_X), nbt.method_10550(NBT_Y), nbt.method_10550(NBT_Z));
    }

    /**
     * Read a JOML Vector3i from NBT.
     */
    public static Vector3i getNbtVector3i(class_2487 compound, String name) {
        class_2487 nbt = compound.method_10562(name);
        return new Vector3i(nbt.method_10550(NBT_X), nbt.method_10550(NBT_Y), nbt.method_10550(NBT_Z));
    }

    /**
     * Read a Vec3 (double) from NBT.
     */
    public static class_243 getNbtVec3(class_2487 compound, String name) {
        class_2487 nbt = compound.method_10562(name);
        return new class_243(nbt.method_10574(NBT_X), nbt.method_10574(NBT_Y), nbt.method_10574(NBT_Z));
    }

    /**
     * Read a JOML Vector3f from NBT.
     */
    public static Vector3f getNbtVector3f(class_2487 compound, String name) {
        class_2487 nbt = compound.method_10562(name);
        return new Vector3f((float)nbt.method_10574(NBT_X), (float)nbt.method_10574(NBT_Y), (float)nbt.method_10574(NBT_Z));
    }

    /**
     * Read a JOML Vector3d from NBT.
     */
    public static Vector3d getNbtVector3d(class_2487 compound, String name) {
        class_2487 nbt = compound.method_10562(name);
        return new Vector3d(nbt.method_10574(NBT_X), nbt.method_10574(NBT_Y), nbt.method_10574(NBT_Z));
    }

    /**
     * Read a ChunkPos stored under {@code name} (stores x and z).
     */
    public static class_1923 getNbtChunkPos(class_2487 compound, String name) {
        class_2487 nbt = compound.method_10562(name);
        return new class_1923(nbt.method_10550(NBT_X), nbt.method_10550(NBT_Z));
    }
    
    /**
     * Store a ChunkPos under {@code name} (stores x and z).
     */
    public static void putNbtChunkPos(class_2487 compound, String name, class_1923 pos) {
        class_2487 nbt = new class_2487();
        nbt.method_10569(NBT_X, pos.field_9181);
        nbt.method_10569(NBT_Z, pos.field_9180);
        compound.method_10566(name, nbt);
    }

    public static <K, V> void putMap(class_2487 nbt, String key, Map<K, V> map, Function<K, String> keySerializer, Function<V, class_2487> valueSerializer) {
        class_2487 mapNbt = new class_2487();
        for (Map.Entry<K, V> entry : map.entrySet()) {
            mapNbt.method_10566(keySerializer.apply(entry.getKey()), valueSerializer.apply(entry.getValue()));
        }
        nbt.method_10566(key, mapNbt);
    }

    public static <K, V> Map<K, V> getMap(class_2487 nbt, String key, Function<String, K> keyDeserializer, Function<class_2487, V> valueDeserializer) {
        class_2487 mapNbt = nbt.method_10562(key);
        Map<K, V> map = new HashMap<>(mapNbt.method_10546());
        for (String k : mapNbt.method_10541()) {
            map.put(keyDeserializer.apply(k), valueDeserializer.apply(mapNbt.method_10562(k)));
        }
        return map;
    }
  }
