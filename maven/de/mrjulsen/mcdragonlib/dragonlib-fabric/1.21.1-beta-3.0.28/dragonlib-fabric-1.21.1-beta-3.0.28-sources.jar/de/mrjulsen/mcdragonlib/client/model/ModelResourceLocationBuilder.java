package de.mrjulsen.mcdragonlib.client.model;

import java.util.LinkedList;
import java.util.List;
import net.minecraft.class_1091;
import net.minecraft.class_2769;
import net.minecraft.class_2960;

public abstract class ModelResourceLocationBuilder {

    private final class_2960 location;

    public ModelResourceLocationBuilder(class_2960 location) {
        this.location = location;
    }

    public class_2960 getLocation() {
        return location;
    }

    public abstract class_1091 build();


    public static class Base extends ModelResourceLocationBuilder {

        public Base(class_2960 location) {
            super(location);
        }

        @Override
        public class_1091 build() {
            return new class_1091(getLocation(), "");
        }
    }

    public static class BlockState extends ModelResourceLocationBuilder {

        private final List<String> properties = new LinkedList<>();

        public BlockState(class_2960 location) {
            super(location);
        }

        public <T extends Comparable<T>> BlockState with(class_2769<T> property, T value) {
            this.properties.add(property.method_11899() + "=" + property.method_11901(value));
            return this;
        }

        @Override
        public class_1091 build() {
            return new class_1091(getLocation(), String.join(",", this.properties));
        }
    }

    public static class Inventory extends ModelResourceLocationBuilder {

        public Inventory(class_2960 location) {
            super(location);
        }

        @Override
        public class_1091 build() {
            return new class_1091(getLocation(), "inventory");
        }
    }
}
