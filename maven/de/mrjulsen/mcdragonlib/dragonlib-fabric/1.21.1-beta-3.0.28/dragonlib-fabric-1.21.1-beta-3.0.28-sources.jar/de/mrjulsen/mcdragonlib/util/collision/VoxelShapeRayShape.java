package de.mrjulsen.mcdragonlib.util.collision;

import java.util.Optional;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_265;
import net.minecraft.class_3965;
import org.joml.Vector3f;

/**
 * Adapter that uses a Minecraft VoxelShape to perform precise ray-voxel intersection tests.
 *
 * <p>The shape.clip(...) call is used to find an intersection point and convert it to a Vector3f.
 */
public class VoxelShapeRayShape implements IRayTraceShape {
    private final class_265 shape;
    private final class_2338 pos;

    public VoxelShapeRayShape(class_265 shape, class_2338 pos) {
        this.shape = shape;
        this.pos = pos;
    }

    @Override
    public Optional<Vector3f> intersects(Vector3f rayOrigin, Vector3f rayDirection) {
        class_243 start = new class_243(rayOrigin.x(), rayOrigin.y(), rayOrigin.z());
        class_243 end = start.method_1019(new class_243(rayDirection.x(), rayDirection.y(), rayDirection.z()).method_1021(100)); // max ray length

        class_3965 result = shape.method_1092(start, end, pos);
        if (result == null) {
            return Optional.empty();
        }
        return Optional.ofNullable(result.method_17784().method_46409());
    }
}

