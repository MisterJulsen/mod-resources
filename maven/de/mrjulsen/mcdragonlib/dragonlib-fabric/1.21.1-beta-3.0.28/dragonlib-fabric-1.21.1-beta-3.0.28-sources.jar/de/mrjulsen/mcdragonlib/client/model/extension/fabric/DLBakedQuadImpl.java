package de.mrjulsen.mcdragonlib.client.model.extension.fabric;

import de.mrjulsen.mcdragonlib.client.model.ModelUtils;
import de.mrjulsen.mcdragonlib.client.model.extension.DLBakedQuad;
import java.util.Arrays;
import java.util.List;
import net.minecraft.class_1058;
import net.minecraft.class_2350;
import net.minecraft.class_765;

public class DLBakedQuadImpl extends DLBakedQuad {

    protected DLBakedQuadImpl(int[] vertices, int tintIndex, class_2350 direction, class_1058 sprite, boolean shade, boolean ambientOcclusion, boolean emissive, List<String> tags) {
        super(vertices, tintIndex, direction, sprite, shade, ambientOcclusion, emissive, tags);
    }

    public static DLBakedQuad create(int[] vertices, int tintIndex, class_2350 direction, class_1058 sprite, boolean shade, boolean ambientOcclusion, boolean emissive, List<String> tags) {
        if (emissive) {
            int corners = 4;
            int[] lightmap = new int[2];
            for (int i = 0; i < corners; i++) {
                ModelUtils.unpackLight(vertices, lightmap, i);
                Arrays.fill(lightmap, class_765.field_32767);
                ModelUtils.packLight(lightmap, vertices, i);
            }
        }

        return new DLBakedQuadImpl(
                vertices,
                tintIndex,
                direction,
                sprite,
                !emissive && shade,
                !emissive && ambientOcclusion,
                emissive,
                tags
        );
    }
}
