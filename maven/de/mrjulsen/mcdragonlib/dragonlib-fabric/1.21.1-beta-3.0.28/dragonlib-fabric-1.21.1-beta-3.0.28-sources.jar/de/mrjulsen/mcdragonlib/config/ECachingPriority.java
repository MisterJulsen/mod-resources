package de.mrjulsen.mcdragonlib.config;

import java.util.Arrays;
import net.minecraft.class_3542;

/** The importance of caching data. */
public enum ECachingPriority implements class_3542 {
    /** Must always be cached, regardless of the settings the user has made. */
    ALWAYS(1, "always"),
    NORMAL(0, "normal"),
    LOW(-1, "low"),
    LOWEST(-2, "lowest");

    int idx;
    String name;

    ECachingPriority(int idx, String name) {
        this.idx = idx;
        this.name = name;
    }

    public int getIndex() {
        return idx;
    }

    public String getName() {
        return name;
    }

    @Override
    public String method_15434() {
        return name;
    }

    public static ECachingPriority getByIndex(int index) {
        return Arrays.stream(values()).filter(x -> x.getIndex() == index).findFirst().orElse(NORMAL);
    }

    public boolean shouldCache() {
        return getIndex() >= LOWEST.getIndex() + (ModCommonConfig.SPEC.isLoaded() ? ModCommonConfig.CACHING.get().getIndex() : ECachingPriority.NORMAL.getIndex());
    }
}
