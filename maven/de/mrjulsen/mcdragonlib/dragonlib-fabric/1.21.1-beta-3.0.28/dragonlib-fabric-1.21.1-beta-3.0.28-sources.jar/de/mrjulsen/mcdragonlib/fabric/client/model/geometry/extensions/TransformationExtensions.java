package de.mrjulsen.mcdragonlib.fabric.client.model.geometry.extensions;

import net.minecraft.class_2350;
import net.minecraft.class_4590;
import org.joml.Matrix3f;
import org.joml.Vector3f;
import org.joml.Vector4f;

public interface TransformationExtensions {
		default class_4590 dragonlib$applyOrigin(Vector3f origin) {
		throw new RuntimeException("this should be overridden via mixin. what?");
	}

	default Matrix3f dragonlib$getNormalMatrix() {
		throw new RuntimeException("this should be overridden via mixin. what?");
	}

	default void dragonlib$transformPosition(Vector4f position) {
		throw new RuntimeException("this should be overridden via mixin. what?");
	}

	default class_2350 dragonlib$rotateTransform(class_2350 facing) {
		throw new RuntimeException("this should be overridden via mixin. what?");
	}

	default boolean dragonlib$isIdentity() {
		return this.equals(class_4590.method_22931());
	}

	default void dragonlib$transformNormal(Vector3f normal) {
		normal.mul(dragonlib$getNormalMatrix());
		normal.normalize();
	}

	default class_4590 dragonlib$blockCenterToCorner() {
		return dragonlib$applyOrigin(new Vector3f(.5f, .5f, .5f));
	}

	default class_4590 dragonlib$blockCornerToCenter() {
		return dragonlib$applyOrigin(new Vector3f(-.5f, -.5f, -.5f));
	}
}
