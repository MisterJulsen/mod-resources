package de.mrjulsen.mcdragonlib.mixin;

import net.minecraft.class_1088;
import net.minecraft.class_1100;
import net.minecraft.class_2960;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_1088.class)
public interface ModelBakeryAccessor {

    @Invoker("getModel")
    class_1100 dragonlib$getModel(class_2960 modelLocation);
}
