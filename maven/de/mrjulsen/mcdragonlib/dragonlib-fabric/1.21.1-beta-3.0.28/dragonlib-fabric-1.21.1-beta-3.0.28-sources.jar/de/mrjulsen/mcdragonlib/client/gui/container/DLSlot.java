package de.mrjulsen.mcdragonlib.client.gui.container;

import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_156;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836.class_1837;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;
import de.mrjulsen.mcdragonlib.client.gui.events.DLGuiStandardEvents;
import de.mrjulsen.mcdragonlib.client.gui.events.DLGuiStandardEvents.DraggingOverEvent;
import de.mrjulsen.mcdragonlib.client.gui.events.DLGuiStandardEvents.MouseDownEvent;
import de.mrjulsen.mcdragonlib.client.gui.events.DLGuiStandardEvents.MouseReleaseEvent;
import de.mrjulsen.mcdragonlib.client.gui.widgets.base.DLGuiComponent;
import de.mrjulsen.mcdragonlib.client.gui.widgets.base.DLWindowManager;
import de.mrjulsen.mcdragonlib.client.util.DLGuiGraphics;
import de.mrjulsen.mcdragonlib.client.util.DLSprite;
import de.mrjulsen.mcdragonlib.client.util.GuiUtils;
import de.mrjulsen.mcdragonlib.util.DLColor;
import de.mrjulsen.mcdragonlib.util.math.Rectangle;
import de.mrjulsen.mcdragonlib.util.properties.Property;
import de.mrjulsen.mcdragonlib.client.gui.widgets.base.manager.InventoryManager;
import de.mrjulsen.mcdragonlib.client.gui.widgets.render.ILayeredStateRenderer;
import de.mrjulsen.mcdragonlib.client.gui.widgets.render.VanillaSlotRenderer;

public class DLSlot extends DLGuiComponent {
    
    public static enum SlotState {
        NORMAL,
        DISABLED,
        SELECTED,
        DISABLED_SELECTED;
    }

    public final Property<DLSprite> icon = new Property<DLSprite>(DLSprite.empty());
    public final Property<ILayeredStateRenderer<SlotState>> componentRenderer = new Property<>(VanillaSlotRenderer.VANILLA_SLOT);

    public final class_1703 menu;
    private final class_1735 slot;
    private final int slotIndex;

    public DLSlot(int x, int y, int w, int h, class_1735 sl, class_1703 menu) {
        super(x, y, w, h);
        this.menu = menu;
        this.slot = sl;
        this.slotIndex = sl.field_7874;

        addEventListener(DLGuiStandardEvents.MouseDownEvent.class, (s, e) -> {
            handleMouseDownEvent(e);
            return false;
        });

        addEventListener(DLGuiStandardEvents.MouseReleaseEvent.class, (sender, e) -> {
            handleMouseReleaseEvent(e);
            return false;
        });

        addEventListener(DLGuiStandardEvents.DraggingOverEvent.class, (sender, e) -> {
            handleMouseDraggedEvent(e);
            return false;
        });
    }

    protected void handleMouseDownEvent(MouseDownEvent e) {        
        InventoryManager manager = getWindowManager().addManager(InventoryManager::new);
        boolean pickItem = class_310.method_1551().field_1690.field_1871.method_1433(e.button()) && class_310.method_1551().field_1761.method_2914();
        class_1735 slot = menu.method_7611(slotIndex); 
        int slotIndex = slot.field_7874;
        long clickTime = class_156.method_658();
        manager.setDoubleClick(manager.getLastClickedSlot() != null && manager.getLastClickedSlot().slot == slot && clickTime - manager.getLastClickTime() < 250L && manager.getLastClickButton() == e.button());
        manager.setSkipNextRelease(false);

        if ((Boolean) class_310.method_1551().field_1690.method_42446().method_41753()) {
            if (slot != null && slot.method_7681()) {
                manager.setSelectedSlot(this);
                manager.setDraggingItem(class_1799.field_8037);
                manager.setIsSplittingStack(e.button() == GLFW.GLFW_MOUSE_BUTTON_RIGHT);
            } else {
                manager.setSelectedSlot(null);
            }
        } else if (!manager.isQuickCrafting()) {
            if (manager.getHoldingItem().method_7960()) {
                if (pickItem) {
                    this.slotClicked(slotIndex, e.button(), class_1713.field_7796);
                } else {
                    boolean qickMoving = slotIndex != class_1703.field_30730 && (class_3675.method_15987(class_310.method_1551().method_22683().method_4490(), GLFW.GLFW_KEY_LEFT_SHIFT) || class_3675.method_15987(class_310.method_1551().method_22683().method_4490(), GLFW.GLFW_KEY_RIGHT_SHIFT));
                    class_1713 clickType = class_1713.field_7790;
                    if (qickMoving) {
                        manager.setLastQuickMoved(slot != null && slot.method_7681() ? slot.method_7677().method_7972() : class_1799.field_8037);
                        clickType = class_1713.field_7794;
                    } else if (slotIndex == class_1703.field_30730) {
                        clickType = class_1713.field_7795;
                    }
                    this.slotClicked(slotIndex, e.button(), clickType);
                }

                manager.setSkipNextRelease(true);
            } else {
                manager.setQuickCrafting(true, e.button(), switch (e.button()) {
                    case GLFW.GLFW_MOUSE_BUTTON_LEFT -> class_1703.field_30731;
                    case GLFW.GLFW_MOUSE_BUTTON_RIGHT -> class_1703.field_30732;
                    case GLFW.GLFW_MOUSE_BUTTON_MIDDLE -> class_1703.field_30733;
                    default -> -1;
                });
            }
        }

        manager.setLastClickedSlot(this);
        manager.setLastClickTime(clickTime);
        manager.setLastClickedButton(e.button());
    }

    protected void handleMouseReleaseEvent(MouseReleaseEvent e) {
        InventoryManager manager = getWindowManager().addManager(InventoryManager::new);
        DLSlot targetDLSlot = null;
        for (DLGuiComponent c : getWindowManager().getDraggedOverComponents()) {
            if (c instanceof DLSlot s) {
                targetDLSlot = s;
                break;
            }
        }            
        
        if (targetDLSlot == null) {
            targetDLSlot = this; 
        }

        class_1735 targetSlot = targetDLSlot.slot;
        int targetSlotIndex = (targetSlot != null) ? targetSlot.field_7874 : -1;

        if (manager.isDoubleClick() && targetSlot != null && e.button() == GLFW.GLFW_MOUSE_BUTTON_LEFT && this.menu.method_7613(class_1799.field_8037, targetSlot)) {
            if (DLWindowManager.hasShiftDown()) {
                if (!manager.getQuickMovedItem().method_7960()) {
                    for (class_1735 s : this.menu.field_7761) {
                        if (s != null && s.method_7674(class_310.method_1551().field_1724) && s.method_7681() && s.field_7871 == targetSlot.field_7871 && class_1703.method_7592(s, manager.getQuickMovedItem(), true)) {
                            this.slotClicked(s.field_7874, e.button(), class_1713.field_7794);
                        }
                    }
                }
            } else {
                this.slotClicked(targetSlotIndex, e.button(), class_1713.field_7793);
            }
            manager.setSkipNextRelease(true);
        } else {
            if (manager.isQuickCrafting() && manager.getQuickCraftingButton() != e.button()) {
                manager.setQuickCrafting(false);
                manager.setSkipNextRelease(true);
                return;
            }
            if (manager.shouldSkipNextRelease()) {
                manager.setSkipNextRelease(false);
                return;
            }

            boolean canQuickReplace;
            if (manager.getSelectedSlot() != null && class_310.method_1551().field_1690.method_42446().method_41753()) {
                if (e.button() == GLFW.GLFW_MOUSE_BUTTON_LEFT || e.button() == GLFW.GLFW_MOUSE_BUTTON_RIGHT) {
                    if (manager.getDraggingItem().method_7960() && targetSlot != manager.getSelectedSlot().slot) {
                        manager.setDraggingItem(manager.getSelectedSlot().slot.method_7677());
                    }
                    canQuickReplace = class_1703.method_7592(targetSlot, manager.getDraggingItem(), false);
                    
                    if (targetSlotIndex != -1 && !manager.getDraggingItem().method_7960() && canQuickReplace) {                            
                        this.slotClicked(manager.getSelectedSlot().slot.field_7874, e.button(), class_1713.field_7790);                            
                        this.slotClicked(targetSlotIndex, 0, class_1713.field_7790);
                        
                        if (this.menu.method_34255().method_7960()) {
                            manager.setSnapbackItem(class_1799.field_8037);
                        } else {                                
                            this.slotClicked(manager.getSelectedSlot().slot.field_7874, e.button(), class_1713.field_7790);
                            manager.setSnapbackStartX(class_3532.method_15357(e.mouseX() + getXOnScreen())); 
                            manager.setSnapbackStartY(class_3532.method_15357(e.mouseY() + getYOnScreen()));
                            manager.setSnapbackEnd(manager.getSelectedSlot());
                            manager.setSnapbackItem(manager.getDraggingItem());
                            manager.setSnapbackTime(class_156.method_658());
                        }
                    } else if (!manager.getDraggingItem().method_7960()) {
                        
                        manager.setSnapbackStartX(class_3532.method_15357(e.mouseX() + getXOnScreen())); 
                        manager.setSnapbackStartY(class_3532.method_15357(e.mouseY() + getYOnScreen()));
                        manager.setSnapbackEnd(manager.getSelectedSlot());
                        manager.setSnapbackItem(manager.getDraggingItem());
                        manager.setSnapbackTime(class_156.method_658());
                    }
                    this.clearDraggingState(manager);
                }
            } else if (manager.isQuickCrafting() && !manager.getQuickCraftingSlots().isEmpty()) {
                this.slotClicked(class_1703.field_30730, class_1703.method_7591(class_1703.field_30734, manager.getQuickCraftingType()), class_1713.field_7789);
                for (class_1735 s : manager.getQuickCraftingSlots()) {
                    this.slotClicked(s.field_7874, class_1703.method_7591(class_1703.field_30735, manager.getQuickCraftingType()), class_1713.field_7789);
                }
                this.slotClicked(class_1703.field_30730, class_1703.method_7591(class_1703.field_30736, manager.getQuickCraftingType()), class_1713.field_7789);
            } else if (!this.menu.method_34255().method_7960()) {
                if (class_310.method_1551().field_1690.field_1871.method_1433(e.button())) {
                    this.slotClicked(targetSlotIndex, e.button(), class_1713.field_7796); 
                } else {
                    canQuickReplace = targetSlotIndex != class_1703.field_30730 && (class_3675.method_15987(class_310.method_1551().method_22683().method_4490(), GLFW.GLFW_KEY_LEFT_SHIFT) || class_3675.method_15987(class_310.method_1551().method_22683().method_4490(), GLFW.GLFW_KEY_RIGHT_SHIFT));
                    if (canQuickReplace) {
                        manager.setLastQuickMoved(targetSlot != null && targetSlot.method_7681() ? targetSlot.method_7677().method_7972() : class_1799.field_8037);
                    }

                    this.slotClicked(targetSlotIndex, e.button(), canQuickReplace ? class_1713.field_7794 : class_1713.field_7790); 
                }
            }
        }

        if (this.menu.method_34255().method_7960()) {
            manager.setLastClickTime(0);
        }

        manager.setQuickCrafting(false);
    }

    protected void handleMouseDraggedEvent(DraggingOverEvent e) {        
        DLSlot slot = null;
        if (e.other() != null) { 
            for (DLGuiComponent c : e.other()) {
                if (c instanceof DLSlot s) {
                    slot = s;
                    break;
                }
            }
        }

        InventoryManager manager = getWindowManager().addManager(InventoryManager::new);
        class_1799 itemStack = this.menu.method_34255();
        if (manager.getSelectedSlot() != null && (Boolean) class_310.method_1551().field_1690.method_42446().method_41753()) {
            if (e.button() == GLFW.GLFW_MOUSE_BUTTON_LEFT || e.button() == GLFW.GLFW_MOUSE_BUTTON_RIGHT) {
                if (manager.getDraggingItem().method_7960()) {
                    boolean stillOverOriginalSlot = (slot != null && slot == manager.getSelectedSlot());
                    
                    if (!stillOverOriginalSlot && !manager.getSelectedSlot().slot.method_7677().method_7960()) {
                        manager.setDraggingItem(manager.getSelectedSlot().slot.method_7677().method_7972());
                    }
                } else if (manager.getDraggingItem().method_7947() > 1 && slot != null && class_1703.method_7592(slot.slot, manager.getDraggingItem(), false)) {
                    long l = class_156.method_658();
                    if (manager.getQuickdropSlot() == slot.slot) {
                        if (l - manager.getQuickdropTime() > 500L) {
                            this.slotClicked(manager.getSelectedSlot().slot.field_7874, 0, class_1713.field_7790);
                            this.slotClicked(slot.slotIndex, 1, class_1713.field_7790);
                            this.slotClicked(manager.getSelectedSlot().slot.field_7874, 0, class_1713.field_7790);
                            manager.setQuickdropTime(l + 750L);
                            manager.getDraggingItem().method_7934(1);
                        }
                    } else {
                        manager.setQuickdropSlot(slot.slot);
                        manager.setQuickdropTime(l);
                    }
                }
            }
        } else if (manager.isQuickCrafting() && slot != null && !itemStack.method_7960()
                && (itemStack.method_7947() > manager.getQuickCraftingSlots().size() || manager.getQuickCraftingType() == 2)
                && class_1703.method_7592(slot.slot, itemStack, true) && slot.slot.method_7680(itemStack)
                && this.menu.method_7615(slot.slot)) {
            manager.getQuickCraftingSlots().add(this.slot);
            manager.getQuickCraftingSlots().add(slot.slot);
            this.recalculateQuickCraftRemaining(manager);
        }
    }

    private void recalculateQuickCraftRemaining(InventoryManager manager) {
        class_1799 itemStack = this.menu.method_34255();
        if (!itemStack.method_7960() && manager.isQuickCrafting()) {
            if (manager.getQuickCraftingType() == 2) {
                manager.setQuickCraftingRemainder(itemStack.method_7914());
            } else {
                int remainder = itemStack.method_7947();
                for (class_1735 slot : manager.getQuickCraftingSlots()) {
                    class_1799 slotStack = slot.method_7677();
                    int count = slotStack.method_7960() ? 0 : slotStack.method_7947();
                    int maxCount = Math.min(itemStack.method_7914(), slot.method_7676(itemStack));
                    int usedCount = Math.min(class_1703.method_7617(
                            manager.getQuickCraftingSlots(), manager.getQuickCraftingType(), itemStack) + count, maxCount);
                    remainder -= usedCount - count;
                }
                manager.setQuickCraftingRemainder(remainder);
            }
        }
    }

    protected void slotClicked(int slotId, int mouseButton, class_1713 type) {
        class_310.method_1551().field_1761.method_2906(menu.field_7763, slotId, mouseButton, type, class_310.method_1551().field_1724);
    }

    public void clearDraggingState(InventoryManager manager) {
        manager.setDraggingItem(class_1799.field_8037);
        manager.setSelectedSlot(null);
    }

    @Override
    public void renderMainLayer(DLGuiGraphics graphics, double mouseX, double mouseY, Rectangle renderBounds) {
        InventoryManager manager = getWindowManager().addManager(InventoryManager::new);
        class_1799 itemStack = slot.method_7677();
        class_1799 carriedStack = manager.getHoldingItem();
        String string = null;
        boolean renderHighlight = false;
        boolean renderEmptyIcon = false;

        if (manager.getSelectedSlot() != null && slot == manager.getSelectedSlot().slot && !manager.getDraggingItem().method_7960() && manager.isSplittingStack() && !itemStack.method_7960()) {
            itemStack = itemStack.method_46651(itemStack.method_7947() / 2);
        }
        else if (manager.isQuickCrafting() && manager.getQuickCraftingSlots().contains(this.slot) && !carriedStack.method_7960()) {
            if (manager.getQuickCraftingSlots().size() == 1) {
                return;
            }

            if (class_1703.method_7592(slot, carriedStack, true) && this.menu.method_7615(slot)) {
                renderHighlight = true;
                int maxStackSize = Math.min(carriedStack.method_7914(), slot.method_7676(carriedStack));
                int stackSize = slot.method_7677().method_7960() ? 0 : slot.method_7677().method_7947();
                int count = class_1703.method_7617(manager.getQuickCraftingSlots(), manager.getQuickCraftingType(), carriedStack) + stackSize;

                if (count > maxStackSize) {
                    count = maxStackSize;
                    String maxStackSizeTxt = class_124.field_1054.toString();
                    string = maxStackSizeTxt + maxStackSize;
                }

                itemStack = carriedStack.method_46651(count);
            } else {
                manager.getQuickCraftingSlots().remove(this.slot);
                this.recalculateQuickCraftRemaining(manager);
            }
        }

        if (!enabled.get() && isMouseOver(mouseX, mouseY)) {
            componentRenderer.get().renderSprite(graphics, 0, 0, width(), height(), this, SlotState.DISABLED_SELECTED);
        } else if (!enabled.get()) {
            componentRenderer.get().renderSprite(graphics, 0, 0, width(), height(), this, SlotState.DISABLED);
        } else if (isSelected()) {
            componentRenderer.get().renderSprite(graphics, 0, 0, width(), height(), this, SlotState.SELECTED);
        } else {
            componentRenderer.get().renderSprite(graphics, 0, 0, width(), height(), this, SlotState.NORMAL);
        }
        
        if (itemStack.method_7960() && slot.method_7682()) {
            DLSprite sprite = icon.get();
            sprite.render(graphics, width() / 2 - sprite.getWidth() / 2, height() / 2 - sprite.getHeight() / 2);
        }

        if (!renderEmptyIcon) {
            if (renderHighlight) {
                GuiUtils.fill(graphics, 1, 1, 16, 16, DLColor.fromInt(-2130706433));
            }
            GuiUtils.renderItem(graphics, itemStack, 1, 1, 1, true);
            GuiUtils.renderItemDecoration(graphics, itemStack, 1, 1, 1, string);
        }

        

        if (!enabled.get() && isMouseOver(mouseX, mouseY)) {
            componentRenderer.get().renderSpritePost(graphics, 0, 0, width(), height(), this, SlotState.DISABLED_SELECTED);
        } else if (!enabled.get()) {
            componentRenderer.get().renderSpritePost(graphics, 0, 0, width(), height(), this, SlotState.DISABLED);
        } else if (isSelected()) {
            componentRenderer.get().renderSpritePost(graphics, 0, 0, width(), height(), this, SlotState.SELECTED);
        } else {
            componentRenderer.get().renderSpritePost(graphics, 0, 0, width(), height(), this, SlotState.NORMAL);
        }
    }

    @Override
    public void renderFrontLayer(DLGuiGraphics graphics, double mouseX, double mouseY, Rectangle renderBounds) {
        if (isSelected()) {
            InventoryManager manager = getWindowManager().addManager(InventoryManager::new);
            if (manager == null || (!manager.isHoldingItem() && manager.getDraggingItem().method_7960())) {
                class_1799 itemstack = menu.method_7611(slotIndex).method_7677();
                if (!itemstack.method_7960()) {
                    class_310 mc = class_310.method_1551();
                    graphics.graphics().method_51437(mc.field_1772, getTooltipFromItem(itemstack), itemstack.method_32347(), (int) mouseX, (int) mouseY);
                }
            }
        }
    }

    public static List<class_2561> getTooltipFromItem(class_1799 item) {
        return item.method_7950(class_1792.class_9635.field_51353, class_310.method_1551().field_1724, class_310.method_1551().field_1690.field_1827 ? class_1837.field_41071 : class_1837.field_41070);
    }

    public class_1735 getSlot() {
        return slot;
    }
}