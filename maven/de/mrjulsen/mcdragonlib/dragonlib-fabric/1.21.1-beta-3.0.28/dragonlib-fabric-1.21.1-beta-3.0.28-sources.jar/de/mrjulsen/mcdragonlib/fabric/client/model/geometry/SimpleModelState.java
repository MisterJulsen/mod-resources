package de.mrjulsen.mcdragonlib.fabric.client.model.geometry;

import net.minecraft.class_3665;
import net.minecraft.class_4590;

public final class SimpleModelState implements class_3665 {
	private final class_4590 transformation;
	private final boolean uvLocked;

	public SimpleModelState(class_4590 transformation, boolean uvLocked) {
		this.transformation = transformation;
		this.uvLocked = uvLocked;
	}

	public SimpleModelState(class_4590 transformation) {
		this(transformation, false);
	}

	@Override
	public class_4590 method_3509() {
		return transformation;
	}

	@Override
	public boolean method_3512() {
		return uvLocked;
	}
}

