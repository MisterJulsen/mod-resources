package de.mrjulsen.mcdragonlib.config;

import net.minecraft.class_3542;

public enum ETimeSystem implements class_3542 {
    AUTO(0, "auto"),
    VANILLA(1, "vanilla"),
    CUSTOM(2, "custom");

    private final int id;
    private final String name;

    private ETimeSystem(int id, String name) {
        this.id = id;
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    @Override
    public String method_15434() {
        return name;
    }
}
