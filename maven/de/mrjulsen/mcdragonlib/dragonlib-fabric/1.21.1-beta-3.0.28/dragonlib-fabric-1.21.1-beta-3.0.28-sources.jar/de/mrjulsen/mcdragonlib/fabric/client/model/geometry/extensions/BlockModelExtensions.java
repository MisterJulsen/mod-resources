package de.mrjulsen.mcdragonlib.fabric.client.model.geometry.extensions;

import de.mrjulsen.mcdragonlib.fabric.client.model.geometry.IUnbakedGeometry;
import de.mrjulsen.mcdragonlib.fabric.client.model.geometry.VisibilityData;
import java.util.function.Function;
import net.minecraft.class_1058;
import net.minecraft.class_4590;
import net.minecraft.class_4730;
import net.minecraft.class_7775;
import net.minecraft.class_793;
import net.minecraft.class_806;

public interface BlockModelExtensions {

	default class_806 dragonlib$getOverrides(class_7775 pModelBakery, class_793 pModel, Function<class_4730, class_1058> textureGetter) {
		throw new RuntimeException("this should be overridden via mixin. what?");
	}

	default void dragonlib$setCustomGeometry(IUnbakedGeometry<?> geometry) {
		throw new RuntimeException("this should be overridden via mixin. what?");
	}

	default IUnbakedGeometry<?> dragonlib$getCustomGeometry() {
		throw new RuntimeException("this should be overridden via mixin. what?");
	}

	default boolean dragonlib$isComponentVisible(String part, boolean fallback) {
		throw new RuntimeException("this should be overridden via mixin. what?");
	}

	default VisibilityData dragonlib$getVisibilityData() {
		throw new RuntimeException("this should be overridden via mixin. what?");
	}

	default class_4590 dragonlib$getRootTransform() {
		throw new RuntimeException("this should be overridden via mixin. what?");
	}

	default void dragonlib$setRootTransform(class_4590 rootTransform) {
		throw new RuntimeException("this should be overridden via mixin. what?");
	}
}
