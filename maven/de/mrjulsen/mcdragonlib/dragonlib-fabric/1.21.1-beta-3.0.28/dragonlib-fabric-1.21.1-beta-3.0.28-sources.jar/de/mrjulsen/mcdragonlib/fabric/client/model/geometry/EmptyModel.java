package de.mrjulsen.mcdragonlib.fabric.client.model.geometry;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import net.minecraft.class_1047;
import net.minecraft.class_1058;
import net.minecraft.class_1059;
import net.minecraft.class_1087;
import net.minecraft.class_1093;
import net.minecraft.class_1100;
import net.minecraft.class_2960;
import net.minecraft.class_3665;
import net.minecraft.class_4730;
import net.minecraft.class_7775;
import net.minecraft.class_793;
import net.minecraft.class_806;
import net.minecraft.class_809;

public class EmptyModel implements IUnbakedGeometry<EmptyModel> {
	public static final class_1087 BAKED = new Baked();
	public static final EmptyModel INSTANCE = new EmptyModel();
	public static final IGeometryLoader<EmptyModel> LOADER = (json, ctx) -> INSTANCE;

	private EmptyModel() {}

	@Override
	public class_1087 bake(class_793 context, class_7775 baker, Function<class_4730, class_1058> spriteGetter, class_3665 modelState, class_806 overrides, boolean isGui3d) {
		return BAKED;
	}

	@Override
	public void resolveParents(Function<class_2960, class_1100> modelGetter, class_793 context) {
		
	}

	private static class Baked extends class_1093 {
		@SuppressWarnings("deprecation")
		private static final class_4730 MISSING_TEXTURE = new class_4730(class_1059.field_5275, class_1047.method_4539());

		public Baked() {
			super(List.of(), Map.of(), false, false, false, MISSING_TEXTURE.method_24148(), class_809.field_4301, class_806.field_4292);
		}

		@Override
		public class_1058 method_4711() {
			return MISSING_TEXTURE.method_24148();
		}
	}
}
