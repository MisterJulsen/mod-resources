package de.mrjulsen.mcdragonlib.fabric.client.model.geometry;

import java.util.Set;
import java.util.function.Function;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_1100;
import net.minecraft.class_2960;
import net.minecraft.class_3665;
import net.minecraft.class_4730;
import net.minecraft.class_7775;
import net.minecraft.class_793;
import net.minecraft.class_806;

public interface IUnbakedGeometry<T extends IUnbakedGeometry<T>> {
	class_1087 bake(class_793 context, class_7775 baker, Function<class_4730, class_1058> spriteGetter, class_3665 modelState, class_806 overrides, boolean isGui3d);

	default void resolveParents(Function<class_2960, class_1100> modelGetter, class_793 context) {

	}

	default Set<String> getConfigurableComponentNames() {
		return Set.of();
	}
}
