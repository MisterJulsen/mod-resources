package de.mrjulsen.mcdragonlib.internal;

import de.mrjulsen.mcdragonlib.DragonLib;
import de.mrjulsen.mcdragonlib.block.DLSyncedBlockEntity;
import de.mrjulsen.mcdragonlib.block.DLWritableSignBlockEntity;
import de.mrjulsen.mcdragonlib.client.gui.builtin.WritableSignScreen;
import de.mrjulsen.mcdragonlib.util.DLColor;
import net.minecraft.class_2338;
import net.minecraft.class_241;
import net.minecraft.class_2591;
import net.minecraft.class_2680;

public class DragonLibBlockEntity extends DLWritableSignBlockEntity {

    protected DragonLibBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state) {
        super(type, pos, state);
    }

    @Override
    public WritableSignScreen.WritableSignConfig getRenderConfig() {
        float y = 120;
        return new WritableSignScreen.WritableSignConfig(new WritableSignScreen.ConfiguredLineData[] {
                new WritableSignScreen.ConfiguredLineData(0, -1.0F / 16.0F * 4.25f, new class_241(1, 1.5f), new class_241(1.5f, 1.5f), 1.0F / 16.0F * 15, 1, 0)
        }, true, 1.0F / 16.0F * 6.5f, y, WritableSignScreen.WritableSignConfig.DEFAULT_SCALE, 90, 0.4f, 0.0f, 0.02f, (blockState) -> {
            return 90f;
        }, DLColor.pickBasedOnBrightness(DLColor.WHITE, DLColor.WHITE, DLColor.BLACK, 0.5f).getAsARGB());
    }

    public DragonLibBlockEntity(class_2338 pos, class_2680 state) {
        super(DragonLib.DRAGONLIB_BLOCK_ENTITY.get(), pos, state);
    }
}
