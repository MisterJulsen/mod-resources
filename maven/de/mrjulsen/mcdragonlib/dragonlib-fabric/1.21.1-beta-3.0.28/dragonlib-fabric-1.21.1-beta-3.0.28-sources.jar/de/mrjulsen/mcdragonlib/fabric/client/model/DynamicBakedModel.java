package de.mrjulsen.mcdragonlib.fabric.client.model;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Supplier;

import de.mrjulsen.mcdragonlib.client.model.ICustomModelBlockEntity;
import de.mrjulsen.mcdragonlib.client.model.IDynamicBakedModel;
import de.mrjulsen.mcdragonlib.client.model.ModelContext;
import de.mrjulsen.mcdragonlib.client.model.extension.DLBakedQuad;
import de.mrjulsen.mcdragonlib.client.model.extension.DLFaceData;
import de.mrjulsen.mcdragonlib.client.model.extension.fabric.DLBakedQuadImpl;
import de.mrjulsen.mcdragonlib.client.model.mesh.DLModel;
import de.mrjulsen.mcdragonlib.client.model.mesh.DLModel.ModelType;
import de.mrjulsen.mcdragonlib.fabric.client.model.loaders.DLBakedModelExtension;
import net.fabricmc.fabric.api.renderer.v1.Renderer;
import net.fabricmc.fabric.api.renderer.v1.RendererAccess;
import net.fabricmc.fabric.api.renderer.v1.material.BlendMode;
import net.fabricmc.fabric.api.renderer.v1.material.MaterialFinder;
import net.fabricmc.fabric.api.renderer.v1.material.RenderMaterial;
import net.fabricmc.fabric.api.renderer.v1.mesh.QuadEmitter;
import net.fabricmc.fabric.api.renderer.v1.model.ForwardingBakedModel;
import net.fabricmc.fabric.api.renderer.v1.model.ModelHelper;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;
import net.minecraft.class_1087;
import net.minecraft.class_1799;
import net.minecraft.class_1920;
import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_5819;
import net.minecraft.class_777;

public class DynamicBakedModel extends ForwardingBakedModel implements IDynamicBakedModel {
    private static final Renderer RENDERER = RendererAccess.INSTANCE.getRenderer();

    private final class_2680 defaultState;
    private final DLModel newModel;

    private record MaterialKey(class_1921 renderType, boolean ambientOcclusion, boolean emissive) {
        public static MaterialKey create(class_1921 rendertype, class_777 bakedquad) {
            if (bakedquad instanceof DLBakedQuad ext) {
                return new MaterialKey(rendertype, ext.isAmbientOcclusion(), ext.isEmissive());
            }
            return new MaterialKey(rendertype, DLFaceData.DEFAULT.ambientOcclusion(), DLFaceData.DEFAULT.emissive());
        }
    }
    private final Map<MaterialKey, RenderMaterial> materialCache = new ConcurrentHashMap<>();

    public DynamicBakedModel(class_1087 src, class_2680 defaultState, DLModel newModel) {
        this.wrapped = Objects.requireNonNull(src);
        this.defaultState = Objects.requireNonNull(defaultState);
        this.newModel = Objects.requireNonNull(newModel);
    }

    private RenderMaterial getMaterial(class_1921 renderType, class_777 quad) {
        return materialCache.computeIfAbsent(MaterialKey.create(renderType, quad), key -> {
            MaterialFinder finder = RENDERER.materialFinder().blendMode(BlendMode.fromRenderLayer(key.renderType));
            if (quad instanceof DLBakedQuad ext) {
                finder = DLBakedModelExtension.applyMaterial(ext, finder);
            }
            return finder.find();
        });
    }

    @Override
    public void emitBlockQuads(class_1920 blockView, class_2680 state, class_2338 pos, Supplier<class_5819> randomSupplier, RenderContext context) {
        ModelContext modelContext = ModelContext.EMPTY;
        if (blockView.method_8321(pos) instanceof ICustomModelBlockEntity be) {
            modelContext = be.getModelContext();
        }
        emitQuads(context, randomSupplier.get(), state, ModelType.BLOCK, modelContext);
    }

    @Override
    public void emitItemQuads(class_1799 stack, Supplier<class_5819> randomSupplier, RenderContext context) {
        emitQuads(context, randomSupplier.get(), defaultState, ModelType.ITEM, ModelContext.EMPTY);
    }

    private void emitQuads(RenderContext context, class_5819 rand, class_2680 state, ModelType type, ModelContext modelContext) {
        QuadEmitter emitter = context.getEmitter();

        for (int i = 0; i <= ModelHelper.NULL_FACE_ID; i++) {
            final class_2350 cullFace = ModelHelper.faceFromIndex(i);

            if (type == ModelType.BLOCK && cullFace != null && context.isFaceCulled(cullFace)) {
                continue;
            }

            for (class_1921 renderType : newModel.getSupportedRenderTypes()) {
                final List<class_777> quads = newModel.getQuads(type, wrapped, state, rand, renderType, cullFace, modelContext);

                for (class_777 q : quads) {
                    emitter.fromVanilla(q, getMaterial(renderType, q), cullFace).emit();
                }
            }
        }
    }



    @Override
    public class_1087 getOriginalModel() {
        return wrapped;
    }

    @Override
    public DLModel getModel() {
        return newModel;
    }

    @Override
    public boolean isVanillaAdapter() {
        return false;
    }
}
