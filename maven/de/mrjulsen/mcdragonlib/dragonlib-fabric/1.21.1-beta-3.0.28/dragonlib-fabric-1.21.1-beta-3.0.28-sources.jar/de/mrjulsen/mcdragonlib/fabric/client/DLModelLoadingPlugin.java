package de.mrjulsen.mcdragonlib.fabric.client;

import com.google.common.collect.ImmutableMap;

import de.mrjulsen.mcdragonlib.client.model.DLBlockModelRegistry;
import de.mrjulsen.mcdragonlib.client.model.DLBlockModelRegistry.ModelRegistryData;
import de.mrjulsen.mcdragonlib.events.client.ModelEvents;
import de.mrjulsen.mcdragonlib.fabric.client.model.DynamicBakedModel;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.model.loading.v1.ModelLoadingPlugin;
import net.minecraft.class_1087;
import net.minecraft.class_1088;
import net.minecraft.class_1091;
import net.minecraft.class_1100;
import net.minecraft.class_2960;
import net.minecraft.client.resources.model.*;

@Environment(EnvType.CLIENT)
public class DLModelLoadingPlugin implements ModelLoadingPlugin {

    @Override
    public void onInitializeModelLoader(Context pluginContext) {
        ModelEvents.ADDITIONAL_MODELS.invoker().registerAdditionalModels(e -> pluginContext.addModels(e.comp_2875()));
        pluginContext.modifyModelAfterBake().register((original, ctx) -> {
            class_1087 model = ModelEvents.MODIFY_MODELS.invoker().modifyModels(original, new ModelEvents.ModifyModels.Context() {
                @Override
                public class_1088 getModelBakery() {
                    return ctx.loader();
                }

                @Override
                public class_1091 getModelLocation() {
                    return ctx.topLevelId();
                }

                @Override
                public class_1100 getUnbakedModel() {
                    return ctx.sourceModel();
                }
            });
            return model == null ? original : model;
        });

        ImmutableMap<class_2960, ModelRegistryData> factories = DLBlockModelRegistry.getCustomRegisteredModelsMapped();

        pluginContext.modifyModelAfterBake().register((original, context) -> {
            class_1087 model = original;
            if (factories.containsKey(context.resourceId())) {
                ModelRegistryData data = factories.get(context.resourceId());
                DLBlockModelRegistry.setOriginalModel(data.state(), model);
                model = new DynamicBakedModel(model, data.state(), data.factory().getModelFactory().get());
            }
            return model;
        });
    }
}