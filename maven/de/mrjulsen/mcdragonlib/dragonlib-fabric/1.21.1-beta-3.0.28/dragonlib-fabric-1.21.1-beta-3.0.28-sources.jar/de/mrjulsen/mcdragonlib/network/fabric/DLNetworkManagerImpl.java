package de.mrjulsen.mcdragonlib.network.fabric;

import de.mrjulsen.mcdragonlib.network.DLNetworkManager;
import de.mrjulsen.mcdragonlib.network.NetworkPacketContext;
import de.mrjulsen.mcdragonlib.network.NetworkSide;
import de.mrjulsen.mcdragonlib.util.DLUtils;
import dev.architectury.utils.Env;
import dev.architectury.utils.EnvExecutor;
import io.netty.buffer.ByteBufUtil;
import io.netty.buffer.Unpooled;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1255;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2596;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import java.util.concurrent.CompletableFuture;
import java.util.function.Supplier;

public class DLNetworkManagerImpl {
    
    public static void registerChannel(class_2960 channelId, String name, NetworkSide side, String protocolVersion) {
        class_8710.class_9154<DLNetworkManager.BufCustomPacketPayload> type = new class_8710.class_9154<>(DLUtils.resourceLocation(channelId.method_12836(), channelId.method_12832() + "/" + name));
        class_9139<? super class_9129, DLNetworkManager.BufCustomPacketPayload> codec = DLNetworkManager.BufCustomPacketPayload.streamCodec(type);
        PayloadTypeRegistry.playC2S().register(type, codec);
        PayloadTypeRegistry.playS2C().register(type, codec);

        ServerPlayNetworking.registerGlobalReceiver(type, (payload, ctx) -> {
            NetworkPacketContext context = context(ctx.player(), ctx.server(), false);
            class_9129 buf = new class_9129(Unpooled.wrappedBuffer(payload.payload()), ctx.player().method_56673());
            DLNetworkManager.receiveData(channelId, buf, NetworkSide.S2C, context);
            buf.release();
        });

        EnvExecutor.runInEnv(Env.CLIENT, () -> () -> ClientNetworkManager.registerChannel(channelId, name, protocolVersion));
    }
    
    
    static NetworkPacketContext context(class_1657 player, class_1255<?> taskQueue, boolean client) {
        return new NetworkPacketContext() {
            @Override
            public class_1657 getPlayer() {
                return player;
            }
            
            @Override
            public void queue(Runnable runnable) {
                taskQueue.execute(runnable);
            }

            @Override
            public <O> O queueResult(Supplier<O> supplier) {
                CompletableFuture<O> future = new CompletableFuture<>();
                taskQueue.execute(() -> {
                    try {
                        future.complete(supplier.get());
                    } catch (Throwable t) {
                        future.completeExceptionally(t);
                    }
                });
                return future.join();
            }
            
            @Override
            public Env getEnvironment() {
                return client ? Env.CLIENT : Env.SERVER;
            }
        };
    }
    
    public static class_2596<?> toPacket(class_2960 channelId, String name, NetworkSide side, class_2540 buf) {
        class_2960 id = DLUtils.resourceLocation(channelId.method_12836(), channelId.method_12832() + "/" + name);
        if (side == NetworkSide.C2S) {
            return toC2SPacket(id, buf);
        } else if (side == NetworkSide.S2C) {
            return toS2CPacket(id, buf);
        }
        
        throw new IllegalArgumentException("Invalid side: " + side);
    }
    

    
    @Environment(EnvType.CLIENT)
    private static class_2596<?> toC2SPacket(class_2960 id, class_2540 buf) {
        class_8710.class_9154<DLNetworkManager.BufCustomPacketPayload> type = new class_8710.class_9154<>(id);
        DLNetworkManager.BufCustomPacketPayload payload = new DLNetworkManager.BufCustomPacketPayload(type, ByteBufUtil.getBytes(buf));
        return ClientPlayNetworking.createC2SPacket(payload);
    }
    
    private static class_2596<?> toS2CPacket(class_2960 id, class_2540 buf) {
        class_8710.class_9154<DLNetworkManager.BufCustomPacketPayload> type = new class_8710.class_9154<>(id);
        DLNetworkManager.BufCustomPacketPayload payload = new DLNetworkManager.BufCustomPacketPayload(type, ByteBufUtil.getBytes(buf));
        return ServerPlayNetworking.createS2CPacket(payload);
    }
}
