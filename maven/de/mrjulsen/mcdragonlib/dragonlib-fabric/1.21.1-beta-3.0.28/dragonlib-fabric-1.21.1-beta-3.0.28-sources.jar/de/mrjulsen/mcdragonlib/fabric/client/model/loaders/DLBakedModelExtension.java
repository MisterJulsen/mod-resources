package de.mrjulsen.mcdragonlib.fabric.client.model.loaders;

import de.mrjulsen.mcdragonlib.client.model.extension.DLBakedQuad;
import de.mrjulsen.mcdragonlib.client.model.extension.DLFaceData;
import de.mrjulsen.mcdragonlib.client.model.extension.DLFaceKey;
import net.fabricmc.fabric.api.renderer.v1.Renderer;
import net.fabricmc.fabric.api.renderer.v1.RendererAccess;
import net.fabricmc.fabric.api.renderer.v1.material.MaterialFinder;
import net.fabricmc.fabric.api.renderer.v1.material.RenderMaterial;
import net.fabricmc.fabric.api.renderer.v1.mesh.QuadEmitter;
import net.fabricmc.fabric.api.renderer.v1.model.ForwardingBakedModel;
import net.fabricmc.fabric.api.renderer.v1.model.ModelHelper;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;
import net.fabricmc.fabric.api.util.TriState;
import net.minecraft.class_1087;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_5819;
import net.minecraft.class_777;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Supplier;

public class DLBakedModelExtension extends ForwardingBakedModel {

    private static final Renderer RENDERER = RendererAccess.INSTANCE.getRenderer();
    private static final RenderMaterial DEFAULT_MAT = RENDERER.materialFinder()
            .find();

    private static final RenderMaterial EMISSIVE_MAT = RENDERER.materialFinder()
            .emissive(true)
            .ambientOcclusion(TriState.FALSE)
            .disableDiffuse(true)
            .find();

    private static final RenderMaterial NO_AO_MAT = RENDERER.materialFinder()
            .ambientOcclusion(TriState.FALSE)
            .find();


    private final Map<DLFaceKey, DLFaceData> faceData;


    private record CacheKey(class_2680 state, class_2350 side) {}
    private final Map<CacheKey, List<class_777>> cachedQuads = new ConcurrentHashMap<>();

    public DLBakedModelExtension(class_1087 parent, Map<DLFaceKey, DLFaceData> faceData) {
        this.wrapped = parent;
        this.faceData = faceData;
    }

    @Override
    public boolean isVanillaAdapter() {
        return false;
    }

    @Override
    public void emitBlockQuads(class_1920 blockView, class_2680 state, class_2338 pos, Supplier<class_5819> randomSupplier, RenderContext context) {
        emitQuads(context, randomSupplier.get(), state);
    }

    private void emitQuads(RenderContext context, class_5819 rand, class_2680 state) {
        QuadEmitter emitter = context.getEmitter();

        for (int i = 0; i <= ModelHelper.NULL_FACE_ID; i++) {
            final class_2350 cullFace = ModelHelper.faceFromIndex(i);

            if (cullFace != null && context.isFaceCulled(cullFace)) {
                continue;
            }

            List<class_777> quads = method_4707(state, cullFace, rand);
            for (class_777 q : quads) {
                if (q instanceof DLBakedQuad dlq) {
                    context.pushTransform(quadView -> {
                        RenderMaterial mat = DEFAULT_MAT;
                        if (dlq.isEmissive()) {
                            mat = EMISSIVE_MAT;
                        } else if (!dlq.isAmbientOcclusion()) {
                            mat = NO_AO_MAT;
                        }
                        quadView.fromVanilla(dlq, mat, cullFace);
                        return true;
                    });
                    emitter.emit();
                    context.popTransform();
                } else {
                    emitter.fromVanilla(q, DEFAULT_MAT, cullFace);
                    emitter.emit();
                }
            }
        }
    }

    public static MaterialFinder applyMaterial(DLBakedQuad quad, MaterialFinder material) {
        if (quad.isEmissive()) {
            return material.emissive(true).ambientOcclusion(TriState.FALSE).disableDiffuse(true);
        } else if (!quad.isAmbientOcclusion()) {
            return material.copyFrom(NO_AO_MAT);
        }
        return material;
    }

    @Override
    public List<class_777> method_4707(class_2680 blockState, class_2350 face, class_5819 rand) {
        return cachedQuads.computeIfAbsent(new CacheKey(blockState, face), k -> {
            List<class_777> src = super.method_4707(blockState, face, rand);
            List<class_777> quads = new ArrayList<>(src.size());
            int i = 0;
            for (class_777 q : src) {
                DLFaceKey key = new DLFaceKey(i, face);
                DLFaceData data = faceData.get(key);
                if (data != null) {
                    quads.add(DLBakedQuad.create(q, data));
                } else {
                    quads.add(q);
                }
                i++;
            }
            return quads;
        });
    }
}
