package de.mrjulsen.mcdragonlib.client.model.mesh;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_1091;
import net.minecraft.class_1723;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_5819;
import net.minecraft.class_777;
import de.mrjulsen.mcdragonlib.client.model.ModelResourceLocationBuilder;
import de.mrjulsen.mcdragonlib.client.model.ModelUtils;

public class BasicMesh extends Mesh {

    public BasicMesh() {
        super(new ArrayList<>(), new ArrayList<>(), new ArrayList<>());
    }


    public static BasicMesh fromBakedModel(class_2680 state, class_1087 srcModel, class_5819 random) {
        BasicMesh mesh = new BasicMesh();
        class_2350[] directions = new class_2350[class_2350.values().length + 1];
        System.arraycopy(class_2350.values(), 0, directions, 0, class_2350.values().length);
        for (class_2350 side : directions) {
            for (class_777 quad : srcModel.method_4707(state, side, random)) {
                mesh.addFace(new Face(quad, side));
            }
        }
        mesh.cleanUp(0.0001f, true, true, true);
        return mesh;
    }

    public static BasicMesh fromBlock(class_2680 state, class_5819 random) {
        class_1087 srcModel = class_310.method_1551().method_1554().method_4743().method_3335(state);
        return fromBakedModel(state, srcModel, random);
    }

    public static BasicMesh fromLocation(class_1091 modelLocation, class_5819 random) {
        return fromBakedModel(null, ModelUtils.getModel(modelLocation), random);
    }

    public void combine(boolean merge, Mesh... meshes) {
        for (Mesh mesh : meshes) {
            if (mesh == this) {
                throw new IllegalArgumentException("Cannot combine Mesh with itself.");
            }
            for (Face face : mesh.getFaces()) {
                addFace(face);
            }
        }

        if (merge) {
            cleanUp(0.0001F, true, true, true);
        }
    }

    public void addFace(Face face) {
        faces.add(face);
        edges.addAll(face.getEdges());
        for (FaceVertex wrapper : face.getCorners()) {
            vertices.add(wrapper.getVertex());
        }
    }

    public void removeFace(Face face) {
        Map<Vertex, Vertex> replacements = new HashMap<>(4);
        faces.remove(face);
        for (FaceVertex wrapper : face.getCorners()) {
            Vertex current = wrapper.getVertex();
            Vertex copy = current.copy();
            wrapper.updateVertex(copy);
            replacements.put(current, copy);
        }        
        face.updateEdges(x -> x.copy(y -> replaceFunc(replacements, y)));
    }

    public void swapTextures(class_2960 current, class_2960 newLocation) {
        for (Face face : faces) {
            if (face.getTextureLocation() == null) {
                continue;
            }
            class_2960 loc = face.getTextureLocation();
            if (!loc.equals(current)) {
                continue;
            }

            class_1058 sprite = class_310.method_1551().method_1554().method_24153(class_1723.field_21668).method_4608(newLocation);
            face.setTexture(sprite);
        }
    }

}
