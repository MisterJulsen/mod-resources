package de.mrjulsen.mcdragonlib.fabric.client.model.geometry;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.google.gson.JsonObject;

import de.mrjulsen.mcdragonlib.DragonLib;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

import com.google.common.collect.ImmutableMap;

import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;
import net.fabricmc.loader.api.metadata.CustomValue;
import net.fabricmc.loader.api.metadata.CustomValue.CvType;
import net.minecraft.class_2960;
import net.minecraft.class_3518;

public final class GeometryLoaderManager {
	private static ImmutableMap<class_2960, IGeometryLoader<?>> LOADERS;
	private static String LOADER_LIST;
	public static final List<class_2960> KNOWN_MISSING_LOADERS = new ArrayList<>();

		@Nullable
	public static IGeometryLoader<?> get(class_2960 name) {
		return LOADERS.get(name);
	}

		public static String getLoaderList() {
		return LOADER_LIST;
	}

		@Nullable
	public static String getModelLoader(JsonObject json) {
		if (json.has(DragonLib.MODID + ":loader")) {
			return class_3518.method_15265(json, DragonLib.MODID + ":loader");
		} else if (json.has("loader")) {
			return class_3518.method_15265(json, "loader");
		} else {
			return null;
		}
	}

	@ApiStatus.Internal
	public static void init() {
		Map<class_2960, IGeometryLoader<?>> loaders = new HashMap<>();
		RegisterGeometryLoadersCallback.EVENT.invoker().registerGeometryLoaders(loaders);
		getProvidedLoaders(loaders);
		LOADERS = ImmutableMap.copyOf(loaders);
		LOADER_LIST = loaders.keySet().stream().map(class_2960::toString).collect(Collectors.joining(", "));
	}

		private static void getProvidedLoaders(Map<class_2960, IGeometryLoader<?>> loaders) {
		List<class_2960> providedLoaders = new ArrayList<>();
		for (ModContainer mod : FabricLoader.getInstance().getAllMods()) {
			CustomValue provided = mod.getMetadata().getCustomValue(DragonLib.MODID + ":provided_loaders");
			if (provided == null) {
				continue;
			}
			if (provided.getType() != CvType.ARRAY) {
				DragonLib.LOGGER.error("Mod {} specifies provided loaders, but it's not an array! got: {}",
						mod.getMetadata().getName(), provided.getType());
				continue;
			}
			for (CustomValue value : provided.getAsArray()) {
				if (value.getType() != CvType.STRING) {
					DragonLib.LOGGER.error("Mod {} specifies an array of provided loaders, but it contains a non-string! got: {}",
							mod.getMetadata().getName(), value.getType());
					continue;
				}
				String idString = value.getAsString();
				class_2960 id = class_2960.method_12829(idString);
				if (id == null) {
					DragonLib.LOGGER.error("Mod {} provides loader {}, which is not a valid ID!",
							mod.getMetadata().getName(), idString);
					continue;
				}
				providedLoaders.add(id);
			}
		}
		if (!providedLoaders.isEmpty()) {
			StringBuilder out = new StringBuilder("Registered %s provided loaders: ".formatted(providedLoaders.size()));
			for (class_2960 loader : providedLoaders) {
				out.append(loader).append(", ");
				loaders.put(loader, NullGeometryLoader.INSTANCE);
			}
			DragonLib.LOGGER.info(out.substring(0, out.length() - 2)); 
		}
	}

	private GeometryLoaderManager() {}

	static {
		init();
	}
}
