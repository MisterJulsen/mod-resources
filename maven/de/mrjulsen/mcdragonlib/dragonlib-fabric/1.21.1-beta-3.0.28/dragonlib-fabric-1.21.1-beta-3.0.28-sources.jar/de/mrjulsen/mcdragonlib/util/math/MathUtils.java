package de.mrjulsen.mcdragonlib.util.math;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.function.Predicate;
import net.minecraft.class_1923;
import net.minecraft.class_2338;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_2350.class_2352;
import net.minecraft.class_238;
import net.minecraft.class_2382;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_3532;
import net.minecraft.class_4076;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import org.joml.Vector3fc;
import org.joml.Vector3i;
import org.joml.Vector3ic;

/**
 * Collection of assorted math helpers used across the codebase (vector/geometry, clamps, rotations etc).
 *
 * <p>All methods are static utilities. Javadocs describe semantics, parameters and return values
 * to make usage unambiguous.
 */
public final class MathUtils {
    private MathUtils() {}

    /**
     * Compute the proportion of a value relative to a maximum value.
     *
     * @param val value to compare
     * @param max maximum reference value (non-zero)
     * @return proportion in range (-inf, +inf); typically used when {@code 0 <= val <= max}
     */
    public static double proportion(double val, double max) {
        return (1D / max) * val;
    }

    /**
     * Add {@code add} to {@code value} while preventing crossing the provided [min, max] bounds.
     *
     * <p>If adding would push the value beyond the interval, the original value is returned.
     *
     * @param value current value
     * @param add delta to add (may be negative)
     * @param min lower bound (inclusive)
     * @param max upper bound (inclusive)
     * @return new bounded value or original value if adding would overflow bounds
     */
    public static double bounds(double value, double add, double min, double max) {
        if ((add > 0 && value >= max - add) || (add < 0 && value <= min + add)) {
            return value;
        }
        return value + add;
    }
    
    /**
     * Round a double value to the given number of decimal places.
     *
     * @param value value to round
     * @param decimals number of decimal places {@code >= 0}
     * @return rounded value
     * @throws IllegalArgumentException if {@code decimals < 0} 
     */
    public static double round(double value, int decimals) {
        if (decimals < 0)
            throw new IllegalArgumentException();

        long factor = (long) java.lang.Math.pow(10, decimals);
        value = value * factor;
        long tmp = java.lang.Math.round(value);
        return (double) tmp / factor;
    }

    /**
     * Format a Vector3f into a readable "(x, y, z)" string.
     *
     * @param vec vector to format
     * @return formatted string
     */
    public static String printVector3f(Vector3fc vec) {
        return String.format("(%s, %s, %s)", vec.x(), vec.y(), vec.z());
    }

    /**
     * Convert a BlockPos to a Vec3i.
     *
     * @param pos the BlockPos to convert
     * @return Vec3i with identical integer components
     */
    public static class_2382 blockPosToVec3i(class_2338 pos) {
        return new class_2382(pos.method_10263(), pos.method_10264(), pos.method_10260());
    }

    /**
     * Convert a BlockPos to a Vec3 (double components).
     *
     * @param pos the BlockPos to convert
     * @return Vec3 at the block coordinates (integers as doubles)
     */
    public static class_243 blockPosToVec3(class_2338 pos) {
        return new class_243(pos.method_10263(), pos.method_10264(), pos.method_10260());
    }

    /**
     * Convert a BlockPos to a JOML Vector3f.
     *
     * @param pos the BlockPos to convert
     * @return Vector3f with float components
     */
    public static Vector3f blockPosToVector3f(class_2338 pos) {
        return new Vector3f(pos.method_10263(), pos.method_10264(), pos.method_10260());
    }

    /**
     * Convert a JOML integer vector to a BlockPos.
     *
     * @param vec input vector (integer components)
     * @return BlockPos built from vector components
     */
    public static class_2338 vector3iToBlockPos(Vector3ic vec) {
        return new class_2338((int)vec.x(), (int)vec.y(), (int)vec.z());
    }

    /**
     * Convert a Vec3 to a BlockPos by truncating coordinates to integers.
     *
     * @param vec input Vec3
     * @return BlockPos with truncated components
     */
    public static class_2338 vec3ToBlockPos(class_243 vec) {
        return new class_2338((int)vec.method_10216(), (int)vec.method_10214(), (int)vec.method_10215());
    }

    /**
     * Convert a Vec3i to a BlockPos.
     *
     * @param vec input Vec3i
     * @return BlockPos with identical components
     */
    public static class_2338 vec3iToBlockPos(class_2382 vec) {
        return new class_2338(vec.method_10263(), vec.method_10264(), vec.method_10260());
    }

    /**
     * Convert a BlockPos to a JOML Vector3i.
     *
     * @param pos BlockPos
     * @return Vector3i with same coordinates
     */
    public static Vector3i blockPosToVector3i(class_2338 pos) {
        return new Vector3i(pos.method_10263(), pos.method_10264(), pos.method_10260());
    }

    /**
     * Calculate slope between two 3D points as horizontal distance divided by vertical difference.
     *
     * @param a first point
     * @param b second point
     * @return slope (horizontal / vertical). Caller must handle potential division by zero if heights equal.
     */
    public static double slope(Vector3f a, Vector3f b) {
        double heightDiff = java.lang.Math.max(a.y, b.y) - java.lang.Math.min(a.y, b.y);
        float dx = a.x - b.x;
        float dz = a.z - b.z;
        float horizontalDistance = (float) Math.sqrt(dx * dx + dz * dz);
        return horizontalDistance / heightDiff;
    }

    /**
     * Linear interpolation between start and end with parameter delta in [0,1].
     *
     * @param delta interpolation factor
     * @param start start value
     * @param end end value
     * @return interpolated value
     */
    public static double lerp(double delta, double start, double end) {
        return start + delta * (end - start);    
    }

    /**
     * Clamp primitive byte value to a range.
     */
    public static byte clamp(byte value, byte min, byte max) {
        if (value < min) {
            return min;
        } else {
            return value > max ? max : value;
        }
    }

    /**
     * Clamp int value to a range.
     */
    public static int clamp(int value, int min, int max) {
        if (value < min) {
            return min;
        } else {
            return value > max ? max : value;
        }
    }

    /**
     * Clamp long value to a range.
     */
    public static long clamp(long value, long min, long max) {
        if (value < min) {
            return min;
        } else {
            return value > max ? max : value;
        }
    }

    /**
     * Clamp float value to a range.
     */
    public static float clamp(float value, float min, float max) {
        if (value < min) {
            return min;
        } else {
            return value > max ? max : value;
        }
    }

    /**
     * Clamp double value to a range.
     */
    public static double clamp(double value, double min, double max) {
        if (value < min) {
            return min;
        } else {
            return value > max ? max : value;
        }
    }

    /**
     * Compute a compass-like angle from a vector.
     *
     * @param vec input vector
     * @return angle in degrees rounded to nearest integer
     */
    public static double getVectorAngle(Vector3f vec) {
        return Math.round(Math.atan2(vec.x(), -vec.z()) * (180.0 / Math.PI));
    }

    private static double calcScale(double minScale, double maxScale, double maxWidth, double fontWidth) {
        double scale = Math.min(maxWidth / fontWidth, 1.0D);
        return Math.max(maxScale * scale, minScale);
    }

    public static double getScale(float fontWidth, float lineWidth, float min, float max) {
        return calcScale(min, max, lineWidth / max, fontWidth);
    }  

    /**
     * Calculate a smoothed median from a queue of values with filtering.
     *
     * @param database queue containing values
     * @param smoothingThreshold max deviation accepted from median when averaging
     * @param filter predicate to include values
     * @return smoothed median average or 0 if database empty
     */
    public static double calculateMedian(Queue<Double> database, double smoothingThreshold, Predicate<Double> filter) {
        if (database.isEmpty()) {
            return 0;
        }

        List<Double> values = new LinkedList<>();
        for (double i : database) {
            if (!filter.test(i)) 
                continue;

            values.add(i);
        }

        Collections.sort(values);
        double median = 0;
        if (values.size() % 2 == 0) {
            median = ((double)values.get(values.size() / 2) + (double)values.get(values.size() / 2 + 1)) / 2D;
        }
        median = values.get(values.size() / 2);

        final double med = median;
        return database.stream().mapToDouble(x -> x).filter(x -> Math.abs(med - x) <= smoothingThreshold).average().orElse(0);
    }

    /**
     * A Vec3 constant for the center of origin (0.5,0.5,0.5).
     */
    public static final class_243 CENTER_OF_ORIGIN = new class_243(0.5f, 0.5f, 0.5f);
    /**
     * A Vector3f constant for the center of origin.
     */
    public static final Vector3f CENTER_OF_ORIGIN2 = new Vector3f(0.5f, 0.5f, 0.5f);

    /**
     * Rotate a Vec3 by Euler angles.
     */
    public static class_243 rotate(class_243 vec, class_243 rotationVec) {
        return rotate(vec, rotationVec.field_1352, rotationVec.field_1351, rotationVec.field_1350);
    }

    /**
     * Rotate a Vec3 by three Euler angles (degrees).
     */
    public static class_243 rotate(class_243 vec, double xRot, double yRot, double zRot) {
        return rotate(rotate(rotate(vec, xRot, class_2351.field_11048), yRot, class_2351.field_11052), zRot, class_2351.field_11051);
    }

    /**
     * Rotate around the center of a block (0.5,0.5,0.5).
     */
    public static class_243 rotateCentered(class_243 vec, double deg, class_2351 axis) {
        class_243 shift = getCenterOf(class_2338.field_10980);
        return rotate(vec.method_1020(shift), deg, axis).method_1019(shift);
    }

    /**
     * Rotate a vector around a given axis by degrees.
     */
    public static class_243 rotate(class_243 vec, double deg, class_2351 axis) {
        if (deg == 0)
            return vec;
        if (vec == class_243.field_1353)
            return vec;

        float angle = (float) (deg / 180f * Math.PI);
        double sin = Math.sin(angle);
        double cos = Math.cos(angle);
        double x = vec.field_1352;
        double y = vec.field_1351;
        double z = vec.field_1350;

        if (axis == class_2351.field_11048)
            return new class_243(x, y * cos - z * sin, z * cos + y * sin);
        if (axis == class_2351.field_11052)
            return new class_243(x * cos + z * sin, y, z * cos - x * sin);
        if (axis == class_2351.field_11051)
            return new class_243(x * cos - y * sin, y * cos + x * sin, z);
        return vec;
    }

    /**
     * Compute center of a block position (Vec3).
     */
    public static class_243 getCenterOf(class_2382 pos) {
        if (pos.equals(class_2382.field_11176))
            return CENTER_OF_ORIGIN;
        return class_243.method_24954(pos).method_1031(0.5f, 0.5f, 0.5f);
    }

    /**
     * Check whether two axis-aligned rectangles intersect.
     *
     * @return true if rectangles overlap
     */
    public static boolean rectanglesIntersecting(double x1, double y1, double w1, double h1, double x2, double y2, double w2, double h2) {
        return (x1 < x2 + w2 && y1 < y2 + h2) && (x1 + w1 > x2 && y1 + h1 > y2);
    }

    /**
     * Check whether a section belongs to a given chunk.
     */
    public boolean isSectionInChunk(class_4076 section, class_1923 chunk) {
        return section.method_10263() == chunk.field_9181 && section.method_10260() == chunk.field_9180;
    }

    /**
     * Convert a SectionPos into a ChunkPos containing it.
     */
    public class_1923 getChunkOfSection(class_4076 section) {
        return new class_1923(section.method_10263(), section.method_10260());
    }

    /**
     * Rotate a 2D vector (Vec2) around origin by degrees (Y-rotation analog).
     */
    public static class_241 rotateY(class_241 vec, double deg) {
		if (deg == 0)
			return vec;
		if (vec == class_241.field_1340)
			return vec;

		float angle = (float) (deg / 180f * Math.PI);
		double sin = class_3532.method_15374(angle);
		double cos = class_3532.method_15362(angle);
		double x = vec.field_1343;
		double y = vec.field_1342;
        return new class_241((float)(x * cos + y * sin), (float)(y * cos - x * sin));
    }
    
    /**
     * Move a VoxelShape by a vector.
     */
    public static class_265 moveShape(class_265 shape, class_243 vec) {
        class_238[] aabbs = shape.method_1090().toArray(class_238[]::new);
        class_265[] shapes = new class_265[aabbs.length];
        for (int i = 0; i < aabbs.length; i++) {
            shapes[i] = class_259.method_1078(moveAABB(aabbs[i], vec));
        }
        return class_259.method_17786(class_259.method_1073(), shapes);
    }

    /**
     * Move an AABB by the given vector.
     */
    public static class_238 moveAABB(class_238 aabb, class_243 vec) {
        return new class_238(aabb.field_1323 + vec.field_1352, aabb.field_1322 + vec.field_1351, aabb.field_1321 + vec.field_1350, aabb.field_1320 + vec.field_1352, aabb.field_1325 + vec.field_1351, aabb.field_1324 + vec.field_1350);
    }

    /**
     * Rotate a VoxelShape around an axis by multiples of 90 degrees.
     */
    public static class_265 rotateShape(class_265 shape, class_2351 axis, int degrees) {
        class_238[] aabbs = shape.method_1090().toArray(class_238[]::new);
        class_265[] shapes = new class_265[aabbs.length];
        for (int i = 0; i < aabbs.length; i++) {
            shapes[i] = class_259.method_1078(rotateAABB(aabbs[i], axis, degrees));
        }
        return class_259.method_17786(class_259.method_1073(), shapes);
    }

    /**
     * Rotate an AABB around the unit cube center by 0/90/180/270 degrees.
     *
     * @throws IllegalArgumentException for unsupported degrees
     */
    public static class_238 rotateAABB(class_238 aabb, class_2351 axis, int degrees) {
        int normalizedDegrees = ((degrees % 360) + 360) % 360;
        if (normalizedDegrees == 0) return aabb;

        double minX = aabb.field_1323;
        double minY = aabb.field_1322;
        double minZ = aabb.field_1321;
        double maxX = aabb.field_1320;
        double maxY = aabb.field_1325;
        double maxZ = aabb.field_1324;
        
        switch (axis) {
            case field_11048:
                switch (normalizedDegrees) {
                    case 90:
                        return new class_238(minX, -maxZ, minY, maxX, -minZ, maxY);
                    case 180:
                        return new class_238(minX, -maxY, -maxZ, maxX, -minY, -minZ);
                    case 270:
                        return new class_238(minX, minZ, -maxY, maxX, maxZ, -minY);
                }
                break;
            case field_11052:
                switch (normalizedDegrees) {
                    case 90:
                        return new class_238(1f-maxZ, minY, minX, 1f-minZ, maxY, maxX);
                    case 180:
                        return new class_238(1f-maxX, minY, 1f-maxZ, 1f-minX, maxY, 1f-minZ);
                    case 270:
                        return new class_238(minZ, minY, 1f-maxX, maxZ, maxY, 1f-minX);
                }
                break;
            case field_11051:
                switch (normalizedDegrees) {
                    case 90:
                        return new class_238(-maxY, minX, minZ, -minY, maxX, maxZ);
                    case 180:
                        return new class_238(-maxX, -maxY, minZ, -minX, -minY, maxZ);
                    case 270:
                        return new class_238(minY, -maxX, minZ, maxY, -minX, maxZ);
                }
                break;
            default:
                throw new IllegalArgumentException("Axis must be 'x', 'y', or 'z'");
        }
        throw new IllegalArgumentException("Degrees must be 0, 90, 180, or 270");
    }

    /**
     * Scale a VoxelShape along an axis around a pivot.
     */
    public static class_265 scaleShape(class_265 shape, class_2351 axis, double factor, double pivot) {
        class_238[] aabbs = shape.method_1090().toArray(class_238[]::new);
        class_265[] shapes = new class_265[aabbs.length];
        for (int i = 0; i < aabbs.length; i++) {
            shapes[i] = class_259.method_1078(scaleAABB(aabbs[i], axis, factor, pivot));
        }
        return class_259.method_17786(class_259.method_1073(), shapes);
    }

    /**
     * Scales the AABB along an axis by a factor with an optional pivot.
     */
    public static class_238 scaleAABB(class_238 aabb, class_2351 axis, double factor, double pivot) {
        double min, max;
        switch (axis) {
            case field_11048:
                min = aabb.field_1323;
                max = aabb.field_1320;
                break;            
            case field_11052:
                min = aabb.field_1322;
                max = aabb.field_1325;
                break;
            case field_11051:
                min = aabb.field_1321;
                max = aabb.field_1324;
                break;
            default:
                throw new IllegalArgumentException("Axis must be 'x', 'y', or 'z'");
        }

        double minDiff = 0.5d - min;
        double maxDiff = max - 0.5d;
        double newMin = 0.5d - (factor * minDiff);
        double newMax = 0.5d + (factor * maxDiff);

        return switch (axis) {
            case field_11048 -> new class_238(newMin, aabb.field_1322, aabb.field_1321, newMax, aabb.field_1325, aabb.field_1324);
            case field_11052 -> new class_238(aabb.field_1323, newMin, aabb.field_1321, aabb.field_1320, newMax, aabb.field_1324);
            case field_11051 -> new class_238(aabb.field_1323, aabb.field_1322, newMin, aabb.field_1320, aabb.field_1325, newMax);
            default -> aabb;
        };
    }

    /**
     * Scale a VoxelShape keeping one side fixed.
     */
    public static class_265 scaleShapeOneSide(class_265 shape, class_2351 axis, double factor, class_2352 direction) {
        class_238[] aabbs = shape.method_1090().toArray(class_238[]::new);
        class_265[] shapes = new class_265[aabbs.length];
        for (int i = 0; i < aabbs.length; i++) {
            shapes[i] = class_259.method_1078(scaleAABBOneSide(aabbs[i], axis, factor, direction));
        }
        return class_259.method_17786(class_259.method_1073(), shapes);
    }

     /**
     * Scales the AABB along an axis, keeping one side fixed.
     */
    public static class_238 scaleAABBOneSide(class_238 aabb, class_2351 axis, double factor, class_2352 direction) {
        double min, max;
        switch (axis) {
            case field_11048:
                min = aabb.field_1323;
                max = aabb.field_1320;
                break;            
            case field_11052:
                min = aabb.field_1322;
                max = aabb.field_1325;
                break;
            case field_11051:
                min = aabb.field_1321;
                max = aabb.field_1324;
                break;
            default:
                throw new IllegalArgumentException("Axis must be 'x', 'y', or 'z'");
        }

        double minDiff = 0.5d - min;
        double maxDiff = max - 0.5d;
        double newMin = direction == class_2352.field_11060 ? 0.5d - (factor * minDiff) : min;
        double newMax = direction == class_2352.field_11056 ? 0.5d + (factor * maxDiff) : max;

        return switch (axis) {
            case field_11048 -> new class_238(newMin, aabb.field_1322, aabb.field_1321, newMax, aabb.field_1325, aabb.field_1324);
            case field_11052 -> new class_238(aabb.field_1323, newMin, aabb.field_1321, aabb.field_1320, newMax, aabb.field_1324);
            case field_11051 -> new class_238(aabb.field_1323, aabb.field_1322, newMin, aabb.field_1320, aabb.field_1325, newMax);
            default -> aabb;
        };
    }

    /**
     * Check the orientation of pointP relative to the directed line (pointA -> pointB).
     *
     * @return signum of cross product (1 = left, -1 = right, 0 = collinear)
     */
    public static int checkPointPosition(class_241 pointA, class_241 pointB, class_241 pointP) {
        return (int)Math.signum((pointB.field_1343 - pointA.field_1343) * (pointP.field_1342 - pointA.field_1342) - (pointB.field_1342 - pointA.field_1342) * (pointP.field_1343 - pointA.field_1343));
    }

    /**
     * Rotate vector v to align with dir using quaternion-based rotation.
     *
     * @param v input vector to rotate
     * @param dir target direction (normalized preferred)
     * @return rotated vector
     */
    public static Vector3f rotateToDirection(Vector3f v, Vector3f dir) {
        Vector3f direction = new Vector3f(dir).normalize();
        Vector3f xAxis = new Vector3f(1, 0, 0);
        if (xAxis.equals(direction, 1e-6f)) {
            return new Vector3f(v);
        }

        if (xAxis.equals(new Vector3f(direction).negate(), 1e-6f)) {
            Quaternionf q180 = new Quaternionf().fromAxisAngleRad(0, 0, 1, (float)Math.PI);
            return q180.transform(new Vector3f(v));
        }

        Vector3f axis = xAxis.cross(direction, new Vector3f()).normalize();
        float angle = (float)Math.acos(xAxis.dot(direction));
        Quaternionf rotation = new Quaternionf().fromAxisAngleRad(axis, angle);
        return rotation.transform(new Vector3f(v));
    }

    /**
     * Rotate a Vector3f by Euler angles vector.
     */
    public static Vector3f rotate(Vector3f vec, Vector3f rotationVec) {
        return rotate(vec, rotationVec.x, rotationVec.y, rotationVec.z);
    }

    /**
     * Rotate a Vector3f by X/Y/Z Euler rotations (degrees).
     */
    public static Vector3f rotate(Vector3f vec, double xRot, double yRot, double zRot) {
        return rotate(rotate(rotate(vec, xRot, class_2351.field_11048), yRot, class_2351.field_11052), zRot, class_2351.field_11051);
    }

    /**
     * Rotate a Vector3f around center of integer position.
     */
    public static Vector3f rotateCentered(Vector3f vec, double deg, class_2351 axis) {
        Vector3f shift = getCenterOf(new Vector3i());
        return rotate(new Vector3f(vec).sub(shift), deg, axis).add(shift);
    }

    /**
     * Rotate Vector3f by deg around axis.
     */
    public static Vector3f rotate(Vector3f vec, double deg, class_2351 axis) {
        if (deg == 0)
            return vec;

		float angle = (float) (deg / 180f * Math.PI);
		float sin = class_3532.method_15374(angle);
		float cos = class_3532.method_15362(angle);
		float x = vec.x;
		float y = vec.y;
		float z = vec.z;

		if (axis == class_2351.field_11048)
			return new Vector3f(x, y * cos - z * sin, z * cos + y * sin);
		if (axis == class_2351.field_11052)
			return new Vector3f(x * cos + z * sin, y, z * cos - x * sin);
		if (axis == class_2351.field_11051)
			return new Vector3f(x * cos - y * sin, y * cos + x * sin, z);
		return vec;
	}

    /**
     * Returns center-of-block as Vector3f.
     */
    public static Vector3f getCenterOf(Vector3i pos) {
        if (pos.equals(new Vector3i()))
            return CENTER_OF_ORIGIN2;
        return new Vector3f(pos).add(.5f, .5f, .5f);
    }

    /**
     * Compute center (arithmetic mean) of an array of Vector3f.
     *
     * @param points array of points (non-null, non-empty)
     * @return center Vector3f or null if input invalid
     */
    public static Vector3f centerOf(Vector3f... points) {
        if (points == null || points.length == 0) {
            return null;
        }

        Vector3f sum = new Vector3f(0, 0, 0);

        for (Vector3f v : points) {
            sum.add(v);
        }

        sum.div(points.length);

        return sum;
    }

    /**
     * Snap a value down to the nearest multiple of a.
     *
     * @param x value to snap
     * @param a snap increment (>0)
     * @return snapped value
     */
    public static double snap(double x, double a) {
        if (a <= 0) throw new IllegalArgumentException("a must be > 0");
        return Math.floor(x / a) * a;
    }

    /**
     * Snap a value to the nearest multiple of a.
     *
     * @param x value to snap
     * @param a snap increment (>0)
     * @return snapped value
     */
    public static double snapNearest(double x, double a) {
        if (a <= 0) throw new IllegalArgumentException("a must be > 0");
        return Math.round(x / a) * a;
    }
}


