package de.mrjulsen.mcdragonlib.fabric.client.model.loaders;

import de.mrjulsen.mcdragonlib.client.model.extension.DLFaceData;
import de.mrjulsen.mcdragonlib.client.model.extension.DLFaceKey;
import de.mrjulsen.mcdragonlib.fabric.client.model.geometry.IUnbakedGeometry;
import java.util.Map;
import java.util.function.Function;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_3665;
import net.minecraft.class_4730;
import net.minecraft.class_7775;
import net.minecraft.class_793;
import net.minecraft.class_806;

public class DLUnbakedModelExtension implements IUnbakedGeometry<DLUnbakedModelExtension> {

    private final class_793 parent;
    private final Map<DLFaceKey, DLFaceData> faceData;

    public DLUnbakedModelExtension(class_793 parent, Map<DLFaceKey, DLFaceData> data) {
        this.parent = parent;
        this.faceData = data;
    }

    @Override
    public class_1087 bake(class_793 context, class_7775 baker, Function<class_4730, class_1058> spriteGetter, class_3665 modelState, class_806 overrides, boolean isGui3d) {
        class_1087 vanilla = parent.method_3446(baker, parent, spriteGetter, modelState, isGui3d);
        return new DLBakedModelExtension(vanilla, faceData);
    }
}
