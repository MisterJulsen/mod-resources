package de.mrjulsen.mcdragonlib.fabric.client.model.loaders;

import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import net.fabricmc.fabric.api.renderer.v1.Renderer;
import net.fabricmc.fabric.api.renderer.v1.material.RenderMaterial;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import org.joml.Vector4f;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import de.mrjulsen.mcdragonlib.DragonLib;
import de.mrjulsen.mcdragonlib.fabric.client.model.geometry.IUnbakedGeometry;
import de.mrjulsen.mcdragonlib.fabric.client.model.geometry.UnbakedGeometryHelper;
import de.mrjulsen.mcdragonlib.fabric.client.model.geometry.extensions.BlockModelExtensions;
import de.mrjulsen.mcdragonlib.fabric.client.model.geometry.extensions.TransformationExtensions;
import de.mrjulsen.mcdragonlib.fabric.client.model.obj.ObjBakedModel;
import de.mrjulsen.mcdragonlib.fabric.client.model.obj.ObjMaterialLibrary;
import de.mrjulsen.mcdragonlib.util.math.MathUtils;
import net.fabricmc.fabric.api.renderer.v1.RendererAccess;
import net.fabricmc.fabric.api.renderer.v1.mesh.Mesh;
import net.fabricmc.fabric.api.renderer.v1.mesh.MeshBuilder;
import net.fabricmc.fabric.api.renderer.v1.mesh.MutableQuadView;
import net.fabricmc.fabric.api.renderer.v1.mesh.QuadEmitter;
import net.minecraft.class_1047;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_1100;
import net.minecraft.class_1723;
import net.minecraft.class_2350;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_3665;
import net.minecraft.class_4590;
import net.minecraft.class_4730;
import net.minecraft.class_765;
import net.minecraft.class_7775;
import net.minecraft.class_7833;
import net.minecraft.class_793;
import net.minecraft.class_806;
import net.minecraft.class_809;

public class MultipartObjModel implements IUnbakedGeometry<MultipartObjModel>, class_1100 {
	public static final boolean ENABLED;
	private static final Renderer renderer;
	private static final RenderMaterial diffuseMaterial;
	private static final RenderMaterial defaultMaterial;

	static {
		renderer = RendererAccess.INSTANCE.getRenderer();
		ENABLED = renderer != null;
		if (ENABLED) {
			diffuseMaterial = renderer.materialFinder().disableDiffuse(true).find();
			defaultMaterial = renderer.materialById(RenderMaterial.MATERIAL_STANDARD);
		} else {
			DragonLib.LOGGER.error("The Fabric Rendering API is not available. If you have Sodium, install Indium!");
			diffuseMaterial = defaultMaterial = null;
		}
	}

	private static final Vector4f COLOR_WHITE = new Vector4f(1, 1, 1, 1);
	private static final class_241[] DEFAULT_COORDS = {
			new class_241(0, 0),
			new class_241(0, 1),
			new class_241(1, 1),
			new class_241(1, 0),
	};

	final Map<String, ModelGroup> parts = Maps.newLinkedHashMap();
	private final Set<String> rootComponentNames = Collections.unmodifiableSet(parts.keySet());
	private Set<String> allComponentNames;

	final List<Vector3f> positions = Lists.newArrayList();
	final List<class_241> texCoords = Lists.newArrayList();
	final List<Vector3f> normals = Lists.newArrayList();
	final List<Vector4f> colors = Lists.newArrayList();

	public final boolean automaticCulling;
	public final boolean shadeQuads;
	public final boolean flipV;
	public final boolean emissiveAmbient;
	@Nullable
	public final String mtlOverride;

	public final class_2960 modelLocation;

	public MultipartObjModel(ModelSettings settings) {
		this.modelLocation = settings.modelLocation;
		this.automaticCulling = settings.automaticCulling;
		this.shadeQuads = settings.shadeQuads;
		this.flipV = settings.flipV;
		this.emissiveAmbient = settings.emissiveAmbient;
		this.mtlOverride = settings.mtlOverride;
	}

    public void addPart(String name, ModelGroup part) {
        parts.computeIfAbsent(name, a -> part);
    }
    
    public Collection<? extends ModelObject> getParts() {
        return parts.values();
    }

	public Set<String> getRootComponentNames() {
		return rootComponentNames;
	}

		@Override
	public class_1087 bake(class_793 owner, class_7775 baker, Function<class_4730, class_1058> spriteGetter, class_3665 modelTransform, class_806 overrides, boolean isGui3d) {
		ImmutableList<Mesh> meshes = bakeMeshes(owner, baker, spriteGetter, modelTransform);
		class_1058 particle = spriteGetter.apply(owner.method_24077("particle"));
		return new ObjBakedModel(
				meshes, owner.method_3444(), isGui3d, owner.method_24298().method_24299(),
				false, owner.method_3443(), overrides, particle
		);
	}

	@Nullable
	@Override
	public class_1087 method_4753(@NotNull class_7775 baker, @NotNull Function<class_4730, class_1058> spriteGetter, @NotNull class_3665 modelTransform) {
		ImmutableList<Mesh> meshes = bakeMeshes(null, baker, spriteGetter, modelTransform);
		class_1058 particle = spriteGetter.apply(new class_4730(class_1723.field_21668, class_1047.method_4539()));
		return new ObjBakedModel(
				meshes, false, false, false, false,
				class_809.field_4301, class_806.field_4292, particle
		);
	}

	private ImmutableList<Mesh> bakeMeshes(class_793 owner, class_7775 baker, Function<class_4730, class_1058> spriteGetter, class_3665 modelTransform) {
		ImmutableList.Builder<Mesh> bakedMeshes = new ImmutableList.Builder<>();
		parts.values().forEach(part -> {
			MeshBuilder meshBuilder = renderer.meshBuilder();
			part.buildMeshes(owner, meshBuilder, baker, spriteGetter, modelTransform, modelLocation);
			bakedMeshes.add(meshBuilder.build());
		});
		return bakedMeshes.build();
	}

	@Override
	public Set<String> getConfigurableComponentNames() {
		if (allComponentNames != null) {
			return allComponentNames;
		}
		var names = new HashSet<String>();
		for (var group : parts.values()) {
			group.addNamesRecursively(names);
		}
		return allComponentNames = Collections.unmodifiableSet(names);
	}

	private void makeQuad(SubModelSettings subSettings, MeshBuilder builder, int[][] indices, int tintIndex, Vector4f colorTint, Vector4f ambientColor, class_1058 texture, class_4590 transform) {
		boolean needsNormalRecalculation = false;
		for (int[] ints : indices) {
			needsNormalRecalculation |= ints.length < 3;
		}
		Vector3f faceNormal = new Vector3f();
		if (needsNormalRecalculation) {
			Vector3f a = positions.get(indices[0][0]);
			Vector3f ab = positions.get(indices[1][0]);
			Vector3f ac = positions.get(indices[2][0]);
			Vector3f abs = new Vector3f(ab);
			abs.sub(a);
			Vector3f acs = new Vector3f(ac);
			acs.sub(a);
			abs.cross(acs);
			abs.normalize();
			faceNormal = abs;
		}

		var quadBaker = builder.getEmitter();

		quadBaker.spriteBake(texture, MutableQuadView.BAKE_ROTATE_NONE);
		quadBaker.colorIndex(tintIndex);

		int uv2 = 0;
		if (emissiveAmbient) {
			int fakeLight = (int) ((ambientColor.x() + ambientColor.y() + ambientColor.z()) * 15 / 3.0f);
			uv2 = class_765.method_23687(fakeLight, fakeLight);
			quadBaker.material((fakeLight == 0 && shadeQuads) ? defaultMaterial : diffuseMaterial);
		} else {
			quadBaker.material(shadeQuads ? defaultMaterial : diffuseMaterial);
		}

		boolean hasTransform = !((TransformationExtensions)(Object)transform).dragonlib$isIdentity();
		
		class_4590 transformation = hasTransform ? ((TransformationExtensions)(Object)transform).dragonlib$blockCenterToCorner() : transform;

        if (subSettings != null) {
            Vector3f eulerRadians = transformation.method_22937().getEulerAnglesYXZ(new Vector3f());
            Vector3f oldRot = new Vector3f(
                (float) Math.toDegrees(eulerRadians.x),
                (float) Math.toDegrees(eulerRadians.y),
                (float) Math.toDegrees(eulerRadians.z)
            );
            Vector3f rot = new Vector3f(subSettings.rotX(), subSettings.rotY(), subSettings.rotZ());
            class_243 offset = new class_243(subSettings.x() / 16f, subSettings.y() / 16f, subSettings.z() / 16f);
            offset = MathUtils.rotateCentered(offset, oldRot.x(), net.minecraft.class_2350.class_2351.field_11048);
            offset = MathUtils.rotateCentered(offset, oldRot.y(), net.minecraft.class_2350.class_2351.field_11052);
            offset = MathUtils.rotateCentered(offset, oldRot.z(), net.minecraft.class_2350.class_2351.field_11051);
            Quaternionf q = class_7833.field_40716.rotationDegrees((float)(rot.y() + oldRot.y()));
            q.mul(class_7833.field_40714.rotationDegrees((float)(rot.x() + oldRot.x())));
            q.mul(class_7833.field_40718.rotationDegrees((float)(rot.z() + oldRot.z())));
            transformation = new class_4590(new Vector3f((float)offset.method_10216(), (float)offset.method_10214(), (float)offset.method_10215()), q, transformation.method_35866(), transformation.method_35867());
            hasTransform = true;
        }

		Vector4f[] pos = new Vector4f[4];
		Vector3f[] norm = new Vector3f[4];

		for (int i = 0; i < 4; i++) {
			int[] index = indices[Math.min(i, indices.length - 1)];
			Vector4f position = new Vector4f(positions.get(index[0]), 1);
			class_241 texCoord = index.length >= 2 && texCoords.size() > 0 ? texCoords.get(index[1]) : DEFAULT_COORDS[i];
			Vector3f norm0 = !needsNormalRecalculation && index.length >= 3 && normals.size() > 0 ? normals.get(index[2]) : faceNormal;
			Vector3f normal = norm0;
			Vector4f color = index.length >= 4 && colors.size() > 0 ? colors.get(index[3]) : COLOR_WHITE;
			if (hasTransform) {
				normal = new Vector3f(norm0);
				((TransformationExtensions)(Object)transformation).dragonlib$transformPosition(position);
				((TransformationExtensions)(Object)transformation).dragonlib$transformNormal(normal);
			}
			Vector4f tintedColor = new Vector4f(
					color.x() * colorTint.x(),
					color.y() * colorTint.y(),
					color.z() * colorTint.z(),
					color.w() * colorTint.w());
			quadBaker.pos(i, position.x(), position.y(), position.z());
			int spriteColor = encodeQuadColor(tintedColor);
			quadBaker.color(spriteColor, spriteColor, spriteColor, spriteColor);
			/*
			quadBaker.uv(i,
					texture.getU(texCoord.x * 16),
					texture.getV((flipV ? 1 - texCoord.y : texCoord.y) * 16)
			);

			 */
			quadBaker.uv(i,
					texture.method_4580(texCoord.field_1343),
					texture.method_4570(flipV ? 1 - texCoord.field_1342 : texCoord.field_1342)
			);
			quadBaker.lightmap(i, uv2);
			quadBaker.normal(i, normal);
			if (i == 0) {
				quadBaker.nominalFace(class_2350.method_10147(normal.x(), normal.y(), normal.z()));
			}

			pos[i] = position;
			norm[i] = normal;
		}

		class_2350 cull = null;
		if (automaticCulling) {
			if (class_3532.method_15347(pos[0].x(), 0) && 
					class_3532.method_15347(pos[1].x(), 0) &&
					class_3532.method_15347(pos[2].x(), 0) &&
					class_3532.method_15347(pos[3].x(), 0) &&
					norm[0].x() < 0) 
			{
				cull = class_2350.field_11039;
			} else if (class_3532.method_15347(pos[0].x(), 1) && 
					class_3532.method_15347(pos[1].x(), 1) &&
					class_3532.method_15347(pos[2].x(), 1) &&
					class_3532.method_15347(pos[3].x(), 1) &&
					norm[0].x() > 0) 
			{
				cull = class_2350.field_11034;
			} else if (class_3532.method_15347(pos[0].z(), 0) && 
					class_3532.method_15347(pos[1].z(), 0) &&
					class_3532.method_15347(pos[2].z(), 0) &&
					class_3532.method_15347(pos[3].z(), 0) &&
					norm[0].z() < 0) 
			{
				cull = class_2350.field_11043; 
			} else if (class_3532.method_15347(pos[0].z(), 1) && 
					class_3532.method_15347(pos[1].z(), 1) &&
					class_3532.method_15347(pos[2].z(), 1) &&
					class_3532.method_15347(pos[3].z(), 1) &&
					norm[0].z() > 0) 
			{
				cull = class_2350.field_11035;
			} else if (class_3532.method_15347(pos[0].y(), 0) && 
					class_3532.method_15347(pos[1].y(), 0) &&
					class_3532.method_15347(pos[2].y(), 0) &&
					class_3532.method_15347(pos[3].y(), 0) &&
					norm[0].y() < 0) 
			{
				cull = class_2350.field_11033; 
			} else if (class_3532.method_15347(pos[0].y(), 1) && 
					class_3532.method_15347(pos[1].y(), 1) &&
					class_3532.method_15347(pos[2].y(), 1) &&
					class_3532.method_15347(pos[3].y(), 1) &&
					norm[0].y() > 0) 
			{
				cull = class_2350.field_11036;
			}
		}

		quadBaker.cullFace(cull);
		quadBaker.emit();
	}

	
	private int encodeQuadColor(Vector4f colorTint) {
		int r = (int) (colorTint.x() * 255.0F);
		int g = (int) (colorTint.y() * 255.0F);
		int b = (int) (colorTint.z() * 255.0F);
		int a = (int) (colorTint.w() * 255.0F);

		return ((a & 0xFF) << 24) |
				((b & 0xFF) << 16) |
				((g & 0xFF) << 8) |
				(r & 0xFF);
	}

	@Override
	@NotNull
	public Collection<class_2960> method_4755() {
		return List.of();
	}

	@Override
	public void method_45785(@NotNull Function<class_2960, class_1100> function) {
	}

	public class ModelObject {
		public final String name;
        final SubModelSettings settings;

		List<ModelMesh> meshes = Lists.newArrayList();

		ModelObject(String name, SubModelSettings settings) {
			this.name = name;
            this.settings = settings;
		}

        public ModelObject copy(SubModelSettings settings) {
            ModelObject m = new ModelObject(name, this.settings.combineTransform(settings));
            m.meshes.addAll(meshes.stream().map(x -> x.copy(this.settings.combineTransform(settings))).toList());
            return m;
        }

		public String name() {
			return name;
		}

		public void buildMeshes(@Nullable class_793 owner, MeshBuilder meshBuilder, class_7775 baker, Function<class_4730, class_1058> spriteGetter, class_3665 modelTransform, class_2960 modelLocation) {
			for (ModelMesh mesh : meshes) {
				mesh.buildMesh(owner, meshBuilder, spriteGetter, modelTransform);
			}
		}

		public Collection<class_4730> getTextures(class_793 owner, Function<class_2960, class_1100> modelGetter, Set<com.mojang.datafixers.util.Pair<String, String>> missingTextureErrors) {
			return meshes.stream()
					.flatMap(mesh -> mesh.mat != null
							? Stream.of(UnbakedGeometryHelper.resolveDirtyMaterial(mesh.mat.diffuseColorMap, owner))
							: Stream.of())
					.collect(Collectors.toSet());
		}

		protected void addNamesRecursively(Set<String> names) {
			names.add(name());
		}
	}

	public class ModelGroup extends ModelObject {
		final Map<String, ModelObject> parts = Maps.newLinkedHashMap();

		ModelGroup(String name, SubModelSettings settings) {
			super(name, settings);
		}

        public Collection<? extends ModelObject> getParts() {
            return parts.values();
        }

        public ModelGroup copy(SubModelSettings settings, String name) {
            ModelGroup m = new ModelGroup(name, this.settings.combineTransform(settings));
            m.parts.putAll(parts.entrySet().stream().collect(Collectors.toMap(a -> a.getKey(), a -> a.getValue().copy(a.getValue().settings.combineTransform(settings)))));
            m.meshes.addAll(meshes.stream().map(x -> x.copy(settings.combineTransform(x.subSettings))).toList());
            return m;
        }

		@Override
		public void buildMeshes(class_793 owner, MeshBuilder meshBuilder, class_7775 baker, Function<class_4730, class_1058> spriteGetter, class_3665 modelTransform, class_2960 modelLocation) {
			super.buildMeshes(owner, meshBuilder, baker, spriteGetter, modelTransform, modelLocation);

			parts.values().stream().filter(part -> ((BlockModelExtensions)owner).dragonlib$isComponentVisible(part.name(), true))
					.forEach(part -> part.buildMeshes(owner, meshBuilder, baker, spriteGetter, modelTransform, modelLocation));
		}

		@Override
		public Collection<class_4730> getTextures(class_793 owner, Function<class_2960, class_1100> modelGetter, Set<com.mojang.datafixers.util.Pair<String, String>> missingTextureErrors) {
			Set<class_4730> combined = Sets.newHashSet();
			combined.addAll(super.getTextures(owner, modelGetter, missingTextureErrors));
			for (ModelObject part : parts.values()) {
				combined.addAll(part.getTextures(owner, modelGetter, missingTextureErrors));
			}
			return combined;
		}

		@Override
		protected void addNamesRecursively(Set<String> names) {
			super.addNamesRecursively(names);
			for (ModelObject object : parts.values()) {
				object.addNamesRecursively(names);
			}
		}
	}

	class ModelMesh {
		@Nullable
		public ObjMaterialLibrary.Material mat;
		@Nullable
		public String smoothingGroup;
		public final List<int[][]> faces = Lists.newArrayList();
        public SubModelSettings subSettings;

		public ModelMesh(SubModelSettings subSettings, @Nullable ObjMaterialLibrary.Material currentMat, @Nullable String currentSmoothingGroup) {
			this.mat = currentMat;
			this.smoothingGroup = currentSmoothingGroup;
			this.subSettings = subSettings;
		}

        public ModelMesh copy(SubModelSettings subSettings) {
            ModelMesh m = new ModelMesh(subSettings, mat, smoothingGroup);
            m.faces.addAll(faces);
            return m;
        }

		public void buildMesh(@Nullable class_793 owner, MeshBuilder meshBuilder, Function<class_4730, class_1058> spriteGetter, class_3665 modelTransform) {
			if (mat == null) {
				return;
			}
			class_1058 texture = spriteGetter.apply(UnbakedGeometryHelper.resolveDirtyMaterial(mat.diffuseColorMap, owner));
			int tintIndex = mat.diffuseTintIndex;
			Vector4f colorTint = mat.diffuseColor;

			var rootTransform = owner != null ? ((BlockModelExtensions)owner).dragonlib$getRootTransform() : class_4590.method_22931();
			var transform = ((TransformationExtensions)(Object)rootTransform).dragonlib$isIdentity() ? modelTransform.method_3509() : modelTransform.method_3509().method_22933(rootTransform);
			for (int[][] face : faces) {
				makeQuad(subSettings, meshBuilder, face, tintIndex, colorTint, mat.ambientColor, texture, transform);
			}
		}
	}

    public record ModelSettings(@NotNull class_2960 modelLocation,
            boolean automaticCulling, boolean shadeQuads, boolean flipV,
            boolean emissiveAmbient, @Nullable String mtlOverride,
            List<SubModelSettings> subSettings) {
    }	

    public static class SubModelSettings {
        String model;
        float[] offset = new float[3];
        float[] rotation = new float[3];
        boolean centered = false;
        boolean inheritable = true;

        public SubModelSettings() {}

        public SubModelSettings(String model, float[] offset, float[] rotation, boolean centered, boolean inheritable) {
            this.model = model;
            this.offset = offset;
            this.rotation = rotation;
            this.centered = centered;
            this.inheritable = inheritable;
        }

        public String model() {
            return model;
        }

        public float x() {
            return offset[0] - (centered ? 8 : 0);
        }

        public float y() {
            return offset[1] - (centered ? 8 : 0);
        }

        public float z() {
            return offset[2] - (centered ? 8 : 0);
        }

        public float rotX() {
            return rotation[0];
        }

        public float rotY() {
            return rotation[1];
        }

        public float rotZ() {
            return rotation[2];
        }

        public boolean centered() {
            return centered;
        }

        public boolean isJson() {
            return model.endsWith(".json");
        }

        public boolean inheritable() {
            return inheritable;
        }

        public SubModelSettings combineTransform(@Nullable SubModelSettings other) {
            if (other == null) {
                return new SubModelSettings(
                    model(),
                    new float[] {
                        offset[0],
                        offset[1],
                        offset[2]
                    },
                    new float[] {
                        rotation[0],
                        rotation[1],
                        rotation[2]
                    },
                    centered(),
                    other == null ? inheritable() : other.inheritable()
                );
            }
            return new SubModelSettings(
                model(),
                new float[] {
                    offset[0] + other.offset[0],
                    offset[1] + other.offset[1],
                    offset[2] + other.offset[2]
                },
                new float[] {
                    rotation[0] + other.rotation[0],
                    rotation[1] + other.rotation[1],
                    rotation[2] + other.rotation[2]
                },
                centered(),
                other == null ? inheritable() : other.inheritable()
            );
        }
    }
}
