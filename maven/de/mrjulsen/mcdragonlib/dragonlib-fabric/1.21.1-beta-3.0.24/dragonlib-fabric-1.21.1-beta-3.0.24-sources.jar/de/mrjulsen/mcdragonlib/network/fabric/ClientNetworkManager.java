package de.mrjulsen.mcdragonlib.network.fabric;

import de.mrjulsen.mcdragonlib.network.DLNetworkManager;
import de.mrjulsen.mcdragonlib.network.NetworkPacketContext;
import de.mrjulsen.mcdragonlib.network.NetworkSide;
import de.mrjulsen.mcdragonlib.util.DLUtils;
import io.netty.buffer.Unpooled;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;

public class ClientNetworkManager {
    public static void registerChannel(class_2960 channelId, String name, String protocolVersion) {
        class_8710.class_9154<DLNetworkManager.BufCustomPacketPayload> type = new class_8710.class_9154<>(DLUtils.resourceLocation(channelId.method_12836(), channelId.method_12832() + "/" + name));

        ClientPlayNetworking.registerGlobalReceiver(type, new ClientPlayNetworking.PlayPayloadHandler() {
            @Override
            public void receive(class_8710 payload, ClientPlayNetworking.Context ctx) {
                NetworkPacketContext context = DLNetworkManagerImpl.context(ctx.player(), ctx.client(), true);
                class_9129 buf = new class_9129(Unpooled.wrappedBuffer(((DLNetworkManager.BufCustomPacketPayload)payload).payload()), ctx.player().method_56673());
                DLNetworkManager.receiveData(channelId, buf, NetworkSide.C2S, context);
                buf.release();
            }
        });
    }
}
