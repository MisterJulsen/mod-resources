package de.mrjulsen.mcdragonlib.fabric.client.model.geometry;

import Z;
import de.mrjulsen.mcdragonlib.fabric.client.model.geometry.extensions.TransformationExtensions;
import de.mrjulsen.mcdragonlib.fabric.client.model.geometry.mixin.client.BlockModelAccessor;
import de.mrjulsen.mcdragonlib.fabric.client.model.geometry.mixin.client.ItemModelGeneratorAccessor;
import de.mrjulsen.mcdragonlib.util.DLUtils;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;
import net.minecraft.class_1047;
import net.minecraft.class_1058;
import net.minecraft.class_1059;
import net.minecraft.class_156;
import net.minecraft.class_2350;
import net.minecraft.class_2960;
import net.minecraft.class_3665;
import net.minecraft.class_4590;
import net.minecraft.class_4730;
import net.minecraft.class_7764;
import net.minecraft.class_777;
import net.minecraft.class_783;
import net.minecraft.class_785;
import net.minecraft.class_787;
import net.minecraft.class_793;
import net.minecraft.class_796;
import net.minecraft.class_801;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.BitSet;
import java.util.HashMap;
import java.util.List;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class UnbakedGeometryHelper {
	private static final ItemModelGeneratorAccessor ITEM_MODEL_GENERATOR = (ItemModelGeneratorAccessor)new class_801();
	private static final class_796 FACE_BAKERY = new class_796();

		private static final Pattern FILESYSTEM_PATH_TO_RESLOC =
			Pattern.compile("(?:.*[\\\\/]assets[\\\\/](?<namespace>[a-z_-]+)[\\\\/]textures[\\\\/])?(?<path>[a-z_\\\\/-]+)\\.png");

		@SuppressWarnings("deprecation")
	public static class_4730 resolveDirtyMaterial(@Nullable String tex, @Nullable class_793 owner) {
		if (tex == null)
			return new class_4730(class_1059.field_5275, class_1047.method_4539());
		if (tex.startsWith("#") && owner != null)
			return owner.method_24077(tex);

		
		
		Matcher match = FILESYSTEM_PATH_TO_RESLOC.matcher(tex);
		if (match.matches()) {
			String namespace = match.group("namespace");
			String path = match.group("path").replace("\\", "/");
			tex = namespace != null ? namespace + ":" + path : path;
		}

		return new class_4730(class_1059.field_5275, DLUtils.resourceLocation(tex));
	}

	public static class_777 bakeElementFace(class_785 element, class_783 face, class_1058 sprite, class_2350 direction, class_3665 state, class_2960 modelLocation) {
		return FACE_BAKERY.method_3468(element.field_4228, element.field_4231, face, sprite, direction, state, element.field_4232, element.field_4229);
	}

		public static RenderContext.QuadTransform applyRootTransform(class_3665 modelState, class_4590 rootTransform) {
		
		
		
		class_4590 transform = ((TransformationExtensions)(Object)modelState.method_3509()).dragonlib$applyOrigin(new Vector3f(.5F, .5F, .5F));
		return QuadTransformers.applying(transform.method_22933(rootTransform).method_22933(transform.method_22935()));
	}

	public static void bakeElements(List<class_777> quads, List<class_785> elements, Function<class_4730, class_1058> spriteGetter, class_3665 modelState, class_2960 modelLocation) {
		for (class_785 element : elements) {
			element.field_4230.forEach((side, face) -> {
				@SuppressWarnings("deprecation")
				var sprite = spriteGetter.apply(new class_4730(class_1059.field_5275, DLUtils.resourceLocation(face.comp_2869())));
				quads.add(BlockModelAccessor.dragonlib$getFaceBakery().method_3468(element.field_4228, element.field_4231, face, sprite, side, modelState, element.field_4232, element.field_4229));
			});
		}
	}

		public static List<class_777> bakeElements(List<class_785> elements, Function<class_4730, class_1058> spriteGetter, class_3665 modelState, class_2960 modelLocation) {
		if (elements.isEmpty())
			return List.of();
		var list = new ArrayList<class_777>();
		bakeElements(list, elements, spriteGetter, modelState, modelLocation);
		return list;
	}

		public static List<class_785> createUnbakedItemElements(int layerIndex, class_7764 spriteContents) {
		return ITEM_MODEL_GENERATOR.dragonlib$processFrames(layerIndex, "layer" + layerIndex, spriteContents);
	}

		public static List<class_785> createUnbakedItemMaskElements(int layerIndex, class_7764 spriteContents) {
		var elements = createUnbakedItemElements(layerIndex, spriteContents);
		elements.remove(0); 

		int width = spriteContents.method_45807(), height = spriteContents.method_45815();
		var bits = new BitSet(width * height);

		
		spriteContents.method_45817().forEach(frame -> {
			for (int x = 0; x < width; x++)
				for (int y = 0; y < height; y++)
					if (!spriteContents.method_45810(frame, x, y))
						bits.set(x + y * width);
		});

		
		for (int y = 0; y < height; y++) {
			int xStart = -1;
			for (int x = 0; x < width; x++) {
				var opaque = bits.get(x + y * width);
				if (opaque == (xStart == -1)) { 
					if (xStart == -1) {
						
						xStart = x;
						continue;
					}

					
					int yEnd = y + 1;
					expand:
					for (; yEnd < height; yEnd++)
						for (int x2 = xStart; x2 <= x; x2++)
							if (!bits.get(x2 + yEnd * width))
								break expand;

					
					for (int i = xStart; i < x; i++)
						for (int j = y; j < yEnd; j++)
							bits.clear(i + j * width);

					
					elements.add(new class_785(
							new Vector3f(16 * xStart / (float) width, 16 - 16 * yEnd / (float) height, 7.5F),
							new Vector3f(16 * x / (float) width, 16 - 16 * y / (float) height, 8.5F),
							class_156.method_654(new HashMap<>(), map -> {
								for (class_2350 direction : class_2350.values())
									map.put(direction, new class_783(null, layerIndex, "layer" + layerIndex, new class_787(null, 0)));
							}),
							null,
							true
					));

					
					xStart = -1;
				}
			}
		}
		return elements;
	}

		public static class_3665 composeRootTransformIntoModelState(class_3665 modelState, class_4590 rootTransform) {
		
		
		rootTransform = ((TransformationExtensions)(Object)rootTransform).dragonlib$applyOrigin(new Vector3f(-.5F, -.5F, -.5F));
		return new SimpleModelState(modelState.method_3509().method_22933(rootTransform), modelState.method_3512());
	}
}
