package de.mrjulsen.mcdragonlib.network.packet;

import net.minecraft.class_2540;

public record SegmentedPacketHeaderInfo(PacketHeaderInfo type, SegmentType segment, int expectedParts, int partNumber) {

    public void writeBufferHeader(class_2540 buffer) {
        type.writeBufferHeader(buffer);
        buffer.method_52997(segment.getId());
        buffer.method_53002(expectedParts);
        buffer.method_53002(partNumber);
    }

    public static SegmentedPacketHeaderInfo readBufferHeader(class_2540 buffer) {
        return new SegmentedPacketHeaderInfo(
            PacketHeaderInfo.readBufferHeader(buffer),
            SegmentType.getById(buffer.readByte()),
            buffer.readInt(),
            buffer.readInt()
        );
    }

    public static int getSize(PacketHeaderInfo info) {
        int size = 0;
        size += info.getSize();
        size += Byte.BYTES;
        size += Integer.BYTES;
        size += Integer.BYTES;
        return size;
    }

    
}
