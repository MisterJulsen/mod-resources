package de.mrjulsen.mcdragonlib.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import de.mrjulsen.mcdragonlib.DragonLib;
import de.mrjulsen.mcdragonlib.client.render.ICustomItemRenderer;
import de.mrjulsen.mcdragonlib.client.util.DLGraphics;
import net.minecraft.class_1087;
import net.minecraft.class_1799;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_811;
import net.minecraft.class_918;

@Mixin(class_918.class)
public class ItemRendererMixin {

    @Inject(method = "render", at = @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/vertex/PoseStack;popPose()V", shift = Shift.BEFORE))
    public void dragonlib$render(class_1799 itemStack, class_811 displayContext, boolean leftHand, class_4587 poseStack, class_4597 bufferSource, int combinedLight, int combinedOverlay, class_1087 model, CallbackInfo ci) {
        if (itemStack.method_7909() instanceof ICustomItemRenderer renderer) {
            poseStack.method_22903();
            DLGraphics graphics = new DLGraphics(poseStack, bufferSource, combinedLight, combinedOverlay, 1f);
            poseStack.method_22905(DragonLib.BLOCK_PIXEL, DragonLib.BLOCK_PIXEL, DragonLib.BLOCK_PIXEL);
            poseStack.method_22903();
            renderer.renderAdditional(graphics, itemStack, displayContext, leftHand, poseStack, bufferSource, combinedLight, combinedOverlay, model);
            poseStack.method_22909();
            poseStack.method_22909();
        }
    }
}