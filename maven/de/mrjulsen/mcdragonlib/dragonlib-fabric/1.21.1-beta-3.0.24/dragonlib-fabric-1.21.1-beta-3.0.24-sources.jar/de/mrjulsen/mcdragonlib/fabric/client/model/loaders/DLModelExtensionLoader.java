package de.mrjulsen.mcdragonlib.fabric.client.model.loaders;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.gson.*;
import com.mojang.datafixers.util.Either;
import de.mrjulsen.mcdragonlib.client.model.extension.DLFaceData;
import de.mrjulsen.mcdragonlib.client.model.extension.DLFaceKey;
import de.mrjulsen.mcdragonlib.fabric.client.model.geometry.IGeometryLoader;
import de.mrjulsen.mcdragonlib.util.DLUtils;
import org.apache.commons.lang3.mutable.MutableInt;
import org.jetbrains.annotations.Nullable;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1059;
import net.minecraft.class_2350;
import net.minecraft.class_2960;
import net.minecraft.class_3518;
import net.minecraft.class_4730;
import net.minecraft.class_785;
import net.minecraft.class_793;
import net.minecraft.class_799;
import net.minecraft.class_809;

public class DLModelExtensionLoader implements IGeometryLoader<DLUnbakedModelExtension> {
    public static final class_2960 ID = DLUtils.resourceLocation("dragonlib", "advanced_json");
    public static final DLModelExtensionLoader INSTANCE = new DLModelExtensionLoader();

    private record DirectionKey(class_2350 dir) {}

    @Override
    public DLUnbakedModelExtension read(JsonObject json, JsonDeserializationContext ctx) {
        class_793 vanilla = new Deserializer().deserialize(json, class_793.class, ctx);
        Map<DLFaceKey, DLFaceData> faceData = new HashMap<>();

        Map<DirectionKey, MutableInt> faceIndex = new HashMap<>();
        JsonArray elements = json.getAsJsonArray("elements");
        for (int e = 0; e < elements.size(); e++) {
            JsonObject element = elements.get(e).getAsJsonObject();
            JsonObject faces = element.getAsJsonObject("faces");

            for (Map.Entry<String, JsonElement> entry : faces.entrySet()) {
                JsonObject face = entry.getValue().getAsJsonObject();
                class_2350 cullFace = this.getCullFacing(face);
                MutableInt idx = faceIndex.computeIfAbsent(new DirectionKey(cullFace), c -> new MutableInt(0));
                DLFaceData data = DLFaceData.read(face.getAsJsonObject("dragonlib_data"), DLFaceData.DEFAULT);

                if (data != null) {
                    faceData.put(new DLFaceKey(idx.getAndIncrement(), cullFace), data);
                }
            }
        }

        return new DLUnbakedModelExtension(vanilla, faceData);
    }

    @Nullable
    private class_2350 getCullFacing(JsonObject json) {
        String s = class_3518.method_15253(json, "cullface", "");
        return class_2350.method_10168(s);
    }

    public static class Deserializer implements JsonDeserializer<class_793> {
        public class_793 deserialize(JsonElement json, Type type, JsonDeserializationContext context) throws JsonParseException {
            JsonObject jsonObject = json.getAsJsonObject();
            List<class_785> list = this.getElements(context, jsonObject);
            String string = this.getParentName(jsonObject);
            Map<String, Either<class_4730, String>> map = this.getTextureMap(jsonObject);
            Boolean boolean_ = this.getAmbientOcclusion(jsonObject);
            class_809 itemTransforms = class_809.field_4301;
            if (jsonObject.has("display")) {
                JsonObject jsonObject2 = class_3518.method_15296(jsonObject, "display");
                itemTransforms = (class_809)context.deserialize(jsonObject2, class_809.class);
            }

            List<class_799> list2 = this.getOverrides(context, jsonObject);
            class_793.class_4751 guiLight = null;
            if (jsonObject.has("gui_light")) {
                guiLight = class_793.class_4751.method_24300(class_3518.method_15265(jsonObject, "gui_light"));
            }

            class_2960 resourceLocation = string.isEmpty() ? null : DLUtils.resourceLocation(string);
            return new class_793(resourceLocation, list, map, boolean_, guiLight, itemTransforms, list2);
        }

        protected List<class_799> getOverrides(JsonDeserializationContext context, JsonObject json) {
            List<class_799> list = Lists.newArrayList();
            if (json.has("overrides")) {
                for(JsonElement jsonElement : class_3518.method_15261(json, "overrides")) {
                    list.add((class_799)context.deserialize(jsonElement, class_799.class));
                }
            }

            return list;
        }

        private Map<String, Either<class_4730, String>> getTextureMap(JsonObject json) {
            class_2960 resourceLocation = class_1059.field_5275;
            Map<String, Either<class_4730, String>> map = Maps.newHashMap();
            if (json.has("textures")) {
                JsonObject jsonObject = class_3518.method_15296(json, "textures");

                for(Map.Entry<String, JsonElement> entry : jsonObject.entrySet()) {
                    map.put((String)entry.getKey(), parseTextureLocationOrReference(resourceLocation, ((JsonElement)entry.getValue()).getAsString()));
                }
            }

            return map;
        }

        static boolean isTextureReference(String str) {
            return str.charAt(0) == '#';
        }

        private static Either<class_4730, String> parseTextureLocationOrReference(class_2960 location, String name) {
            if (isTextureReference(name)) {
                return Either.right(name.substring(1));
            } else {
                class_2960 resourceLocation = class_2960.method_12829(name);
                if (resourceLocation == null) {
                    throw new JsonParseException(name + " is not valid resource location");
                } else {
                    return Either.left(new class_4730(location, resourceLocation));
                }
            }
        }

        private String getParentName(JsonObject json) {
            return class_3518.method_15253(json, "parent", "");
        }

        @Nullable
        protected Boolean getAmbientOcclusion(JsonObject json) {
            return json.has("ambientocclusion") ? class_3518.method_15270(json, "ambientocclusion") : null;
        }

        protected List<class_785> getElements(JsonDeserializationContext context, JsonObject json) {
            List<class_785> list = Lists.newArrayList();
            if (json.has("elements")) {
                for(JsonElement jsonElement : class_3518.method_15261(json, "elements")) {
                    list.add((class_785)context.deserialize(jsonElement, class_785.class));
                }
            }

            return list;
        }
    }
}
