package de.mrjulsen.mcdragonlib.client.gui.builtin;

import java.util.Arrays;
import java.util.function.Function;
import java.util.stream.IntStream;
import net.minecraft.class_1921;
import net.minecraft.class_241;
import net.minecraft.class_2680;
import net.minecraft.class_308;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3728;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5244;
import net.minecraft.class_776;
import net.minecraft.class_7833;
import org.joml.Vector3f;
import de.mrjulsen.mcdragonlib.DragonLib;
import de.mrjulsen.mcdragonlib.block.DLWritableSignBlockEntity;
import de.mrjulsen.mcdragonlib.network.NetworkDirection;
import de.mrjulsen.mcdragonlib.network.builtin.WritableSignPacketData;
import de.mrjulsen.mcdragonlib.util.TextUtils;
import de.mrjulsen.mcdragonlib.util.math.MathUtils;

public class WritableSignScreen extends class_437 {

    public static final int DEFAULT_LINE_HEIGHT = 10;

    protected final DLWritableSignBlockEntity sign;
    protected final class_2680 blockState;
    protected final WritableSignConfig config;
    protected final ConfiguredLine[] messages;
    protected final int lineCount;

    protected int blinkFrame;
    protected int selectedLine;
    protected class_3728 signTextField;

    // Controls
    protected class_4185 btnDone;

    public WritableSignScreen(DLWritableSignBlockEntity pSign) {
        this(pSign, pSign.getRenderConfig(), pSign.method_11010().method_26204().method_9564(), getMessages(pSign, pSign.getRenderConfig()));
    }

    protected WritableSignScreen(DLWritableSignBlockEntity pSign, WritableSignConfig config, class_2680 state, ConfiguredLine[] messages) {
        super(TextUtils.translate("sign.edit"));

        this.config = config;
        this.blockState = state;
        this.sign = pSign;

        this.messages = messages;
        this.lineCount = this.messages.length;

    }

    protected static ConfiguredLine[] getMessages(DLWritableSignBlockEntity pSign, WritableSignConfig config) {
        return IntStream.range(0, config.lineData.length).mapToObj((i) -> {
            return new ConfiguredLine(pSign.getText(i), config.lineData[i]);
        }).toArray((length) -> {
            return new ConfiguredLine[length];
        });
    }

    protected void method_25426() {
        class_4185 btn = class_4185.method_46430(class_5244.field_24334, (b) -> {
            this.onDone();
        }).method_46437(200, 20).method_46433(this.field_22789 / 2 - 100, this.field_22790 / 4 + 120).method_46431();
        this.btnDone = method_37063(btn);

        this.signTextField = new class_3728(() -> {
            return this.messages[this.selectedLine].text;
        }, (text) -> {
            this.messages[this.selectedLine].text = text;
            this.sign.setText(text, selectedLine);
        }, class_3728.method_27550(class_310.method_1551()), class_3728.method_27561(class_310.method_1551()), (text) -> {
            return text == null || class_310.method_1551().field_1772.method_1727(text) <= config.lineData[this.selectedLine].maxLineWidth() * config.scale();
        });
    }

    public void method_25432() {
        DragonLib.UPDATE_SIGN_TEXT.send(NetworkDirection.toServer(), new WritableSignPacketData(this.sign.method_11016(), Arrays.stream(messages).map(x -> x.text).toArray(String[]::new)));
    }

    public void method_25393() {
        ++this.blinkFrame;
        if (!this.sign.method_11017().method_20526(this.sign.method_11010())) {
            this.onDone();
        }

    }

    protected void onDone() {
        DragonLib.UPDATE_SIGN_TEXT.send(NetworkDirection.toServer(), new WritableSignPacketData(this.sign.method_11016(), Arrays.stream(messages).map(x -> x.text).toArray(String[]::new)));
        class_310.method_1551().method_1507(null);
    }

    public boolean method_25400(char pCodePoint, int pModifiers) {
        this.signTextField.method_16199(pCodePoint);
        return true;
    }

    public void method_25419() {
        this.onDone();
    }

    public boolean method_25404(int pKeyCode, int pScanCode, int pModifiers) {
        if (pKeyCode == 265) {
            this.selectedLine = this.selectedLine - 1 & lineCount - 1;
            this.signTextField.method_16204();
            return true;
        } else if (pKeyCode != 264 && pKeyCode != 257 && pKeyCode != 335) {
            return this.signTextField.method_16202(pKeyCode) ? true : super.method_25404(pKeyCode, pScanCode, pModifiers);
        } else {
            this.selectedLine = this.selectedLine + 1 & lineCount - 1;
            this.signTextField.method_16204();
            return true;
        }
    }

    protected void renderSignBackground(class_332 graphics) {
        class_4597.class_4598 bufferSource = class_310.method_1551().method_22940().method_23000();
        class_4587 poseStack = graphics.method_51448();
        graphics.method_51448().method_46416((float)this.field_22789 / 2.0F + config.scale / 2 + config.xCenterOffset * config.scale, config.y + config.scale / 2, 100);
        poseStack.method_22905(-config.scale, -config.scale, -1);
        poseStack.method_22907(class_7833.field_40716.rotationDegrees(config.yRot()));

        class_776 blockRenderer = class_310.method_1551().method_1541();
        blockRenderer.method_3353(blockState, graphics.method_51448(), bufferSource, 15728880, class_4608.field_21444);
    }

    private void renderSignText(class_332 pGuiGraphics) {
        boolean flag = this.blinkFrame / 6 % 2 == 0;
        int cursorPos = this.signTextField.method_16201();
        int selectionPos = this.signTextField.method_16203();

        for (int line = 0; line < this.messages.length; ++line) {
            pGuiGraphics.method_51448().method_22903();
            ConfiguredLine configuredLine = this.messages[line];

            Vector3f vector3f = config.screenTextScale(field_22793, config.scale(), configuredLine);
            pGuiGraphics.method_51448().method_46416((float)this.field_22789 / 2.0F + configuredLine.data.xOffset() * config.scale(), config.y + configuredLine.data.yOffset() * config.scale - (int)(WritableSignScreen.DEFAULT_LINE_HEIGHT / 2 * config.lineData()[0].lineHeightScale()) + config.getLineHeightsUntil(line) + config.getLineOffset(line, vector3f.y), 105);
            pGuiGraphics.method_51448().method_22905(vector3f.x(), vector3f.y(), vector3f.z());

            if (configuredLine != null) {
                if (this.field_22793.method_1726()) {
                    configuredLine.text = this.field_22793.method_1721(configuredLine.text);
                }

                int xCenter = -this.field_22793.method_1727(configuredLine.text) / 2;
                pGuiGraphics.method_51433(this.field_22793, configuredLine.text, xCenter, 0, configuredLine.data.color(), false);
                if (line == this.selectedLine && cursorPos >= 0 && flag) {
                    int l1 = this.field_22793.method_1727(configuredLine.text.substring(0, Math.max(Math.min(cursorPos, configuredLine.text.length()), 0)));
                    int i2 = l1 - this.field_22793.method_1727(configuredLine.text) / 2;
                    if (cursorPos >= configuredLine.text.length()) {
                        pGuiGraphics.method_51433(this.field_22793, "_", i2, 0, configuredLine.data.color(), false);
                    }
                }
            }
            pGuiGraphics.method_51448().method_22909();
        }

        for (int lineHighlight = 0; lineHighlight < this.messages.length; ++lineHighlight) {
            ConfiguredLine configuredLineH = this.messages[lineHighlight];
            pGuiGraphics.method_51448().method_22903();
            Vector3f vector3f = config.screenTextScale(field_22793, config.scale(), configuredLineH);
            pGuiGraphics.method_51448().method_46416((float)this.field_22789 / 2.0F + configuredLineH.data.xOffset() * config.scale(), config.y + configuredLineH.data.yOffset() * config.scale - (int)(WritableSignScreen.DEFAULT_LINE_HEIGHT / 2 * config.lineData()[0].lineHeightScale()) + config.getLineHeightsUntil(lineHighlight + 1) - config.halfLineHeight(lineHighlight) + config.getHalfLineHeightScales(lineHighlight, vector3f.y), 105);
            pGuiGraphics.method_51448().method_22905(vector3f.x(), vector3f.y(), vector3f.z());

            float lineScale = config.lineData()[lineHighlight].lineHeightScale();

            if (configuredLineH != null && lineHighlight == this.selectedLine && cursorPos >= 0) {
                int l3 = this.field_22793.method_1727(configuredLineH.text.substring(0, Math.max(Math.min(cursorPos, configuredLineH.text.length()), 0)));
                int i4 = l3 - this.field_22793.method_1727(configuredLineH.text) / 2;
                if (flag && cursorPos < configuredLineH.text.length()) {
                    pGuiGraphics.method_25294(i4, -(int)(DEFAULT_LINE_HEIGHT * (lineScale + 1) * 0.5F), i4 + 1, -(int)(DEFAULT_LINE_HEIGHT * (lineScale - 1) * 0.5F), -16777216 | configuredLineH.data.color());
                }

                if (selectionPos != cursorPos) {
                    int j4 = Math.min(cursorPos, selectionPos);
                    int j2 = Math.max(cursorPos, selectionPos);
                    int k2 = this.field_22793.method_1727(configuredLineH.text.substring(0, j4)) - this.field_22793.method_1727(configuredLineH.text) / 2;
                    int l2 = this.field_22793.method_1727(configuredLineH.text.substring(0, j2)) - this.field_22793.method_1727(configuredLineH.text) / 2;
                    int i3 = Math.min(k2, l2);
                    int j3 = Math.max(k2, l2);
                    pGuiGraphics.method_51739(class_1921.method_51786(), i3, -(int)(DEFAULT_LINE_HEIGHT * (lineScale + 1) * 0.5F), j3, -(int)(DEFAULT_LINE_HEIGHT * (lineScale - 1) * 0.5F), -16776961);
                }
            }
            pGuiGraphics.method_51448().method_22909();
        }

    }

    public void method_25420(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        this.method_52752(guiGraphics);
    }

    public void renderSign(class_332 graphics) {
        graphics.method_51448().method_34426();
        graphics.method_51448().method_22903();
        graphics.method_51448().method_22903();
        this.renderSignBackground(graphics);
        graphics.method_51448().method_22909();
        this.renderSignText(graphics);
        graphics.method_51448().method_22909();
    }

    @Override
    public void method_25394(class_332 graphics, int pMouseX, int pMouseY, float pPartialTick) {
        class_308.method_24210();
        graphics.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 40, 16777215);
        this.renderSign(graphics);
        class_308.method_24211();
        super.method_25394(graphics, pMouseX, pMouseY, pPartialTick);
    }

    public static record WritableSignConfig(ConfiguredLineData[] lineData, boolean renderBack, float xCenterOffset, float y, float scale, float yRot, float berX, float berY, float berZ, Function<class_2680, Float> blockEntityRendererRotation, int berColor) {
        public static final int DEFAULT_SCALE = 96;

        public int getLineHeightsUntil(int index) {
            return (int)IntStream.range(0, index).mapToLong(x -> (int)(lineData()[x].lineHeightScale() * WritableSignScreen.DEFAULT_LINE_HEIGHT)).sum();
        }

        public int getLineOffset(int index, float currentScaleY) {
            float halfLineHeight = halfLineHeight(index);
            return (int)(halfLineHeight - (WritableSignScreen.DEFAULT_LINE_HEIGHT * 0.5F * currentScaleY));
        }

        public float lineHeight(int index) {
            return lineData()[index].lineHeightScale() * WritableSignScreen.DEFAULT_LINE_HEIGHT;
        }

        public float halfLineHeight(int index) {
            return lineData()[index].lineHeightScale() * WritableSignScreen.DEFAULT_LINE_HEIGHT * 0.5F;
        }

        public float getHalfLineHeightScales(int index, float currentScaleY) {
            return halfLineHeight(index) * currentScaleY;
        }

        public Vector3f screenTextScale(class_327 font, float scale, ConfiguredLine line) {
            float scaleX = (float)MathUtils.getScale(font.method_1727(line.text), line.data.maxLineWidth() * scale, line.data.minScale().field_1343, line.data.maxScale().field_1343);
            float scaleY = (float)MathUtils.getScale(font.method_1727(line.text), line.data.maxLineWidth() * scale, line.data.minScale().field_1342, line.data.maxScale().field_1342);
            return new Vector3f(scaleX, scaleY, 1);
        }

        public Vector3f berTextScale(String text, class_327 font, float scale, ConfiguredLineData data) {
            float scaleX = (float)MathUtils.getScale(font.method_1727(text) * scale, data.maxLineWidth(), data.minScale().field_1343, data.maxScale().field_1343);
            float scaleY = (float)MathUtils.getScale(font.method_1727(text) * scale, data.maxLineWidth(), data.minScale().field_1342, data.maxScale().field_1342);
            return new Vector3f(scaleX, scaleY, 1);
        }
    }

    public static record ConfiguredLineData(float xOffset, float yOffset, class_241 minScale, class_241 maxScale, float maxLineWidth, float lineHeightScale, int color) {}
    protected static class ConfiguredLine {
        public String text;
        public final ConfiguredLineData data;

        public ConfiguredLine(String text, ConfiguredLineData data) {
            this.text = text;
            this.data = data;
        }
    }
}
