package de.mrjulsen.mcdragonlib.network.packet;

import java.nio.charset.StandardCharsets;
import net.minecraft.class_2540;
import de.mrjulsen.mcdragonlib.network.CommunicationType;

public record PacketHeaderInfo(PacketType type, CommunicationType communication, long requestId, String name) {

    public void writeBufferHeader(class_2540 buffer) {
        buffer.method_52997(type.getId());
        buffer.method_52997(communication.getId());
        buffer.method_52974(requestId);
        buffer.method_10814(name);
    }

    public static PacketHeaderInfo readBufferHeader(class_2540 buffer) {
        return new PacketHeaderInfo(
            PacketType.getById(buffer.readByte()),
            CommunicationType.getById(buffer.readByte()),
            buffer.readLong(),
            buffer.method_19772()
        );
    }

    public int getSize() {
        int size = 0;
        size += Byte.BYTES;
        size += Byte.BYTES;
        size += Long.BYTES;
        size += name.getBytes(StandardCharsets.UTF_8).length;
        return size;
    }
    
}
