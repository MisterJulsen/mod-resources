package de.mrjulsen.mcdragonlib.network.fabric;

import de.mrjulsen.mcdragonlib.network.DLNetworkManager;
import de.mrjulsen.mcdragonlib.network.NetworkPacketContext;
import de.mrjulsen.mcdragonlib.network.NetworkSide;
import dev.architectury.utils.Env;
import dev.architectury.utils.EnvExecutor;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1255;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2596;
import net.minecraft.class_2960;
import java.util.concurrent.CompletableFuture;
import java.util.function.Supplier;

public class DLNetworkManagerImpl {
    
    public static void registerChannel(class_2960 channelId, String protocolVersion) {
        ServerPlayNetworking.registerGlobalReceiver(channelId, (server, player, handler, buf, sender) -> {
            NetworkPacketContext context = context(player, server, false);
            DLNetworkManager.receiveData(channelId, buf, NetworkSide.S2C, context);             
        });
        EnvExecutor.runInEnv(Env.CLIENT, () -> () -> ClientNetworkManager.registerChannel(channelId, protocolVersion));
    }
    
    
    static NetworkPacketContext context(class_1657 player, class_1255<?> taskQueue, boolean client) {
        return new NetworkPacketContext() {
            @Override
            public class_1657 getPlayer() {
                return player;
            }
            
            @Override
            public void queue(Runnable runnable) {
                taskQueue.execute(runnable);
            }

            @Override
            public <O> O queueResult(Supplier<O> supplier) {
                CompletableFuture<O> future = new CompletableFuture<>();
                taskQueue.execute(() -> {
                    try {
                        future.complete(supplier.get());
                    } catch (Throwable t) {
                        future.completeExceptionally(t);
                    }
                });
                return future.join();
            }
            
            @Override
            public Env getEnvironment() {
                return client ? Env.CLIENT : Env.SERVER;
            }
        };
    }
    
    public static class_2596<?> toPacket(class_2960 channelId, NetworkSide side, class_2540 buf) {
        if (side == NetworkSide.C2S) {
            return toC2SPacket(channelId, buf);
        } else if (side == NetworkSide.S2C) {
            return toS2CPacket(channelId, buf);
        }
        
        throw new IllegalArgumentException("Invalid side: " + side);
    }
    

    
    @Environment(EnvType.CLIENT)
    private static class_2596<?> toC2SPacket(class_2960 channelId, class_2540 buf) {
        return ClientPlayNetworking.createC2SPacket(channelId, buf);
    }
    
    private static class_2596<?> toS2CPacket(class_2960 channelId, class_2540 buf) {
        return ServerPlayNetworking.createS2CPacket(channelId, buf);
    }
}
