package de.mrjulsen.mcdragonlib.internal;

import de.mrjulsen.mcdragonlib.client.model.ModelContext;
import de.mrjulsen.mcdragonlib.client.model.mesh.BasicMesh;
import de.mrjulsen.mcdragonlib.client.model.mesh.DLModel;
import de.mrjulsen.mcdragonlib.client.model.mesh.Mesh;
import de.mrjulsen.mcdragonlib.util.DLColor;
import net.minecraft.class_1087;
import net.minecraft.class_2680;
import net.minecraft.class_5819;

public class TestModel extends DLModel {

    @Override
    protected Mesh getMesh(ModelType type, class_1087 originalModel, class_2680 state, class_5819 random, ModelContext context) {
        Mesh mesh = BasicMesh.fromBakedModel(state, originalModel, random);
        mesh.getFaces().forEach(f -> {
            if (f.getTags().contains("Test")) {
                f.setColor(DLColor.RED);
            }
        });
        return mesh;
    }


}
