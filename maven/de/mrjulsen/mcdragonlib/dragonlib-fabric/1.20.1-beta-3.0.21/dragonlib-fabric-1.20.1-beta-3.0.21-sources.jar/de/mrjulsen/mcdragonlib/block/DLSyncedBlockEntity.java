package de.mrjulsen.mcdragonlib.block;

import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_3218;

public abstract class DLSyncedBlockEntity extends class_2586 {

	public DLSyncedBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state) {
		super(type, pos, state);
	}

	@Override
	public class_2487 method_16887() {
		return this.method_38242();
	}

	@Override
	public class_2622 method_38235() {
		return class_2622.method_38585(this);
	}

	// Special handling for client update packets
	public void readClient(class_2487 tag) {
		method_11014(tag);
	}

	// Special handling for client update packets
	public class_2487 writeClient(class_2487 tag) {
		method_11007(tag);
		return tag;
	}

	public void sendData() {
		if (field_11863 instanceof class_3218 serverLevel) {			
			serverLevel.method_14178().method_14128(method_11016());
		}
	}

	public void notifyUpdate() {
		method_5431();
		sendData();
	}

	public class_2818 containedChunk() {
		return field_11863.method_8500(field_11867);
	}
}
