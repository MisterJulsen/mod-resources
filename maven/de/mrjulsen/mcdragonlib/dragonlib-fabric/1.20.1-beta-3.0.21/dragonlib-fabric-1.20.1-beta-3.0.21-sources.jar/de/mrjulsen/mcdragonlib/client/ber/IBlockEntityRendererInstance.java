package de.mrjulsen.mcdragonlib.client.ber;

import de.mrjulsen.mcdragonlib.client.util.FontUtils;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2583;
import net.minecraft.class_2586;
import net.minecraft.class_2680;

public interface IBlockEntityRendererInstance<T extends class_2586> {

    final FontUtils fontUtils = new FontUtils(class_2583.field_24359);

    /**
     * The rendering method.
     * @param graphics
     * @param partialTick
     */
    void render(BERGraphics<T> graphics, float partialTick);

    /**
     * Called every tick. Can be used for animations.
     * @param level
     * @param pos
     * @param state
     * @param blockEntity
     */
    default void tick(class_1937 level, class_2338 pos, class_2680 state, T blockEntity) { }

    /**
     * Called when the content of the BER changes. Can be used to perform recalculations only when necessary.
     * @param level
     * @param pos
     * @param state
     * @param blockEntity
     * @param data
     */
    default void update(class_1937 level, class_2338 pos, class_2680 state, T blockEntity, Object data) { }

    default FontUtils getFontUtils() {
        return fontUtils;
    }
}
