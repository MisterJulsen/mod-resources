package de.mrjulsen.mcdragonlib.internal;

import de.mrjulsen.mcdragonlib.DragonLib;
import de.mrjulsen.mcdragonlib.block.DLSyncedBlockEntity;
import net.minecraft.class_2338;
import net.minecraft.class_2591;
import net.minecraft.class_2680;

public class DragonLibBlockEntity extends DLSyncedBlockEntity {

    protected DragonLibBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state) {
        super(type, pos, state);
    }

    public DragonLibBlockEntity(class_2338 pos, class_2680 state) {
        super(DragonLib.DRAGONLIB_BLOCK_ENTITY.get(), pos, state);
    }
}
