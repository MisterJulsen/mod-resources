package de.mrjulsen.mcdragonlib.mixin;

import net.minecraft.class_437;
import net.minecraft.class_8023;
import net.minecraft.class_8028;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_437.class)
public interface ScreenAccessor {
    
    @Invoker("createTabEvent")
    class_8023.class_8026 dragonlib$createTabEvent();

    @Invoker("createArrowEvent")
    class_8023.class_8024 dragonlib$createArrowEvent(class_8028 direction);

    @Invoker("clearFocus")
    void dragonlib$clearFocus();
}