package de.mrjulsen.mcdragonlib.fabric.client.model.geometry.mixin.client;

import java.util.List;
import net.minecraft.class_7764;
import net.minecraft.class_785;
import net.minecraft.class_801;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_801.class)
public interface ItemModelGeneratorAccessor {

    @Invoker("processFrames")
    List<class_785> dragonlib$processFrames(int tintIndex, String texture, class_7764 sprite);
    
}
