package de.mrjulsen.mcdragonlib.client.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import net.minecraft.class_1087;
import net.minecraft.class_1109;
import net.minecraft.class_124;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_2477;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2680;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_308;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3417;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5348;
import net.minecraft.class_5481;
import net.minecraft.class_5819;
import net.minecraft.class_757;
import net.minecraft.class_765;
import net.minecraft.class_7833;
import net.minecraft.class_898;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import com.mojang.blaze3d.systems.RenderSystem;
import de.mrjulsen.mcdragonlib.client.gui.widgets.util.EAlign;
import de.mrjulsen.mcdragonlib.client.model.ModelContext;
import de.mrjulsen.mcdragonlib.client.model.mesh.BasicMesh;
import de.mrjulsen.mcdragonlib.client.model.mesh.DLModel;
import de.mrjulsen.mcdragonlib.client.model.mesh.Mesh;
import de.mrjulsen.mcdragonlib.client.model.mesh.DLModel.ModelType;
import de.mrjulsen.mcdragonlib.data.ETextAlignment;
import de.mrjulsen.mcdragonlib.data.ITranslatableEnum;
import de.mrjulsen.mcdragonlib.util.DLColor;
import de.mrjulsen.mcdragonlib.util.TextUtils;
import de.mrjulsen.mcdragonlib.util.math.Rectangle;

/**
 * Utility class providing a collection of static helper methods for GUI rendering
 * and common in-GUI operations used by DragonLib's client code.
 *
 * <p>Responsibilities include:
 * - Screen / mouse coordinate helpers
 * - Scissor (clipping) helpers
 * - Texture binding and drawing (including tiled drawing)
 * - Color and tint helpers
 * - Rendering helpers for items, entities, blocks and models into GUI contexts
 * - Basic shape and text drawing helpers
 *
 * <p>All methods in this class are stateless and operate on provided graphics
 * contexts or global Minecraft client state.
 */
public class GuiUtils {

    /**
     * Specifies how a texture should be filled into a rectangular area.
     * STRETCH scales the source region to fit the destination area.
     * TILE repeats the source region to fill the destination area.
     */
    public static enum TextureFillMode {
        STRETCH,
        TILE
    }
    

    /**
     * Returns the current mouse X coordinate in GUI-scaled pixels.
     *
     * @return mouse X position relative to the GUI scale
     */
    public static double mouseXOnScreen() {
        return class_310.method_1551().field_1729.method_1603() * (double)class_310.method_1551().method_22683().method_4486() / (double)class_310.method_1551().method_22683().method_4480();
    }

    /**
     * Returns the current mouse Y coordinate in GUI-scaled pixels.
     *
     * @return mouse Y position relative to the GUI scale
     */
    public static double mouseYOnScreen() {
        return class_310.method_1551().field_1729.method_1604() * (double)class_310.method_1551().method_22683().method_4502() / (double)class_310.method_1551().method_22683().method_4507();
    }

    /**
     * Returns the current GUI-scaled screen width.
     *
     * @return width in GUI-scaled pixels
     */
    public static double getScreenWidth() {
        return class_310.method_1551().method_22683().method_4486();
    }

    /**
     * Returns the current GUI-scaled screen height.
     *
     * @return height in GUI-scaled pixels
     */
    public static double getScreenHeight() {
        return class_310.method_1551().method_22683().method_4502();
    }

    /**
     * Enables OpenGL scissor test (clipping) for the specified rectangular area.
     *
     * @param graphics the DLGuiGraphics context (not modified)
     * @param area the rectangle in GUI coordinates to enable scissor for
     */
    public static void enableScissor(DLGuiGraphics graphics, Rectangle area) {
        enableScissor(graphics, (int)area.x(), (int)area.y(), (int)area.width(), (int)area.height());
    }

    /**
     * Enables OpenGL scissor test (clipping) for the specified rectangular area.
     *
     * @param graphics the DLGuiGraphics context (not modified)
     * @param x left coordinate in GUI pixels
     * @param y top coordinate in GUI pixels
     * @param w width in GUI pixels
     * @param h height in GUI pixels
     */
    public static void enableScissor(DLGuiGraphics graphics, int x, int y, int w, int h) {
        int scale = (int)class_310.method_1551().method_22683().method_4495();    
        RenderSystem.enableScissor(x * scale, class_310.method_1551().method_22683().method_4506() - (y + h) * scale, w * scale, h * scale);   
    }

    /**
     * Disables any previously enabled scissor (clipping) region.
     *
     * @param graphics the DLGuiGraphics context (not modified)
     */
    public static void disableScissor(DLGuiGraphics graphics) {
        RenderSystem.disableScissor();
    }

    /**
     * Plays the standard UI button click sound at default pitch and volume.
     */
    public static void playButtonSound() {
        class_310.method_1551().method_1483().method_4873(class_1109.method_47978(class_3417.field_15015, 1.0F));
    }

    /**
     * Converts a FormattedText instance to a visual-order FormattedCharSequence.
     *
     * @param text the formatted text to convert
     * @return a FormattedCharSequence suitable for rendering
     */
    public static class_5481 toFormattedCharSequence(class_5348 text) {
        return text instanceof class_2561 ? ((class_2561)text).method_30937() : class_2477.method_10517().method_30934(text);
    }
    
    
    /**
     * Splits a collection of formatted texts into visual-order char sequences
     * using the provided font and maximum line width.
     *
     * @param font font used for measuring and splitting
     * @param components collection of formatted texts to split
     * @param maxWidth maximum width in pixels for each resulting line
     * @param <T> a type extending FormattedText
     * @return list of resulting FormattedCharSequence lines
     */
    public static <T extends class_5348> List<class_5481> splitToFormattedCharSequences(class_327 font, Collection<T> components, int maxWidth) {
        List<class_5481> lines = new ArrayList<>(components.size());
        for (T component : components) {
            lines.addAll(font.method_1728(component, maxWidth));
        }
        return lines;
    }
    
    /**
     * Splits a collection of formatted texts into FormattedText line objects
     * using the provided font and maximum line width.
     *
     * @param font font used for measuring and splitting
     * @param components collection of formatted texts to split
     * @param maxWidth maximum width in pixels for each resulting line
     * @param <T> a type extending FormattedText
     * @return list of resulting FormattedText lines
     */
    public static <T extends class_5348> List<class_5348> splitText(class_327 font, Collection<T> components, int maxWidth) {
        List<class_5348> lines = new ArrayList<>(components.size());
        for (T component : components) {
            lines.addAll(font.method_27527().method_27495(component, maxWidth, class_2583.field_24360));
        }
        return lines;
    }

    /**
     * Draws a tooltip comprised of multiple formatted text lines at the specified location.
     *
     * @param graphics DLGuiGraphics wrapper used for rendering
     * @param font font used to render tooltip text
     * @param x x coordinate where tooltip should be shown
     * @param y y coordinate where tooltip should be shown
     * @param lines list of formatted text lines to display
     * @param maxWidth maximum width for tooltip text wrapping
     */
    public static void drawTooltip(DLGuiGraphics graphics, class_327 font, int x, int y, List<? extends class_5348> lines, int maxWidth) {
        graphics.graphics().method_51447(font, splitToFormattedCharSequences(font, lines, maxWidth), x, y);
    }

    /**
     * Draws a tooltip at a position adjusted directly from the raw input (useful for mouse-based tooltips).
     *
     * @param graphics DLGuiGraphics wrapper used for rendering
     * @param font font used to render the tooltip
     * @param x raw x coordinate (will be offset internally)
     * @param y raw y coordinate (will be offset internally)
     * @param lines tooltip lines
     * @param maxWidth maximum width for tooltip text wrapping
     */
    public static void drawTooltipDirectlyAt(DLGuiGraphics graphics, class_327 font, int x, int y, List<? extends class_5348> lines, int maxWidth) {
        drawTooltip(graphics, font, x - 8, y - 16, lines, maxWidth);
    }

    /**
     * Builds a descriptive tooltip for a translatable enum class, including
     * the enum description and each enum constant's name and description.
     *
     * @param enumClass the enum class to describe (must implement ITranslatableEnum)
     * @param maxWidth maximum width to consider when splitting lines (unused by current implementation but kept for API compatibility)
     * @param <T> enum type
     * @return list of Components representing the tooltip lines
     */
    public static <T extends Enum<T> & ITranslatableEnum> List<class_2561> getEnumTooltipData(Class<T> enumClass, int maxWidth) {
        List<class_2561> c = new ArrayList<>();
        T enumValue = enumClass.getEnumConstants()[0];
        c.add(enumValue.getEnumDescriptionTranslation());
        c.add(TextUtils.text(" "));
        for (T t : enumClass.getEnumConstants()) {
            c.add(TextUtils.text("> ").method_27692(class_124.field_1067).method_10852(t.getValueTranslation()).method_27692(class_124.field_1067));
            c.add(t.getValueDescriptionTranslation().method_27692(class_124.field_1080));
        }
        return c;
    }



    /**
     * Binds the given ResourceLocation as the active texture for subsequent draw calls.
     *
     * @param texture the texture resource location to bind
     */
    public static void setTexture(class_2960 texture) {
        RenderSystem.setShaderTexture(0, texture);
    }

    /**
     * Binds the given OpenGL texture id as the active texture for subsequent draw calls.
     *
     * @param textureId the OpenGL texture id
     */
    public static void setTexture(int textureId) {
        RenderSystem.setShaderTexture(0, textureId);
    }

    /**
     * Sets the current shader color/tint from a DLColor instance.
     *
     * @param color color used to set the shader color (including alpha)
     */
    public static void setTint(DLColor color) {
        float a = color.getAlphaF();
        float r = color.getRedF();
        float g = color.getGreenF();
        float b = color.getBlueF();
        RenderSystem.setShaderColor(r, g, b, a);
    }

    /**
     * Resets the shader color/tint to opaque white (no tint).
     */
    public static void resetTint() {
        RenderSystem.setShaderColor(1, 1, 1, 1);
    }

    /**
     * Renders a texture repeatedly (tiled) to fill the specified area.
     *
     * @param graphics DLGuiGraphics context used for matrix access
     * @param bindTexture a Runnable that binds the appropriate texture when executed
     * @param x destination x coordinate
     * @param y destination y coordinate
     * @param w destination width
     * @param h destination height
     * @param u source texture u coordinate
     * @param v source texture v coordinate
     * @param uW source width in texture pixels
     * @param vH source height in texture pixels
     * @param texWidth full texture atlas width (for UV normalization)
     * @param texHeight full texture atlas height (for UV normalization)
     */
    public static void renderTiledTexture(DLGuiGraphics graphics, Runnable bindTexture, int x, int y, int w, int h, float u, float v, float uW, float vH, int texWidth, int texHeight) {
        RenderSystem.setShader(class_757::method_34542);
        bindTexture.run();

        float minU = u / texWidth;
        float minV = v / texHeight;
        float maxU = (u + uW) / texWidth;
        float maxV = (v + vH) / texHeight;
        float uSpan = maxU - minU;
        float vSpan = maxV - minV;

        Matrix4f matrix = graphics.poseStack().method_23760().method_23761();
        class_289 tess = class_289.method_1348();
        class_287 buffer = tess.method_1349();
        buffer.method_1328(class_293.class_5596.field_27382, class_290.field_1585);

        int fullXTiles = w / (int)uW;
        int fullYTiles = h / (int)vH;
        float restX = w % uW;
        float restY = h % vH;

        float offsetY = 0f;
        for (int yTile = 0; yTile <= fullYTiles; yTile++) {
            float tileHeight = (yTile < fullYTiles) ? vH : restY;
            if (tileHeight <= 0) break;

            float offsetX = 0f;
            for (int xTile = 0; xTile <= fullXTiles; xTile++) {
                float tileWidth = (xTile < fullXTiles) ? uW : restX;
                if (tileWidth <= 0) break;

                float u0 = minU;
                float v0 = minV;
                float u1 = minU + uSpan * (tileWidth / uW);
                float v1 = minV + vSpan * (tileHeight / vH);

                float quadX0 = x + offsetX;
                float quadY0 = y + offsetY;
                float quadX1 = quadX0 + tileWidth;
                float quadY1 = quadY0 + tileHeight;

                buffer.method_22918(matrix, quadX0, quadY1, 0).method_22913(u0, v1).method_1344();
                buffer.method_22918(matrix, quadX1, quadY1, 0).method_22913(u1, v1).method_1344();
                buffer.method_22918(matrix, quadX1, quadY0, 0).method_22913(u1, v0).method_1344();
                buffer.method_22918(matrix, quadX0, quadY0, 0).method_22913(u0, v0).method_1344();

                offsetX += tileWidth;
            }
            offsetY += tileHeight;
        }

        tess.method_1350();
    }

    /**
     * Draws a texture resource at specified destination area. Supports STRETCH and TILE fill modes.
     *
     * @param texture texture resource to draw
     * @param graphics DLGuiGraphics wrapper used for rendering
     * @param x destination x
     * @param y destination y
     * @param w destination width
     * @param h destination height
     * @param u source u in texture
     * @param v source v in texture
     * @param uW source width in texture pixels
     * @param vH source height in texture pixels
     * @param mode fill mode (STRETCH or TILE)
     */
    public static void drawTexture(class_2960 texture, DLGuiGraphics graphics, int x, int y, int w, int h, int u, int v, int uW, int vH, TextureFillMode mode) {
        drawTexture(texture, graphics, x, y, w, h, u, v, uW, vH, mode, 256, 256);
    }

    /**
     * Draws a texture resource at specified destination area with an explicit texture atlas size.
     *
     * @param texture texture resource to draw
     * @param graphics DLGuiGraphics wrapper used for rendering
     * @param x destination x
     * @param y destination y
     * @param w destination width
     * @param h destination height
     * @param u source u in texture
     * @param v source v in texture
     * @param uW source width in texture pixels
     * @param vH source height in texture pixels
     * @param mode fill mode (STRETCH or TILE)
     * @param textureWidth full texture atlas width for UV calculation
     * @param textureHeight full texture atlas height for UV calculation
     */
    public static void drawTexture(class_2960 texture, DLGuiGraphics graphics, int x, int y, int w, int h, int u, int v, int uW, int vH, TextureFillMode mode, int textureWidth, int textureHeight) {
        switch (mode) {
            case TILE -> renderTiledTexture(graphics, () -> RenderSystem.setShaderTexture(0, texture), x, y, w, h, u, v, uW, vH, textureWidth, textureHeight);
            default -> graphics.graphics().method_25293(texture, x, y, w, h, u, v, uW, vH, textureWidth, textureHeight);
        }
    }

    /**
     * Draws a texture by OpenGL texture id, supporting tiled and stretched modes.
     *
     * @param textureId OpenGL texture id to bind
     * @param graphics DLGuiGraphics wrapper used for rendering
     * @param x destination x
     * @param y destination y
     * @param w destination width
     * @param h destination height
     * @param u source u in texture
     * @param v source v in texture
     * @param uW source width in texture pixels
     * @param vH source height in texture pixels
     * @param mode fill mode (STRETCH or TILE)
     * @param textureWidth full texture atlas width for UV calculation
     * @param textureHeight full texture atlas height for UV calculation
     */
    public static void drawTexture(int textureId, DLGuiGraphics graphics, int x, int y, int w, int h, int u, int v, int uW, int vH, TextureFillMode mode, int textureWidth, int textureHeight) {
        switch (mode) {
            case TILE -> renderTiledTexture(graphics, () -> RenderSystem.setShaderTexture(0, textureId), x, y, w, h, u, v, uW, vH, textureWidth, textureHeight);
            default -> blit(graphics.graphics(), textureId, x, y, w, h, u, v, uW, vH, textureWidth, textureHeight);
        }
        
    }

    /**
     * Draws a DLTexture wrapper which may either use a ResourceLocation or a texture id.
     *
     * @param texture DLTexture wrapper
     * @param graphics DLGuiGraphics wrapper used for rendering
     * @param x destination x
     * @param y destination y
     * @param w destination width
     * @param h destination height
     * @param u source u in texture
     * @param v source v in texture
     * @param uW source width in texture pixels
     * @param vH source height in texture pixels
     * @param mode fill mode (STRETCH or TILE)
     */
    public static void drawTexture(DLTexture texture, DLGuiGraphics graphics, int x, int y, int w, int h, int u, int v, int uW, int vH, TextureFillMode mode) {
        if (texture.usesTextureId() || texture.getTexture().isEmpty()) {
            drawTexture(texture.getTextureId(), graphics, x, y, w, h, u, v, uW, vH, mode, texture.width(), texture.height());
        } else {            
            drawTexture(texture.getTexture().get(), graphics, x, y, w, h, u, v, uW, vH, mode, texture.width(), texture.height());
        }
    }
    
    /**
     * Convenience overload that draws the entire DLTexture to the destination rectangle
     * using STRETCH mode.
     *
     * @param texture DLTexture wrapper
     * @param graphics DLGuiGraphics wrapper used for rendering
     * @param x destination x
     * @param y destination y
     * @param w destination width (also used as source width)
     * @param h destination height (also used as source height)
     * @param u source u in texture
     * @param v source v in texture
     */
    public static void drawTexture(DLTexture texture, DLGuiGraphics graphics, int x, int y, int w, int h, int u, int v) {
        drawTexture(texture, graphics, x, y, w, h, u, v, w, h, TextureFillMode.STRETCH);
    }
    
    /**
     * Convenience overload that draws the entire DLTexture to the destination rectangle
     * using STRETCH mode and source region equal to destination size.
     *
     * @param texture DLTexture wrapper
     * @param graphics DLGuiGraphics wrapper used for rendering
     * @param x destination x
     * @param y destination y
     * @param w destination width
     * @param h destination height
     */
    public static void drawTexture(DLTexture texture, DLGuiGraphics graphics, int x, int y, int w, int h) {
        drawTexture(texture, graphics, x, y, w, h, 0, 0, w, h, TextureFillMode.STRETCH);
    }


    /* COPY OF: GuiGraphics */
    private static void innerBlit(class_4587 pose, int textureId, int pX1, int pX2, int pY1, int pY2, int pBlitOffset, float pMinU, float pMaxU, float pMinV, float pMaxV) {
        RenderSystem.setShaderTexture(0, textureId);
        RenderSystem.setShader(class_757::method_34542);
        Matrix4f matrix4f = pose.method_23760().method_23761();
        class_287 bufferbuilder = class_289.method_1348().method_1349();
        bufferbuilder.method_1328(class_293.class_5596.field_27382, class_290.field_1585);
        bufferbuilder.method_22918(matrix4f, (float)pX1, (float)pY1, (float)pBlitOffset).method_22913(pMinU, pMinV).method_1344();
        bufferbuilder.method_22918(matrix4f, (float)pX1, (float)pY2, (float)pBlitOffset).method_22913(pMinU, pMaxV).method_1344();
        bufferbuilder.method_22918(matrix4f, (float)pX2, (float)pY2, (float)pBlitOffset).method_22913(pMaxU, pMaxV).method_1344();
        bufferbuilder.method_22918(matrix4f, (float)pX2, (float)pY1, (float)pBlitOffset).method_22913(pMaxU, pMinV).method_1344();
        class_286.method_43433(bufferbuilder.method_1326());
    }
    
    private static void blit(class_332 graphics, int textureId, int pX, int pY, int pWidth, int pHeight, float pUOffset, float pVOffset, int pUWidth, int pVHeight, int pTextureWidth, int pTextureHeight) {
        blit(graphics, textureId, pX, pX + pWidth, pY, pY + pHeight, 0, pUWidth, pVHeight, pUOffset, pVOffset, pTextureWidth, pTextureHeight);
    }

    private static void blit(class_332 graphics, int textureId, int pX1, int pX2, int pY1, int pY2, int pBlitOffset, int pUWidth, int pVHeight, float pUOffset, float pVOffset, int pTextureWidth, int pTextureHeight) {
        innerBlit(graphics.method_51448(), textureId, pX1, pX2, pY1, pY2, pBlitOffset, (pUOffset + 0.0F) / (float)pTextureWidth, (pUOffset + (float)pUWidth) / (float)pTextureWidth, (pVOffset + 0.0F) / (float)pTextureHeight, (pVOffset + (float)pVHeight) / (float)pTextureHeight);
    }
    /* END */


    /**
     * Fills a rectangle area with the provided color.
     *
     * @param graphics DLGuiGraphics used for rendering
     * @param area rectangle to fill
     * @param color color to fill with (including alpha)
     */
    public static void fill(DLGuiGraphics graphics, Rectangle area, DLColor color) {
        fill(graphics, (int)area.x(), (int)area.y(), (int)area.width(), (int)area.height(), color);
    }

    /**
     * Fills a rectangle area with the provided color.
     *
     * @param graphics DLGuiGraphics used for rendering
     * @param x left coordinate
     * @param y top coordinate
     * @param w width
     * @param h height
     * @param color color to fill with (including alpha)
     */
    public static void fill(DLGuiGraphics graphics, int x, int y, int w, int h, DLColor color) {
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        graphics.graphics().method_25294(x, y, x + w, y + h, color.getAsARGB());
        RenderSystem.disableBlend();
    }

    /**
     * Fills a rectangle with a gradient between two colors aligned according to the given alignment.
     *
     * @param graphics DLGuiGraphics used for rendering
     * @param area rectangle to fill
     * @param colorA first color
     * @param colorB second color
     * @param align alignment determining vertex color order
     */
    public static void fillGradient(DLGuiGraphics graphics, Rectangle area, DLColor colorA, DLColor colorB, EAlign align) {
        fillGradient(graphics, (int)area.x(), (int)area.y(), (int)area.width(), (int)area.height(), colorA, colorB, align);
    }

    /**
     * Fills a rectangle with a gradient between two colors aligned according to the given alignment.
     *
     * @param graphics DLGuiGraphics used for rendering
     * @param x left coordinate
     * @param y top coordinate
     * @param w width
     * @param h height
     * @param colorA first color
     * @param colorB second color
     * @param align alignment determining vertex color order
     */
    public static void fillGradient(DLGuiGraphics graphics, int x, int y, int w, int h, DLColor colorA, DLColor colorB, EAlign align) {
        DLColor[] vertexColors = new DLColor[4];
        for (int i = 0; i < vertexColors.length; i++) {
            vertexColors[(align.getOrder() + i) % vertexColors.length] = (i < 2 ? colorA : colorB);
        }

        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(class_757::method_34540);

        class_289 tessellator = class_289.method_1348();
        class_287 buffer = tessellator.method_1349();
        buffer.method_1328(class_293.class_5596.field_27382, class_290.field_1576);
        buffer.method_22918(graphics.poseStack().method_23760().method_23761(), x + w, y, 0).method_39415(vertexColors[0].getAsARGB()).method_1344();
        buffer.method_22918(graphics.poseStack().method_23760().method_23761(), x, y, 0).method_39415(vertexColors[1].getAsARGB()).method_1344();
        buffer.method_22918(graphics.poseStack().method_23760().method_23761(), x, y + h, 0).method_39415(vertexColors[2].getAsARGB()).method_1344();
        buffer.method_22918(graphics.poseStack().method_23760().method_23761(), x + w, y + h, 0).method_39415(vertexColors[3].getAsARGB()).method_1344();
        tessellator.method_1350();

        RenderSystem.disableBlend();
    }

    /**
     * Draws a filled box with a solid fill color and a border color.
     *
     * @param graphics DLGuiGraphics used for rendering
     * @param area rectangle describing the box
     * @param fillColor interior fill color
     * @param borderColor outline color
     */
    public static void drawBox(DLGuiGraphics graphics, Rectangle area, DLColor fillColor, DLColor borderColor) {
        drawBox(graphics, (int)area.x(), (int)area.y(), (int)area.width(), (int)area.height(), fillColor, borderColor);
    }

    /**
     * Draws a filled box with a solid fill color and a border color.
     *
     * @param graphics DLGuiGraphics used for rendering
     * @param x left coordinate
     * @param y top coordinate
     * @param w width
     * @param h height
     * @param fillColor interior fill color
     * @param borderColor outline color
     */
    public static void drawBox(DLGuiGraphics graphics, int x, int y, int w, int h, DLColor fillColor, DLColor borderColor) {
        fill(graphics, x, y, w, h, fillColor);
        fill(graphics, x, y, w, 1, borderColor);
        fill(graphics, x, y + h - 1, w, 1, borderColor);
        fill(graphics, x, y + 1, 1, h - 2, borderColor);
        fill(graphics, x + w - 1, y + 1, 1, h - 2, borderColor);
    }

    /**
     * Draws a string with the specified alignment and optional drop shadow.
     *
     * @param graphics DLGuiGraphics used for rendering
     * @param font font used to render text
     * @param x x coordinate for the text anchor
     * @param y y coordinate for the text baseline
     * @param text plain string to render
     * @param color color to use for text
     * @param alignment left / center / right alignment mode
     * @param dropShadow whether to render a drop shadow
     */
    public static void drawString(DLGuiGraphics graphics, class_327 font, int x, int y, String text, DLColor color, ETextAlignment alignment, boolean dropShadow) {
        drawString(graphics, font, x, y, TextUtils.text(text), color, alignment, dropShadow);
    }

    /**
     * Draws a formatted text with the specified alignment and optional drop shadow.
     *
     * @param graphics DLGuiGraphics used for rendering
     * @param font font used to render text
     * @param x x coordinate for the text anchor
     * @param y y coordinate for the text baseline
     * @param text formatted text to render
     * @param color color to use for text
     * @param alignment left / center / right alignment mode
     * @param dropShadow whether to render a drop shadow
     */
    public static void drawString(DLGuiGraphics graphics, class_327 font, int x, int y, class_5348 text, DLColor color, ETextAlignment alignment, boolean dropShadow) {
        int width = font.method_27525(text);
        int offset = 0;
        switch (alignment) {
            default:
            case LEFT:
                break;
            case CENTER:
                offset = -width / 2;
                break;
            case RIGHT:
                offset = -width;
                break;
        }

        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);
        graphics.graphics().method_51430(font, toFormattedCharSequence(text), x + offset, y, color.getAsARGB(), dropShadow);
    }

    /**
     * Renders an item stack into the GUI at default scale and with decorations.
     *
     * @param graphics DLGuiGraphics used for rendering
     * @param stack item stack to render
     * @param x x coordinate
     * @param y y coordinate
     */
    public static void renderItem(DLGuiGraphics graphics, class_1799 stack, int x, int y) {
        renderItem(graphics, stack, x, y, 1, true);
    }

    /**
     * Renders an item stack into the GUI with custom scale and optional decorations.
     *
     * @param graphics DLGuiGraphics used for rendering
     * @param stack item stack to render
     * @param x x coordinate
     * @param y y coordinate
     * @param scale uniform scale factor to apply
     * @param drawDecorations whether to draw stack count, durability, etc.
     */
    public static void renderItem(DLGuiGraphics graphics, class_1799 stack, int x, int y, float scale, boolean drawDecorations) {
        graphics.poseStack().method_22903();
        graphics.poseStack().method_46416(x, y, 0);
        graphics.poseStack().method_22905(scale, scale, 1);        
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);
        graphics.graphics().method_51427(stack, 0, 0);
        if (drawDecorations) {
            graphics.graphics().method_51431(class_310.method_1551().field_1772, stack, 0, 0);
        }
        graphics.poseStack().method_22909();
    }
    

    /**
     * Renders only the item decorations (count, text overlays) for the specified item stack.
     *
     * @param graphics DLGuiGraphics used for rendering
     * @param stack the item stack whose decorations to render
     * @param x x coordinate
     * @param y y coordinate
     * @param scale uniform scale factor to apply to decoration rendering
     * @param text optional overlay text to render (may be null or empty)
     */
    public static void renderItemDecoration(DLGuiGraphics graphics, class_1799 stack, int x, int y, float scale, String text) {
        graphics.poseStack().method_22903();
        graphics.poseStack().method_46416(x, y, 0);
        graphics.poseStack().method_22905(scale, scale, 1);        
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);
        graphics.graphics().method_51432(class_310.method_1551().field_1772, stack, 0, 0, text);
        graphics.poseStack().method_22909();
    }

    /**
     * Renders a living entity into GUI space at default brightness.
     *
     * @param graphics DLGuiGraphics used for rendering
     * @param x x coordinate
     * @param y y coordinate
     * @param entity entity instance to render
     */
    public static void renderEntity(DLGuiGraphics graphics, int x, int y, class_1309 entity) {
        renderEntity(graphics, x, y, 1, entity, class_765.field_32767);
    }

    /**
     * Renders a living entity into GUI space with a custom scale and brightness.
     *
     * @param graphics DLGuiGraphics used for rendering
     * @param x x coordinate
     * @param y y coordinate
     * @param scale uniform scale factor to apply to the entity rendering
     * @param entity entity instance to render
     * @param light packed light coordinate controlling brightness
     */
    public static void renderEntity(DLGuiGraphics graphics, int x, int y, float scale, class_1309 entity, int light) {
        renderEntity(graphics, x, y, scale, entity, new Matrix4f(), new Quaternionf(), light);
    }

    /**
     * Renders a living entity into GUI space applying a transformation matrix and optional camera orientation override.
     *
     * <p>This overload allows fine-grained control of the transform and camera orientation used
     * when rendering the entity for UI previews.
     *
     * @param graphics DLGuiGraphics used for rendering
     * @param x x coordinate
     * @param y y coordinate
     * @param scale uniform scale factor
     * @param entity entity instance to render
     * @param transformation additional model transformation matrix to apply
     * @param cameraOrientation optional quaternion representing camera orientation (may be null)
     * @param light packed light to use for rendering
     */
    @SuppressWarnings("deprecation")
    public static void renderEntity(DLGuiGraphics graphics, int x, int y, float scale, class_1309 entity, Matrix4f transformation, @Nullable Quaternionf cameraOrientation, int light) {
        float s = 16 * scale;
        graphics.poseStack().method_22903();
        graphics.poseStack().method_22904((double)x, (double)y, 16 * (scale + 1));
        graphics.poseStack().method_34425((new Matrix4f()).scaling(s, s, -s));
        graphics.poseStack().method_34425(transformation);
        class_308.method_34742();
        class_898 entityRenderDispatcher = class_310.method_1551().method_1561();
        if (cameraOrientation != null) {
            cameraOrientation.conjugate();
            entityRenderDispatcher.method_24196(cameraOrientation);
        }

        entityRenderDispatcher.method_3948(false);
        RenderSystem.runAsFancy(() -> {
            entityRenderDispatcher.method_3954(entity, 0.0, 0.0, 0.0, 0.0F, 1.0F, graphics.poseStack(), graphics.graphics().method_51450(), light);
        });
        graphics.graphics().method_51452();
        entityRenderDispatcher.method_3948(true);
        graphics.poseStack().method_22909();
        class_308.method_24211();
    }
    

    /**
     * Renders an entity that rotates following the mouse position (default scale).
     *
     * @param graphics DLGuiGraphics used for rendering
     * @param x x coordinate
     * @param y y coordinate
     * @param entity entity to render
     */
    public static void renderEntityFollowingMouse(DLGuiGraphics graphics, int x, int y, class_1309 entity) {
        renderEntityFollowingMouse(graphics, x, y, 1, entity);
    }

    /**
     * Renders an entity that rotates following the mouse position.
     *
     * @param graphics DLGuiGraphics used for rendering
     * @param x x coordinate
     * @param y y coordinate
     * @param scale uniform scale factor
     * @param entity entity to render
     */
    public static void renderEntityFollowingMouse(DLGuiGraphics graphics, int x, int y, float scale, class_1309 entity) {
        renderEntityFollowingMouse(graphics, x, y, scale, (float)class_310.method_1551().field_1729.method_1603(), (float)class_310.method_1551().field_1729.method_1604(), entity, class_765.field_32767);
    }

    /**
     * Renders an entity that rotates following a given screen-space mouse coordinate.
     *
     * @param graphics DLGuiGraphics used for rendering
     * @param x x coordinate
     * @param y y coordinate
     * @param scale uniform scale factor
     * @param screenMouseX mouse X in screen coordinates used to compute rotation
     * @param screenMouseY mouse Y in screen coordinates used to compute rotation
     * @param entity entity to render
     * @param light packed light for rendering
     */
    public static void renderEntityFollowingMouse(DLGuiGraphics graphics, int x, int y, float scale, float screenMouseX, float screenMouseY, class_1309 entity, int light) {
        Matrix4f transformation = graphics.poseStack().method_23760().method_23761();
        float aX = (float)Math.atan((double)((transformation.m30() + x - screenMouseX) / 40.0F));
        float aY = (float)Math.atan((double)((transformation.m31() + y - (screenMouseY + entity.method_5751() * (16 * scale))) / 40.0F));
        renderEntityFollowingAngle(graphics, x, y, scale, aX, aY, entity, light);
    }

    /**
     * Renders an entity rotated according to precomputed angle components.
     *
     * @param graphics DLGuiGraphics used for rendering
     * @param x x coordinate
     * @param y y coordinate
     * @param scale uniform scale factor
     * @param angleXComponent X-angle influence component
     * @param angleYComponent Y-angle influence component
     * @param entity entity to render
     * @param light packed light for rendering
     */
    public static void renderEntityFollowingAngle(DLGuiGraphics graphics, int x, int y, float scale, float angleXComponent, float angleYComponent, class_1309 entity, int light) {
        Quaternionf quaternionf = (new Quaternionf()).rotateZ((float)Math.PI);
        Quaternionf quaternionf1 = (new Quaternionf()).rotateX(angleYComponent * 20.0F * 0.017453292F);
        quaternionf.mul(quaternionf1);
        float f2 = entity.field_6283;
        float f3 = entity.method_36454();
        float f4 = entity.method_36455();
        float f5 = entity.field_6259;
        float f6 = entity.field_6241;
        entity.field_6283 = 180.0F + angleXComponent * 20.0F;
        entity.method_36456(180.0F + angleXComponent * 40.0F);
        entity.method_36457(-angleYComponent * 20.0F);
        entity.field_6241 = entity.method_36454();
        entity.field_6259 = entity.method_36454();        
        Matrix4f matrix = new Matrix4f().rotate(quaternionf);
        renderEntity(graphics, x, y, scale, entity, matrix, quaternionf1, light);
        entity.field_6283 = f2;
        entity.method_36456(f3);
        entity.method_36457(f4);
        entity.field_6259 = f5;
        entity.field_6241 = f6;
    }
    

    /**
     * Renders a block state as a simple flat model in GUI space using a generated mesh.
     *
     * @param graphics DLGuiGraphics used for rendering
     * @param x x coordinate
     * @param y y coordinate
     * @param state block state to render
     * @param renderType render layer to use when rendering the model
     */
    public static void renderBlockState(DLGuiGraphics graphics, int x, int y, class_2680 state, class_1921 renderType) {
        renderBlockState(graphics, x, y, 1, state, renderType, new Matrix4f(), class_765.field_32767);
    }

    /**
     * Renders a block state as a simple flat model in GUI space with custom scale and lighting.
     *
     * @param graphics DLGuiGraphics used for rendering
     * @param x x coordinate
     * @param y y coordinate
     * @param scale uniform scale factor
     * @param state block state to render
     * @param renderType render layer to use when rendering the model
     * @param light packed light for rendering
     */
    public static void renderBlockState(DLGuiGraphics graphics, int x, int y, float scale, class_2680 state, class_1921 renderType, int light) {
        renderBlockState(graphics, x, y, scale, state, renderType, new Matrix4f(), light);
    }

    /**
     * Renders a block state as a simple flat model in GUI space with transformation control.
     *
     * @param graphics DLGuiGraphics used for rendering
     * @param x x coordinate
     * @param y y coordinate
     * @param scale uniform scale factor
     * @param state block state to render
     * @param renderType render layer to use when rendering the model
     * @param transformation additional matrix to apply to the model
     * @param light packed light for rendering
     */
    public static void renderBlockState(DLGuiGraphics graphics, int x, int y, float scale, class_2680 state, class_1921 renderType, Matrix4f transformation, int light) {
        DLModel model = new DLModel() {
            @Override
            protected Mesh getMesh(ModelType type, class_1087 originalModel, class_2680 state, class_5819 random, ModelContext context) {
                Mesh mesh = BasicMesh.fromBlock(state, random);
                mesh.rotate(class_7833.field_40718.rotationDegrees(180), new Vector3f(0.5f));
                return mesh;
            }
        };
        renderModel(graphics, x, y, scale, model, state, renderType, transformation, light);
    }
    

    /**
     * Renders a DLModel for a given block state at the default scale.
     *
     * @param graphics DLGuiGraphics used for rendering
     * @param x x coordinate
     * @param y y coordinate
     * @param model model instance to render
     * @param state block state to provide to the model
     * @param renderType render layer to use
     */
    public static void renderModel(DLGuiGraphics graphics, int x, int y, DLModel model, class_2680 state, class_1921 renderType) {
        renderModel(graphics, x, y, 1, model, state, renderType, new Matrix4f(), class_765.field_32767);
    }

    /**
     * Renders a DLModel for a given block state with custom scale and lighting.
     *
     * @param graphics DLGuiGraphics used for rendering
     * @param x x coordinate
     * @param y y coordinate
     * @param scale uniform scale factor
     * @param model model instance to render
     * @param state block state to provide to the model
     * @param renderType render layer to use
     * @param light packed light for rendering
     */
    public static void renderModel(DLGuiGraphics graphics, int x, int y, float scale, DLModel model, class_2680 state, class_1921 renderType, int light) {
        renderModel(graphics, x, y, scale, model, state, renderType, new Matrix4f(), light);
    }

    /**
     * Renders a DLModel for a given block state with full transformation control and lighting.
     *
     * @param graphics DLGuiGraphics used for rendering
     * @param x x coordinate
     * @param y y coordinate
     * @param scale uniform scale factor
     * @param model model instance to render
     * @param state block state to provide to the model
     * @param renderType render layer to use
     * @param transformation additional transformation to apply
     * @param light packed light for rendering
     */
    public static void renderModel(DLGuiGraphics graphics, int x, int y, float scale, DLModel model, class_2680 state, class_1921 renderType, Matrix4f transformation, int light) {
        float s = scale * 16;
        class_308.method_24210();
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(true);
        class_4587 stack = graphics.poseStack();
        stack.method_22903();
        stack.method_22905(1, 1, -1);
        stack.method_22904((double)x, (double)y, 16 * (scale + 1));
        stack.method_34425((new Matrix4f()).scaling((float)s, (float)s, (float)(s)));
        stack.method_34425(transformation);
        class_4597.class_4598 buffersource = class_310.method_1551().method_22940().method_23000();
        model.render(graphics.poseStack().method_23760(), buffersource.getBuffer(renderType), ModelType.BLOCK, state, ModelContext.EMPTY, DLColor.WHITE, class_765.field_32767, 0);
        buffersource.method_22993();
        stack.method_22909();
        class_308.method_24211();
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);
    }
}
