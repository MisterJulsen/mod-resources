package de.mrjulsen.mcdragonlib.util.registry;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;
import net.minecraft.class_2487;
import net.minecraft.class_2960;
import de.mrjulsen.mcdragonlib.data.INBTSerializable;

public class DLRegistry<T extends INBTSerializable & IRegisterable<T>> {
    private final Map<class_2960, DLRegistryObject<? extends T>> TYPES = new HashMap<>();

    public <S extends T> DLRegistryObject<S> register(class_2960 id, Supplier<S> factory) {
        DLRegistryObject<S> type = new DLRegistryObject<>(id, factory);
        TYPES.put(id, type);
        return type;
    }

    @SuppressWarnings("unchecked")
    private DLRegistryObject<T> get(class_2960 id) {
        return (DLRegistryObject<T>)TYPES.get(id);
    }

    public T load(class_2487 tag) {
        return DLRegistryObject.load(tag, this::get);
    }

}
