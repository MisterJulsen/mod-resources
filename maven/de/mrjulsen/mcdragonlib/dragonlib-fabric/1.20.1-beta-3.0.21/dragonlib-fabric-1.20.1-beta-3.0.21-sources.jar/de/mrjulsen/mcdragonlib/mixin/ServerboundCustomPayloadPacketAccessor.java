package de.mrjulsen.mcdragonlib.mixin;

import net.minecraft.class_2817;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_2817.class)
public abstract class ServerboundCustomPayloadPacketAccessor {
    
    @Accessor("MAX_PAYLOAD_SIZE")
    public static int dragonlib$maxPayloadSize() {
        throw new AssertionError();
    }
}
