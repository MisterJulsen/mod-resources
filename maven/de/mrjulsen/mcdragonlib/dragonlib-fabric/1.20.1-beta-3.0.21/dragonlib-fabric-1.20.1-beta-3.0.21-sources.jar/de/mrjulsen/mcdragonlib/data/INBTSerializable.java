package de.mrjulsen.mcdragonlib.data;

import net.minecraft.class_2487;

public interface INBTSerializable {
    class_2487 serializeNbt();
    void deserializeNbt(class_2487 nbt);
}
