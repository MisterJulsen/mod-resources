package de.mrjulsen.mcdragonlib.client.render;

import de.mrjulsen.mcdragonlib.client.util.DLGraphics;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1087;
import net.minecraft.class_1799;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_811;

public interface ICustomItemRenderer {
    @Environment(EnvType.CLIENT)
    void renderAdditional(DLGraphics graphics, class_1799 itemStack, class_811 context, boolean leftHand, class_4587 poseStack, class_4597 buffer, int combinedLight, int combinedOverlay, class_1087 model);
}
