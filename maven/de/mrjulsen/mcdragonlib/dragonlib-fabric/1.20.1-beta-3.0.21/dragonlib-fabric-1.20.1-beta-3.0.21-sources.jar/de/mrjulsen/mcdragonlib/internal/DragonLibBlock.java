package de.mrjulsen.mcdragonlib.internal;

import de.mrjulsen.mcdragonlib.client.DLOverlayManager;
import de.mrjulsen.mcdragonlib.client.gui.widgets.base.DLWindow;
import de.mrjulsen.mcdragonlib.data.DLStatus;
import de.mrjulsen.mcdragonlib.menu.PlayerInventoryContainerMenu;
import de.mrjulsen.mcdragonlib.network.NetworkDirection;
import de.mrjulsen.mcdragonlib.util.TextUtils;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1814;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2464;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3908;
import net.minecraft.class_3914;
import net.minecraft.class_3965;
import net.minecraft.class_4970;
import net.minecraft.class_747;

public class DragonLibBlock extends class_2237 {

    public DragonLibBlock(class_4970.class_2251 properties) {
        super(properties);
    }

    public static class DragonLibItem extends class_1747 {
        public DragonLibItem(class_2248 pBlock, class_1793 pProperties) {
            super(pBlock, pProperties.method_7894(class_1814.field_8904));            
        }
    }

    @Override
    public class_2586 method_10123(class_2338 arg0, class_2680 arg1) {
        return new DragonLibBlockEntity(arg0, arg1);
    }
    
    @Override
    public class_2464 method_9604(class_2680 pState) {
        return class_2464.field_11458;
    }

    

    public class_1269 method_9534(class_2680 pState, class_1937 pLevel, class_2338 pPos, class_1657 pPlayer, class_1268 pHand, class_3965 pHit) {
        if (pLevel.field_9236) {
            //DLWindow.openWindow(mgr -> new DLTestWindow(mgr));
            DLOverlayManager.addOverlay(mgr -> new TimeWindow(mgr));
            return class_1269.field_5812;
        } else {

            //pPlayer.openMenu(pState.getMenuProvider(pLevel, pPos));
            return class_1269.field_21466;
        }
    }

    public class_3908 method_17454(class_2680 pState, class_1937 pLevel, class_2338 pPos) {
        return new class_747((containerId, inv, player) -> {
            return new PlayerInventoryContainerMenu.Base(containerId, inv, class_3914.method_17392(pLevel, pPos));
        }, TextUtils.text(""));
    }
    
}