package de.mrjulsen.mcdragonlib.mixin;

import net.minecraft.class_5225;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_5225.class)
public interface StringSplitterAccessor {

    @Accessor("widthProvider")
    class_5225.class_5231 dragonlib$getWidthProvider();
}
