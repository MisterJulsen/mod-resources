package de.mrjulsen.mcdragonlib.client.ber;

import de.mrjulsen.mcdragonlib.client.util.DLGraphics;
import net.minecraft.class_1921;
import net.minecraft.class_2586;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_5614;

public class BERGraphics<B extends class_2586> extends DLGraphics { 
    
    protected final B blockEntity;
    protected final class_5614.class_5615 berProviderContext;

    public BERGraphics(B blockEntity, class_4587 poseStack, class_4597 multiBufferSource, class_5614.class_5615 berProviderContext, int packedLight, int packedOverlay, float partialTick) {
        super(poseStack, multiBufferSource, packedLight, packedOverlay, partialTick);
        this.blockEntity = blockEntity;
        this.berProviderContext = berProviderContext;
    }
    
    public B blockEntity() {
        return blockEntity;
    }

    public class_5614.class_5615 BERProviderContext() {
        return berProviderContext;
    }

    public class_4588 vertexConsumer(class_2960 textureLocation) {
        return multiBufferSource.getBuffer(class_1921.method_23028(textureLocation));
    }
}
