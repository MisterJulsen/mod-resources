package de.mrjulsen.mcdragonlib.mixin;

import de.mrjulsen.mcdragonlib.item.IItemExtension;
import net.minecraft.class_1792;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_1792.class)
public class ItemMixin implements IItemExtension {
}

