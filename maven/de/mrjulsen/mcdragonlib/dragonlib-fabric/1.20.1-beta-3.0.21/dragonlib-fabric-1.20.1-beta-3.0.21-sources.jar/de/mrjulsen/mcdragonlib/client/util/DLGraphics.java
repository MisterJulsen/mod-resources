package de.mrjulsen.mcdragonlib.client.util;

import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;

public class DLGraphics { 

    protected final class_4587 poseStack;
    protected final class_4597 multiBufferSource;
    protected final int packedLight;
    protected final int packedOverlay;
    protected final float partialTick;

    public DLGraphics(class_4587 poseStack, class_4597 multiBufferSource, int packedLight, int packedOverlay, float partialTick) {
        this.poseStack = poseStack;
        this.multiBufferSource = multiBufferSource;
        this.packedLight = packedLight;
        this.packedOverlay = packedOverlay;
        this.partialTick = partialTick;
    }

    public class_4587 poseStack() {
        return poseStack;
    }

    public class_4597 multiBufferSource() {
        return multiBufferSource;
    }

    public int packedLight() {
        return packedLight;
    }

    public int packedOverlay() {
        return packedOverlay;
    }

    public float partialTick() {
        return partialTick;
    }

    public class_4588 vertexConsumer(class_2960 textureLocation) {
        return multiBufferSource.getBuffer(class_1921.method_23028(textureLocation));
    }
}
