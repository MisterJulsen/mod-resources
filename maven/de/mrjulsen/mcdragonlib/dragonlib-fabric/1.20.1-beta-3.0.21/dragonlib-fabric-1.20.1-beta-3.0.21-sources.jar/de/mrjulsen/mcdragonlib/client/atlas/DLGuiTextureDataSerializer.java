package de.mrjulsen.mcdragonlib.client.atlas;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_3270;
import net.minecraft.class_3518;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import de.mrjulsen.mcdragonlib.client.atlas.DLTextureSheetData.AbstractSprite;
import de.mrjulsen.mcdragonlib.client.gui.widgets.util.ScaleType;

public class DLGuiTextureDataSerializer implements class_3270<DLTextureSheetData> {
	@Override
	public DLTextureSheetData method_14421(JsonObject json) {
		Map<String, DLTextureSheetData.AbstractSprite> result = new HashMap<>();
		
		JsonArray textureSizeJson = class_3518.method_15261(json, "texture_size");
		int[] textureSize = new int[2];
		for (int i = 0; i < textureSize.length; i++) {
			textureSize[i] = class_3518.method_15257(textureSizeJson.get(i), "texture_size[" + i + "]");
		}

		JsonObject sprites = class_3518.method_15296(json, "sprites");
		for (Map.Entry<String, JsonElement> entry : sprites.entrySet()) {
			String key = entry.getKey();
			JsonObject innerObject = class_3518.method_15295(entry.getValue(), key);

			String typeString = class_3518.method_15265(innerObject, "type");
			ScaleType type = ScaleType.getByName(typeString);
			
			AbstractSprite sprite = DLTextureSheetData.EMPTY_SPRITE;
			switch (type) {
				case STRETCH -> {
					JsonArray uvArrayJson = class_3518.method_15292(innerObject, "uv", new JsonArray(2));
					int[] uvArray = new int[2];
					for (int i = 0; i < uvArray.length; i++) {
						uvArray[i] = class_3518.method_15257(uvArrayJson.get(i), "uv[" + i + "]");
					}

					JsonArray sizeArrayJson = class_3518.method_15292(innerObject, "size", new JsonArray(2));
					int[] sizeArray = new int[2];
					for (int i = 0; i < sizeArray.length; i++) {
						sizeArray[i] = class_3518.method_15257(sizeArrayJson.get(i), "size[" + i + "]");
					}
					sprite = new DLTextureSheetData.StretchedSprite(uvArray, sizeArray);
				}
				case TILE -> {
					JsonArray uvArrayJson = class_3518.method_15292(innerObject, "uv", new JsonArray(2));
					int[] uvArray = new int[2];
					for (int i = 0; i < uvArray.length; i++) {
						uvArray[i] = class_3518.method_15257(uvArrayJson.get(i), "uv[" + i + "]");
					}

					JsonArray sizeArrayJson = class_3518.method_15292(innerObject, "size", new JsonArray(2));
					int[] sizeArray = new int[2];
					for (int i = 0; i < sizeArray.length; i++) {
						sizeArray[i] = class_3518.method_15257(sizeArrayJson.get(i), "size[" + i + "]");
					}
					sprite = new DLTextureSheetData.TiledSprite(uvArray, sizeArray);
				}
				case NINE_SLICE -> {
					JsonArray uvArrayJson = class_3518.method_15292(innerObject, "uv", new JsonArray(2));
					int[] uvArray = new int[2];
					for (int i = 0; i < uvArray.length; i++) {
						uvArray[i] = class_3518.method_15257(uvArrayJson.get(i), "uv[" + i + "]");
					}

					JsonArray sizeArrayJson = class_3518.method_15292(innerObject, "size", new JsonArray(2));
					int[] sizeArray = new int[2];
					for (int i = 0; i < sizeArray.length; i++) {
						sizeArray[i] = class_3518.method_15257(sizeArrayJson.get(i), "size[" + i + "]");
					}

					JsonArray borderArrayJson = class_3518.method_15292(innerObject, "border", new JsonArray(4));
					int[] borderArray = new int[4];
					for (int i = 0; i < borderArray.length; i++) {
						borderArray[i] = class_3518.method_15257(borderArrayJson.get(i), "border[" + i + "]");
					}
					
					boolean tiledContent = class_3518.method_15258(innerObject, "tiled_content", false);
					boolean tiledBorder = class_3518.method_15258(innerObject, "tiled_border", false);
					sprite = new DLTextureSheetData.NineSlicedSprite(uvArray, sizeArray, borderArray, tiledBorder, tiledContent);
				}
			};
			result.put(key, sprite);
		}
		return new DLTextureSheetData(result, textureSize);
	}

	@Override
	public String method_14420() {
		return "dragonlib-gui";
	}
}
