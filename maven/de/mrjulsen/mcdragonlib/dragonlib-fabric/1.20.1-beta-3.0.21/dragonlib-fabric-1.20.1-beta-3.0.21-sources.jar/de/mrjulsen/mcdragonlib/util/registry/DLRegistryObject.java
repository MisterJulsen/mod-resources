package de.mrjulsen.mcdragonlib.util.registry;

import java.util.function.Function;
import java.util.function.Supplier;
import net.minecraft.class_2487;
import net.minecraft.class_2960;
import de.mrjulsen.mcdragonlib.data.INBTSerializable;

public final record DLRegistryObject<T extends INBTSerializable>(class_2960 id, Supplier<T> factory) {

    public static final String NBT_ID = "Id";
    public static final String NBT_DATA = "Content";

    public class_2487 wrap(T data) {
        class_2487 tag = new class_2487();
        tag.method_10582(NBT_ID, id.toString());
        class_2487 metaData = data.serializeNbt();
        if (metaData != null && !metaData.method_33133()) tag.method_10566(NBT_DATA, metaData);
        return tag;
    }

    public T unwrap(class_2487 tag) {
        T instance = create();
        instance.deserializeNbt(tag.method_10545(NBT_DATA) ? tag.method_10562(NBT_DATA) : new class_2487());
        return instance;
    }
    
    public static <T extends INBTSerializable> T load(class_2487 tag, Function<class_2960, DLRegistryObject<T>> registryGetter) {
        class_2960 typeId = new class_2960(tag.method_10558(NBT_ID));
        DLRegistryObject<T> type = registryGetter.apply(typeId);
        if (type == null) return null;
        return type.unwrap(tag);
    }

    public T create() {
        return factory.get();
    }
}

