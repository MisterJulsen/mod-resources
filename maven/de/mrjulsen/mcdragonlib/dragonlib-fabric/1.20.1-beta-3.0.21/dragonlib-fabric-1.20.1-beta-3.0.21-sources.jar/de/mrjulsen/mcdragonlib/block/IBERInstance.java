package de.mrjulsen.mcdragonlib.block;

import de.mrjulsen.mcdragonlib.client.ber.IBlockEntityRendererInstance;
import net.minecraft.class_2586;

public interface IBERInstance<T extends class_2586> {
    IBlockEntityRendererInstance<T> getRenderer();
}
