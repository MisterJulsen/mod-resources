package de.mrjulsen.mcdragonlib.client.render;

import java.io.IOException;
import java.util.function.Supplier;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import com.google.common.base.Suppliers;

import de.mrjulsen.mcdragonlib.DragonLib;
import de.mrjulsen.mcdragonlib.client.atlas.DLTextureSheetData;
import de.mrjulsen.mcdragonlib.client.atlas.DLTextureSheetData.AbstractSprite;

public class DLTextureSheet {

    public static final DLTextureSheet VANILLA_BUTTON = new DLTextureSheet(new class_2960(DragonLib.MODID, "textures/gui/vanilla_buttons.png"));
    public static final DLTextureSheet DRAGONLIB_UI = new DLTextureSheet(new class_2960(DragonLib.MODID, "textures/gui/ui2.png"));
    public static final DLTextureSheet VANILLA_TEXTBOX = new DLTextureSheet(new class_2960(DragonLib.MODID, "textures/gui/vanilla_textbox.png"));
    public static final DLTextureSheet VANILLA_SCROLLBAR = new DLTextureSheet(new class_2960(DragonLib.MODID, "textures/gui/vanilla_scrollbar.png"));

    public static final String SPRITE_NAME_WINDOW_ROUNDED = "window_rounded";
    
    private final class_2960 location;
    private final Supplier<DLTextureSheetData> metadata = Suppliers.memoize(() -> {
        return class_310.method_1551().method_1478().method_14486(location())
            .map(r -> {
                try {
                    return r.method_14481().method_43041(DLTextureSheetData.SERIALIZER).map(t -> {
                        t.setTextureLocation(location());
                        return t;
                    }).orElse(DLTextureSheetData.EMPTY);
                } catch (IOException e) {
                    return DLTextureSheetData.EMPTY;
                }
            })
            .orElse(DLTextureSheetData.EMPTY);
    });

    public DLTextureSheet(class_2960 location) {
        this.location = location;
    }

    public class_2960 location() {
        return location;
    }

    public DLTextureSheetData metadata() {
        return metadata.get();
    }

    public AbstractSprite getSprite(String spriteName) {
        return metadata().getSprite(spriteName);
    } 
}
