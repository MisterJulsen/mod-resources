package de.mrjulsen.mcdragonlib.network;

import dev.architectury.utils.Env;
import java.util.function.Supplier;
import net.minecraft.class_1657;
import net.minecraft.class_3222;

public interface NetworkPacketContext {
    class_1657 getPlayer();    
    void queue(Runnable runnable);    
    <O> O queueResult(Supplier<O> runnable);
    Env getEnvironment();

    default NetworkDirection buildDirection() {
        return getEnvironment() == Env.CLIENT ? NetworkDirection.toServer() : NetworkDirection.toPlayer((class_3222)getPlayer());
    }
}