package de.mrjulsen.mcdragonlib.client.ber;

import de.mrjulsen.mcdragonlib.block.IBERInstance;
import de.mrjulsen.mcdragonlib.client.util.RenderUtils;
import net.minecraft.class_2586;
import net.minecraft.class_5614;

public class StaticBlockEntityRenderer<T extends class_2586 & IBERInstance<T>> extends RotatableBlockEntityRenderer<T> {


    public StaticBlockEntityRenderer(class_5614.class_5615 context) {
        super(context);
    }

    @Override
    protected void renderBlock(BERGraphics<T> graphics, float partialTick) {
        RenderUtils.initRenderEngine();
        graphics.blockEntity().getRenderer().render(graphics, partialTick);
    }

}
