package de.mrjulsen.mcdragonlib.network.builtin;

import de.mrjulsen.mcdragonlib.block.DLWritableSignBlockEntity;
import de.mrjulsen.mcdragonlib.data.DLStatus;
import de.mrjulsen.mcdragonlib.network.NetworkPacketContext;
import de.mrjulsen.mcdragonlib.network.NetworkPacketData;
import de.mrjulsen.mcdragonlib.util.NbtUtils;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2520;
import net.minecraft.class_3222;

public class WritableSignPacketData extends NetworkPacketData {

    private static final String NBT_POS = "Pos";
    private static final String NBT_MESSAGES = "Messages";

    private String[] messages;
    private class_2338 pos;

    public WritableSignPacketData(DLStatus status) {
        super(status);
    }

    public WritableSignPacketData(class_2338 pos, String[] messages) {
        super(DLStatus.OK);
        this.pos = pos;
        this.messages = messages;
    }
    

    @Override
    protected void write(class_2487 nbt) {
        NbtUtils.putNbtPos(nbt, NBT_POS, pos);
        class_2499 msgs = new class_2499();
        for (String msg : messages) {
            msgs.add(class_2519.method_23256(msg));
        }
        nbt.method_10566(NBT_MESSAGES, msgs);
    }

    @Override
    protected void read(class_2487 nbt) {
        this.pos = NbtUtils.getNbtBlockPos(nbt, NBT_POS);
        this.messages = nbt.method_10554(NBT_MESSAGES, class_2520.field_33258).stream().map(x -> ((class_2519)x).method_10714()).toArray(String[]::new);
    }

    public static void handler(WritableSignPacketData packet, NetworkPacketContext context) {
        context.queue(() -> {
            class_3222 sender = (class_3222)context.getPlayer();
            if (sender.method_37908().method_8321(packet.pos) instanceof DLWritableSignBlockEntity blockEntity) {
                blockEntity.setTexts(packet.messages);
            }
        });
    }
}

