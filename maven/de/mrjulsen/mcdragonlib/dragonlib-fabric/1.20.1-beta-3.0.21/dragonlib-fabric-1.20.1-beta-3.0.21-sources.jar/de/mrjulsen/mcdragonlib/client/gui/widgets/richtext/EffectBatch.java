package de.mrjulsen.mcdragonlib.client.gui.widgets.richtext;

import com.google.common.collect.Lists;
import java.util.List;
import net.minecraft.class_382;

public class EffectBatch {
    private final List<class_382.class_328> effects;
    private final float x;
    private final float y;
    private final float scale;

    public EffectBatch(float x, float y, float scale) {
        this.effects = Lists.newLinkedList();
        this.x = x;
        this.y = y;
        this.scale = scale;
    }

    public void addEffectToBatch(class_382.class_328 effect) {
        this.effects.add(effect);
    }

    public List<class_382.class_328> getEffects() {
        return effects;
    }

    public boolean isEmpty() {
        return effects.isEmpty();
    }

    public float x() {
        return x;
    }

    public float y() {
        return y;
    }

    public float scale() {
        return scale;
    }
}
