package de.mrjulsen.mcdragonlib.client.model.extension;

import dev.architectury.injectables.annotations.ExpectPlatform;
import java.util.List;
import net.minecraft.class_1058;
import net.minecraft.class_2350;
import net.minecraft.class_777;

public abstract class DLBakedQuad extends class_777 {

    protected final boolean ambientOcclusion;
    protected final boolean emissive;
    protected final List<String> tags;

    protected DLBakedQuad(class_777 quad, boolean ambientOcclusion, boolean emissive, List<String> tags) {
        this(quad.method_3357(), quad.method_3359(), quad.method_3358(), quad.method_35788(), quad.method_24874(), ambientOcclusion, emissive, tags);
    }

    protected DLBakedQuad(int[] vertices, int tintIndex, class_2350 direction, class_1058 sprite, boolean shade, boolean ambientOcclusion, boolean emissive, List<String> tags) {
        super(vertices, tintIndex, direction, sprite, shade);
        this.ambientOcclusion = ambientOcclusion;
        this.emissive = emissive;
        this.tags = tags;
    }

    public boolean isAmbientOcclusion() {
        return ambientOcclusion;
    }

    public boolean isEmissive() {
        return emissive;
    }

    public List<String> getTags() {
        return tags;
    }

    public static DLBakedQuad create(class_777 quad, DLFaceData data) {
        return create(quad.method_3357(), quad.method_3359(), quad.method_3358(), quad.method_35788(), quad.method_24874(), data.ambientOcclusion(), data.emissive(), data.tags());
    }

    @ExpectPlatform
    public static DLBakedQuad create(int[] vertices, int tintIndex, class_2350 direction, class_1058 sprite, boolean shade, boolean ambientOcclusion, boolean emissive, List<String> tags) {
        throw new AssertionError();
    }
}
