package de.mrjulsen.mcdragonlib.commands;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import de.mrjulsen.mcdragonlib.DragonLib;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2170.class_5364;

public class DebugCommand {

    private static final String CMD_NAME = DragonLib.MODID;
    
    private static final String SUB_DEBUG = "debug";
    private static final String SUB_NETWORK = "network";
    
    @SuppressWarnings("all")
    public static void register(CommandDispatcher<class_2168> dispatcher, class_5364 selection) {        
        
        LiteralArgumentBuilder<class_2168> builder = class_2170.method_9247(CMD_NAME)
            .then(class_2170.method_9247(SUB_DEBUG)
                .requires(x -> x.method_9259(4))
                .then(class_2170.method_9247(SUB_NETWORK)
                )
            )
        ;

        dispatcher.register(builder);
    }
}