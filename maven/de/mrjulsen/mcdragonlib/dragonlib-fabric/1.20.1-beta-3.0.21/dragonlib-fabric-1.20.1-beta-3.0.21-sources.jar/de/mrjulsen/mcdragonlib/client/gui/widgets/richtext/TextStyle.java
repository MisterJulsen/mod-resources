package de.mrjulsen.mcdragonlib.client.gui.widgets.richtext;

import net.minecraft.class_2487;
import net.minecraft.class_2583;
import net.minecraft.class_310;
import net.minecraft.class_327;

public record TextStyle(
        class_327 font,
        boolean bold,
        boolean italic,
        boolean underlined,
        boolean strikethrough,
        boolean obfuscated,
        int color,
        boolean dropShadow,
        float scale,
        int highlightColor
) {
    public static final TextStyle EMPTY = new Builder().build();

    public static final TextStyle URL_STYLE = new Builder().color(0xFF5555FF).underlined(true).build();

    private static final String NBT_BOLD = "bold";
    private static final String NBT_ITALIC = "italic";
    private static final String NBT_UNDERLINED = "underlined";
    private static final String NBT_STRIKETHROUGH = "strikethrough";
    private static final String NBT_OBFUSCATED = "obfuscated";
    private static final String NBT_COLOR = "color";
    private static final String NBT_SHADOW = "shadow";
    private static final String NBT_SCALE = "scale";
    private static final String NBT_HIGHLIGHT_COLOR = "highlight_color";

    public TextStyle copy() {
        return new TextStyle(
                font,
                bold,
                italic,
                underlined,
                strikethrough,
                obfuscated,
                color,
                dropShadow,
                scale,
                highlightColor
        );
    }

    public class_2487 toNbt() {
        class_2487 nbt = new class_2487();
        nbt.method_10556(NBT_BOLD, bold);
        nbt.method_10556(NBT_ITALIC, italic);
        nbt.method_10556(NBT_UNDERLINED, underlined);
        nbt.method_10556(NBT_STRIKETHROUGH, strikethrough);
        nbt.method_10556(NBT_OBFUSCATED, obfuscated);
        nbt.method_10569(NBT_COLOR, color);
        nbt.method_10556(NBT_SHADOW, dropShadow);
        nbt.method_10548(NBT_SCALE, scale);
        nbt.method_10569(NBT_HIGHLIGHT_COLOR, highlightColor);
        return nbt;
    }

    public static TextStyle fromNbt(class_2487 nbt) {
        return new Builder()
                .bold(nbt.method_10577(NBT_BOLD))
                .italic(nbt.method_10577(NBT_ITALIC))
                .underlined(nbt.method_10577(NBT_UNDERLINED))
                .strikethrough(nbt.method_10577(NBT_STRIKETHROUGH))
                .obfuscated(nbt.method_10577(NBT_OBFUSCATED))
                .shadow(nbt.method_10577(NBT_SHADOW))
                .color(nbt.method_10550(NBT_COLOR))
                .size((int)(class_310.method_1551().field_1772.field_2000 * nbt.method_10583(NBT_SCALE)))
                .highlightColor(nbt.method_10550(NBT_HIGHLIGHT_COLOR))
                .build();
    }

    public class_2583 toStyle() {
        return class_2583.field_24360
                .method_10982(bold)
                .method_10978(italic)
                .method_30938(underlined)
                .method_36140(strikethrough)
                .method_36141(obfuscated)
                .method_36139(color)
            ;
    }

    public static TextStyle fromStyle(class_2583 style) {
        return new Builder()
            .bold(style.method_10984())
            .italic(style.method_10966())
            .underlined(style.method_10965())
            .obfuscated(style.method_10987())
            .strikethrough(style.method_10986())
            .color(style.method_10973().method_27716())
            .build();
    }

    public static class Builder {
        private class_327 font = class_310.method_1551().field_1772;
        private boolean bold;
        private boolean italic;
        private boolean underlined;
        private boolean strikethrough;
        private boolean obfuscated;
        private int color = 0xFFFFFFFF;
        private boolean dropShadow;
        private int size = class_310.method_1551().field_1772.field_2000;
        private int highlightColor = 0;

        public Builder font(class_327 font) {
            this.font = font;
            return this;
        }
        public Builder bold(boolean b) {
            this.bold = b;
            return this;
        }
        public Builder italic(boolean b) {
            this.italic = b;
            return this;
        }
        public Builder strikethrough(boolean b) {
            this.strikethrough = b;
            return this;
        }
        public Builder underlined(boolean b) {
            this.underlined = b;
            return this;
        }
        public Builder obfuscated(boolean b) {
            this.obfuscated = b;
            return this;
        }
        public Builder color(int color) {
            this.color = color;
            return this;
        }
        public Builder shadow(boolean b) {
            this.dropShadow = b;
            return this;
        }
        public Builder size(int size) {
            this.size = size;
            return this;
        }

        public Builder highlightColor(int highlightColor) {
            this.highlightColor = highlightColor;
            return this;
        }

        public TextStyle build() {
            return new TextStyle(
                    font,
                    bold,
                    italic,
                    underlined,
                    strikethrough,
                    obfuscated,
                    color,
                    dropShadow,
                    (float)size / font.field_2000,
                    highlightColor
            );
        }
    }
}
