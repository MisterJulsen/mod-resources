package de.mrjulsen.mcdragonlib.fabric.client.model.geometry.mixin.client;

import java.lang.reflect.Type;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import net.minecraft.class_2960;
import net.minecraft.class_3518;
import net.minecraft.class_4590;
import net.minecraft.class_785;
import net.minecraft.class_793;
import com.google.gson.JsonParseException;
import de.mrjulsen.mcdragonlib.DragonLib;
import de.mrjulsen.mcdragonlib.fabric.client.model.geometry.GeometryLoaderManager;
import de.mrjulsen.mcdragonlib.fabric.client.model.geometry.IGeometryLoader;
import de.mrjulsen.mcdragonlib.fabric.client.model.geometry.IUnbakedGeometry;
import de.mrjulsen.mcdragonlib.fabric.client.model.geometry.extensions.BlockModelExtensions;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

@Mixin(class_793.class_795.class)
public abstract class BlockModelDeserializerMixin {

	@Inject(method = "deserialize(Lcom/google/gson/JsonElement;Ljava/lang/reflect/Type;Lcom/google/gson/JsonDeserializationContext;)Lnet/minecraft/client/renderer/block/model/BlockModel;", at = @At("RETURN"), cancellable = true)
	public void modelLoading(JsonElement element, Type type, JsonDeserializationContext deserializationContext, CallbackInfoReturnable<class_793> cir) {
		class_793 model = cir.getReturnValue();
		JsonObject jsonobject = element.getAsJsonObject();
		IUnbakedGeometry<?> geometry = deserializeGeometry(deserializationContext, jsonobject);

		List<class_785> elements = model.method_3433();
		if (geometry != null) {
			elements.clear();
			((BlockModelExtensions)model).dragonlib$setCustomGeometry(geometry);
		}

		if (jsonobject.has("transform")) {
			JsonObject transform = class_3518.method_15296(jsonobject, "transform");
			((BlockModelExtensions)model).dragonlib$setRootTransform(deserializationContext.deserialize(transform, class_4590.class));
		}

		if (jsonobject.has("visibility")) {
			JsonObject visibility = class_3518.method_15296(jsonobject, "visibility");
			for (Map.Entry<String, JsonElement> part : visibility.entrySet()) {
				((BlockModelExtensions)model).dragonlib$getVisibilityData().setVisibilityState(part.getKey(), part.getValue().getAsBoolean());
			}
		}

	}

	@Unique
	@Nullable
	private static IUnbakedGeometry<?> deserializeGeometry(JsonDeserializationContext deserializationContext, JsonObject object) throws JsonParseException {
		String loaderId = GeometryLoaderManager.getModelLoader(object);
		if (loaderId == null)
			return null;

		class_2960 name = new class_2960(loaderId);
		IGeometryLoader<?> loader = GeometryLoaderManager.get(name);
		if (loader == null) {
			if (!GeometryLoaderManager.KNOWN_MISSING_LOADERS.contains(name)) {
				GeometryLoaderManager.KNOWN_MISSING_LOADERS.add(name);
				DragonLib.LOGGER.warn(String.format(Locale.ENGLISH, "Model loader '%s' not found. Registered loaders: %s", name, GeometryLoaderManager.getLoaderList()));
				DragonLib.LOGGER.warn("Falling back to vanilla logic.");
			}
			return null;
		}

		return loader.read(object, deserializationContext);
	}
}
