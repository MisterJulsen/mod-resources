package de.mrjulsen.mcdragonlib.client.ber;

import net.minecraft.class_2246;
import net.minecraft.class_2586;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5614;
import net.minecraft.class_827;

public abstract class SafeBlockEntityRenderer<T extends class_2586> implements class_827<T> {

	private final class_5614.class_5615 context;

	public SafeBlockEntityRenderer(class_5614.class_5615 context) {
		this.context = context;
	}

	@Override
	public final void method_3569(T be, float partialTicks, class_4587 ms, class_4597 bufferSource, int light, int overlay) {
		if (isInvalid(be)) {
			return;
        }
		renderSafe(new BERGraphics<>(be, ms, bufferSource, context, light, overlay, partialTicks), partialTicks);
	}

	protected abstract void renderSafe(BERGraphics<T> graphics, float partialTicks);

	public boolean isInvalid(T be) {
		return !be.method_11002() || be.method_11010().method_26204() == class_2246.field_10124;
	}
}
