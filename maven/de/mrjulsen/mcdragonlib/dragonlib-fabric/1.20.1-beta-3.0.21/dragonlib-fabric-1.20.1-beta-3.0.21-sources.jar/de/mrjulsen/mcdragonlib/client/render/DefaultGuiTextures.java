package de.mrjulsen.mcdragonlib.client.render;

import java.io.IOException;
import java.util.function.Supplier;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import com.google.common.base.Suppliers;

import de.mrjulsen.mcdragonlib.DragonLib;
import de.mrjulsen.mcdragonlib.client.atlas.GLGuiTextureData;

@Deprecated(forRemoval = true)
public class DefaultGuiTextures {

    @Deprecated(forRemoval = true)
    public static final DefaultGuiTextures VANILLA_BUTTON = new DefaultGuiTextures(new class_2960(DragonLib.MODID, "textures/gui/vanilla_buttons.png"));
    @Deprecated(forRemoval = true)
    public static final DefaultGuiTextures DRAGONLIB_UI = new DefaultGuiTextures(new class_2960(DragonLib.MODID, "textures/gui/ui2.png"));
    @Deprecated(forRemoval = true)
    public static final DefaultGuiTextures VANILLA_TEXTBOX = new DefaultGuiTextures(new class_2960(DragonLib.MODID, "textures/gui/vanilla_textbox.png"));
    @Deprecated(forRemoval = true)
    public static final DefaultGuiTextures VANILLA_SCROLLBAR = new DefaultGuiTextures(new class_2960(DragonLib.MODID, "textures/gui/vanilla_scrollbar.png"));

    @Deprecated(forRemoval = true)
    public static final String SPRITE_NAME_WINDOW_ROUNDED = "window_rounded";
    
    private final class_2960 location;
    private final Supplier<GLGuiTextureData> metadata = Suppliers.memoize(() -> {
        return class_310.method_1551().method_1478().method_14486(location())
            .map(r -> {
                try {
                    return r.method_14481().method_43041(GLGuiTextureData.SERIALIZER).map(t -> {
                        t.setTextureLocation(location());
                        return t;
                    }).orElse(GLGuiTextureData.EMPTY);
                } catch (IOException e) {
                    return GLGuiTextureData.EMPTY;
                }
            })
            .orElse(GLGuiTextureData.EMPTY);
    });

    @Deprecated(forRemoval = true)
    public DefaultGuiTextures(class_2960 location) {
        this.location = location;
    }

    @Deprecated(forRemoval = true)
    public class_2960 location() {
        return location;
    }

    @Deprecated(forRemoval = true)
    public GLGuiTextureData metadata() {
        return metadata.get();
    }

    @Deprecated(forRemoval = true)
    public GLGuiTextureData.AbstractSprite getSprite(String spriteName) {
        return metadata().getSprite(spriteName);
    } 
}
