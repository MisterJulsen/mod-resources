package de.mrjulsen.mcdragonlib.client.ber;

import net.minecraft.class_2586;
import net.minecraft.class_327;
import net.minecraft.class_5614;

public abstract class BasicBlockEntityRenderer<T extends class_2586> extends SafeBlockEntityRenderer<T> {
    
    protected final class_327 font;

    public BasicBlockEntityRenderer(class_5614.class_5615 context) {
        super(context);
        this.font = context.method_32143();
    }

    @Override
    protected final void renderSafe(BERGraphics<T> graphics, float partialTick) {        
        graphics.poseStack().method_22903();
        graphics.poseStack().method_22904(0.5D, 0, 0.5F);
        graphics.poseStack().method_46416(-0.5f, 1, -0.5f);
        graphics.poseStack().method_22905(0.0625f, -0.0625f, 0.0625f);

        renderBlock(graphics, partialTick);

        graphics.poseStack().method_22909();
        
    }

    protected abstract void renderBlock(BERGraphics<T> graphics, float partialTick);
}
