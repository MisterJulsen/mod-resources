package de.mrjulsen.mcdragonlib.registry;

import dev.architectury.injectables.annotations.ExpectPlatform;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_5614;

public class DLClientRegistries {
    
    @ExpectPlatform
    public static <T extends class_2586> void register(class_2591<T> type, class_5614<? super T> provider) {
        throw new AssertionError();
    }
}
