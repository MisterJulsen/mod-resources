package de.mrjulsen.mcdragonlib.client.gui.widgets.base;

import net.minecraft.class_332;
import net.minecraft.class_4587;

public record Graphics(class_332 graphics, class_4587 poseStack, float partialTick) {}
