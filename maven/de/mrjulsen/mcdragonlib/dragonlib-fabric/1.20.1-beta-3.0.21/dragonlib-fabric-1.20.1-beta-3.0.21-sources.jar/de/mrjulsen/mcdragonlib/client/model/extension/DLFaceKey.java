package de.mrjulsen.mcdragonlib.client.model.extension;

import net.minecraft.class_2350;

public record DLFaceKey(int index, class_2350 direction) {
}
