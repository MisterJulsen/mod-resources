package de.mrjulsen.mcdragonlib.block;

import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;

public abstract class DLTickableBlockEntity<E extends DLTickableBlockEntity<E>> extends DLSyncedBlockEntity {

    protected DLTickableBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state) {
        super(type, pos, state);
    }    
    
    public static <T extends class_2586> void globalTick(class_1937 level, class_2338 pos, class_2680 state, T blockEntity) {
        if (blockEntity instanceof DLTickableBlockEntity<?> instance) {
            instance.tick(level, pos, state);
        }
    }

    public abstract void tick(class_1937 level, class_2338 pos, class_2680 state);
}
