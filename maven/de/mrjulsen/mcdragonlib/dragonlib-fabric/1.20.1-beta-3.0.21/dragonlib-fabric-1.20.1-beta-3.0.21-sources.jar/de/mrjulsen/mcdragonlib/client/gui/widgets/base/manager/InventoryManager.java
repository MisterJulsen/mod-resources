package de.mrjulsen.mcdragonlib.client.gui.widgets.base.manager;

import java.util.HashSet;
import java.util.Set;
import net.minecraft.class_124;
import net.minecraft.class_156;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_3532;
import de.mrjulsen.mcdragonlib.client.gui.container.DLSlot;
import de.mrjulsen.mcdragonlib.client.gui.widgets.base.DLWindowManager;
import de.mrjulsen.mcdragonlib.client.gui.widgets.base.IGuiManagementComponent;
import de.mrjulsen.mcdragonlib.client.gui.widgets.util.RenderLayer;
import de.mrjulsen.mcdragonlib.client.util.DLGuiGraphics;
import de.mrjulsen.mcdragonlib.client.util.GuiUtils;

public class InventoryManager implements IGuiManagementComponent {

    public final DLWindowManager windowManager;

    protected final Set<class_1735> quickCraftSlots = new HashSet<>();
    private boolean isQuickCrafting = false;
    private int quickCraftingButton = -1;
    private int quickCraftingType = -1;
    private int quickCraftingRemainder = 0;

    private DLSlot lastClickedSlot;
    private long lastClickedTime;
    private int lastClickedButton;
    private boolean doubleClick;

    private class_1799 quickMovedItem = class_1799.field_8037;
    private boolean skipNextRelease;

    private class_1799 draggingStack = class_1799.field_8037;
    private boolean isSplittingStack;
    private DLSlot clickedSlot;

    private DLSlot snapbackEnd;
    private int snapbackStartX;
    private int snapbackStartY;
    private long snapbackTime;
    private class_1799 snapbackItem = class_1799.field_8037;
    private class_1735 quickdropSlot;
    private long quickdropTime;


    public InventoryManager(DLWindowManager windowManager) {
        this.windowManager = windowManager;
    }

    @Override
    public int getPriority() {
        return 1;
    }

    public boolean isHoldingItem() {
        return lastClickedSlot == null ? false : !lastClickedSlot.menu.method_34255().method_7960();
    }

    public class_1799 getHoldingItem() {
        class_1799 ret = lastClickedSlot != null ? lastClickedSlot.menu.method_34255() : class_1799.field_8037;
        return ret;
    }

    public boolean isQuickCrafting() {
        return isQuickCrafting;
    }

    public void setQuickCrafting(boolean b, int button, int type) {
        setQuickCrafting(b);
        this.quickCraftingButton = button;
        this.quickCraftingType = type;
    }

    public void setQuickCrafting(boolean b) {
        this.isQuickCrafting = b;
        this.quickCraftSlots.clear();
    }

    public int getQuickCraftingButton() {
        return quickCraftingButton;
    }

    public int getQuickCraftingType() {
        return quickCraftingType;
    }

    public Set<class_1735> getQuickCraftingSlots() {
        return quickCraftSlots;
    }

    public class_1799 getQuickMovedItem() {
        return quickMovedItem;
    }

    public void setLastQuickMoved(class_1799 quickMovedItem) {
        this.quickMovedItem = quickMovedItem;
    }

    public void setQuickCraftingRemainder(int value) {
        this.quickCraftingRemainder = value;
    }

    public int getQuickCraftingRemainder() {
        return quickCraftingRemainder;
    }

    public void setSkipNextRelease(boolean b) {
        this.skipNextRelease = b;
    }

    public boolean shouldSkipNextRelease() {
        return skipNextRelease;
    }

    public void setLastClickedSlot(DLSlot slot) {
        this.lastClickedSlot = slot;
    }

    public void setLastClickTime(long time) {
        this.lastClickedTime = time;
    }

    public void setLastClickedButton(int button) {
        this.lastClickedButton = button;
    }

    public long getLastClickTime() {
        return lastClickedTime;
    }

    public int getLastClickButton() {
        return lastClickedButton;
    }

    public void setDoubleClick(boolean b) {
        this.doubleClick = b;
    }

    public boolean isDoubleClick() {
        return doubleClick;
    }

    public DLSlot getLastClickedSlot() {
        return lastClickedSlot;
    }

    public void setDraggingItem(class_1799 stack) {
        this.draggingStack = stack;
    }

    public class_1799 getDraggingItem() {
        return draggingStack;
    }

    public void setIsSplittingStack(boolean b) {
        this.isSplittingStack = b;
    }

    public boolean isSplittingStack() {
        return isSplittingStack;
    }

    public void setSelectedSlot(DLSlot slot) {
        this.clickedSlot = slot;
    }

    public DLSlot getSelectedSlot() {
        return clickedSlot;
    }

    public DLSlot getSnapbackEnd() {
        return snapbackEnd;
    }

    public void setSnapbackEnd(DLSlot snapbackEnd) {
        this.snapbackEnd = snapbackEnd;
    }

    public int getSnapbackStartX() {
        return snapbackStartX;
    }

    public void setSnapbackStartX(int snapbackStartX) {
        this.snapbackStartX = snapbackStartX;
    }

    public int getSnapbackStartY() {
        return snapbackStartY;
    }

    public void setSnapbackStartY(int snapbackStartY) {
        this.snapbackStartY = snapbackStartY;
    }

    public long getSnapbackTime() {
        return snapbackTime;
    }

    public void setSnapbackTime(long snapbackTime) {
        this.snapbackTime = snapbackTime;
    }

    public class_1799 getSnapbackItem() {
        return snapbackItem;
    }

    public void setSnapbackItem(class_1799 snapbackItem) {
        this.snapbackItem = snapbackItem;
    }

    public class_1735 getQuickdropSlot() {
        return quickdropSlot;
    }

    public void setQuickdropSlot(class_1735 quickdropSlot) {
        this.quickdropSlot = quickdropSlot;
    }

    public long getQuickdropTime() {
        return quickdropTime;
    }

    public void setQuickdropTime(long quickdropTime) {
        this.quickdropTime = quickdropTime;
    }


    /*
    protected void slotClicked(int slotId, int mouseButton, ClickType type) {
        Minecraft.getInstance().gameMode.handleInventoryMouseClick(windowManager.getMenu().containerId, slotId, mouseButton, type, Minecraft.getInstance().player);
    }

    @Override
    public boolean mouseClicked(Phase phase, boolean consumed, double mouseX, double mouseY, int button) {
        if (phase == Phase.POST && !consumed && isHoldingItem() && getLastClickedSlot() != null) {
            this.slotClicked(getLastClickedSlot().getSlot().index, button, ClickType.THROW);
            return true;
        }
        return false;
    }
        */

    @Override
    public void render(Phase phase, DLGuiGraphics graphics, int mouseX, int mouseY, RenderLayer layer) {
        if (phase != Phase.POST && layer != RenderLayer.FRONT) {
            return;
        }
        class_1799 itemStack = getDraggingItem().method_7960() ? getHoldingItem() : getDraggingItem();
        String string = null;

        if (!itemStack.method_7960()) {
            if (isQuickCrafting() && getQuickCraftingSlots().size() > 1) {
                itemStack = itemStack.method_46651(getQuickCraftingRemainder());
                if (itemStack.method_7960()) {
                    string = class_124.field_1054 + "0";
                }
            }
            
            else if (isSplittingStack() && !itemStack.method_7960()) {
                itemStack = itemStack.method_46651(class_3532.method_15386((float) itemStack.method_7947() / 2.0F));
            }

            graphics.poseStack().method_22903();
            graphics.poseStack().method_46416(0.0F, 0.0F, 232.0F);
            
            int itemX = mouseX - 8;
            int itemY = mouseY - 8;            
            if (!getDraggingItem().method_7960()) {
                itemY = mouseY - 16;
            }
            GuiUtils.renderItem(graphics, itemStack, itemX, itemY, 1, true);
            GuiUtils.renderItemDecoration(graphics, itemStack, itemX, itemY, 1, string);            
            
            graphics.poseStack().method_22909();
        }
        
        if (!this.snapbackItem.method_7960()) {
            float f = (float) (class_156.method_658() - this.snapbackTime) / 100.0F;
            if (f >= 1.0F) {
                f = 1.0F;
                this.snapbackItem = class_1799.field_8037;
            }
            
            int l = (int)(this.snapbackEnd.getXOnScreen() - this.snapbackStartX);
            int m = (int)(this.snapbackEnd.getYOnScreen() - this.snapbackStartY);
            int o = this.snapbackStartX + (int) ((float) l * f);
            int p = this.snapbackStartY + (int) ((float) m * f);
            this.renderFloatingItem(graphics, this.snapbackItem, o, p, (String) null);
        }
    }


    private void renderFloatingItem(DLGuiGraphics guiGraphics, class_1799 stack, int x, int y, String text) {
        guiGraphics.poseStack().method_22903();
        guiGraphics.poseStack().method_46416(0.0F, 0.0F, 232.0F);
        GuiUtils.renderItem(guiGraphics, stack, x, y, 1, false);
        guiGraphics.poseStack().method_22909();
    }


}