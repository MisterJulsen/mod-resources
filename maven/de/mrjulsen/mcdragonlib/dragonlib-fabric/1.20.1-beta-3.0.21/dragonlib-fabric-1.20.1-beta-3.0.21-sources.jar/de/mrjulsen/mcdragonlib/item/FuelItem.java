package de.mrjulsen.mcdragonlib.item;

import dev.architectury.registry.fuel.FuelRegistry;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_3956;

public class FuelItem extends class_1792 {

    private int burnTime = 0;

    public FuelItem(class_1793 properties) {
        super(properties);
    }
    
    public void setBurnTime(int burnTime) {
		FuelRegistry.register(burnTime, this);
		this.burnTime = burnTime;
	}

	public int getBurnTime(class_1799 itemStack, class_3956<?> recipeType) {
		return this.burnTime;
	}
    
}
