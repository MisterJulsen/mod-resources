package de.mrjulsen.mcdragonlib.client.ber;

import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_327;
import net.minecraft.class_5614;
import net.minecraft.class_7833;

public abstract class RotatableBlockEntityRenderer<T extends class_2586> extends SafeBlockEntityRenderer<T> {
    
    protected final class_327 font;

    public RotatableBlockEntityRenderer(class_5614.class_5615 context) {
        super(context);
        this.font = context.method_32143();
    }

    @Override
    protected final void renderSafe(BERGraphics<T> graphics, float partialTick) {
        class_2680 blockState = graphics.blockEntity().method_11010();
        
        graphics.poseStack().method_22903();
        graphics.poseStack().method_22904(0.5D, 0, 0.5F);
        graphics.poseStack().method_22907(class_7833.field_40716.rotationDegrees(
            blockState.method_11654(class_2383.field_11177) == class_2350.field_11034 || blockState.method_11654(class_2383.field_11177) == class_2350.field_11039
                ? blockState.method_11654(class_2383.field_11177).method_10153().method_10144()
                : blockState.method_11654(class_2383.field_11177).method_10144()
        ));
        graphics.poseStack().method_46416(-0.5f, 1, -0.5f);
        graphics.poseStack().method_22905(0.0625f, -0.0625f, 0.0625f);

        renderBlock(graphics, partialTick);

        graphics.poseStack().method_22909();
        
    }

    protected abstract void renderBlock(BERGraphics<T> graphics, float partialTick);
}
