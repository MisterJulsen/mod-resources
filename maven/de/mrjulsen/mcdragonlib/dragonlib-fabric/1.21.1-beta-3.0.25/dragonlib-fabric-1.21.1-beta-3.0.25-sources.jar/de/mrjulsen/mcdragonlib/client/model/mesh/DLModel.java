package de.mrjulsen.mcdragonlib.client.model.mesh;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import net.minecraft.class_1087;
import net.minecraft.class_1921;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_5819;
import net.minecraft.class_777;
import org.jetbrains.annotations.Nullable;

import com.google.common.collect.ListMultimap;
import com.google.common.collect.MultimapBuilder.ListMultimapBuilder;
import de.mrjulsen.mcdragonlib.client.model.DLBlockModelRegistry;
import de.mrjulsen.mcdragonlib.client.model.IDynamicBakedModel;
import de.mrjulsen.mcdragonlib.client.model.ModelCacheKey;
import de.mrjulsen.mcdragonlib.client.model.ModelContext;
import de.mrjulsen.mcdragonlib.util.Cache;
import de.mrjulsen.mcdragonlib.util.DLColor;

public abstract class DLModel {

    public static enum ModelType {
        BLOCK(false),
        ITEM(true);

        final boolean isItem;

        private ModelType(boolean b) {
            this.isItem = b;
        }

        public static ModelType isItem(boolean b) {
            return b ? ITEM : BLOCK;
        }
    }

    private final Map<ModelCacheKey, Map<DirectionKey, ListMultimap<class_1921, class_777>>> cachedBlockQuads = Collections.synchronizedMap(new HashMap<>());

    /**
     * Creates the key for the cache of this model. This method is not called for item models.
     * @param state
     * @param random
     * @param contex
     * @return
     */
    protected ModelCacheKey createCacheKey(class_2680 state, class_5819 random, ModelContext contex) {
        return new ModelCacheKey(contex, state);
    }

    protected boolean invalidateCacheFor(ModelType type, class_2680 state, class_5819 random, ModelContext context) {
        return false;
    }

    /**
     * Enabled or disables ambient occlusion for this model.
     * 
     * @return {@code true} if ambient occlusion should be used, {@code false}
     *         otherwise. If the model's default behaviour should be kept, return
     *         {@code null}.
     */
    public @Nullable Boolean useAmbientOcclusion() {
        return null;
    }

    protected abstract Mesh getMesh(ModelType type, class_1087 originalModel, class_2680 state, class_5819 random, ModelContext context);

    private final Cache<List<class_1921>> renderTypesCache = new Cache<>(() -> {
        Set<class_1921> types = new HashSet<>(class_1921.method_22720().size());
        for (Map<DirectionKey, ListMultimap<class_1921, class_777>> m : cachedBlockQuads.values()) {
            for (ListMultimap<class_1921, class_777> k : m.values()) {
                for (class_1921 t : k.keySet()) {
                    types.add(t);
                }
            }
        }
        return new ArrayList<>(types);
    });
    

    private static class DirectionKey {
        private static final HashMap<class_2350, DirectionKey> keys;
        static {
            keys = new HashMap<>(class_2350.values().length + 1);
            for (class_2350 dir : class_2350.values()) {
                keys.put(dir, new DirectionKey());
            }
            keys.put(null, new DirectionKey());
        }

        private DirectionKey() {
        }

        public static DirectionKey of(class_2350 direction) {
            return keys.get(direction);
        }
    }

    public final List<class_777> getQuads(ModelType type, class_1087 originalModel, class_2680 state, class_5819 random, class_1921 renderType, class_2350 cullface, ModelContext context) {
        boolean isItem = type == ModelType.ITEM;
        ModelCacheKey key = !isItem ? createCacheKey(state, random, context) : new ModelCacheKey(context);

        if (invalidateCacheFor(type, state, random, context) && cachedBlockQuads.containsKey(key)) {
            cachedBlockQuads.remove(key);
        }

        Map<DirectionKey, ListMultimap<class_1921, class_777>> quadsByCullface = cachedBlockQuads.computeIfAbsent(key,
            c -> {
                boolean clearRenderTypeCache = false;
                Mesh mesh = getMesh(type, originalModel, state, random, c.context());

                Map<DirectionKey, ListMultimap<class_1921, class_777>> map = new HashMap<>(6);
                for (Face face : mesh.getFaces()) {
                    DirectionKey cullfaceKey = DirectionKey.of(face.getCullface());
                    ListMultimap<class_1921, class_777> mm = map.computeIfAbsent(cullfaceKey,
                            x -> ListMultimapBuilder.hashKeys(class_1921.method_22720().size())
                                    .arrayListValues().build());
                    if (!clearRenderTypeCache && !mm.containsKey(face.getRenderType())) {
                        clearRenderTypeCache = true;
                    }
                    mm.putAll(face.getRenderType(), face.build());
                }

                if (clearRenderTypeCache)
                    clearCaches();
                return map;
            });

        DirectionKey requestedCullfaceKey = DirectionKey.of(cullface);
        if (!quadsByCullface.containsKey(requestedCullfaceKey)) {
            return List.of();
        }

        ListMultimap<class_1921, class_777> quadsByRenderType = quadsByCullface.get(requestedCullfaceKey);
        if (isItem) {
            return new ArrayList<>(quadsByRenderType.values());
        }

        if (!quadsByRenderType.containsKey(renderType)) {
            return List.of();
        }
        return quadsByRenderType.get(renderType);
    }

    public final List<class_1921> getSupportedRenderTypes() {
        return cachedBlockQuads.isEmpty() ? class_1921.method_22720() : renderTypesCache.get();
    }

    private final void clearCaches() {
        renderTypesCache.clear();
    }





    public static class_1087 getModel(class_2680 state) {
        return class_310.method_1551().method_1554().method_4743().method_3335(state);
    }

    public static boolean hasDynamicModel(class_2680 state) {
        class_1087 model = getModel(state);
        return model instanceof IDynamicBakedModel;
    }

    public static Optional<DLModel> of(class_2680 state) {
        if (!hasDynamicModel(state)) return Optional.empty();
        return Optional.ofNullable(((IDynamicBakedModel)getModel(state)).getModel());
    }

    public static void renderModel(class_4587.class_4665 pose, class_4588 consumer, @Nullable class_2680 state, ModelContext context) {
        of(state).ifPresent(x -> x.render(pose, consumer, state, context));
    }

    public static void renderModel(class_4587.class_4665 pose, class_4588 consumer, ModelType type, @Nullable class_2680 state, ModelContext context, DLColor color, int packedLight, int packedOverlay) {
        of(state).ifPresent(x -> x.render(pose, consumer, type, state, context, color, packedLight, packedOverlay));
    }

    public void render(class_4587.class_4665 pose, class_4588 consumer, @Nullable class_2680 state, ModelContext context) {
        render(pose, consumer, ModelType.BLOCK, state, context, DLColor.WHITE, 0, 0);
    }

    public void render(class_4587.class_4665 pose, class_4588 consumer, ModelType type, @Nullable class_2680 state, ModelContext context, DLColor color, int packedLight, int packedOverlay) {
        class_5819 randomSource = class_5819.method_43047();
        long seed = 42L;
        for (class_1921 renderType : getSupportedRenderTypes()) {
            for (class_2350 direction : class_2350.values()) {
                randomSource.method_43052(seed);
                renderQuadList(pose, consumer, color, getQuads(type, DLBlockModelRegistry.getOriginalModel(state), state, randomSource, renderType, direction, context), packedLight, packedOverlay);
            }
            randomSource.method_43052(seed);
            renderQuadList(pose, consumer, color, getQuads(type, DLBlockModelRegistry.getOriginalModel(state), state, randomSource, renderType, null, context), packedLight, packedOverlay);
        }
        
    }

    private static void renderQuadList(class_4587.class_4665 pose, class_4588 consumer, DLColor color, List<class_777> quads, int packedLight, int packedOverlay) {
        class_777 bakedQuad;
        float r;
        float g;
        float b;
        float a;
        for (Iterator<class_777> iterator = quads.iterator(); iterator.hasNext(); consumer.method_22919(pose, bakedQuad, r, g, b, a, packedLight, packedOverlay)) {
            bakedQuad = (class_777)iterator.next();
            if (bakedQuad.method_3360()) {
                r = class_3532.method_15363(color.getRedF(), 0.0F, 1.0F);
                g = class_3532.method_15363(color.getGreenF(), 0.0F, 1.0F);
                b = class_3532.method_15363(color.getBlueF(), 0.0F, 1.0F);
                a = class_3532.method_15363(color.getAlphaF(), 0.0F, 1.0F);
            } else {
                r = 1.0F;
                g = 1.0F;
                b = 1.0F;
                a = 1.0F;
            }
        }

    }
}
