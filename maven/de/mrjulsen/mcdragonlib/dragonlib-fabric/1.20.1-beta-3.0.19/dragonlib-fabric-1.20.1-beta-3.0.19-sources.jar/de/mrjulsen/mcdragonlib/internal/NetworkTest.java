package de.mrjulsen.mcdragonlib.internal;

import de.mrjulsen.mcdragonlib.DragonLib;
import de.mrjulsen.mcdragonlib.data.DLStatus;
import de.mrjulsen.mcdragonlib.network.DLNetworkManager;
import de.mrjulsen.mcdragonlib.network.NetworkDirection;
import de.mrjulsen.mcdragonlib.network.NetworkPacketData;
import de.mrjulsen.mcdragonlib.network.NetworkPacketType;
import net.minecraft.class_2487;
import net.minecraft.class_2960;

public class NetworkTest {

    public static class TestData extends NetworkPacketData {

        String txt;

        public TestData(DLStatus status) {
            super(status);
        }
        
        public TestData(DLStatus status, String txt) {
            super(status);
            this.txt = txt;
        }

        @Override
        protected void write(class_2487 nbt) {
            nbt.method_10582("txt", txt);
        }

        @Override
        protected void read(class_2487 nbt) {
            this.txt = nbt.method_10558("txt");
        }

    }


    public static final DLNetworkManager NETWORK = new DLNetworkManager(new class_2960(DragonLib.MODID, "test"), "1");

    public static final NetworkPacketType.Send<NetworkDirection.C2S, TestData> SEND = NETWORK.registerSendOnlyPacket("string_message", NetworkDirection.C2S,
        (data, ctx) -> {
            DLNetworkManager.LOGGER.info("Text message is: " + data.txt);
        }, TestData::new);

    public static void init() {
    }

}
