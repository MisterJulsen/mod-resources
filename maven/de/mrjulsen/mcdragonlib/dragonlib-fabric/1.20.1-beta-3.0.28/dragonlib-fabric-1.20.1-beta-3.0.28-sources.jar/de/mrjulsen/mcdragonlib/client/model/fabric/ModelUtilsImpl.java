package de.mrjulsen.mcdragonlib.client.model.fabric;

import net.minecraft.class_1087;
import net.minecraft.class_1091;
import net.minecraft.class_2960;
import net.minecraft.class_310;

public class ModelUtilsImpl {

    public static class_1087 getModel(class_2960 location) {
        return class_310.method_1551().method_1554().getModel(location);
    }

    public static class_1087 getModel(class_1091 location) {
        return class_310.method_1551().method_1554().method_4742(location);
    }
}
