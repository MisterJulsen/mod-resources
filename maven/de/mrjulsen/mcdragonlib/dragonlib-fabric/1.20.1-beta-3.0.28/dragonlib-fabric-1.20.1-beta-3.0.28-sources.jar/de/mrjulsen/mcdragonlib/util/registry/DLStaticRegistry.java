package de.mrjulsen.mcdragonlib.util.registry;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import net.minecraft.class_2487;
import net.minecraft.class_2960;
import com.google.common.base.Supplier;
import com.google.common.base.Suppliers;

public class DLStaticRegistry<T extends IStaticRegisterable<T>> {
    private final LinkedHashMap<class_2960, DLStaticRegistryObject<? extends T>> TYPES = new LinkedHashMap<>();

    public <S extends T> DLStaticRegistryObject<S> register(class_2960 id, Supplier<S> factory) {
        DLStaticRegistryObject<S> type = new DLStaticRegistryObject<>(id, Suppliers.memoize(factory));
        TYPES.put(id, type);
        return type;
    }

    public boolean has(class_2960 id) {
        return TYPES.containsKey(id);
    }

    @SuppressWarnings("unchecked")
    public DLStaticRegistryObject<T> get(class_2960 id) {
        return (DLStaticRegistryObject<T>)TYPES.get(id);
    }

    public T load(class_2487 tag) {
        return DLStaticRegistryObject.load(tag, this::get);
    }

    public List<T> getAll() {
        List<T> result = new ArrayList<>(TYPES.size());
        for (DLStaticRegistryObject<? extends T> v : TYPES.values()) {
            result.add(v.get());
        }
        return result;
    }

}
