package de.mrjulsen.mcdragonlib.events.client;

import dev.architectury.event.Event;
import dev.architectury.event.EventFactory;
import net.minecraft.class_1087;
import net.minecraft.class_1088;
import net.minecraft.class_1100;
import net.minecraft.class_2960;

public interface ModelEvents {
    Event<AdditionalModels> ADDITIONAL_MODELS = EventFactory.createLoop();
    Event<ModifyModels> MODIFY_MODELS = EventFactory.createLoop();

    interface AdditionalModels {
        void registerAdditionalModels(AdditionalModelsRegistry registry);

        @FunctionalInterface
        interface AdditionalModelsRegistry {
            void register(class_2960 model);
        }
    }

    @FunctionalInterface
    interface ModifyModels {
        class_1087 modifyModels(class_1087 originalModel, Context context);

        interface Context {
            class_1088 getModelBakery();
            class_2960 getModelLocation();
            class_1100 getUnbakedModel();
        }
    }
}
