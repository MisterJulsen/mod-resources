package de.mrjulsen.mcdragonlib.client.util;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_377;
import net.minecraft.class_379;
import net.minecraft.class_382;
import net.minecraft.class_5223;
import net.minecraft.class_5224;
import net.minecraft.class_5250;
import net.minecraft.class_5348;
import net.minecraft.class_5481;
import org.apache.commons.lang3.mutable.MutableFloat;
import de.mrjulsen.mcdragonlib.mixin.BakedGlyphAccessor;
import de.mrjulsen.mcdragonlib.mixin.FontAccessor;
import de.mrjulsen.mcdragonlib.mixin.StringSplitterAccessor;
import de.mrjulsen.mcdragonlib.util.TextUtils;

public class FontUtils {
    public class_327 font;
    public class_377 fontSet;
    
    protected static record UVData(float u0, float v0, float u1, float v1) {}
    protected static final Map<Integer, Deque<UVData>> uvStack = new HashMap<>();

    public FontUtils(class_2960 fontStyle) {
        this.font = class_310.method_1551().field_1772;
        this.fontSet = ((FontAccessor)this.font).dragonlib$invokeGetFontSet(fontStyle);
    }    

    private void checkAndUpdateFont() {
        if (this.font != class_310.method_1551().field_1772) {
        }
    }

    public BakedGlyphAccessor getGlyphAccessor(int charCode) {
        return (BakedGlyphAccessor)getGlyph(charCode);
    }

    public void pushUV(int charCode) {
        BakedGlyphAccessor glyph = getGlyphAccessor(charCode);
        pushUV(charCode, glyph.dragonlib$getU0(), glyph.dragonlib$getV0(), glyph.dragonlib$getU1(), glyph.dragonlib$getV1());
    }

    protected void pushUV(int charCode, float u0, float v0, float u1, float v1) {
        if (!uvStack.containsKey(charCode)) {
            uvStack.put(charCode, new ArrayDeque<>());
        }
        uvStack.get(charCode).addLast(new UVData(u0, v0, u1, v1));
    }

    public boolean popUV(int charCode) {
        if (!uvStack.containsKey(charCode)) {
            return false;
        }

        UVData data = uvStack.get(charCode).pollLast();
        if (uvStack.get(charCode).isEmpty()) {
            uvStack.remove(charCode);
        }
        
        BakedGlyphAccessor glyph = getGlyphAccessor(charCode);
        glyph.dragonlib$setU0(data.u0());
        glyph.dragonlib$setV0(data.v0());
        glyph.dragonlib$setU1(data.u1());
        glyph.dragonlib$setV1(data.v1());
        return true;
    }

    public class_379 getGlyphInfo(int charCode) {
        return fontSet.method_2011(charCode, false);
    }

    public class_382 getGlyph(int charCode) {
        return fontSet.method_2014(charCode);
    }

    public void reset() {
        uvStack.clear();
    }




    /**
     * Misst die Breite eines formatierten Strings bis (exklusiv) zum angegebenen Zeichen-Index.
     *
     * @param content Der rohe String mit Formatierung.
     * @param index   Der Char-Index, bis zu dem gemessen werden soll (exklusive).
     * @param style   Der Start-Style für den String.
     * @return Die Breite in Pixeln bis zum gegebenen Index.
     */
    public static float formattedWidthByIndex(String content, int index, class_2583 style) {
        MutableFloat sum = new MutableFloat(0.0F);
        class_327 font = class_310.method_1551().field_1772;
        StringSplitterAccessor accessor = (StringSplitterAccessor)font.method_27527();
        class_5224 sink = new class_5224() {
            @Override
            public boolean accept(int pos, class_2583 s, int codePoint) {
                // pos ist der Char-Offset im String
                if (pos >= index) {
                    return false; // Abbruch
                }
                sum.add(accessor.dragonlib$getWidthProvider().getWidth(codePoint, s));
                return true;
            }
        };
        // Iteriere formatiert bis zum Abbruch
        class_5223.method_27479(content, style, sink);
        return sum.floatValue();
    }

    public static class_5348 substring(class_5348 text, int start, int end) {
        AtomicInteger currentIndex = new AtomicInteger(0);
        class_5250 result = TextUtils.empty();
        text.method_27658(
                (currentStyle, part) -> {
                    int currentIdx = currentIndex.get();
                    currentIndex.set(currentIdx + part.length());
                    if (currentIndex.get() < start || currentIdx > end) {
                        return Optional.empty();
                    }
                    result.method_10852(TextUtils.text(part.substring(Math.max(start, currentIdx), Math.min(end, currentIdx + part.length()))).method_27696(currentStyle));
                    return Optional.ofNullable(null);
                },
                class_2583.field_24360
        );
        return result;
    }


    /**
     * Variante für bereits aufgebautes FormattedText.
     */
    public static float formattedWidthByIndex(class_5348 content, int index, class_2583 style) {
        MutableFloat sum = new MutableFloat(0.0F);
        class_327 font = class_310.method_1551().field_1772;
        StringSplitterAccessor accessor = (StringSplitterAccessor)font.method_27527();

        AtomicBoolean finished = new AtomicBoolean(false);
        AtomicInteger currentIndex = new AtomicInteger(0);
        class_5224 sink = (pos, s, codePoint) -> {
            if (currentIndex.getAndIncrement() >= index) {
                finished.set(true);
                return false;
            }
            sum.add(accessor.dragonlib$getWidthProvider().getWidth(codePoint, s));
            return true;
        };

        content.method_27658(
                (currentStyle, part) -> {
                    if (finished.get())
                        return Optional.ofNullable("");
                    return class_5223.method_27479(part, currentStyle, sink) ? Optional.empty() : Optional.ofNullable("");
                },
                style
        );
        return sum.floatValue();
    }

    /**
     * Variante für FormattedCharSequence.
     */
    public static float formattedWidthByIndex(class_5481 content, int index) {
        MutableFloat sum = new MutableFloat(0.0F);
        class_327 font = class_310.method_1551().field_1772;
        StringSplitterAccessor accessor = (StringSplitterAccessor)font.method_27527();
        class_5224 sink = (pos, s, codePoint) -> {
            if (pos >= index) return false;
            sum.add(accessor.dragonlib$getWidthProvider().getWidth(codePoint, s));
            return true;
        };
        content.accept(sink);
        return sum.floatValue();
    }
}
