package de.mrjulsen.mcdragonlib.network.fabric;

import de.mrjulsen.mcdragonlib.network.DLNetworkManager;
import de.mrjulsen.mcdragonlib.network.NetworkPacketContext;
import de.mrjulsen.mcdragonlib.network.NetworkSide;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketSender;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_634;

public class ClientNetworkManager {
    public static void registerChannel(class_2960 channelId, String protocolVersion) {
        ClientPlayNetworking.registerGlobalReceiver(channelId, new ClientPlayNetworking.PlayChannelHandler() {
            @Override
            public void receive(class_310 client, class_634 handler, class_2540 buf, PacketSender sender) {
                NetworkPacketContext context = DLNetworkManagerImpl.context(client.field_1724, client, true);
                DLNetworkManager.receiveData(channelId, buf, NetworkSide.C2S, context);
            }
        });
    }
}
