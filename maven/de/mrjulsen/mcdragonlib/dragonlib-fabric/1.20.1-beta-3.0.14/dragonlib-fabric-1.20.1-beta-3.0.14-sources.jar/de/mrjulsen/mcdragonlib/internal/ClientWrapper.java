package de.mrjulsen.mcdragonlib.internal;

import de.mrjulsen.mcdragonlib.network.NetworkDirection.C2S;
import net.minecraft.class_1937;
import net.minecraft.class_310;

public class ClientWrapper {

    public static class_1937 getClientLevel() {
        return class_310.method_1551().field_1687;
    }

    public static C2S toServer() {
        return packet -> {
            if (class_310.method_1551().method_1562() != null) {
                class_310.method_1551().method_1562().method_2883(packet);
            } else {
                throw new IllegalStateException("Unable to send packet to the server while not in game!");
            }
        };
    }
}
