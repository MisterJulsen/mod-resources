package de.mrjulsen.mcdragonlib.util;

import java.util.Collection;
import java.util.Iterator;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_5250;
import de.mrjulsen.mcdragonlib.DragonLib;

/**
 * This class contains some useful utilities for text components. It uses its
 * own methods to create text components and forms a unified wrapper around the
 * Minecraft methods.
 */
public final class TextUtils {
    
    /** 🐉 */
    public static final class_2561 TEXT_DRAGON = TextUtils.translate("text." + DragonLib.MODID + ".dragon");
    public static final class_2561 TEXT_NEXT = TextUtils.translate("text." + DragonLib.MODID + ".next");
    public static final class_2561 TEXT_PREVIOUS = TextUtils.translate("text." + DragonLib.MODID + ".previous");
    public static final class_2561 TEXT_GO_BACK = TextUtils.translate("text." + DragonLib.MODID + ".go_back");
    public static final class_2561 TEXT_GO_FORTH = TextUtils.translate("text." + DragonLib.MODID + ".go_forth");    
    public static final class_2561 TEXT_GO_UP = TextUtils.translate("text." + DragonLib.MODID + ".go_down");
    public static final class_2561 TEXT_GO_DOWN = TextUtils.translate("text." + DragonLib.MODID + ".go_up");
    public static final class_2561 TEXT_GO_RIGHT= TextUtils.translate("text." + DragonLib.MODID + ".go_right");
    public static final class_2561 TEXT_GO_LEFT = TextUtils.translate("text." + DragonLib.MODID + ".go_left");
    public static final class_2561 TEXT_GO_TO_TOP = TextUtils.translate("text." + DragonLib.MODID + ".go_to_top");
    public static final class_2561 TEXT_GO_TO_BOTTOM = TextUtils.translate("text." + DragonLib.MODID + ".go_to_bottom");
    public static final class_2561 TEXT_RESET_DEFAULTS = TextUtils.translate("text." + DragonLib.MODID + ".reset_defaults");
    public static final class_2561 TEXT_EXPAND = TextUtils.translate("text." + DragonLib.MODID + ".expand");
    public static final class_2561 TEXT_COLLAPSE = TextUtils.translate("text." + DragonLib.MODID + ".collapse");
    public static final class_2561 TEXT_COUNT = TextUtils.translate("text." + DragonLib.MODID + ".count");
    public static final class_2561 TEXT_TRUE = TextUtils.translate("text." + DragonLib.MODID + ".true");
    public static final class_2561 TEXT_FALSE = TextUtils.translate("text." + DragonLib.MODID + ".false");
    public static final class_2561 TEXT_CLOSE = TextUtils.translate("text." + DragonLib.MODID + ".close");
    public static final class_2561 TEXT_SHOW = TextUtils.translate("text." + DragonLib.MODID + ".show");
    public static final class_2561 TEXT_HIDE = TextUtils.translate("text." + DragonLib.MODID + ".hide");
    public static final class_2561 TEXT_SEARCH = TextUtils.translate("text." + DragonLib.MODID + ".search");
    public static final class_2561 TEXT_REFRESH = TextUtils.translate("text." + DragonLib.MODID + ".refresh");
    public static final class_2561 TEXT_RELOAD = TextUtils.translate("text." + DragonLib.MODID + ".reload");

    /**
     * a predefined an immutable empty text component. Similar to {@link TextUtils#empty()}
     */
    public static final class_2561 EMPTY = empty();
    private static final class_2561 TEXT_CONCAT = text("     ***     ");
    public static final String ELLIPSIS_STRING = "...";
    public static final class_2561 ELLIPSIS_COMPONENT = TextUtils.text(ELLIPSIS_STRING);
    
    /**
     * Creates a new text component with the specified text.
     * @param text The literal text of the component.
     * @return A new text component.
     */
    public static class_5250 text(String text) {
        return class_2561.method_43470(text);
    }
    
    /**
     * Creates a new translatable text component.
     * @param text The translation key
     * @param args Additional parameters for placeholders
     * @return The translated text component
     */
    public static class_5250 translate(String text, Object... args) {
        return class_2561.method_43469(text, args);
    }

    /**
     * Creates a new translatable text component.
     * @param text The translation key
     * @return The translated text component
     */
    public static class_5250 translate(String text) {
        return class_2561.method_43471(text);
    }

    /**
     * Creates a new keybind text component.
     * @param text The keybind key
     * @return The keybind component
     */
    public static class_5250 keybind(String key) {
        return class_2561.method_43472(key);
    }

    /**
     * Creates an empty text component with {@code ""}.
     * @return An enmpty text component.
     */
    public static class_5250 empty() {
        return text("");
    }

    

    /**
     * Truncates the given text component and appends an ellipsis {@code ...} to it. The text is truncated so that the remainder, including the ellipsis, does not exceed the maximum bounds.
     * @param font The font to use for this operation
     * @param text The text to truncate
     * @param maxWidth The maximum width
     * @return The truncated text component with the ellipsis {@code ...}.
     */
	public static class_2561 truncateWithEllipsis(class_327 font, class_2561 text, int maxWidth) {
		int lineWidth = font.method_27525(text);
		return lineWidth < maxWidth ? text : TextUtils.text(font.method_1714(text, maxWidth - font.method_27525(TextUtils.text(ELLIPSIS_STRING).method_27696(text.method_10866()))).getString() + ELLIPSIS_STRING).method_27696(text.method_10866());
	}

    /**
     * Truncates the given text and appends an ellipsis {@code ...} to it. The text is truncated so that the remainder, including the ellipsis, does not exceed the maximum bounds.
     * @param font The font to use for this operation
     * @param text The text to truncate
     * @param maxWidth The maximum width
     * @return The truncated text with the ellipsis {@code ...}.
     */
    public static String truncateWithEllipsis(class_327 font, String text, int maxWidth) {
		int lineWidth = font.method_1727(text);
		return lineWidth < maxWidth ? text : font.method_27523(text, maxWidth - font.method_1727(ELLIPSIS_STRING)) + ELLIPSIS_STRING;
	}
    

    /**
     * Connects the different text components with {@code *** }.
     * @param components The text components to combine
     * @return The combined text component.
     */
    public static class_5250 concatSimple(class_2561... components) {
        return concat(TEXT_CONCAT, components);
    }

    /**
     * Connects the different text components with the specified string.
     * @param concatString The connection text
     * @param components The text components to combine
     * @return The combined text component.
     */
    public static class_5250 concat(class_2561 concatString, class_2561... components) {
        if (components.length <= 0) {
            return empty();
        }

        class_5250 c = components[0].method_27661();
        for (int i = 1; i < components.length; i++) {
            c.method_10852(concatString);
            c.method_10852(components[i]);
        }
        return c;
    }

    /**
     * Connects the different text components with {@code *** }.
     * @param concatString The connection text
     * @param components The text components to combine
     * @return The combined text component.
     */
    public static class_5250 concat(Collection<class_2561> components) {
        return concat(TEXT_CONCAT, components);
    }

    /**
     * Connects the different text components with the specified string.
     * @param concatString The connection text
     * @param components The text components to combine
     * @return The combined text component.
     */
    public static class_5250 concat(class_2561 concatString, Collection<class_2561> components) {
        if (components == null || components.isEmpty()) {
            return empty();
        }

        Iterator<class_2561> com = components.iterator();
        class_5250 c = empty();

        if (!com.hasNext()) {
            return empty();
        }
        c.method_10852(com.next());

        while (com.hasNext()) {
            c.method_10852(concatString);
            c.method_10852(com.next());
        }
        return c;
    }

}
