package de.mrjulsen.mcdragonlib.client.gui.widgets.richtext.action;

import net.minecraft.class_2561;

@FunctionalInterface
public interface TooltipAction {
    class_2561 getTooltip();
}
