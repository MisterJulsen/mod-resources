package de.mrjulsen.mcdragonlib.util;

import de.mrjulsen.mcdragonlib.client.util.AngleHelper;
import de.mrjulsen.mcdragonlib.util.math.MathUtils;
import net.minecraft.class_2487;
import net.minecraft.class_3532;

/**
 * @see https://github.com/Creators-of-Create/Create/blob/mc1.18/dev/src/main/java/com/simibubi/create/foundation/utility/animation/LerpedFloat.java
 */
public class LerpedFloat {

	protected Interpolator interpolator;
	protected float previousValue;
	protected float value;

	protected Chaser chaseFunction;
	protected float chaseTarget;
	protected float chaseSpeed;
	protected boolean angularChase;

	protected boolean forcedSync;

	public LerpedFloat(Interpolator interpolator) {
		this.interpolator = interpolator;
		startWithValue(0);
		forcedSync = true;
	}

	public static LerpedFloat linear() {
		return new LerpedFloat((p, c, t) -> (float) MathUtils.lerp(p, c, t));
	}

	public static LerpedFloat angular() {
		LerpedFloat lerpedFloat = new LerpedFloat(AngleHelper::angleLerp);
		lerpedFloat.angularChase = true;
		return lerpedFloat;
	}

	public LerpedFloat startWithValue(double value) {
		float f = (float) value;
		this.previousValue = f;
		this.chaseTarget = f;
		this.value = f;
		return this;
	}

	public LerpedFloat chase(double value, double speed, Chaser chaseFunction) {
		updateChaseTarget((float) value);
		this.chaseSpeed = (float) speed;
		this.chaseFunction = chaseFunction;
		return this;
	}
	
	public LerpedFloat disableSmartAngleChasing() {
		angularChase = false;
		return this;
	}

	public void updateChaseTarget(float target) {
		if (angularChase)
			target = value + AngleHelper.getShortestAngleDiff(value, target);
		this.chaseTarget = target;
	}

	public boolean updateChaseSpeed(double speed) {
		float prevSpeed = this.chaseSpeed;
		this.chaseSpeed = (float) speed;
		return !class_3532.method_20390(prevSpeed, speed);
	}

	public void tickChaser() {
		previousValue = value;
		if (chaseFunction == null)
			return;
		if (class_3532.method_20390((double) value, chaseTarget)) {
			value = chaseTarget;
			return;
		}
		value = chaseFunction.chase(value, chaseSpeed, chaseTarget);
	}

	public void setValueNoUpdate(double value) {
		this.value = (float) value;
	}

	public void setValue(double value) {
		this.previousValue = this.value;
		this.value = (float) value;
	}

	public float getValue() {
		return getValue(1);
	}

	public float getValue(float partialTicks) {
		return interpolator.interpolate(partialTicks, previousValue, value);
	}

	public boolean settled() {
		return class_3532.method_20390((double) previousValue, value) && (chaseFunction == null || class_3532.method_20390((double) value, chaseTarget));
	}

	public float getChaseTarget() {
		return chaseTarget;
	}

	public void forceNextSync() {
		forcedSync = true;
	}

	public class_2487 toNbt() {
		class_2487 compoundNBT = new class_2487();
		compoundNBT.method_10548("Speed", chaseSpeed);
		compoundNBT.method_10548("Target", chaseTarget);
		compoundNBT.method_10548("Value", value);
		if (forcedSync)
			compoundNBT.method_10556("Force", true);
		forcedSync = false;
		return compoundNBT;
	}

	public void fromNbt(class_2487 compoundNBT, boolean clientPacket) {
		if (!clientPacket || compoundNBT.method_10545("Force"))
			startWithValue(compoundNBT.method_10583("Value"));
		readChaser(compoundNBT);
	}

	protected void readChaser(class_2487 compoundNBT) {
		chaseSpeed = compoundNBT.method_10583("Speed");
		chaseTarget = compoundNBT.method_10583("Target");
	}

	@FunctionalInterface
	public interface Interpolator {
		float interpolate(double progress, double current, double target);
	}

	@FunctionalInterface
	public interface Chaser {

		Chaser IDLE = (c, s, t) -> (float) c;
		Chaser EXP = exp(Double.MAX_VALUE);
		Chaser LINEAR = (c, s, t) -> (float) (c + MathUtils.clamp(t - c, -s, s));

		static Chaser exp(double maxEffectiveSpeed) {
			return (c, s, t) -> (float) (c + MathUtils.clamp((t - c) * s, -maxEffectiveSpeed, maxEffectiveSpeed));
		}

		float chase(double current, double speed, double target);
	}

}
