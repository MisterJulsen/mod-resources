package de.mrjulsen.mcdragonlib.client.model;

import de.mrjulsen.mcdragonlib.client.model.mesh.DLModel;
import net.minecraft.class_1087;

public interface IDynamicBakedModel {
    class_1087 getOriginalModel();
    DLModel getModel();
}
