package de.mrjulsen.mcdragonlib.fabric.client.model.loaders;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import com.google.common.collect.Maps;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import de.mrjulsen.mcdragonlib.DragonLib;
import de.mrjulsen.mcdragonlib.fabric.client.model.geometry.IGeometryLoader;
import de.mrjulsen.mcdragonlib.fabric.client.model.loaders.MultipartObjModel.ModelGroup;
import de.mrjulsen.mcdragonlib.fabric.client.model.loaders.MultipartObjModel.ModelObject;
import de.mrjulsen.mcdragonlib.fabric.client.model.loaders.MultipartObjModel.ModelSettings;
import de.mrjulsen.mcdragonlib.fabric.client.model.loaders.MultipartObjModel.SubModelSettings;
import de.mrjulsen.mcdragonlib.fabric.client.model.obj.ObjMaterialLibrary;
import de.mrjulsen.mcdragonlib.fabric.client.model.obj.ObjTokenizer;
import net.fabricmc.fabric.api.client.model.loading.v1.ModelLoadingPlugin;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import net.minecraft.class_3518;

public class MultipartObjLoader implements ModelLoadingPlugin, IGeometryLoader<MultipartObjModel> {
    public static final class_2960 ID = new class_2960(DragonLib.MODID, "multipart_obj");
	public static final MultipartObjLoader INSTANCE = new MultipartObjLoader();

	private final Map<MultipartObjModel.ModelSettings, MultipartObjModel> modelCache = Maps.newConcurrentMap();
	private final Map<class_2960, ObjMaterialLibrary> materialCache = Maps.newConcurrentMap();
    
    @Override
    public void onInitializeModelLoader(Context pluginContext) {
        modelCache.clear();
        materialCache.clear();
    }

    @Override
    public MultipartObjModel read(JsonObject jsonObject, JsonDeserializationContext deserializationContext) {
        return readInternal(deserializationContext, jsonObject);
    }

    public MultipartObjModel readInternal(JsonDeserializationContext deserializationContext, JsonObject modelContents) {
        if (!modelContents.has("model"))
            throw new JsonParseException("OBJ Loader requires a 'model' key that points to a valid .OBJ model.");
        if (!modelContents.has("loader") || !modelContents.get("loader").getAsString().equals(ID.toString()))
            throw new RuntimeException("Importing invalid model loader.");

        String modelLocation = modelContents.get("model").getAsString();

        boolean automaticCulling = class_3518.method_15258(modelContents, "automatic_culling", true);
        boolean shadeQuads = class_3518.method_15258(modelContents, "shade_quads", true);
        boolean flipV = class_3518.method_15258(modelContents, "flip_v", false);
        boolean emissiveAmbient = class_3518.method_15258(modelContents, "emissive_ambient", true);
        String mtlOverride = class_3518.method_15253(modelContents, "mtl_override", null);

        List<SubModelSettings> subSettings = new ArrayList<>();
        if (modelContents.has("add")) {
            for (JsonElement element : class_3518.method_15261(modelContents, "add")) {
                subSettings.add(DragonLib.GSON.fromJson(element, SubModelSettings.class));
            }
        }

        MultipartObjModel.ModelSettings settings = new MultipartObjModel.ModelSettings(
            new class_2960(modelLocation),
            automaticCulling,
            shadeQuads,
            flipV,
            emissiveAmbient,
            mtlOverride,
            subSettings
        );
        MultipartObjModel model = loadModel(settings);

        int i = 0;
        for (SubModelSettings subModelSettings : settings.subSettings()) {
            i++;
            MultipartObjModel subModel = subModelSettings.isJson() ? 
                readSubModel(new class_2960(subModelSettings.model())) :
                loadModel(new ModelSettings(new class_2960(subModelSettings.model()), automaticCulling, shadeQuads, flipV, emissiveAmbient, mtlOverride, List.of()))
            ;
            for (ModelObject part : subModel.getParts()) {
                ModelGroup group = ((ModelGroup)part);
                if (!group.settings.inheritable()) continue;
                String newName = "m" + i + "_" + part.name();
                group = group.copy(subModelSettings, newName);
                model.addPart(group.name(), group);
            }
        }

        return model;
    }

	private static class_3300 getResourceManager() {
		return class_310.method_1551().method_1478();
	}

    private MultipartObjModel readSubModel(class_2960 location) {        
        try {
            class_3298 resource = getResourceManager().method_14486(location).orElseThrow();
            InputStreamReader reader = new InputStreamReader(resource.method_14482(), StandardCharsets.UTF_8);
            JsonObject obj = class_3518.method_15255(reader);
            return readInternal(null, obj);
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

    public MultipartObjModel loadModel(MultipartObjModel.ModelSettings settings) {
        return modelCache.computeIfAbsent(settings, (data) -> {
            class_3298 resource = getResourceManager().method_14486(settings.modelLocation()).orElseThrow();
            try (ObjTokenizer tokenizer = new ObjTokenizer(resource.method_14482())) {
                return MultipartObjParser.parse(tokenizer, settings);
            } catch (FileNotFoundException e) {
                throw new RuntimeException("Could not find OBJ model", e);
            } catch (Exception e) {
                throw new RuntimeException("Could not read OBJ model", e);
            }
        });
    }

    public ObjMaterialLibrary loadMaterialLibrary(class_2960 materialLocation) {
        return materialCache.computeIfAbsent(materialLocation, (location) -> {
            class_3298 resource = getResourceManager().method_14486(location).orElseThrow();
            try (ObjTokenizer rdr = new ObjTokenizer(resource.method_14482())) {
                return new ObjMaterialLibrary(rdr);
            } catch (FileNotFoundException e) {
                throw new RuntimeException("Could not find OBJ material library", e);
            } catch (Exception e) {
                throw new RuntimeException("Could not read OBJ material library", e);
            }
        });
    }
}