package de.mrjulsen.mcdragonlib.data;

import org.joml.Vector3d;
import org.joml.Vector3dc;
import org.joml.Vector3f;
import org.joml.Vector3fc;
import org.joml.Vector3i;

import de.mrjulsen.mcdragonlib.util.DLUtils;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2960;

public class WorldLocation {
    private static final String NBT_X = "x";
    private static final String NBT_Y = "y";
    private static final String NBT_Z = "z";
    private static final String NBT_DIM = "dimension";

    public final double x;
    public final double y;
    public final double z;
    public final class_2960 dimension;
    

    public WorldLocation(double x, double y, double z, class_2960 dimension) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.dimension = dimension;
    }

    public WorldLocation(int x, int y, int z, class_1937 level) {
        this((double)x, (double)y, (double)z, level);
    }

    public WorldLocation(double x, double y, double z, class_1937 level) {
        this(x, y, z, level.method_27983().method_29177());
    }

    public WorldLocation(class_2382 vec, class_1937 level) {
        this(vec.method_10263(), vec.method_10264(), vec.method_10260(), level);
    }

    public WorldLocation(class_243 vec, class_1937 level) {
        this(vec.field_1352, vec.field_1351, vec.field_1350, level);
    }

    public WorldLocation(Vector3fc vec, class_1937 level) {
        this(vec.x(), vec.y(), vec.z(), level);
    }

    public WorldLocation(Vector3dc vec, class_1937 level) {
        this(vec.x(), vec.y(), vec.z(), level);
    }
    

    public class_2338 getLocationBlockPos() {
        return new class_2338(getLocationVec3i());
    }

    public class_2382 getLocationVec3i() {
        return new class_2382((int)x, (int)y, (int)z);
    }

    public class_243 getLocationVec3() {
        return new class_243(x, y, z);
    }

    public Vector3f getLocationVector3f() {
        return new Vector3f((float)x, (float)y, (float)z);
    }

    public Vector3i getLocationVector3i() {
        return new Vector3i((int)x, (int)y, (int)z);
    }

    public Vector3d getLocationVector3d() {
        return new Vector3d(x, y, z);
    }

    public class_2487 toNbt() {
        class_2487 tag = new class_2487();
        tag.method_10549(NBT_X, x);
        tag.method_10549(NBT_Y, y);
        tag.method_10549(NBT_Z, z);
        tag.method_10582(NBT_DIM, dimension.toString());

        return tag;
    }

    public static WorldLocation loadFromNbt(class_2487 tag) {
        return new WorldLocation(
            tag.method_10574(NBT_X),
            tag.method_10574(NBT_Y),
            tag.method_10574(NBT_Z),
            DLUtils.resourceLocation(tag.method_10558(NBT_DIM))
        );
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof WorldLocation other) {
            return x == other.x && y == other.y && z == other.z && dimension.equals(other.dimension);
        }
        return false;
    }

    @Override
    public String toString() {
        return String.format("x=%s, y=%s, z=%s, dim=%s", x, y, z, dimension);
    }
}
