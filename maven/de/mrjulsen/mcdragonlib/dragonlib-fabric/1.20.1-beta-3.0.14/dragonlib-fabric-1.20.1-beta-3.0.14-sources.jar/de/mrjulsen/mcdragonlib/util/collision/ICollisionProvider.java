package de.mrjulsen.mcdragonlib.util.collision;

import java.util.Optional;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import org.joml.Vector3f;

public interface ICollisionProvider {
    Optional<RaycastHitResult> tryHit(class_1937 level, class_2338 pos, Vector3f rayOrigin, Vector3f rayDirection);
}

