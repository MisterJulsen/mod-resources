package de.mrjulsen.mcdragonlib.client.model;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.function.Supplier;
import net.minecraft.class_1087;
import net.minecraft.class_1091;
import net.minecraft.class_1747;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3300;
import net.minecraft.class_4013;
import net.minecraft.class_773;
import org.jetbrains.annotations.ApiStatus.Internal;

import com.google.common.collect.ImmutableMap;

import de.mrjulsen.mcdragonlib.client.model.mesh.DLModel;
import de.mrjulsen.mcdragonlib.client.model.mesh.DLModel.ModelType;

/**
 * Register custom {@link class_1087}s for {@link class_2248}s and their {@link class_1747}s. 
 */
public class DLBlockModelRegistry implements class_4013 {

    private static final Map<class_2680, class_1087> originalModels = new ConcurrentHashMap<>();

    private static final Queue<ICustomModelFactory> customModels = new LinkedBlockingQueue<>();

    public static interface ICustomModelFactory {
        Collection<class_2680> getStates();
        Supplier<DLModel> getModelFactory();
        ModelType getType();
    }

    private static abstract class AbstractModelFactory implements ICustomModelFactory {
        private final Supplier<DLModel> modelFactory;

        public AbstractModelFactory(Supplier<DLModel> modelFactory) {
            this.modelFactory = modelFactory;
        }

        @Override
        public Supplier<DLModel> getModelFactory() {
            return modelFactory;
        }
    }

    private static class BlockModelFactory extends AbstractModelFactory {

        private final Supplier<class_2248> block;

        public BlockModelFactory(Supplier<class_2248> block, Supplier<DLModel> modelFactory) {
            super(modelFactory);
            this.block = block;
        }

        @Override
        public Collection<class_2680> getStates() {
            return block.get().method_9595().method_11662();
        }

        @Override
        public ModelType getType() {
            return ModelType.BLOCK;
        }
    }

    private static class BlockStateModelFactory extends AbstractModelFactory {

        private final Supplier<Collection<class_2680>> blockStates;

        public BlockStateModelFactory(Supplier<Collection<class_2680>> blockStates, Supplier<DLModel> modelFactory) {
            super(modelFactory);
            this.blockStates = blockStates;
        }

        @Override
        public Collection<class_2680> getStates() {
            return blockStates.get();
        }

        @Override
        public ModelType getType() {
            return ModelType.BLOCK;
        }
    }

    private static class BlockItemModelFactory extends AbstractModelFactory {

        private final Supplier<class_2680> itemBlockState;

        public BlockItemModelFactory(Supplier<class_2680> itemBlockState, Supplier<DLModel> modelFactory) {
            super(modelFactory);
            this.itemBlockState = itemBlockState;
        }

        @Override
        public Collection<class_2680> getStates() {
            return List.of(itemBlockState.get());
        }

        @Override
        public ModelType getType() {
            return ModelType.ITEM;
        }
    }

    /**
     * Register a new model for the specified block and swap it accordingly for all possible {@link class_2680} from {@link class_2689#method_11662()} when loading the game .
     * @param block The block of which the models are to be replaced.
     * @param blockModelFactory The new model for the {@link class_2248} or {@code null} if the original model should be used.
     * @param itemModelFactory The new model for the {@link class_1747} or {@code null} if the original model should be used.
     * For items the default {@link class_2680} from {@link class_2248#method_9564()} will be used.
     */
    public static void registerForBlock(Supplier<class_2248> block, Supplier<DLModel> blockModelFactory, Supplier<DLModel> itemModelFactory) {
        if (blockModelFactory != null) customModels.add(new BlockModelFactory(block, blockModelFactory));
        if (itemModelFactory != null) customModels.add(new BlockItemModelFactory(() -> block.get().method_9564(), itemModelFactory));
    }
    
    /**
     * Register a new model for the specified {@link class_2680} and swap it accordingly when loading the game.
     * @param blockStates The block states for which the models should be replaced.
     * @param modelFactory The new model for the given states or {@code null} if the original model should be used.
     */
    public static void registerForStates(Supplier<Collection<class_2680>> blockStates, Supplier<DLModel> modelFactory) {
        customModels.add(new BlockStateModelFactory(blockStates, modelFactory));
    }
    
    /**
     * Register a new model for the {@link class_1747} of the {@link class_2248} specified by a {@link class_2680} and swap it accordingly when loading the game.
     * @param itemBlockState The {@link class_2680} which should be used as a reference when building the item model.
     * @param modelFactory The new model for the {@link class_1747} or {@code null} if the original model should be used.
     */
    public static void registerForBlockItem(Supplier<class_2680> itemBlockState, Supplier<DLModel> modelFactory) {
        customModels.add(new BlockItemModelFactory(itemBlockState, modelFactory));
    }


    public static record ModelRegistryData(ICustomModelFactory factory, class_2680 state) {
        @Override
        public final int hashCode() {
            return factory.hashCode();
        }

        @Override
        public final boolean equals(Object obj) {
            if (obj instanceof ModelRegistryData o) {
                return factory == o.factory;
            }
            return false;
        }
    }

    public static Queue<ICustomModelFactory> getCustomRegisteredModels(Map<class_2960, class_1087> registry) {
        return new LinkedBlockingQueue<>(customModels);
    }

    public static ImmutableMap<class_2960, ModelRegistryData> getCustomRegisteredModelsMapped() {
        ImmutableMap.Builder<class_2960, ModelRegistryData> builder = ImmutableMap.builder();
        while (!customModels.isEmpty()) {
            ICustomModelFactory factory = customModels.poll();
            if (factory.getModelFactory() != null) {
                for (class_2680 state : factory.getStates()) {
                    class_2960 location = class_773.method_3340(state);
                    if (factory.getType() == ModelType.ITEM) {
                        location = new class_1091(location, "inventory");
                    }
                    builder.put(location, new ModelRegistryData(factory, state));
                }
            }
        }
        return builder.build();
    }


    @Internal
    public static void setOriginalModel(class_2680 state, class_1087 model) {
        originalModels.computeIfAbsent(state, s -> model);
    }

    public static class_1087 getOriginalModel(class_2680 state) {
        if (originalModels.containsKey(state)) {
            return originalModels.get(state);
        }
        return class_310.method_1551().method_1554().method_4743().method_3335(state);
    }

    @Override
    public void method_14491(class_3300 resourceManager) {
    }
}
