package de.mrjulsen.mcdragonlib.mixin;

import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_377;
import net.minecraft.class_382;
import net.minecraft.class_4588;
import net.minecraft.class_5225;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_327.class)
public interface FontAccessor {

    @Invoker("getFontSet")
    public class_377 dragonlib$invokeGetFontSet(class_2960 pFontLocation);

    @Accessor("splitter")
    class_5225 dragonlib$getSplitter();

    @Accessor("filterFishyGlyphs")
    boolean dragonlib$filterFishyGlyphs();

    @Invoker("renderChar")
    void dragonlib$renderChar(class_382 glyph, boolean bold, boolean italic, float boldOffset, float x, float y, Matrix4f matrix, class_4588 buffer, float red, float green, float blue, float alpha, int packedLight);
}

