package de.mrjulsen.mcdragonlib.client.ber;

import net.minecraft.class_2586;

public abstract class AbstractBlockEntityRenderInstance<T extends class_2586> implements IBlockEntityRendererInstance<T> {

    public AbstractBlockEntityRenderInstance(T blockEntity) {
        preinit(blockEntity);
        update(blockEntity.method_10997(), blockEntity.method_11016(), blockEntity.method_11010(), blockEntity, null);
    }

    protected void preinit(T blockEntity) {}

}