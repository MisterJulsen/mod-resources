package de.mrjulsen.mcdragonlib.mixin;

import de.mrjulsen.mcdragonlib.client.DLOverlayManager;
import de.mrjulsen.mcdragonlib.client.gui.widgets.base.DLWindow;
import de.mrjulsen.mcdragonlib.internal.DLTestWindow;
import net.minecraft.class_310;
import net.minecraft.class_4011;
import net.minecraft.class_4341;
import net.minecraft.class_542;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_310.class)
public class MinecraftMixin {

    @Inject(method = "setInitialScreen", at = @At(value = "HEAD"), cancellable = true)
    public void dragonlib$showScreen(class_4341 realmsClient, class_4011 reloadInstance, class_542.class_8495 quickPlayData, CallbackInfo ci) {
        //DLWindow.openWindow(mgr -> new DLTestWindow(mgr));
        //ci.cancel();
    }

    @Inject(method = "resizeDisplay", at = @At(value = "TAIL"))
    public void dragonlib$resizeDisplay(CallbackInfo ci) {
        DLOverlayManager.resizeDisplay();
    }
}
