package de.mrjulsen.mcdragonlib.internal;

import org.joml.Vector3f;

import de.mrjulsen.mcdragonlib.client.ber.BERGraphics;
import de.mrjulsen.mcdragonlib.client.ber.BERLabel;
import de.mrjulsen.mcdragonlib.client.ber.BasicBlockEntityRenderer;
import de.mrjulsen.mcdragonlib.client.ber.BERLabel.EScrollMode;
import de.mrjulsen.mcdragonlib.client.model.mesh.BasicMesh;
import de.mrjulsen.mcdragonlib.client.model.mesh.Mesh;
import de.mrjulsen.mcdragonlib.client.util.DLTexture;
import de.mrjulsen.mcdragonlib.client.util.RenderUtils;
import de.mrjulsen.mcdragonlib.data.ETextAlignment;
import de.mrjulsen.mcdragonlib.util.DLColor;
import de.mrjulsen.mcdragonlib.util.DLUtils;
import de.mrjulsen.mcdragonlib.util.TextUtils;
import net.minecraft.class_124;
import net.minecraft.class_2246;
import net.minecraft.class_2350;
import net.minecraft.class_5614.class_5615;
import net.minecraft.class_5819;

public class DragonLibBlockEntityRenderer extends BasicBlockEntityRenderer<DragonLibBlockEntity> {
    private final BERLabel label = new BERLabel();
    private final Mesh model;

    public DragonLibBlockEntityRenderer(class_5615 context) {
        super(context);
        label.text.set(TextUtils.text("DragonLib ").method_27692(class_124.field_1065).method_10852(TextUtils.text("🐉").method_27692(class_124.field_1061)));
        label.y.set(11f);
        label.fullBackground.set(false);
        label.horizontalScrollingSpeed.set(8f);
        label.horizontalAlign.set(ETextAlignment.LEFT);
        label.horizontalMaxScale.set(0.5f);
        label.horizontalMinScale.set(0.5f);
        label.verticalMaxScale.set(0.5f);
        label.verticalMinScale.set(0.5f);
        label.horizontalScrollMode.set(EScrollMode.ALWAYS);

        model = BasicMesh.fromBlock(class_2246.field_10538.method_9564(), class_5819.method_43047());
    }


    @Override
    protected void renderBlock(BERGraphics<DragonLibBlockEntity> graphics, float partialTick) {
        graphics.poseStack().method_22903();
        graphics.poseStack().method_46416(0, 0, 16.01f);
        model.render(graphics, graphics.packedLight(), true);
        RenderUtils.drawString(graphics, font, 0, 0, "Salz", DLColor.WHITE, ETextAlignment.LEFT, false);
        RenderUtils.renderTexture(DLUtils.resourceLocation("textures/block/crafting_table_front.png"), graphics, new Vector3f(), 1, 1, class_2350.field_11034,true);
        label.render(graphics);
        graphics.poseStack().method_22909();
    }
}
