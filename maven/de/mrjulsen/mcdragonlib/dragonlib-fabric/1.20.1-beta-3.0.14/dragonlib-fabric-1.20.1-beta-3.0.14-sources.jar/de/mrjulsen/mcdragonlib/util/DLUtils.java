package de.mrjulsen.mcdragonlib.util;

import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.function.Consumer;
import javax.imageio.ImageIO;
import net.minecraft.class_1011;
import net.minecraft.class_161;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2470;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_4076;
import org.apache.commons.codec.binary.Base64;

public final class DLUtils {

    public static class_2960 resourceLocation(String namespace, String path) {
        return new class_2960(namespace, path);
    }

    public static class_2960 resourceLocation(String path) {
        return new class_2960(path);
    }

    public static void giveAdvancement(class_3222 player, String modid, String name, String criteriaKey) {
        class_161 adv = player.method_5682().method_3851().method_12896(new class_2960(modid, name));
        player.method_14236().method_12878(adv, criteriaKey);
    }

    public static String textureToBase64(class_1011 image) {
        try {
            return Base64.encodeBase64String(image.method_24036());
        } catch (IOException e) {
            e.printStackTrace();
            return "";
        }
    }

    public static InputStream scaleImage(InputStream inputStream, int width, int height) throws IOException {
        BufferedImage originalImage = ImageIO.read(inputStream);

        BufferedImage scaledImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = scaledImage.createGraphics();
        g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g2d.drawImage(originalImage, 0, 0, width, height, null);
        g2d.dispose();

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        ImageIO.write(scaledImage, "png", outputStream);
        byte[] imageBytes = outputStream.toByteArray();
        return new ByteArrayInputStream(imageBytes);
    }

    public static long encode3DCoordinates(int x, int y, int z) {
        long encodedValue = 0;

        encodedValue |= ((long)x & 0xFFFFFFFFL) << 32;
        encodedValue |= ((long)y & 0xFFFFFFFFL) << 16;
        encodedValue |= ((long)z & 0xFFFFFFFFL);

        return encodedValue;
    }    

    @Deprecated
    public static int coordsToInt(byte x, byte y) {
        int coords = ((x & 0xFF) << 16) | (y & 0xFF);
        return coords;
    }
    
    @Deprecated
    public static byte[] intToCoords(int coords) {
        byte x = (byte) ((coords >> 16) & 0xFF);
        byte y = (byte) (coords & 0xFF);
        return new byte[] {x, y};
    }

    public static record Point3D(int x, int y, int z) {}
    public static Point3D decode3DCoordinates(long encodedValue) {
        int x = (int) (encodedValue >> 32);
        int y = (int) ((encodedValue >> 16) & 0xFFFF);
        int z = (int) (encodedValue & 0xFFFF);

        return new Point3D(x, y, z);
    }

    /**
     * @see https://github.com/BluSunrize/ImmersiveEngineering/blob/1.19.2/src/main/java/blusunrize/immersiveengineering/common/util/orientation/RotationUtil.java#L28
     */
    public static boolean rotateBlock(class_1937 world, class_2338 pos, class_2470 rotation) {

        class_2680 state = world.method_8320(pos);
        class_2680 newState = state.method_26186(rotation);
        if (newState != state) {
            world.method_8501(pos, newState);
            for (class_2350 d : class_2741.field_12481.method_11898()) {
                final class_2338 otherPos = pos.method_10093(d);
                final class_2680 otherState = world.method_8320(otherPos);
                final class_2680 nextState = newState.method_26191(d, otherState, world, pos, otherPos);
                if (nextState != newState) {
                    if (!nextState.method_26215()) {
                        world.method_8501(pos, nextState);
                        newState = nextState;
                    } else {
                        world.method_8501(pos, state);
                        return false;
                    }
                }
            }
            for (class_2350 d : class_2741.field_12481.method_11898()) {
                final class_2338 otherPos = pos.method_10093(d);
                final class_2680 otherState = world.method_8320(otherPos);
                final class_2680 nextOther = otherState.method_26191(d.method_10153(), newState, world, otherPos, pos);
                if (nextOther != otherState)
                    world.method_8501(otherPos, nextOther);
            }
            return true;
        } else
            return false;
    }

    public static <T> void doIfNotNull(T obj, Consumer<T> action) {
        if (obj != null) {
            action.accept(obj);
        }
    }

    public static <T> void doIfNull(T obj, Runnable action) {
        if (obj == null) {
            action.run();
        }
    }

    public boolean isSectionInChunk(class_4076 section, class_1923 chunk) {
        return section.method_10263() == chunk.field_9181 && section.method_10260() == chunk.field_9180;
    }

    public class_1923 getChunkOfSection(class_4076 section) {
        return new class_1923(section.method_10263(), section.method_10260());
    }

    public static boolean isValidURL(String urlString) {
        try {
            URL url = new URL(urlString);
            url.toURI();
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
