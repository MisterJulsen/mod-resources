package de.mrjulsen.mcdragonlib.client.gui.widgets.base;

import net.minecraft.class_1703;
import net.minecraft.class_3936;

public abstract class DLMenuWindow<M extends class_1703> extends DLWindow implements class_3936<M> {

    protected final M menu;

    public DLMenuWindow(Class<M> menuType, DLWindowManager manager) {
        super(manager);
        if (menuType == null) {
            throw new IllegalArgumentException("No menu type defined.");
        }
        if (!manager.supportsMenus()) {
            throw new IllegalArgumentException("The current window manager doesn't support menus.");
        }
        if (!menuType.isInstance(getWindowManager().method_17577())) {
            throw new IllegalArgumentException("The provided menu type is not supported by the current window manager. Expected: " + manager.method_17577().getClass().getSimpleName() + ", Provided: " + menuType.getSimpleName());
        }
        this.menu = menuType.cast(manager.method_17577());
    }

    @Override
    public final M method_17577() {
        return menu;
    }
    
}
