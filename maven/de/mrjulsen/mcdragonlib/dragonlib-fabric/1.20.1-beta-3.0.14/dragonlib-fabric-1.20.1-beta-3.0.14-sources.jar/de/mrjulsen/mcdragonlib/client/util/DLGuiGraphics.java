package de.mrjulsen.mcdragonlib.client.util;

import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597.class_4598;

public record DLGuiGraphics(class_332 graphics, class_4587 poseStack, class_327 defaultFont, float partialTick) {

    public class_4598 bufferSource() {
        return  graphics().method_51450();
    }

    public class_4588 vertexConsumer(class_2960 textureLocation) {
        return graphics().method_51450().getBuffer(class_1921.method_23028(textureLocation));
    }

    public class_4588 vertexConsumer() {
        return graphics().method_51450().getBuffer(class_1921.method_23028(RenderUtils.BLANK_TEXTURE_LOCATION));
    }
}
