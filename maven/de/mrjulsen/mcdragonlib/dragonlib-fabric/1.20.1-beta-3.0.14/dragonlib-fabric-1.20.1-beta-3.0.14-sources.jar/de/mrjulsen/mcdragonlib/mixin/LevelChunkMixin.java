package de.mrjulsen.mcdragonlib.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import de.mrjulsen.mcdragonlib.block.IBlockEntityExtension;
import net.minecraft.class_2586;
import net.minecraft.class_2818;

@Mixin(class_2818.class)
public class LevelChunkMixin {
    @Inject(method = "clearAllBlockEntities", at = @At(value = "HEAD"))
    public void dragonlib$onClearAllBlockEntities(CallbackInfo ci) {   
        class_2818 self = (class_2818)(Object)this;
        for (class_2586 be : self.method_12214().values()) {
            if (be instanceof IBlockEntityExtension bext) {
                bext.dragonlib$onChunkUnloaded();
            }
        }
    }
    
    @Inject(method = "addAndRegisterBlockEntity", at = @At(value = "INVOKE", shift = Shift.AFTER, target = "Lnet/minecraft/world/level/chunk/LevelChunk;updateBlockEntityTicker(Lnet/minecraft/world/level/block/entity/BlockEntity;)V"))
    public void dragonlib$onAddAndRegisterBlockEntity(class_2586 blockEntity, CallbackInfo ci) {   
        class_2818 self = (class_2818)(Object)this;
        for (class_2586 be : self.method_12214().values()) {
            if (be instanceof IBlockEntityExtension bext) {
                bext.dragonlib$onBlockEntityLoad();
            }
        }
    }
}
