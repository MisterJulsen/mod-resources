package de.mrjulsen.mcdragonlib.client.model.mesh;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_2350;
import org.joml.Vector3f;

public class CubeMesh extends Mesh {

    public CubeMesh(Vector3f position) {
        this(position, new Vector3f(1, 1, 1));
    }

    public CubeMesh(Vector3f position, Vector3f size) {
        super(new ArrayList<>(), new ArrayList<>(), Arrays.asList(new Face[6]));
        for (int i = 0; i < class_2350.values().length; i++) {
            class_2350 side = class_2350.method_10143(i);
            Vector3f facePos = new Vector3f(side.method_10163().method_10263(), side.method_10163().method_10264(), side.method_10163().method_10260()).max(new Vector3f());
            Face face = Face.createFace(side, facePos, 1, 1);
            setFace(side, face);
        }
        cleanUp();
        scale(size, new Vector3f());
        translate(position);
    }

    @Override
    protected void replaceFaces(List<Face> other) {
        for (int i = 0; i < other.size() && i < faces.size(); i++) {
            faces.set(i, other.get(i));
        }
        
    }

    protected void setFace(class_2350 direction, Face face) {
        faces.set(direction.method_10146(), face);
        edges.addAll(face.getEdges());
        for (FaceVertex wrapper : face.getCorners()) {
            vertices.add(wrapper.getVertex());
        }
    }

    public Face removeFace(class_2350 direction) {
        Map<Vertex, Vertex> replacements = new HashMap<>(4);
        Face face = faces.get(direction.method_10146());
        faces.set(direction.method_10146(), null);
        for (FaceVertex wrapper : face.getCorners()) {
            Vertex current = wrapper.getVertex();
            Vertex copy = current.copy();
            wrapper.updateVertex(copy);
            replacements.put(current, copy);
        }        
        face.updateEdges(x -> x.copy(y -> replaceFunc(replacements, y)));
        return face;
    }

    public Face getFaceOnSide(class_2350 direction) {
        return faces.get(direction.method_10146());
    }
}
