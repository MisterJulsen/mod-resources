package de.mrjulsen.mcdragonlib.client.gui.widgets.richtext.action;

import java.net.URI;
import net.minecraft.class_156;
import net.minecraft.class_2561;

public class UrlClickAction implements ClickAction, TooltipAction {
    private final String url;

    public UrlClickAction(String url) {
        this.url = url;
    }

    @Override
    public void onClick() {
        try {
            class_156.method_668().method_673(new URI(url));
        } catch (Exception e) {
            System.err.println("Failed to open URL: " + url);
            e.printStackTrace();
        }
    }

    @Override
    public class_2561 getTooltip() {
        return class_2561.method_43470(this.url);
    }

    public String getUrl() {
        return url;
    }
}
