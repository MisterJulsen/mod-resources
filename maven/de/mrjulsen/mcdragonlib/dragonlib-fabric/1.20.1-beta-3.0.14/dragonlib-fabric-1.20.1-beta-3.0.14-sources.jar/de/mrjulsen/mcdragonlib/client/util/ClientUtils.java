package de.mrjulsen.mcdragonlib.client.util;

import net.minecraft.class_310;
import net.minecraft.class_4076;
import net.minecraft.class_4587;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

public final class ClientUtils {
    private ClientUtils() {}
    
    public static void setSectionDirty(class_4076 pos) {
        class_310.method_1551().execute(() -> {            
            class_310.method_1551().field_1769.method_8571(pos.method_10263(), pos.method_10264(), pos.method_10260());
        });
    }

    public static void resetTranslation(class_4587 poseStack) {
        class_4587.class_4665 currentPose = poseStack.method_23760();
        Matrix4f matrix = currentPose.method_23761();
        matrix.m30(0);
        matrix.m31(0);
        matrix.m32(0);
    }

    public static void resetRotation(class_4587 poseStack) {
        class_4587.class_4665 currentPose = poseStack.method_23760();
        Matrix4f matrix = currentPose.method_23761();
    
        Vector3f translation = new Vector3f();
        matrix.getTranslation(translation);
        Vector3f scale = new Vector3f();
        matrix.getScale(scale);
        
        matrix.identity();
        matrix.translate(translation);
        matrix.scale(scale);
    }
    
    public static void resetScale(class_4587 poseStack) {
        class_4587.class_4665 currentPose = poseStack.method_23760();
        Matrix4f matrix = currentPose.method_23761();

        Vector3f translation = new Vector3f();
        matrix.getTranslation(translation);
        Quaternionf rotation = new Quaternionf();
        matrix.getUnnormalizedRotation(rotation);

        matrix.identity();
        matrix.translate(translation);
        matrix.rotate(rotation);
    }
}
