package de.mrjulsen.mcdragonlib.internal;

import de.mrjulsen.mcdragonlib.DragonLib;
import de.mrjulsen.mcdragonlib.menu.PlayerInventoryContainerMenu;
import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import net.minecraft.class_1703;
import net.minecraft.class_3917;
import net.minecraft.class_3917.class_3918;
import net.minecraft.class_7701;
import net.minecraft.class_7924;

public class ModMenuTypes {
    public static final DeferredRegister<class_3917<?>> MENUS = DeferredRegister.create(DragonLib.MODID, class_7924.field_41207);
    public static final RegistrySupplier<class_3917<PlayerInventoryContainerMenu.Base>> PLAYER_INVENTORY = registerMenuType(PlayerInventoryContainerMenu.Base::new, "player_inventory");

    private static <T extends class_1703>RegistrySupplier<class_3917<T>> registerMenuType(class_3918<T> factory, String name) {
        return MENUS.register(name, () -> new class_3917<T>(factory, class_7701.field_40183));
    }

    public static void register() {
        MENUS.register();
    }

}