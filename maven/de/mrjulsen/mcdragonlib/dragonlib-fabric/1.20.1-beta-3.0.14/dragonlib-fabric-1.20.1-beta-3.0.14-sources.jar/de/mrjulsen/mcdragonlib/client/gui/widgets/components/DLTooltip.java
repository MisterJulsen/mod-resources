package de.mrjulsen.mcdragonlib.client.gui.widgets.components;

import java.util.List;
import net.minecraft.class_5348;
import de.mrjulsen.mcdragonlib.client.util.DLGuiGraphics;
import de.mrjulsen.mcdragonlib.client.util.GuiUtils;

public record DLTooltip(List<? extends class_5348> lines, int maxWidth) {

    public static final DLTooltip EMPTY = new DLTooltip(List.of(), 100);

    public void render(DLGuiGraphics graphics, int x, int y) {
        GuiUtils.drawTooltip(graphics, graphics.defaultFont(), x, y, lines(), maxWidth());
    }    
}
