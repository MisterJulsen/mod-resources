package de.mrjulsen.mcdragonlib.data;

import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import net.minecraft.class_2487;
import net.minecraft.class_2499;

public class ReadOnlyCompoundTag {
    private final class_2487 delegate;

    public ReadOnlyCompoundTag(class_2487 delegate) {
        this.delegate = delegate;
    }

    public Set<String> getAllKeys() {
        return delegate.method_10541();
    }

    public Optional<Byte> getByte(String key) {
        return delegate.method_10573(key, 99)
                ? Optional.of(delegate.method_10571(key))
                : Optional.empty();
    }

    public Optional<Short> getShort(String key) {
        return delegate.method_10573(key, 99)
                ? Optional.of(delegate.method_10568(key))
                : Optional.empty();
    }

    public Optional<Integer> getInt(String key) {
        return delegate.method_10573(key, 99)
                ? Optional.of(delegate.method_10550(key))
                : Optional.empty();
    }

    public Optional<Long> getLong(String key) {
        return delegate.method_10573(key, 99)
                ? Optional.of(delegate.method_10537(key))
                : Optional.empty();
    }

    public Optional<Float> getFloat(String key) {
        return delegate.method_10573(key, 99)
                ? Optional.of(delegate.method_10583(key))
                : Optional.empty();
    }

    public Optional<Double> getDouble(String key) {
        return delegate.method_10573(key, 99)
                ? Optional.of(delegate.method_10574(key))
                : Optional.empty();
    }

    public Optional<String> getString(String key) {
        return delegate.method_10573(key, 8)
                ? Optional.of(delegate.method_10558(key))
                : Optional.empty();
    }

    public Optional<byte[]> getByteArray(String key) {
        return delegate.method_10573(key, 7)
                ? Optional.of(delegate.method_10547(key))
                : Optional.empty();
    }

    public Optional<int[]> getIntArray(String key) {
        return delegate.method_10573(key, 11)
                ? Optional.of(delegate.method_10561(key))
                : Optional.empty();
    }

    public Optional<long[]> getLongArray(String key) {
        return delegate.method_10573(key, 12)
                ? Optional.of(delegate.method_10565(key))
                : Optional.empty();
    }

    public Optional<UUID> getUUID(String key) {
        return delegate.method_25928(key)
                ? Optional.of(delegate.method_25926(key))
                : Optional.empty();
    }

    public Optional<Boolean> getBoolean(String key) {
        return delegate.method_10573(key, 99)
                ? Optional.of(delegate.method_10577(key))
                : Optional.empty();
    }

    public Optional<ReadOnlyCompoundTag> getCompound(String key) {
        return delegate.method_10573(key, 10)
                ? Optional.of(new ReadOnlyCompoundTag(delegate.method_10562(key)))
                : Optional.empty();
    }

    public Optional<class_2499> getList(String key, int tagType) {
        return delegate.method_10540(key) == 9
                ? Optional.of(delegate.method_10554(key, tagType))
                : Optional.empty();
    }

    public boolean isEmpty() {
        return delegate.method_33133();
    }

    @Override
    public String toString() {
        return delegate.toString();
    }
}

