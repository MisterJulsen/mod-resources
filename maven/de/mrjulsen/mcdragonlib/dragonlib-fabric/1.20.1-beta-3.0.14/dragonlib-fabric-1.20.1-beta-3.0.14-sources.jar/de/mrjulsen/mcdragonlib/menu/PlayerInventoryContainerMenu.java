package de.mrjulsen.mcdragonlib.menu;

import de.mrjulsen.mcdragonlib.DragonLib;
import de.mrjulsen.mcdragonlib.internal.ModMenuTypes;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_3914;
import net.minecraft.class_3917;

public abstract class PlayerInventoryContainerMenu extends class_1703 {

    public final class_3914 access;

    public PlayerInventoryContainerMenu(class_3917<?> type, int containerId, class_1661 inv) {
        this(type, containerId, inv, class_3914.field_17304);
    }

    public PlayerInventoryContainerMenu(class_3917<?> type, int containerId, class_1661 inv, final class_3914 access) {
        super(type, containerId);
        this.access = access;

        addPlayerInventory(inv);
        addPlayerHotbar(inv);
    }
    
    protected void addPlayerInventory(class_1661 playerInventory) {
        for (int i = 0; i < 3; ++i) {
            for (int l = 0; l < 9; ++l) {
                this.method_7621(new class_1735(playerInventory, l + i * 9 + 9, 0, 0));
            }
        }
    }

    protected void addPlayerHotbar(class_1661 playerInventory) {
        for (int i = 0; i < 9; ++i) {
            this.method_7621(new class_1735(playerInventory, i, 0, 0));
        }
    }



    public static class Base extends PlayerInventoryContainerMenu {
        public Base(int containerId, class_1661 inv) {
            this(containerId, inv, class_3914.field_17304);
        }        

        public Base(int containerId, class_1661 inv, final class_3914 access) {
            super(ModMenuTypes.PLAYER_INVENTORY.get(), containerId, inv, access);
        }        

        @Override
        public boolean method_7597(class_1657 player) {
            return method_17695(this.access, player, DragonLib.DRAGON_BLOCK.get());
        }
        
        @Override
        public class_1799 method_7601(class_1657 player, int index) {
            class_1799 itemstack = class_1799.field_8037;
            class_1735 slot = this.field_7761.get(index);

            if (slot != null && slot.method_7681()) {
                class_1799 stackInSlot = slot.method_7677();
                itemstack = stackInSlot.method_7972();

                if (index < 9) {
                    if (!this.method_7616(stackInSlot, 9, 36, false)) {
                        return class_1799.field_8037;
                    }
                }
                
                else if (index < 36) {
                    if (!this.method_7616(stackInSlot, 0, 9, false)) {
                        return class_1799.field_8037;
                    }
                }

                if (stackInSlot.method_7960()) {
                    slot.method_48931(class_1799.field_8037);
                } else {
                    slot.method_7668();
                }

                if (stackInSlot.method_7947() == itemstack.method_7947()) {
                    return class_1799.field_8037;
                }

                slot.method_7667(player, stackInSlot);
            }

            return itemstack;
        }
        
    }
}
