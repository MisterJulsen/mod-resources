package de.mrjulsen.mcdragonlib.client.gui.widgets.util;

import de.mrjulsen.mcdragonlib.client.gui.widgets.base.DLGuiComponent;
import net.minecraft.class_2561;

@FunctionalInterface
public interface ITextFormatter<T extends DLGuiComponent> {
    class_2561 combine(T src);
}
