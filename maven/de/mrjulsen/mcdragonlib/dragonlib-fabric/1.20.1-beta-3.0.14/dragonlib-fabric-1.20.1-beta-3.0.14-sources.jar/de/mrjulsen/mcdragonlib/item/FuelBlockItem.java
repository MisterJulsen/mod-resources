package de.mrjulsen.mcdragonlib.item;

import dev.architectury.registry.fuel.FuelRegistry;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_3956;

public class FuelBlockItem extends class_1747 {

	private int burnTime = 0;

	public FuelBlockItem(class_2248 block, class_1793 properties) {
		super(block, properties);
	}

    public void setBurnTime(int burnTime) {
		FuelRegistry.register(burnTime, this);
		this.burnTime = burnTime;
	}

	public int getBurnTime(class_1799 itemStack, class_3956<?> recipeType) {
		return this.burnTime;
	}
    
}
