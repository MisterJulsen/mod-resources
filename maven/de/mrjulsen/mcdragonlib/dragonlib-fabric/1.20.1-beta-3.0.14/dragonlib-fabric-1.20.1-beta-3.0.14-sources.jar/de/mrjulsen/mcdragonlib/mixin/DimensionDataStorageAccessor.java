package de.mrjulsen.mcdragonlib.mixin;

import java.io.File;
import net.minecraft.class_26;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_26.class)
public interface DimensionDataStorageAccessor {
    @Invoker("getDataFile")
    File dragonlib$getDataFile(String name);
}
