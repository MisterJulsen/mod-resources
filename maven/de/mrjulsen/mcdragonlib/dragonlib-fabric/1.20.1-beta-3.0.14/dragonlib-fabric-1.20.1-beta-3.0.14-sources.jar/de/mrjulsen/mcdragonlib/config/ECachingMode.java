package de.mrjulsen.mcdragonlib.config;

import java.util.Arrays;
import net.minecraft.class_3542;

public enum ECachingMode implements class_3542 {
    NORMAL(0, "normal"),
    REDUCED(1, "reduced"),
    MINIMAL(2, "minimal"),
    OFF(3, "off");

    int idx;
    String name;

    ECachingMode(int idx, String name) {
        this.idx = idx;
        this.name = name;
    }

    public int getIndex() {
        return idx;
    }

    public String getName() {
        return name;
    }

    @Override
    public String method_15434() {
        return name;
    }

    public static ECachingMode getByIndex(int index) {
        return Arrays.stream(values()).filter(x -> x.getIndex() == index).findFirst().orElse(NORMAL);
    }
}
