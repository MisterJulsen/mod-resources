package de.mrjulsen.mcdragonlib.util.collision;

import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_243;

public class RaycastHitResult extends class_239 implements Comparable<RaycastHitResult> {
    private final class_2338 blockPos;
    private final float distance;
    private final Object hitData;

    public RaycastHitResult(class_243 location, class_2338 blockPos, float distance, Object hitData) {
        super(location);
        this.blockPos = blockPos;
        this.distance = distance;
        this.hitData = hitData;
    }

    public class_2338 getBlockPos() {
        return blockPos;
    }

    public float getDistance() {
        return distance;
    }

    public Object getHitData() {
        return hitData;
    }

    @Override
    public int compareTo(RaycastHitResult other) {
        return Float.compare(getDistance(), other.getDistance());
    }

    @Override
    public class_240 method_17783() {
        return class_240.field_1332;
    }
}
