package de.mrjulsen.mcdragonlib.mixin;

import java.util.Map;
import net.minecraft.class_1044;
import net.minecraft.class_1060;
import net.minecraft.class_2960;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import dev.architectury.injectables.annotations.PlatformOnly;

/** Fixes fabric */
@Mixin(class_1060.class)
public class TextureManagerMixin {

    @Final
    @Shadow
    private Map<class_2960, class_1044> byPath;

    @PlatformOnly(value = PlatformOnly.FABRIC)
    @Inject(method = "release", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/texture/TextureManager;safeClose(Lnet/minecraft/resources/ResourceLocation;Lnet/minecraft/client/renderer/texture/AbstractTexture;)V", shift = Shift.BEFORE))
    public void dragonlib$release(class_2960 path, CallbackInfo ci) {
        this.byPath.remove(path);
    }
}
