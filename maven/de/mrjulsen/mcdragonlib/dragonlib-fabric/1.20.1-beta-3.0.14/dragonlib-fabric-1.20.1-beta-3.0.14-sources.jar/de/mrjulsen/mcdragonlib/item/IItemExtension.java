package de.mrjulsen.mcdragonlib.item;

import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import org.jetbrains.annotations.Nullable;

public interface IItemExtension {
    /**
     * Invoked every tick when this item is equipped.
     * @param stack the item stack
     * @param player the player wearing the armor
     */
    default void dragonlib$tickArmor(class_1799 stack, class_1657 player) {
    }
    
    /**
     * Returns the {@link class_1304} for {@link class_1799}.
     * @param stack the item stack
     * @return the {@link class_1304}, return {@code null} to default to vanilla's {@link net.minecraft.class_1308#method_32326(class_1799)}
     */
    @Nullable
    default class_1304 dragonlib$getCustomEquipmentSlot(class_1799 stack) {
        return null;
    }
}