package de.mrjulsen.mcdragonlib.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import it.unimi.dsi.fastutil.ints.IntList;
import net.minecraft.class_293;

@Mixin(class_293.class)
public interface VertexFormatAccessor {
    
    @Accessor("offsets")
    abstract IntList dragonlib$getOffsets();
}
