package de.mrjulsen.mcdragonlib.client.gui.widgets.base;

import java.nio.file.Path;
import java.util.List;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_465;
import de.mrjulsen.mcdragonlib.client.util.DLGuiGraphics;

public class DLContainerScreen<M extends class_1703> extends class_465<M> {

    private final DLWindowManager root;
    
    public <T extends DLWindow> DLContainerScreen(M menu, class_1661 playerInventory, class_2561 title, WindowBuilder<T> window) {
        super(menu, playerInventory, title);
        final class_437 previousScreen = class_310.method_1551().field_1755;
        this.root = new DLWindowManager(menu, window, field_22789, field_22790, (mgr) -> {
            class_310.method_1551().method_1507(mgr.shouldShowPreviousScreenOnClose() ? previousScreen : null);
        });
    }

    public DLWindowManager getWindowManager() {
        return root;
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        root.updateLayout(field_22789, field_22790);
    }

    @Override
    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        DLGuiGraphics graphics = new DLGuiGraphics(guiGraphics, guiGraphics.method_51448(), class_310.method_1551().field_1772, partialTick);
        method_25420(guiGraphics);
        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);
        root.render(graphics, mouseX, mouseY);
    }

    @Override
    protected void method_37432() {
        super.method_37432();
        root.tick();
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        return root.mouseClicked(mouseX, mouseY, button) || super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public void method_16014(double mouseX, double mouseY) {
        boolean b = root.mouseMoved(mouseX, mouseY);
        if (!b) {
            super.method_16014(mouseX, mouseY);
        }
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        return root.mouseReleased(mouseX, mouseY, button) || super.method_25406(mouseX, mouseY, button);
    }

    public boolean onScroll(double mouseX, double mouseY, double scrollX, double scrollY) {
        return root.mouseScrolled(mouseX, mouseY, scrollX, scrollY) || super.method_25401(mouseX, mouseY, scrollY);
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double dragX, double dragY) {
        return root.mouseDragged(mouseX, mouseY, button, dragX, dragY) || super.method_25403(mouseX, mouseY, button, dragX, dragY);
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        return root.keyPressed(keyCode, scanCode, modifiers) || super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_16803(int keyCode, int scanCode, int modifiers) {
        return root.keyReleased(keyCode, scanCode, modifiers) || super.method_16803(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_25400(char codePoint, int modifiers) {
        return root.charTyped(codePoint, modifiers) || super.method_25400(codePoint, modifiers);
    }

    @Override
    public void method_29638(List<Path> paths) {
        boolean b = root.onFilesDrop(paths);
        if (!b) {
            super.method_29638(paths);
        }
    }

    @Override
    public void method_25419() {
        root.onClose();
        super.method_25419();
    }

    @Override
    public boolean method_25421() {
        return root.isPauseScreen();
    }

    @Override
    protected final void method_2389(class_332 guiGraphics, float partialTick, int mouseX, int mouseY) {
        DLGuiGraphics graphics = new DLGuiGraphics(guiGraphics, guiGraphics.method_51448(), class_310.method_1551().field_1772, partialTick);
        renderBg(graphics, mouseX, mouseY);
    }

    protected void renderBg(DLGuiGraphics guiGraphics, int mouseX, int mouseY) {
    }
}
