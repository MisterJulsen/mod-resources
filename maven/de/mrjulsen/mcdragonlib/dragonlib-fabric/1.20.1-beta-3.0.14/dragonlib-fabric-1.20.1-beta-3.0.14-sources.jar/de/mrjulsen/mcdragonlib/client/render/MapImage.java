package de.mrjulsen.mcdragonlib.client.render;

import com.mojang.blaze3d.systems.RenderSystem;

import de.mrjulsen.mcdragonlib.client.util.DLGuiGraphics;
import de.mrjulsen.mcdragonlib.client.util.GuiUtils;
import de.mrjulsen.mcdragonlib.client.util.GuiUtils.TextureFillMode;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_241;
import net.minecraft.class_2680;
import net.minecraft.class_2902;
import net.minecraft.class_3620;

public class MapImage {
    
    private final class_1937 world;
    private final class_2338 pos;
    private final int yLevel;

    private final int areaWidth, areaHeight;
    private final class_241 centerPosOnMap;
    private final boolean sameLayer;

    private int scale;

    private class_1043 texture;

    public MapImage(class_1937 world, class_2338 pos, int yLevel, int width, int height, boolean sameLayer, int scale) {
        this.world = world;
        this.pos = pos;
        this.yLevel = yLevel;
        this.areaWidth = width;
        this.areaHeight = height;
        this.sameLayer = sameLayer;
        this.scale = scale;
        this.centerPosOnMap = new class_241(areaWidth / 2, areaHeight / 2);
    }

    public void bindTexture() {
        if (this.texture == null)
            this.texture = new class_1043(this.createImage());
        RenderSystem.setShaderTexture(0, this.texture.method_4624());
    }

    public void render(DLGuiGraphics graphics, int x, int y) {
        bindTexture();
        GuiUtils.drawTexture(this.texture.method_4624(), graphics, x, y, areaWidth * scale, areaHeight * scale, 0, 0, areaWidth, areaHeight, TextureFillMode.STRETCH, areaWidth, areaHeight);
    }

    public int getWidth() {
        return areaWidth;
    }

    public int getHeight() {
        return areaHeight;
    }

    public void setScale(int scale) {
        this.scale = scale;
    }

    public int getScale() {
        return scale;
    }

    public int getScaledWidth() {
        return getWidth() * getScale();
    }

    public int getScaledHeight() {
        return getHeight() * getScale();
    }

    public class_241 getCenterPosOnMap() {
        return centerPosOnMap;
    }

    public void dispose() {
        if (this.texture != null) {
            this.texture.close();
            this.texture = null;
        }
    }

    private class_1011 createImage() {
        class_1011 image = new class_1011(class_1011.class_1012.field_4997, areaWidth, areaHeight, false);
        int rWidth = areaWidth / 2;
        int rHeight = areaHeight / 2;
        int minX = pos.method_10263() - rWidth;
        int minZ = pos.method_10260() - rHeight;

        for (int x = 0; x < areaWidth; x++) {
            for (int z = 0; z < areaHeight; z++) {
                class_2338 pos;
                int northY, westY;
                if (this.shouldDrawAtSameLayer()) {
                    pos = this.getFirstBlockGoingDown(minX + x, this.yLevel + 1, minZ + z, 5);
                    northY = this.getFirstBlockGoingDown(minX + x, this.yLevel + 1, minZ + z - 1, 6).method_10264();
                    westY = this.getFirstBlockGoingDown(minX + x - 1, this.yLevel + 1, minZ + z, 6).method_10264();
                } else {
                    pos = this.world.method_8598(class_2902.class_2903.field_13202, new class_2338(minX + x, 0, minZ + z))
                            .method_10074();
                    northY = this.world.method_8624(class_2902.class_2903.field_13202, pos.method_10263(), pos.method_10260() - 1) - 1;
                    westY = this.world.method_8624(class_2902.class_2903.field_13202, pos.method_10263() - 1, pos.method_10260()) - 1;
                }

                class_2680 state = this.world.method_8320(pos);
                class_3620 color = state.method_26205(this.world, pos);
                // Apparently blocks can return null map color #66
                int rgb = color == null ? class_3620.field_16008.field_16011 : color.field_16011;

                int red = ((rgb >> 16) & 255);
                int green = ((rgb >> 8) & 255);
                int blue = (rgb & 255);

                if ((pos.method_10264() > northY && northY >= 0) || (pos.method_10264() > westY && westY >= 0)) {
                    if (red == 0 && green == 0 && blue == 0) {
                        red = 3;
                        green = 3;
                        blue = 3;
                    } else {
                        if (red > 0 && red < 3)
                            red = 3;
                        if (green > 0 && green < 3)
                            green = 3;
                        if (blue > 0 && blue < 3)
                            blue = 3;
                        red = Math.min((int) (red / 0.7), 255);
                        green = Math.min((int) (green / 0.7), 255);
                        blue = Math.min((int) (blue / 0.7), 255);
                    }
                }
                if ((pos.method_10264() < northY && northY >= 0) || (pos.method_10264() < westY && westY >= 0)) {
                    red = Math.max((int) (red * 0.7), 0);
                    green = Math.max((int) (green * 0.7), 0);
                    blue = Math.max((int) (blue * 0.7), 0);
                }

                image.method_4305(x, z, (255 << 24) | (blue << 16) | (green << 8) | red);
            }
        }

        return image;
    }

    private class_2338 getFirstBlockGoingDown(int x, int y, int z, int maxTries) {
        class_2338.class_2339 pos = new class_2338.class_2339(x, y, z);
        int tries = 0;
        while (this.world.method_22347(pos) && ++tries < maxTries)
            pos.method_33098(pos.method_10264() - 1);

        return pos;
    }

    private boolean shouldDrawAtSameLayer() {
        return sameLayer || this.world.method_8597().comp_643();
    }
}
