package de.mrjulsen.mcdragonlib.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import de.mrjulsen.mcdragonlib.client.DLOverlayManager;
import de.mrjulsen.mcdragonlib.client.gui.widgets.base.DLScreen;
import net.minecraft.class_310;
import net.minecraft.class_312;
import net.minecraft.class_437;

/*
 * Temp Fix for versions older than 1.21 which adds scrollX
 */
@Mixin(class_312.class)
public abstract class MouseHandlerMixin {

    @Unique
    private double xScrollOffset;
    
    @Inject(method = "onScroll", at = @At(value = "HEAD"))
    private void dragonlib$onScroll(long windowPointer, double xOffset, double yOffset, CallbackInfo ci) {
        if (windowPointer == class_310.method_1551().method_22683().method_4490()) {
            boolean discreteMouseScroll = (Boolean)class_310.method_1551().field_1690.method_42439().method_41753();
            double sensitiviy = (Double)class_310.method_1551().field_1690.method_41806().method_41753();
            xScrollOffset = (discreteMouseScroll ? Math.signum(xOffset) : xOffset) * sensitiviy;
        }
    }
    
    @Inject(method = "onMove", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/screens/Screen;wrapScreenError(Ljava/lang/Runnable;Ljava/lang/String;Ljava/lang/String;)V", shift = Shift.BEFORE, ordinal = 0), locals = LocalCapture.CAPTURE_FAILHARD)
    private void dragonlib$onMove(long windowPointer, double x, double y, CallbackInfo ci, class_437 screen, double mx, double my) {
        if (windowPointer == class_310.method_1551().method_22683().method_4490()) {
            DLOverlayManager.mouseMoved(mx, my);
        }
    }

    @Redirect(method = "onScroll", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/screens/Screen;mouseScrolled(DDD)Z"))
    private boolean dragonlib$onScroll(class_437 screen, double mouseX, double mouseY, double delta) {
        if (screen instanceof DLScreen dlScreen) {
            return dlScreen.onScroll(mouseX, mouseY, xScrollOffset, delta);
        }
        return screen.method_25401(mouseX, mouseY, delta) ? false : DLOverlayManager.mouseScrolled(mouseX, mouseY, xScrollOffset, delta);
    }
}
