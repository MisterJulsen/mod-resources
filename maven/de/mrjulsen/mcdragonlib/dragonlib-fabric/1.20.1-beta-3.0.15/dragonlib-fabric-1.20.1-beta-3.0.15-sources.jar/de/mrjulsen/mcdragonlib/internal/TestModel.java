package de.mrjulsen.mcdragonlib.internal;

import de.mrjulsen.mcdragonlib.client.model.ModelContext;
import de.mrjulsen.mcdragonlib.client.model.mesh.BasicMesh;
import de.mrjulsen.mcdragonlib.client.model.mesh.DLModel;
import de.mrjulsen.mcdragonlib.client.model.mesh.Mesh;
import net.minecraft.class_1087;
import net.minecraft.class_2246;
import net.minecraft.class_2680;
import net.minecraft.class_5819;

public class TestModel extends DLModel {

    @Override
    protected Mesh getMesh(ModelType type, class_1087 originalModel, class_2680 state, class_5819 random, ModelContext context) {
        Mesh mesh = BasicMesh.fromBlock(class_2246.field_16330.method_9564(), random);
        return mesh;
    }
    
}
