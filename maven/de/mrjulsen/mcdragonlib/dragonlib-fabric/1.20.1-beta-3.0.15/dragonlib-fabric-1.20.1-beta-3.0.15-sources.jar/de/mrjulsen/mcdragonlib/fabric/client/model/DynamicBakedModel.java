package de.mrjulsen.mcdragonlib.fabric.client.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Supplier;

import de.mrjulsen.mcdragonlib.client.model.ICustomModelBlockEntity;
import de.mrjulsen.mcdragonlib.client.model.IDynamicBakedModel;
import de.mrjulsen.mcdragonlib.client.model.ModelContext;
import de.mrjulsen.mcdragonlib.client.model.mesh.DLModel;
import de.mrjulsen.mcdragonlib.client.model.mesh.DLModel.ModelType;
import net.fabricmc.fabric.api.renderer.v1.Renderer;
import net.fabricmc.fabric.api.renderer.v1.RendererAccess;
import net.fabricmc.fabric.api.renderer.v1.material.BlendMode;
import net.fabricmc.fabric.api.renderer.v1.material.MaterialFinder;
import net.fabricmc.fabric.api.renderer.v1.material.RenderMaterial;
import net.fabricmc.fabric.api.renderer.v1.model.ModelHelper;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;
import net.fabricmc.fabric.api.util.TriState;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_1799;
import net.minecraft.class_1920;
import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_5819;
import net.minecraft.class_777;
import net.minecraft.class_806;
import net.minecraft.class_809;

public class DynamicBakedModel implements class_1087, IDynamicBakedModel {
    
	private static final Renderer RENDERER = RendererAccess.INSTANCE.getRenderer();
	
	

    private final class_2680 defaultState;
    private final class_1087 src;
    private final DLModel newModel;

    public DynamicBakedModel(class_1087 src, class_2680 defaultState, DLModel newModel) {
        Objects.requireNonNull(src);
        Objects.requireNonNull(defaultState);
        Objects.requireNonNull(newModel);

        this.src = src;
        this.defaultState = defaultState;
        this.newModel = newModel;
    }

    @Override
    public class_1087 getOriginalModel() {
        return src;
    }

    @Override
    public DLModel getModel() {
        return newModel;
    }

    @Override
    public void emitBlockQuads(class_1920 blockView, class_2680 state, class_2338 pos, Supplier<class_5819> randomSupplier, RenderContext context) {
        ModelContext modelContext = ModelContext.EMPTY;
        if (blockView.method_8321(pos) instanceof ICustomModelBlockEntity be) {
            modelContext = be.getModelContext();
        }
        emitQuads(context, randomSupplier.get(), state, ModelType.BLOCK, modelContext);
    }

    @Override
    public void emitItemQuads(class_1799 stack, Supplier<class_5819> randomSupplier, RenderContext context) {
        emitQuads(context, randomSupplier.get(), defaultState, ModelType.ITEM, ModelContext.EMPTY);
    }

    private void emitQuads(RenderContext context, class_5819 rand, class_2680 state, ModelType type,ModelContext modelContext) {
		final MaterialFinder materialFinder = method_4708() ? RENDERER.materialFinder() : RENDERER.materialFinder().ambientOcclusion(TriState.FALSE);
        Map<class_1921, RenderMaterial> materialByRenderType = new HashMap<>();
        
        for (int i = 0; i <= ModelHelper.NULL_FACE_ID; i++) {
			final class_2350 cullFace = ModelHelper.faceFromIndex(i);

			if (!context.hasTransform() && (type == ModelType.BLOCK && context.isFaceCulled(cullFace))) {
				continue;
			}

            for (class_1921 renderType : newModel.getSupportedRenderTypes()) {
                final List<class_777> quads = newModel.getQuads(type, src, state, rand, renderType, cullFace, modelContext);
                final int count = quads.size();

                for (int j = 0; j < count; j++) {
                    final class_777 q = quads.get(j);
                    context.getEmitter()
                        .fromVanilla(q, materialByRenderType.computeIfAbsent(renderType, x -> materialFinder.blendMode(BlendMode.fromRenderLayer(renderType)).find()), cullFace)
                        .emit();
                }
            }
		}
    }

    @Override
    public boolean isVanillaAdapter() {
        return false;
    }

    @Override
    public List<class_777> method_4707(class_2680 states, class_2350 side, class_5819 rand) {        
        return List.of();
    }

    @Override
    public class_806 method_4710() {
        return src.method_4710();
    }

    @Override
    public class_1058 method_4711() {
        return src.method_4711();
    }

    @Override
    public class_809 method_4709() {
        return src.method_4709();
    }

    @Override
    public boolean method_4713() {
        return src.method_4713();
    }

    @Override
    public boolean method_4712() {
        return src.method_4712();
    }

    @Override
    public boolean method_4708() {
        return newModel.useAmbientOcclusion() == null ? src.method_4708() : newModel.useAmbientOcclusion();
    }

    @Override
    public boolean method_24304() {
        return src.method_24304();
    }
    
}
