package de.mrjulsen.mcdragonlib.network;

import de.mrjulsen.mcdragonlib.data.INBTSerializable;
import de.mrjulsen.mcdragonlib.data.DLStatus;
import java.util.function.Function;
import net.minecraft.class_2487;
import net.minecraft.class_6319;
import net.minecraft.class_6328;

@class_6319
@class_6328
public abstract class NetworkPacketData implements INBTSerializable {

    static final Function<DLStatus, NetworkPacketData> DEFAULT_INSTANCE = (status) -> new NetworkPacketData(status) {
        @Override
        protected void write(class_2487 nbt) {}

        @Override
        protected void read(class_2487 nbt) {}
    };
    
    private static final String NBT_STATUS = "Status";
    private static final String NBT_DATA = "Data";

    private DLStatus status = DLStatus.EMPTY;

    public NetworkPacketData(DLStatus status) {
        this.status = status;
    }

    public final DLStatus getStatus() {
        return status;
    }
    
    final void setStatus(DLStatus status) {
        this.status = status;
    }

    @Override
    public final class_2487 serializeNbt() {
        class_2487 nbt = new class_2487();
        nbt.method_10566(NBT_STATUS, status.toNbt());
        class_2487 data = new class_2487();
        write(data);
        nbt.method_10566(NBT_DATA, data);
        return nbt;
    }

    @Override
    public final void deserializeNbt(class_2487 nbt) {
        this.status = DLStatus.fromNbt(nbt.method_10562(NBT_STATUS));
        read(nbt.method_10562(NBT_DATA));
    }


    protected abstract void write(class_2487 nbt);
    protected abstract void read(class_2487 nbt);



    static final class Empty extends NetworkPacketData {
        public Empty(DLStatus result) {
            super(DLStatus.OK);
        }

        @Override
        protected void write(class_2487 nbt) {
        }

        @Override
        protected void read(class_2487 nbt) {
        }        
    }
}
