package de.mrjulsen.mcdragonlib.fabric.client;

import com.google.common.collect.ImmutableMap;

import de.mrjulsen.mcdragonlib.client.model.DLBlockModelRegistry;
import de.mrjulsen.mcdragonlib.client.model.DLBlockModelRegistry.ModelRegistryData;
import de.mrjulsen.mcdragonlib.events.client.ModelEvents;
import de.mrjulsen.mcdragonlib.events.client.ModelEvents.ModifyModels;
import de.mrjulsen.mcdragonlib.events.client.ModelReplacements;
import de.mrjulsen.mcdragonlib.fabric.client.model.DynamicBakedModel;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.model.loading.v1.ModelLoadingPlugin;
import net.minecraft.class_1087;
import net.minecraft.class_1088;
import net.minecraft.class_1091;
import net.minecraft.class_1100;
import net.minecraft.client.resources.model.*;

@Environment(EnvType.CLIENT)
public class DLModelLoadingPlugin implements ModelLoadingPlugin {

    @Override
    public void onInitializeModelLoader(Context pluginContext) {
        ModelEvents.ADDITIONAL_MODELS.invoker().registerAdditionalModels(e -> pluginContext.addModels(e.comp_2875()));

        ModelReplacements replacements = ModelReplacements.collect();
        if (!replacements.isEmpty()) {
            pluginContext.modifyModelAfterBake().register((original, ctx) -> {
                class_1091 id = ctx.topLevelId();
                if (id == null) {
                    return original;
                }

                class_1087 model = replacements.apply(id, loc -> original, new ModifyModels.Context() {
                    @Override
                    public class_1088 getModelBakery() {
                        return ctx.loader();
                    }

                    @Override
                    public class_1091 getModelLocation() {
                        return id;
                    }

                    @Override
                    public class_1100 getUnbakedModel() {
                        return ctx.sourceModel();
                    }
                });
                return model == null ? original : model;
            });
        }

        ImmutableMap<class_1091, ModelRegistryData> factories = DLBlockModelRegistry.getCustomRegisteredModelsMapped();
        if (!factories.isEmpty()) {
            pluginContext.modifyModelAfterBake().register((original, ctx) -> {
                class_1091 id = ctx.topLevelId();
                if (id == null) {
                    return original;
                }

                ModelRegistryData data = factories.get(id);
                if (data == null) {
                    return original;
                }

                DLBlockModelRegistry.setOriginalModel(data.state(), original);
                return new DynamicBakedModel(original, data.state(), data.factory().getModelFactory().get());
            });
        }
    }
}
