/*
 * DragonLib 3 - 1.21.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.client.gui.v2.widget;

import de.mrjulsen.mcdragonlib.client.gui.v2.GuiComponent;
import de.mrjulsen.mcdragonlib.client.gui.v2.render.DLGuiGraphics;
import de.mrjulsen.mcdragonlib.util.DLUtils;
import net.minecraft.class_310;

public class DLAnimator extends GuiComponent {

    @FunctionalInterface
    public interface IAnimatorRenderCallback {
        void execute(DLGuiGraphics g, float currentTicks, int totalTicks, double percentage);
    }

    @FunctionalInterface
    public interface IAnimatorTickCallback {
        void execute(int currentTicks, int totalTicks, double percentage);
    }

    private int maxTicks;
    private int currentTicks;
    private float currentTicksSmooth;
    private boolean running;

    private IAnimatorRenderCallback onAnimateRender;
    private IAnimatorTickCallback onAnimateTick;
    private Runnable onCompleted;

    public DLAnimator() {
        super(0, 0, 0, 0);
    }

    public boolean isRunning() {
        return running;
    }

    public int getTotalTicks() {
        return maxTicks;
    }

    public int getCurrentIntTicks() {
        return currentTicks;
    }

    public float getCurrentTicks() {
        return currentTicksSmooth;
    }

    public double getPercentage() {
        return 1D / (double)maxTicks * currentTicksSmooth;
    }

    @Override
    protected void render(DLGuiGraphics g, double mouseX, double mouseY) {
        if (!running) {
            return;
        }

        float frameTime = class_310.method_1551().method_60646().method_60638();
        currentTicksSmooth += frameTime;
        DLUtils.doIfNotNull(onAnimateRender, x -> x.execute(g, getCurrentTicks(), getTotalTicks(), getPercentage()));
        if (currentTicks >= maxTicks) {
            stop();
            DLUtils.doIfNotNull(onCompleted, Runnable::run);
        }
    }

    @Override
    public void tick() {
        if (running) {
            DLUtils.doIfNotNull(onAnimateTick, x -> x.execute(getCurrentIntTicks(), getTotalTicks(), getPercentage()));
            currentTicks++;
            currentTicksSmooth = currentTicks;
            if (currentTicks >= maxTicks) {
                currentTicksSmooth = maxTicks;
                stop();
                DLUtils.doIfNotNull(onCompleted, Runnable::run);
            }
        }
    }

    public void start(int ticks, IAnimatorRenderCallback renderCallback, IAnimatorTickCallback tickCallback, Runnable onCompleted) {
        this.currentTicks = 0;
        this.currentTicksSmooth = 0;
        this.maxTicks = ticks;
        this.onAnimateRender = renderCallback;
        this.onAnimateTick = tickCallback;
        this.onCompleted = onCompleted;
        this.running = true;
    }

    public void stop() {
        this.running = false;
        this.currentTicks = 1;
        this.currentTicksSmooth = 1;
        this.maxTicks = 1;
    }
}