/*
 * DragonLib 3 - 1.21.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.network.internal;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeoutException;
import java.util.function.BiFunction;
import java.util.function.Function;
import net.minecraft.class_2535;
import net.minecraft.class_2540;
import de.mrjulsen.mcdragonlib.data.DLStatus;
import de.mrjulsen.mcdragonlib.network.v2.ChannelSession;
import de.mrjulsen.mcdragonlib.network.v2.DLNetwork;
import de.mrjulsen.mcdragonlib.network.v2.NetworkError;
import de.mrjulsen.mcdragonlib.network.v2.NetworkSettings;
import de.mrjulsen.mcdragonlib.network.v2.PacketContext;
import de.mrjulsen.mcdragonlib.network.v2.PacketDefinition;
import de.mrjulsen.mcdragonlib.network.v2.PendingRequest;
import de.mrjulsen.mcdragonlib.network.v2.codec.DLStreamCodec;
import de.mrjulsen.mcdragonlib.network.NetworkDirection;
import de.mrjulsen.mcdragonlib.network.NetworkPacketContext;
import de.mrjulsen.mcdragonlib.network.NetworkPacketData;

@Deprecated
public final class LegacyRequestPacket<I extends NetworkPacketData, O extends NetworkPacketData> extends PacketDefinition {

    private static final byte KIND_REQUEST = 0;
    private static final byte KIND_RESPONSE = 1;

    private static final Map<Integer, PendingRequest> FALLBACK = new ConcurrentHashMap<>();

    private final DLStreamCodec<I> inputCodec;
    private final DLStreamCodec<O> outputCodec;
    private final Function<DLStatus, O> outputFactory;
    private final BiFunction<I, NetworkPacketContext, O> handler;

    public LegacyRequestPacket(Settings settings, Function<DLStatus, I> inputFactory, Function<DLStatus, O> outputFactory, BiFunction<I, NetworkPacketContext, O> handler) {
        super(settings);
        this.inputCodec = LegacyBridge.dataCodec(inputFactory);
        this.outputCodec = LegacyBridge.dataCodec(outputFactory);
        this.outputFactory = Objects.requireNonNull(outputFactory, "outputFactory");
        this.handler = Objects.requireNonNull(handler, "handler");
    }

    public static int getFallbackCount() {
        return FALLBACK.size();
    }

    public void send(NetworkDirection sender, I data, CompletableFuture<O> future) {
        long deadline = System.currentTimeMillis() + NetworkSettings.getResponseTimeoutMillis();
        Pending pending = new Pending(future, deadline);

        int correlationId;
        class_2535 connection = sender.getConnection();
        if (connection != null) {
            ChannelSession session = getChannel().getSession(connection);
            correlationId = session.nextCorrelationId();
            session.addPending(correlationId, pending);
        } else {
            sweepFallback();
            correlationId = LegacyBridge.nextFallbackId();
            FALLBACK.put(correlationId, pending);
        }

        try {
            LegacyBridge.send(getChannel(), this, sender, buf -> {
                buf.method_52997(KIND_REQUEST);
                buf.method_10804(correlationId);
                inputCodec.encode(buf, data);
            });
        } catch (Exception e) {
            removePending(connection, correlationId);
            DLNetwork.LOGGER.error("Could not send {}.", this, e);
            pending.fail(NetworkError.of(NetworkError.Reason.MALFORMED, "The request could not be sent."));
        }
    }

    @Override
    protected void receive(PacketContext context, class_2540 payload) {
        byte kind = payload.readByte();
        int correlationId = payload.method_10816();
        if (kind == KIND_REQUEST) {
            receiveRequest(context, correlationId, payload);
        } else {
            receiveResponse(context, correlationId, payload);
        }
    }

    private void receiveRequest(PacketContext context, int correlationId, class_2540 payload) {
        I request;
        try {
            request = inputCodec.decode(payload);
        } catch (Exception e) {
            DLNetwork.LOGGER.error("Could not decode a request for {}.", this, e);
            respond(context, correlationId, outputFactory.apply(DLStatus.error(e)));
            return;
        }

        NetworkPacketContext legacyContext = LegacyBridge.adapt(context);
        LegacyBridge.handlerExecutionMode(this).run(context, () -> {
            O result;
            try {
                result = handler.apply(request, legacyContext);
            } catch (Exception e) {
                DLNetwork.LOGGER.error("Handler of {} failed.", this, e);
                result = outputFactory.apply(DLStatus.error(e));
            }
            respond(context, correlationId, result);
        });
    }

    private void respond(PacketContext context, int correlationId, O result) {
        try {
            dispatch(context.reply(), buf -> {
                buf.method_52997(KIND_RESPONSE);
                buf.method_10804(correlationId);
                outputCodec.encode(buf, result);
            });
        } catch (Exception e) {
            DLNetwork.LOGGER.error("Could not send the response of {}.", this, e);
        }
    }

    private void receiveResponse(PacketContext context, int correlationId, class_2540 payload) {
        PendingRequest waiting = takePending(context.getConnection(), correlationId);
        if (waiting == null) {
            DLNetwork.LOGGER.debug("Discarding a late or unexpected response for {}.", this);
            return;
        }
        if (waiting.getDefinition() != this) {
            waiting.fail(NetworkError.of(NetworkError.Reason.MALFORMED, "The answer did not match the request."));
            return;
        }

        O result;
        try {
            result = outputCodec.decode(payload);
        } catch (Exception e) {
            DLNetwork.LOGGER.error("Could not decode the response of {}.", this, e);
            waiting.fail(NetworkError.of(NetworkError.Reason.MALFORMED, "The response could not be read."));
            return;
        }
        ((Pending) waiting).deliver(result);
    }

    private PendingRequest takePending(class_2535 connection, int correlationId) {
        if (correlationId < 0) {
            return FALLBACK.remove(correlationId);
        }
        ChannelSession session = getChannel().peekSession(connection);
        return session == null ? null : session.removePending(correlationId);
    }

    private void removePending(class_2535 connection, int correlationId) {
        if (correlationId < 0) {
            FALLBACK.remove(correlationId);
            return;
        }
        ChannelSession session = getChannel().peekSession(connection);
        if (session != null) {
            session.removePending(correlationId);
        }
    }

    private static void sweepFallback() {
        long now = System.currentTimeMillis();
        Iterator<Map.Entry<Integer, PendingRequest>> it = FALLBACK.entrySet().iterator();
        while (it.hasNext()) {
            PendingRequest request = it.next().getValue();
            if (request.getDeadline() <= now) {
                it.remove();
                request.fail(NetworkError.of(NetworkError.Reason.TIMEOUT));
            }
        }
    }

    private final class Pending implements PendingRequest {

        private final CompletableFuture<O> future;
        private final long deadline;

        private Pending(CompletableFuture<O> future, long deadline) {
            this.future = future;
            this.deadline = deadline;
        }

        @Override
        public PacketDefinition getDefinition() {
            return LegacyRequestPacket.this;
        }

        @Override
        public long getDeadline() {
            return deadline;
        }

        @Override
        public void fail(NetworkError error) {
            if (error.reason() == NetworkError.Reason.TIMEOUT) {
                future.completeExceptionally(new TimeoutException(error.toString()));
            } else {
                future.completeExceptionally(new IllegalStateException(error.toString()));
            }
        }

        private void deliver(O result) {
            future.complete(result);
        }
    }
}
