/*
 * DragonLib 3 - 1.21.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.network.v2.packet;

import java.util.Objects;
import net.minecraft.class_2540;
import de.mrjulsen.mcdragonlib.network.v2.DLNetwork;
import de.mrjulsen.mcdragonlib.network.v2.PacketContext;
import de.mrjulsen.mcdragonlib.network.v2.PacketDefinition;
import de.mrjulsen.mcdragonlib.network.v2.PacketTarget;
import de.mrjulsen.mcdragonlib.network.v2.codec.DLStreamCodec;

/**
 * A packet that is sent and forgotten.
 *
 * <p>Nothing travels back, so the sender learns nothing about whether the handler succeeded. Use
 * a {@link RequestPacket} when the outcome matters.
 *
 * @param <T> the payload type
 */
public final class SendPacket<T> extends PacketDefinition {

    /**
     * Handles a received payload.
     *
     * @param <T> the payload type
     */
    @FunctionalInterface
    public interface Handler<T> {

        /**
         * Handles one received payload.
         *
         * @param payload the decoded payload
         * @param context what is known about the received message
         */
        void handle(T payload, PacketContext context);
    }

    private final DLStreamCodec<T> codec;
    private final Handler<T> handler;

    SendPacket(Settings settings, DLStreamCodec<T> codec, Handler<T> handler) {
        super(settings);
        this.codec = Objects.requireNonNull(codec, "codec");
        this.handler = Objects.requireNonNull(handler, "handler");
    }

    /**
     * Sends a payload to every recipient the target covers.
     *
     * @param target where the payload goes
     * @param payload the value to send
     */
    public void send(PacketTarget target, T payload) {
        Objects.requireNonNull(target, "target");
        if (target.getFlow() != getDirection().getRequestFlow()) {
            throw new IllegalArgumentException(this + " travels " + getDirection().getRequestFlow() + " but the target is " + target.getFlow() + ".");
        }
        dispatch(target, buf -> codec.encode(buf, payload));
    }

    @Override
    protected void receive(PacketContext context, class_2540 payload) {
        if (context.getFlow() != getDirection().getRequestFlow()) {
            DLNetwork.LOGGER.warn("Ignoring {} received from the wrong side.", this);
            return;
        }
        T value;
        try {
            value = codec.decode(payload);
        } catch (Exception e) {
            DLNetwork.LOGGER.error("Could not decode {}.", this, e);
            return;
        }
        getHandlerExecutionMode().run(context, () -> {
            try {
                handler.handle(value, context);
            } catch (Exception e) {
                DLNetwork.LOGGER.error("Handler of {} failed.", this, e);
            }
        });
    }
}
