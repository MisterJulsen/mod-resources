/*
 * DragonLib 3 - 1.21.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.client.gui.widgets.base;

import java.nio.file.Path;
import java.util.List;
import net.minecraft.class_1703;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import org.jetbrains.annotations.Nullable;

import de.mrjulsen.mcdragonlib.client.util.DLGuiGraphics;
import de.mrjulsen.mcdragonlib.util.TextUtils;

public class DLScreen<M extends class_1703> extends class_437 {

    private final DLWindowManager root;

    @Deprecated(forRemoval = true)
    public <T extends DLWindow> DLScreen(@Nullable M menu, WindowBuilder<T> window) {
        super(TextUtils.empty());
        final class_437 previousScreen = class_310.method_1551().field_1755;
        this.root = new DLWindowManager(null, window, field_22789, field_22790, (mgr) -> {
            class_310.method_1551().method_1507(mgr.shouldShowPreviousScreenOnClose() ? previousScreen : null);
        });
    }

    public <T extends DLWindow> DLScreen(WindowBuilder<T> window) {
        super(TextUtils.empty());
        final class_437 previousScreen = class_310.method_1551().field_1755;
        this.root = new DLWindowManager(null, window, field_22789, field_22790, (mgr) -> {
            class_310.method_1551().method_1507(mgr.shouldShowPreviousScreenOnClose() ? previousScreen : null);
        });
    }

    public DLWindowManager getWindowManager() {
        return root;
    }

    @Deprecated(forRemoval = true)
    public boolean supportsMenus() {
        return false;
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        root.updateLayout(field_22789, field_22790);
    }

    @Override
    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        super.method_25394(guiGraphics, mouseX, mouseY, partialTick); // also renders the background since 1.20.5
        DLGuiGraphics graphics = new DLGuiGraphics(guiGraphics, guiGraphics.method_51448(), class_310.method_1551().field_1772, partialTick);
        root.render(graphics, mouseX, mouseY);
    }

    @Override
    public void method_25393() {
        super.method_25393();
        root.tick();
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        return root.mouseClicked(mouseX, mouseY, button) || super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public void method_16014(double mouseX, double mouseY) {
        boolean b = root.mouseMoved(mouseX, mouseY);
        if (!b) {
            super.method_16014(mouseX, mouseY);
        }
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        return root.mouseReleased(mouseX, mouseY, button) || super.method_25406(mouseX, mouseY, button);
    }

    @Override
    public void method_25420(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        // Keep the look of 1.20: no blur while a level is shown behind the screen.
        if (class_310.method_1551().field_1687 != null) {
            method_52752(guiGraphics);
        } else {
            super.method_25420(guiGraphics, mouseX, mouseY, partialTick);
        }
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double scrollX, double scrollY) {
        return root.mouseScrolled(mouseX, mouseY, scrollX, scrollY) || super.method_25401(mouseX, mouseY, scrollX, scrollY);
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double dragX, double dragY) {
        return root.mouseDragged(mouseX, mouseY, button, dragX, dragY) || super.method_25403(mouseX, mouseY, button, dragX, dragY);
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        return root.keyPressed(keyCode, scanCode, modifiers) || super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_16803(int keyCode, int scanCode, int modifiers) {
        return root.keyReleased(keyCode, scanCode, modifiers) || super.method_16803(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_25400(char codePoint, int modifiers) {
        return root.charTyped(codePoint, modifiers) || super.method_25400(codePoint, modifiers);
    }

    @Override
    public void method_29638(List<Path> paths) {
        boolean b = root.onFilesDrop(paths);
        if (!b) {
            super.method_29638(paths);
        }
    }

    @Override
    public void method_25419() {
        root.onClose();
        super.method_25419();
    }

    @Override
    public boolean method_25421() {
        return root.isPauseScreen();
    }

    @Deprecated(forRemoval = true)
    public M getMenu() {
        return null;
    }
}
