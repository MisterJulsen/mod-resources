/*
 * DragonLib 3 - 1.21.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.network.v2.fabric;

import de.mrjulsen.mcdragonlib.network.v2.DLNetwork;
import de.mrjulsen.mcdragonlib.network.v2.NetworkFlow;
import de.mrjulsen.mcdragonlib.network.v2.PacketContext;
import de.mrjulsen.mcdragonlib.network.v2.internal.FramePayload;
import dev.architectury.utils.Env;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1657;
import net.minecraft.class_2535;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_634;

@Environment(EnvType.CLIENT)
public class ClientNetworkImpl {

    public static void registerChannel(class_2960 channelId) {
        ClientPlayNetworking.registerGlobalReceiver(FramePayload.type(channelId), (payload, context) ->
            DLNetwork.receive(channelId, payload.frame(), clientContext(context.client())));
    }

    static PacketContext clientContext(class_310 client) {
        class_634 handler = client.method_1562();
        class_2535 connection = handler == null ? null : handler.method_48296();
        return new PacketContext() {
            @Override
            public Env getEnvironment() {
                return Env.CLIENT;
            }

            @Override
            public NetworkFlow getFlow() {
                return NetworkFlow.CLIENTBOUND;
            }

            @Override
            public class_2535 getConnection() {
                return connection;
            }

            @Override
            public class_1657 getPlayer() {
                return client.field_1724;
            }

            @Override
            public void queue(Runnable task) {
                client.execute(task);
            }
        };
    }
}
