/*
 * DragonLib 3 - 1.21.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.client.gui.v2.text.style;

import de.mrjulsen.mcdragonlib.DragonLib;
import de.mrjulsen.mcdragonlib.client.gui.v2.theme.Theme;
import de.mrjulsen.mcdragonlib.client.gui.v2.theme.WidgetRenderer;

/**
 * The colors and metrics a text box draws its content with: selection, caret, gutter, highlights and
 * the spacing around them.
 * <p>This only covers the text itself. The background behind it is drawn by a
 * {@link WidgetRenderer}, see {@link TextBoxRenderers}.</p>
 * <p>Colors are packed ARGB ints rather than DLColor, because the text renderer hands them straight
 * to the vanilla font and fill calls.</p>
 */
public class TextBoxStyle {

    public static final TextBoxStyle VANILLA = new TextBoxStyle();

    /**
     * The style a text box uses while no theme defines one.
     */
    public static final Theme.Key<TextBoxStyle> THEME_KEY = Theme.key(DragonLib.MODID + ".textbox.style", VANILLA);

    public int background = 0xFF000000;
    public int border = 0xFFA0A0A0;
    public int borderFocused = 0xFFFFFFFF;
    public int borderDisabled = 0xFF606060;
    public int borderWidth = 1;

    public int textDisabled = 0xFF707070;
    public int placeholder = 0xFF808080;
    public int linkHovered = 0xFF9CC4FF;

    public int selection = 0x803B6EA8;
    public int selectionInactive = 0x40808080;
    public int currentLineHighlight = 0x18FFFFFF;
    public int lineHighlight = 0x40FFD700;
    public int searchHighlight = 0x444D9BFF;
    public int searchHighlightActive = 0x66FFAA00;

    public int caret = 0xFFFFFFFF;
    public boolean invertCaret = true;
    public int caretWidth = 1;
    public int caretMargin = 6;
    public int caretBlinkIntervalMs = 1000;

    public int gutterBackground = 0xFF101010;
    public int gutterText = 0xFF707070;
    public int gutterTextActive = 0xFFD0D0D0;
    public int gutterPadding = 4;

    public int scrollBarSize = 7;
    public int tooltipMaxWidth = 200;
    public float lineBreakSelectionRatio = 0.5F;

    /**
     * The border color for the given widget state.
     */
    public int borderOf(boolean enabled, boolean focused) {
        if (!enabled) {
            return borderDisabled;
        }
        return focused ? borderFocused : border;
    }
}
