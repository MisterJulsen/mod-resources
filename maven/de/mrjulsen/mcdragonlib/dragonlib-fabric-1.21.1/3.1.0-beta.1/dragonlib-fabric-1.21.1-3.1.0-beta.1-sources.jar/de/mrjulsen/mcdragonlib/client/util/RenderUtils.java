/*
 * DragonLib 3 - 1.21.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.client.util;

import java.util.BitSet;
import java.util.List;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_1920;
import net.minecraft.class_1921;
import net.minecraft.class_2350;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_327.class_6415;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_778;
import net.minecraft.class_778.class_780;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Vector3f;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import de.mrjulsen.mcdragonlib.DragonLib;
import de.mrjulsen.mcdragonlib.client.ber.BERGraphics;
import de.mrjulsen.mcdragonlib.data.ETextAlignment;
import de.mrjulsen.mcdragonlib.util.DLColor;
import de.mrjulsen.mcdragonlib.util.TextUtils;
import de.mrjulsen.mcdragonlib.util.math.MathUtils;

public final class RenderUtils {

    private static boolean aoRenderingErrorKnown = false;

    public static final class_2960 BLANK_TEXTURE_LOCATION;
    static {
        class_1011 img = new class_1011(1, 1, false);
        img.method_4305(0, 0, 0xFFFFFFFF);
        BLANK_TEXTURE_LOCATION = class_310.method_1551().method_1531().method_4617(DragonLib.MODID + "_blank_texture", new class_1043(img));
    }

    public static void initRenderEngine() {
        RenderSystem.enableBlend();
        RenderSystem.enableDepthTest();
        RenderSystem.blendFunc(GlStateManager.class_4535.SRC_ALPHA, GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA);
    }

    public static void setTint(DLColor color) {
        de.mrjulsen.mcdragonlib.client.gui.v2.render.GuiUtils.setTint(color);
    }

    public static void resetTint() {
        de.mrjulsen.mcdragonlib.client.gui.v2.render.GuiUtils.resetTint();
    }

    public static void addVert(class_4588 builder, DLGraphics graphics, float x, float y, float z, float u, float v, float r, float g, float b, float a, int lu, int lv) {
        builder.method_22918(graphics.poseStack().method_23760().method_23761(), x, y, z).method_22915(r, g, b, a).method_22913(u, v).method_22921(lu, lv).method_22922(class_4608.field_21444).method_60831(graphics.poseStack().method_23760(), 0, 0, 1);
    }

    private static void renderWithoutAO(class_4588 builder, DLGraphics graphics, float x0, float y0, float z0, float x1, float y1, float z1, float u0, float v0, float u1, float v1, float r, float g, float b, float a, int packedLight) {
        addVert(builder, graphics, x0, y0, z0, u0, v0, r, g, b, a, packedLight & 0xFFFF, (packedLight >> 16) & 0xFFFF);
        addVert(builder, graphics, x0, y1, z0, u0, v1, r, g, b, a, packedLight & 0xFFFF, (packedLight >> 16) & 0xFFFF);
        addVert(builder, graphics, x1, y1, z1, u1, v1, r, g, b, a, packedLight & 0xFFFF, (packedLight >> 16) & 0xFFFF);
        addVert(builder, graphics, x1, y0, z1, u1, v0, r, g, b, a, packedLight & 0xFFFF, (packedLight >> 16) & 0xFFFF);
    }

    private static void renderWithAO(class_2350 direction, class_4588 builder, BERGraphics<?> graphics, float x0, float y0, float z0, float x1, float y1, float z1, float u0, float v0, float u1, float v1, float r, float g, float b, float a, int packedLight) {
        float[] afloat = new float[class_2350.values().length * 2];
        BitSet bitset = new BitSet(3);
        class_778.class_780 ao = new class_780();
        class_1920 batg = class_310.method_1551().field_1687;
        ao.method_3388(batg, graphics.blockEntity().method_11010(), graphics.blockEntity().method_11016(), direction, afloat, bitset, true);
        
        addVert(builder, graphics, x0, y0, z0, u0, v0, r * ao.field_4196[0], g * ao.field_4196[0], b * ao.field_4196[0], a, ao.field_4194[0] & 0xFFFF, (ao.field_4194[0] >> 16) & 0xFFFF);
        addVert(builder, graphics, x0, y1, z0, u0, v1, r * ao.field_4196[1], g * ao.field_4196[1], b * ao.field_4196[1], a, ao.field_4194[1] & 0xFFFF, (ao.field_4194[1] >> 16) & 0xFFFF);
        addVert(builder, graphics, x1, y1, z1, u1, v1, r * ao.field_4196[2], g * ao.field_4196[2], b * ao.field_4196[2], a, ao.field_4194[2] & 0xFFFF, (ao.field_4194[2] >> 16) & 0xFFFF);
        addVert(builder, graphics, x1, y0, z1, u1, v0, r * ao.field_4196[3], g * ao.field_4196[3], b * ao.field_4196[3], a, ao.field_4194[3] & 0xFFFF, (ao.field_4194[3] >> 16) & 0xFFFF);
    }
    
    @SuppressWarnings("resources")
    public static void addQuadSide(class_2350 direction, class_4588 builder, DLGraphics graphics, float x0, float y0, float z0, float x1, float y1, float z1, float u0, float v0, float u1, float v1, float r, float g, float b, float a, int packedLight, boolean ambientOcclusion) {
        if (!ambientOcclusion || !class_310.method_1588() || !(graphics instanceof BERGraphics<?> berGraphics) || berGraphics.blockEntity().method_10997() == null || berGraphics.blockEntity().method_11016() == null) {
            try {
                renderWithoutAO(builder, graphics, x0, y0, z0, x1, y1, z1, u0, v0, u1, v1, r, g, b, a, packedLight);
            } catch (Exception e2) {
                DragonLib.LOGGER.error("Error while rendering without AO.", e2);
            }
        } else {
            try {
                renderWithAO(direction, builder, berGraphics, x0, y0, z0, x1, y1, z1, u0, v0, u1, v1, r, g, b, a, packedLight);
                aoRenderingErrorKnown = false;
            } catch (Exception e) {
                if (!aoRenderingErrorKnown) {
                    DragonLib.LOGGER.error("Error while rendering with AO.", e);
                }
                aoRenderingErrorKnown = true;

                try {
                    renderWithoutAO(builder, graphics, x0, y0, z0, x1, y1, z1, u0, v0, u1, v1, r, g, b, a, packedLight);
                } catch (Exception e2) {
                    DragonLib.LOGGER.error("Error while rendering without AO.", e2);
                }
            }
        }
    }
    
    public static void renderTexture(class_2960 texture, DLGraphics graphics, Vector3f pos, float w, float h, float u, float v, float uW, float vH, class_2350 facing, DLColor tint, int light, boolean ambiebtOcclusion) {
        graphics.multiBufferSource().getBuffer(class_1921.method_23028(texture));
        class_4588 vertexconsumer = graphics.vertexConsumer(texture);
        addQuadSide(facing, vertexconsumer, graphics,
            pos.x(), pos.y(), pos.z(),
            pos.x() + w, pos.y() + h, pos.z(),
            u, v,
            u + uW, v + vH,
            tint.getRedF(), tint.getGreenF(), tint.getBlueF(), tint.getAlphaF(), 
            light,
            ambiebtOcclusion
        );
    }

    public static void renderTexture(class_2960 texture, DLGraphics graphics, Vector3f pos, float w, float h, float u, float v, float uW, float vH, class_2350 facing, DLColor tint, boolean ambientOcclusion) {
        renderTexture(texture, graphics, pos, w, h, u, v, uW, vH, facing, tint, graphics.packedLight(), ambientOcclusion);        
    }

    public static void renderTexture(class_2960 texture, DLGraphics graphics, Vector3f pos, float w, float h, class_2350 facing, boolean ambientOcclusion) {
        renderTexture(texture, graphics, pos, w, h, 0, 0, 1, 1, facing, DLColor.WHITE, graphics.packedLight(), ambientOcclusion);        
    }    

    // RenderStateShard$TextureStateShard for textureId
    public static void renderTexture(DLTexture texture, DLGraphics graphics, Vector3f pos, float w, float h, float u, float v, float uW, float vH, class_2350 facing, DLColor tint, int light, boolean ambientOcclusion) {
        if (texture.usesTextureId() || texture.getTexture().isEmpty()) {
            throw new IllegalArgumentException("TextureIds are not supported in BlockEntityRenderers.");
        }
        renderTexture(
            texture.getTexture().get(),
            graphics,
            pos, w, h,
            (float)MathUtils.proportion(u, texture.width()),
            (float)MathUtils.proportion(v, texture.height()),
            (float)MathUtils.proportion(uW, texture.width()),
            (float)MathUtils.proportion(vH, texture.height()),
            facing,
            tint,
            light,
            ambientOcclusion
        );        
    }

    public static void renderTexture(DLTexture texture, DLGraphics graphics, Vector3f pos, float w, float h, float u, float v, float uW, float vH, class_2350 facing, DLColor tint, boolean ambientOcclusion) {
        renderTexture(texture, graphics, pos, w, h, u, v, uW, vH, facing, tint, graphics.packedLight(), ambientOcclusion);
    }

    public static void renderTexture(DLTexture texture, DLGraphics graphics, Vector3f pos, float w, float h, class_2350 facing, boolean ambientOcclusion) {
        renderTexture(texture, graphics, pos, w, h, 0, 0, texture.width(), texture.height(), facing, DLColor.WHITE, ambientOcclusion);
    }

    public static void fillColor(DLGraphics graphics, Vector3f pos, float w, float h, DLColor color, class_2350 facing, int light, boolean ambientOcclusion) {
        renderTexture(BLANK_TEXTURE_LOCATION, graphics, pos, w, h, 0, 0, 1, 1, facing, color, light, ambientOcclusion);
    }
    
    public static void fillColor(DLGraphics graphics, Vector3f pos, float w, float h, DLColor color, class_2350 facing) {
        fillColor(graphics, pos, w, h, color, facing, graphics.packedLight(), false);
    }

    public static void drawString(DLGraphics graphics, class_327 font, float x, float y, class_2561 text, DLColor color, ETextAlignment alignment, boolean dropShadow, boolean transparent, DLColor backgroundColor, int packedLight) {
        float dx = x;
        switch (alignment) {
            case RIGHT:
                dx = x - font.method_27525(text);
                break;
            case CENTER:
                dx = x - font.method_27525(text) / 2;
                break;
            default:
                break;
        }        
        font.method_30882(text, dx, y, color.getAsARGB(), dropShadow, graphics.poseStack().method_23760().method_23761(), graphics.multiBufferSource(), transparent ? class_6415.field_33994 : class_6415.field_33993, backgroundColor.getAsARGB(), packedLight);
    }

    public static void drawString(DLGraphics graphics, class_327 font, float x, float y, class_2561 text, DLColor color, ETextAlignment alignment, boolean dropShadow, int packedLight) {        
        drawString(graphics, font, x, y, text, color, alignment, dropShadow, false, DLColor.TRANSPARENT, packedLight);
    }

    public static void drawString(DLGraphics graphics, class_327 font, float x, float y, class_2561 text, DLColor color, ETextAlignment alignment, boolean dropShadow) {
        drawString(graphics, font, x, y, text, color, alignment, dropShadow, graphics.packedLight());
    }

    public static void drawString(DLGraphics graphics, class_327 font, float x, float y, String text, DLColor color, ETextAlignment alignment, boolean dropShadow, boolean transparent, DLColor backgroundColor, int packedLight) {        
        drawString(graphics, font, x, y, TextUtils.text(text), color, alignment, dropShadow, transparent, backgroundColor, packedLight);
    }

    public static void drawString(DLGraphics graphics, class_327 font, float x, float y, String text, DLColor color, ETextAlignment alignment, boolean dropShadow, int packedLight) {        
        drawString(graphics, font, x, y, text, color, alignment, dropShadow, false, DLColor.TRANSPARENT, packedLight);
    }

    public static void drawString(DLGraphics graphics, class_327 font, float x, float y, String text, DLColor color, ETextAlignment alignment, boolean dropShadow) {
        drawString(graphics, font, x, y, text, color, alignment, dropShadow, graphics.packedLight());
    }
    
    

    public static void drawDebugLineGradient(class_4587 poseStack, class_4588 consumer, Vector3f from, Vector3f to, DLColor colorA, DLColor colorB) {
        class_4587.class_4665 lastPose = poseStack.method_23760();
        Matrix4f matrix4f = poseStack.method_23760().method_23761();
        Matrix3f matrix3f = poseStack.method_23760().method_23762();

        float dx = to.x() - from.x();
        float dy = to.y() - from.y();
        float dz = to.z() - from.z();
        float length = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);

        if (length > 0) {
            dx /= length;
            dy /= length;
            dz /= length;
        }

        consumer.method_22918(matrix4f, (float) from.x(), (float) from.y(), (float) from.z()).method_22915(colorA.getRedF(), colorA.getGreenF(), colorA.getBlueF(), colorA.getAlphaF()).method_60831(lastPose, dx, dy, dz);
        consumer.method_22918(matrix4f, (float) to.x(), (float) to.y(), (float) to.z()).method_22915(colorB.getRedF(), colorB.getGreenF(), colorB.getBlueF(), colorB.getAlphaF()).method_60831(lastPose, dx, dy, dz);
    }

    public static void drawDebugLine(class_4587 poseStack, class_4588 consumer, Vector3f from, Vector3f to, DLColor color) {
        drawDebugLineGradient(poseStack, consumer, from, to, color, color);
    }
    
    public static void drawDebugLineGradient(DLGraphics graphics, Vector3f from, Vector3f to, DLColor colorA, DLColor colorB) {
        drawDebugLine(graphics.poseStack(), graphics.multiBufferSource().getBuffer(class_1921.method_23594()), from, to, colorB);
    }

    public static void drawDebugLine(DLGraphics graphics, Vector3f from, Vector3f to, DLColor color) {
        drawDebugLineGradient(graphics, from, to, color, color);
    }

    public static void renderNameTag(class_4587 poseStack, class_4597 buffer, Vector3f pos, float yOffset, List<class_2561> text, int packedLight) {
        if (class_310.method_1551().method_1560().method_19538().method_46409().distance(pos) > 64) {
            return;
        }
        final float lineHeight = class_310.method_1551().field_1772.field_2000 * 1.5f;
        poseStack.method_22903();
        poseStack.method_46416(pos.x(), pos.y() + yOffset, pos.z());
        poseStack.method_22907(class_310.method_1551().field_1773.method_19418().method_23767());
        poseStack.method_22905(-0.0125F, -0.0125F, 0.0125F);
        Matrix4f matrix4f = poseStack.method_23760().method_23761();

        for (int k = 0; k < text.size(); k++) {
            float y = lineHeight * k;
            class_2561 txt = text.get(k);

            float opacity = class_310.method_1551().field_1690.method_19343(0.25F);
            int backgroundColor = (int)(opacity * 255.0F) << 24;
            class_327 font = class_310.method_1551().field_1772;
            float x = (float)(-font.method_27525(txt) / 2);

            font.method_30882(txt, x, -(lineHeight * text.size()) + y, 553648127, false, matrix4f, buffer, class_327.class_6415.field_33994, backgroundColor, packedLight);
            font.method_30882(txt, x, -(lineHeight * text.size()) + y, -1, false, matrix4f, buffer, class_327.class_6415.field_33993, 0, packedLight);
        }

        poseStack.method_22909();
    }

    public static void renderNameTag(DLGraphics graphics, Vector3f pos, float yOffset, List<class_2561> text, int packedLight) {
        renderNameTag(graphics.poseStack(), graphics.multiBufferSource(), pos, yOffset, text, packedLight);
    }
}
