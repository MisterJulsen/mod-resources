/*
 * DragonLib 3 - 1.21.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.client.gui.widgets.base;

import net.minecraft.class_1703;
import net.minecraft.class_3936;

public abstract class DLMenuWindow<M extends class_1703> extends DLWindow implements class_3936<M> {

    protected final M menu;

    public DLMenuWindow(Class<M> menuType, DLWindowManager manager) {
        super(manager);
        if (menuType == null) {
            throw new IllegalArgumentException("No menu type defined.");
        }
        if (!manager.supportsMenus()) {
            throw new IllegalArgumentException("The current window manager doesn't support menus.");
        }
        if (!menuType.isInstance(getWindowManager().method_17577())) {
            throw new IllegalArgumentException("The provided menu type is not supported by the current window manager. Expected: " + manager.method_17577().getClass().getSimpleName() + ", Provided: " + menuType.getSimpleName());
        }
        this.menu = menuType.cast(manager.method_17577());
    }

    @Override
    public final M method_17577() {
        return menu;
    }
    
}
