/*
 * DragonLib 3 - 1.21.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.client.gui.v2.text.layout;

import de.mrjulsen.mcdragonlib.client.gui.v2.text.style.TextStyle;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_5348;

public final class TextMeasurer {

    private static final float MIN_SCALE = 0.01F;

    private final class_327 font;

    public TextMeasurer(class_327 font) {
        this.font = font;
    }

    public static TextMeasurer ofDefaultFont() {
        return new TextMeasurer(class_310.method_1551().field_1772);
    }

    public class_327 font() {
        return font;
    }

    public float baseLineHeight() {
        return font.field_2000;
    }

    public float lineHeight(TextStyle style) {
        return font.field_2000 * style.scale();
    }

    public float width(CharSequence text, int from, int to, TextStyle style) {
        if (from >= to) {
            return 0.0F;
        }
        return width(text.subSequence(from, to).toString(), style);
    }

    public float width(String text, TextStyle style) {
        if (text.isEmpty()) {
            return 0.0F;
        }
        return font.method_27527().method_27488(class_5348.method_29431(text, style.toVanillaStyle())) * style.scale();
    }

    public int fitCharacters(String text, TextStyle style, float maxWidth) {
        if (text.isEmpty() || maxWidth <= 0.0F) {
            return 0;
        }
        int scaledWidth = (int) Math.floor(maxWidth / Math.max(style.scale(), MIN_SCALE));
        return font.method_27527().method_27484(text, scaledWidth, style.toVanillaStyle());
    }

    public int indexAtWidth(String text, TextStyle style, float targetX) {
        if (text.isEmpty() || targetX <= 0.0F) {
            return 0;
        }
        int index = snapToCodePoint(text, fitCharacters(text, style, targetX));
        if (index >= text.length()) {
            return text.length();
        }

        int next = index + Character.charCount(text.codePointAt(index));
        float before = width(text.substring(0, index), style);
        float after = width(text.substring(0, next), style);
        return (targetX - before) > (after - targetX) ? next : index;
    }

    public static int snapToCodePoint(String text, int index) {
        if (index > 0 && index < text.length()
                && Character.isLowSurrogate(text.charAt(index))
                && Character.isHighSurrogate(text.charAt(index - 1))) {
            return index - 1;
        }
        return index;
    }
}
