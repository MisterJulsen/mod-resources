/*
 * DragonLib 3 - 1.21.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.client.gui.widgets.base;

public class DLPopupWindow extends DLWindow {

    public DLPopupWindow(DLWindowManager manager, int x, int y, int w) {
        super(manager);
        setPosition(x, y);
        setSize(w, 100);
        addEventListener(DLWindow.WindowFocusEvent.class, (src, e) -> {
            if (!e.focus()) {
                e.windowManager().closeModal(this.getAssignedModal().get());
            }
            return false;
        });
    }
    
}
