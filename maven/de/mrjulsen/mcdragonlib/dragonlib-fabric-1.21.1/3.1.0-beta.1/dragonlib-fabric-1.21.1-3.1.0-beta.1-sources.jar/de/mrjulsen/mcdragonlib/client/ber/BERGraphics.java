/*
 * DragonLib 3 - 1.21.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.client.ber;

import de.mrjulsen.mcdragonlib.client.util.DLGraphics;
import net.minecraft.class_1921;
import net.minecraft.class_2586;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_5614;

public class BERGraphics<B extends class_2586> extends DLGraphics { 
    
    protected final B blockEntity;
    protected final class_5614.class_5615 berProviderContext;

    public BERGraphics(B blockEntity, class_4587 poseStack, class_4597 multiBufferSource, class_5614.class_5615 berProviderContext, int packedLight, int packedOverlay, float partialTick) {
        super(poseStack, multiBufferSource, packedLight, packedOverlay, partialTick);
        this.blockEntity = blockEntity;
        this.berProviderContext = berProviderContext;
    }
    
    public B blockEntity() {
        return blockEntity;
    }

    public class_5614.class_5615 BERProviderContext() {
        return berProviderContext;
    }

    public class_4588 vertexConsumer(class_2960 textureLocation) {
        return multiBufferSource.getBuffer(class_1921.method_23028(textureLocation));
    }
}
