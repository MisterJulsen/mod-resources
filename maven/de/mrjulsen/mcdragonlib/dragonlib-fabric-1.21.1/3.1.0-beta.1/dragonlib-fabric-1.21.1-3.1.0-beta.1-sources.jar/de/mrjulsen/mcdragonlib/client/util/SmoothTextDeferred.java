/*
 * DragonLib 3 - 1.21.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.client.util;

import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.class_1921;
import net.minecraft.class_1937;
import net.minecraft.class_287;
import net.minecraft.class_310;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_9799;
import net.minecraft.class_9801;
import org.jetbrains.annotations.ApiStatus;
import org.joml.Matrix4f;
import org.joml.Matrix4fStack;

import com.mojang.blaze3d.systems.RenderSystem;
import de.mrjulsen.mcdragonlib.DragonLib;
import de.mrjulsen.mcdragonlib.client.ber.BERGraphics;

@ApiStatus.Internal
public final class SmoothTextDeferred {

    private static final DeferredSource SOURCE = new DeferredSource();
    private static Matrix4f modelViewMatrix;
    private static boolean renderingLevel = false;
    private static boolean deferralLogged = false;

    private SmoothTextDeferred() {}

    public static boolean shouldDefer(DLGraphics graphics) {
        if (!renderingLevel || !(graphics instanceof BERGraphics<?> berGraphics) || berGraphics.blockEntity() == null) {
            return false;
        }
        class_1937 level = berGraphics.blockEntity().method_10997();
        boolean defer = level != null && level != class_310.method_1551().field_1687;
        if (defer && !deferralLogged) {
            deferralLogged = true;
            DragonLib.LOGGER.info("Smooth text of block entities in {} is drawn late in the frame.", level.getClass().getName());
        }
        return defer;
    }

    public static class_4597 source() {
        if (modelViewMatrix == null) {
            modelViewMatrix = new Matrix4f(RenderSystem.getModelViewMatrix());
        }
        return SOURCE;
    }

    public static void draw() {
        if (SOURCE.isEmpty()) {
            modelViewMatrix = null;
            return;
        }
        Matrix4fStack modelViewStack = RenderSystem.getModelViewStack();
        modelViewStack.pushMatrix();
        if (modelViewMatrix != null) {
            modelViewStack.set(modelViewMatrix);
        }
        RenderSystem.applyModelViewMatrix();
        try {
            SOURCE.draw();
        } finally {
            modelViewStack.popMatrix();
            RenderSystem.applyModelViewMatrix();
            modelViewMatrix = null;
        }
    }

    public static void beginLevelRendering() {
        SOURCE.discard();
        modelViewMatrix = null;
        renderingLevel = true;
    }

    public static void endLevelRendering() {
        renderingLevel = false;
        SOURCE.discard();
        modelViewMatrix = null;
    }

    private static final class DeferredSource implements class_4597 {

        private final Map<class_1921, class_9799> buffers = new LinkedHashMap<>();
        private final Map<class_1921, class_287> started = new LinkedHashMap<>();

        @Override
        public class_4588 getBuffer(class_1921 type) {
            return started.computeIfAbsent(type, t -> new class_287(buffers.computeIfAbsent(t, x -> new class_9799(x.method_22722())), t.method_23033(), t.method_23031()));
        }

        boolean isEmpty() {
            return started.isEmpty();
        }

        void draw() {
            for (Map.Entry<class_1921, class_287> entry : started.entrySet()) {
                class_1921 type = entry.getKey();
                class_9801 mesh = entry.getValue().method_60794();
                if (mesh == null) {
                    continue;
                }
                if (type.method_60894()) {
                    mesh.method_60819(buffers.get(type), RenderSystem.getVertexSorting());
                }
                type.method_60895(mesh);
            }
            started.clear();
        }

        void discard() {
            for (class_287 builder : started.values()) {
                class_9801 mesh = builder.method_60794();
                if (mesh != null) {
                    mesh.close();
                }
            }
            started.clear();
        }
    }
}
