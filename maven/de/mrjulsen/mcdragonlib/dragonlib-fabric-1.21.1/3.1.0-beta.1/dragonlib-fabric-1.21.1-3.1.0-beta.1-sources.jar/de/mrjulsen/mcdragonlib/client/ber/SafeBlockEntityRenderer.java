/*
 * DragonLib 3 - 1.21.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.client.ber;

import net.minecraft.class_2246;
import net.minecraft.class_2586;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5614;
import net.minecraft.class_827;

public abstract class SafeBlockEntityRenderer<T extends class_2586> implements class_827<T> {

	private final class_5614.class_5615 context;

	public SafeBlockEntityRenderer(class_5614.class_5615 context) {
		this.context = context;
	}

	@Override
	public final void method_3569(T be, float partialTicks, class_4587 ms, class_4597 bufferSource, int light, int overlay) {
		if (isInvalid(be)) {
			return;
        }
		renderSafe(new BERGraphics<>(be, ms, bufferSource, context, light, overlay, partialTicks), partialTicks);
	}

	protected abstract void renderSafe(BERGraphics<T> graphics, float partialTicks);

	public boolean isInvalid(T be) {
		return !be.method_11002() || be.method_11010().method_26204() == class_2246.field_10124;
	}
}
