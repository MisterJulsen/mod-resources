/*
 * DragonLib 3 - 1.21.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.internal;

import de.mrjulsen.mcdragonlib.network.v2.internal.ClientNetworkHooks;
import net.minecraft.class_1937;
import net.minecraft.class_2535;
import net.minecraft.class_2596;
import net.minecraft.class_310;
import de.mrjulsen.mcdragonlib.network.NetworkDirection.C2S;

public class ClientWrapper {

    public static class_1937 getClientLevel() {
        return class_310.method_1551().field_1687;
    }

    public static C2S toServer() {
        return new C2S() {
            @Override
            public void send(class_2596<?> packet) {
                if (class_310.method_1551().method_1562() != null) {
                    class_310.method_1551().method_1562().method_52787(packet);
                } else {
                    throw new IllegalStateException("Unable to send packet to the server while not in game!");
                }
            }

            @Override
            public class_2535 getConnection() {
                return ClientNetworkHooks.getServerConnection();
            }
        };
    }
}
