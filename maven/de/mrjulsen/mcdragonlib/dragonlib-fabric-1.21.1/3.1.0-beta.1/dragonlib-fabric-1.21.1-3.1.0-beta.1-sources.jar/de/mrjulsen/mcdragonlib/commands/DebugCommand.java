/*
 * DragonLib 3 - 1.21.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.commands;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import de.mrjulsen.mcdragonlib.DragonLib;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2170.class_5364;

public class DebugCommand {

    private static final String CMD_NAME = DragonLib.MODID;
    
    private static final String SUB_DEBUG = "debug";
    private static final String SUB_NETWORK = "network";
    
    @SuppressWarnings("all")
    public static void register(CommandDispatcher<class_2168> dispatcher, class_5364 selection) {        
        
        LiteralArgumentBuilder<class_2168> builder = class_2170.method_9247(CMD_NAME)
            .then(class_2170.method_9247(SUB_DEBUG)
                .requires(x -> x.method_9259(4))
                .then(class_2170.method_9247(SUB_NETWORK)
                )
            )
        ;

        dispatcher.register(builder);
    }
}