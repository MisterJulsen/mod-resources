/*
 * DragonLib 3 - 1.21.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.client.model.extension;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_2350;
import net.minecraft.class_3665;
import org.joml.Matrix4f;

public record DLFaceKey(int index, class_2350 direction) {

    public static <T> Map<DLFaceKey, T> rotate(Map<DLFaceKey, T> data, class_3665 modelState) {
        Matrix4f matrix = modelState.method_3509().method_22936();
        Map<DLFaceKey, T> rotated = new HashMap<>(data.size());
        for (Map.Entry<DLFaceKey, T> entry : data.entrySet()) {
            DLFaceKey key = entry.getKey();
            class_2350 direction = key.direction() == null ? null : class_2350.method_23225(matrix, key.direction());
            rotated.put(new DLFaceKey(key.index(), direction), entry.getValue());
        }
        return rotated;
    }
}
