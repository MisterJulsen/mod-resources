/*
 * DragonLib 3 - 1.21.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.client.model.mesh;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_2350;
import com.google.common.collect.ImmutableList;
import de.mrjulsen.mcdragonlib.client.model.ModelUtils;
import de.mrjulsen.mcdragonlib.client.util.DLGraphics;

public abstract class Mesh implements ITransformable<Mesh> {

    protected final List<Vertex> vertices;
    protected final List<Edge> edges;
    protected final List<Face> faces;    

    protected Mesh(List<Vertex> vertices, List<Edge> edges, List<Face> faces) {
        this.vertices = vertices;
        this.edges = edges;
        this.faces = faces;
    }

    @Override
    public List<? extends IVertexElement> getTransformableElements() {
        return vertices;
    }

    public void cleanUp() {
        cleanUp(0.0001f, true, true, true);
    }

    public void cleanUp(float threshold, boolean mergeVertices, boolean mergeEdges, boolean mergeFaces) {
        if (mergeVertices) mergeVertices(threshold);
        if (mergeEdges) mergeEdges(threshold);
        if (mergeFaces) mergeFaces(threshold);
    }

    public Map<Vertex, Vertex> mergeVertices(float threshold) {
        Map<Vertex, Vertex> replaced = new HashMap<>(vertices.size());
        List<Vertex> merged = new ArrayList<>(vertices.size());

        for (Vertex v : vertices) {
            boolean found = false;
            for (Vertex existing : merged) {
                if (ModelUtils.positionsIntersect(v.getPos(), existing.getPos(), threshold)) {
                    replaced.put(v, existing);
                    found = true;
                    break;
                }
            }
            if (!found) {
                merged.add(v);
            }
        }

        replaceVertices(merged);

        for (Edge edge : edges) {
            edge.updateVertices(x -> replaceFunc(replaced, x));
        }
        for (Face face : faces) {
            face.updateVertices(x -> replaceFunc(replaced, x));
        }

        return replaced;
    }

    protected void replaceVertices(List<Vertex> other) {
        vertices.clear();
        vertices.addAll(other);
    }

    public Map<Edge, Edge> mergeEdges(float threshold) {
        Map<Edge, Edge> replaced = new HashMap<>(edges.size());
        List<Edge> merged = new ArrayList<>(edges.size());

        for (Edge v : edges) {
            boolean found = false;
            for (Edge existing : merged) {
                if (v.overlaps(existing, threshold)) {
                    replaced.put(v, existing);
                    found = true;
                    break;
                }
            }
            if (!found) {
                merged.add(v);
            }
        }

        replaceEdges(merged);

        for (Face face : faces) {
            face.updateEdges(x -> replaceFunc(replaced, x));
        }

        return replaced;
    }

    protected void replaceEdges(List<Edge> other) {
        edges.clear();
        edges.addAll(other);
    }
    
    public int mergeFaces(float threshold) {
        int currentFaces = faces.size();
        List<Face> uniqueFaces = new ArrayList<>(faces.size());

        for (Face face : faces) {
            if (face == null) {
                uniqueFaces.add(null);
                continue;
            }
            boolean found = false;
            for (Face u : uniqueFaces) {
                if (u != null && face.overlaps(u, threshold)) {
                    found = true;
                    break;
                }
            }
            if (!found) {
                uniqueFaces.add(face);
            }
        }

        replaceFaces(uniqueFaces);
        return currentFaces - faces.size();
    }

    protected void replaceFaces(List<Face> other) {
        faces.clear();
        faces.addAll(other);
    }

    protected static <T> T replaceFunc(Map<T, T> replacements, T in) {
        if (replacements.containsKey(in)) {
            return replacements.get(in);
        }
        return in;
    }

    public List<Vertex> getVertices() {
        return Collections.unmodifiableList(vertices);
    }

    public List<Edge> getEdges() {
        return Collections.unmodifiableList(edges);
    }

    public List<Face> getFaces() {
        return Collections.unmodifiableList(faces);
    }

    public List<Face> getFacesOfDirection(class_2350 direction) {
        if (direction == null) {
            return getFaces();
        }
        ImmutableList.Builder<Face> builder = ImmutableList.builder();
        for (Face face : getFaces()) {
            if (face.getNormalDirection() == direction) {
                builder.add(face);
            }
        }
        return builder.build();
    }

    


    public void render(DLGraphics graphics) {
        getFaces().forEach(face -> face.render(graphics));
    }
    public void render(DLGraphics graphics, int light, boolean ambientOcclusion) {
        getFaces().forEach(face -> face.render(graphics, light, ambientOcclusion));
    }

    public void render(DLGraphics graphics, int light, int overlay, boolean ambientOcclusion, boolean transformForBER) {
        getFaces().forEach(face -> face.render(graphics, light, overlay, ambientOcclusion, transformForBER));
    }
}


