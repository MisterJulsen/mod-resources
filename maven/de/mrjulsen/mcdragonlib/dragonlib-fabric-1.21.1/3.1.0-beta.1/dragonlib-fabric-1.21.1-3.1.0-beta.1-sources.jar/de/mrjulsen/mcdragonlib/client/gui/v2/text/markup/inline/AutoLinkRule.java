/*
 * DragonLib 3 - 1.21.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.client.gui.v2.text.markup.inline;

import java.util.List;
import net.minecraft.class_2561;
import de.mrjulsen.mcdragonlib.client.gui.v2.text.markup.MarkupText;
import de.mrjulsen.mcdragonlib.client.gui.v2.text.markup.TextContext;
import de.mrjulsen.mcdragonlib.client.gui.v2.text.style.TextStyles;
import de.mrjulsen.mcdragonlib.util.TextUtils;

public final class AutoLinkRule implements IInlineRule {

    public static final AutoLinkRule WEB = new AutoLinkRule(List.of("http://", "https://", "www."));

    private static final String TRAILING_PUNCTUATION = ".,)]!?;:";

    public int color = 0xFF5C9DFF;

    private final List<String> prefixes;

    public AutoLinkRule(List<String> prefixes) {
        this.prefixes = List.copyOf(prefixes);
    }

    @Override
    public List<class_2561> contextTooltip(TextContext context) {
        String link = context == null ? null : context.link();
        return link == null ? List.of() : List.of(TextUtils.text(link));
    }

    @Override
    public int parse(InlineContext context, int at) {
        if (at > 0 && Character.isLetterOrDigit(context.charAt(at - 1))) {
            return 0;
        }
        if (!startsWithPrefix(context, at)) {
            return 0;
        }

        int end = urlEnd(context, at);
        if (end <= at) {
            return 0;
        }

        String url = context.textBetween(at, end);
        context.flushTo(at);
        context.emitStyled(at, end, context.style()
                .withLink(url)
                .withColor(color)
                .with(TextStyles.UNDERLINED, true));
        return end - at;
    }

    private boolean startsWithPrefix(InlineContext context, int at) {
        for (String prefix : prefixes) {
            if (MarkupText.startsWith(context.line(), at, prefix)) {
                return true;
            }
        }
        return false;
    }

    private static int urlEnd(InlineContext context, int from) {
        int limit = context.limit();
        int i = from;
        while (i < limit) {
            char c = context.charAt(i);
            if (Character.isWhitespace(c) || c == '<' || c == '>') {
                break;
            }
            i++;
        }
        while (i > from && TRAILING_PUNCTUATION.indexOf(context.charAt(i - 1)) >= 0) {
            i--;
        }
        return i;
    }
}
