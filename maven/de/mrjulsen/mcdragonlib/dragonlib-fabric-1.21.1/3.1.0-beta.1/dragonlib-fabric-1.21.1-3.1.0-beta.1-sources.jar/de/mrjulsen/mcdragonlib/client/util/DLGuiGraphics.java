/*
 * DragonLib 3 - 1.21.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.client.util;

import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597.class_4598;

@Deprecated
public record DLGuiGraphics(class_332 graphics, class_4587 poseStack, class_327 defaultFont, float partialTick) {

    public class_4598 bufferSource() {
        return  graphics().method_51450();
    }

    public class_4588 vertexConsumer(class_2960 textureLocation) {
        return graphics().method_51450().getBuffer(class_1921.method_23028(textureLocation));
    }

    public class_4588 vertexConsumer() {
        return graphics().method_51450().getBuffer(class_1921.method_23028(RenderUtils.BLANK_TEXTURE_LOCATION));
    }
}
