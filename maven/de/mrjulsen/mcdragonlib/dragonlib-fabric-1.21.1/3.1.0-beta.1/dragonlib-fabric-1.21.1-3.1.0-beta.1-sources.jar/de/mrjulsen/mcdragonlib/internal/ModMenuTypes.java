/*
 * DragonLib 3 - 1.21.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.internal;

import de.mrjulsen.mcdragonlib.DragonLib;
import de.mrjulsen.mcdragonlib.menu.PlayerInventoryContainerMenu;
import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import net.minecraft.class_1703;
import net.minecraft.class_3917;
import net.minecraft.class_3917.class_3918;
import net.minecraft.class_7701;
import net.minecraft.class_7924;

public class ModMenuTypes {
    public static final DeferredRegister<class_3917<?>> MENUS = DeferredRegister.create(DragonLib.MODID, class_7924.field_41207);
    public static final RegistrySupplier<class_3917<PlayerInventoryContainerMenu.Base>> PLAYER_INVENTORY = registerMenuType(PlayerInventoryContainerMenu.Base::new, "player_inventory");

    private static <T extends class_1703>RegistrySupplier<class_3917<T>> registerMenuType(class_3918<T> factory, String name) {
        return MENUS.register(name, () -> new class_3917<T>(factory, class_7701.field_40183));
    }

    public static void register() {
        MENUS.register();
    }

}