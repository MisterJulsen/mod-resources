/*
 * DragonLib 3 - 1.21.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.fabric.client;

import com.google.common.collect.ImmutableMap;

import de.mrjulsen.mcdragonlib.client.model.DLBlockModelRegistry;
import de.mrjulsen.mcdragonlib.client.model.DLBlockModelRegistry.ModelRegistryData;
import de.mrjulsen.mcdragonlib.events.client.ModelEvents;
import de.mrjulsen.mcdragonlib.events.client.ModelEvents.ModifyModels;
import de.mrjulsen.mcdragonlib.events.client.ModelReplacements;
import de.mrjulsen.mcdragonlib.fabric.client.model.DynamicBakedModel;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.model.loading.v1.ModelLoadingPlugin;
import net.minecraft.class_1087;
import net.minecraft.class_1088;
import net.minecraft.class_1091;
import net.minecraft.class_1100;
import net.minecraft.client.resources.model.*;

@Environment(EnvType.CLIENT)
public class DLModelLoadingPlugin implements ModelLoadingPlugin {

    @Override
    public void onInitializeModelLoader(Context pluginContext) {
        ModelEvents.ADDITIONAL_MODELS.invoker().registerAdditionalModels(model -> pluginContext.addModels(model));

        ModelReplacements replacements = ModelReplacements.collect();
        if (!replacements.isEmpty()) {
            pluginContext.modifyModelAfterBake().register((original, ctx) -> {
                class_1091 id = ctx.topLevelId();
                if (id == null) {
                    return original;
                }

                class_1087 model = replacements.apply(id, loc -> original, new ModifyModels.Context() {
                    @Override
                    public class_1088 getModelBakery() {
                        return ctx.loader();
                    }

                    @Override
                    public class_1091 getModelLocation() {
                        return id;
                    }

                    @Override
                    public class_1100 getUnbakedModel() {
                        return ctx.sourceModel();
                    }
                });
                return model == null ? original : model;
            });
        }

        ImmutableMap<class_1091, ModelRegistryData> factories = DLBlockModelRegistry.getCustomRegisteredModelsMapped();
        if (!factories.isEmpty()) {
            pluginContext.modifyModelAfterBake().register((original, ctx) -> {
                class_1091 id = ctx.topLevelId();
                if (id == null) {
                    return original;
                }

                ModelRegistryData data = factories.get(id);
                if (data == null) {
                    return original;
                }

                DLBlockModelRegistry.setOriginalModel(data.factory().getType(), data.state(), original);
                return new DynamicBakedModel(original, data.state(), data.factory().getModelFactory().get());
            });
        }
    }
}
