/*
 * DragonLib 3 - 1.21.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.client.gui.v2.text.markup.block;

import de.mrjulsen.mcdragonlib.client.gui.v2.text.markup.BlockKind;
import de.mrjulsen.mcdragonlib.client.gui.v2.text.markup.MarkupText;
import de.mrjulsen.mcdragonlib.client.gui.v2.text.markup.ParsedLine;
import de.mrjulsen.mcdragonlib.client.gui.v2.text.style.TextStyles;
import de.mrjulsen.mcdragonlib.client.gui.v2.text.style.TextStyle;

public final class HeadingRule implements IBlockRule {

    public static final BlockKind KIND = BlockKind.register("heading", BlockKind.TRAIT_NONE);

    public static final HeadingRule DEFAULT = new HeadingRule('#', 6);

    public int color = 0xFFFFFFFF;
    public float[] scales = { 2.0F, 1.6F, 1.35F, 1.2F, 1.1F, 1.0F };

    private final char marker;
    private final int maxLevel;

    public HeadingRule(char marker, int maxLevel) {
        this.marker = marker;
        this.maxLevel = maxLevel;
    }

    @Override
    public String reservedCharacters() {
        return String.valueOf(marker);
    }

    public float scaleOf(int level) {
        int index = Math.max(1, Math.min(level, scales.length)) - 1;
        return scales[index];
    }

    @Override
    public ParsedLine parse(BlockContext context) {
        if (context.isBlank()) {
            return null;
        }
        int start = context.contentStart();
        int level = MarkupText.runLength(context.line(), start, marker);
        if (level < 1 || level > maxLevel || start + level >= context.length() || context.charAt(start + level) != ' ') {
            return null;
        }

        int contentStart = start + level + 1;
        context.emitMarkup(0, contentStart);
        context.parseInline(contentStart, context.length(), TextStyle.DEFAULT
                .withColor(color)
                .withScale(scaleOf(level))
                .with(TextStyles.BOLD, true));
        return context.build(KIND, level, false);
    }
}
