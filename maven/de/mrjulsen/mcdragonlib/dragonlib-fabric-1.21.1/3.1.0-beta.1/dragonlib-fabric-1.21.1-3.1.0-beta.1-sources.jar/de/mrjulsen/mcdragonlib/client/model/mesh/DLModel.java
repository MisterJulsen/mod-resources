/*
 * DragonLib 3 - 1.21.1
 * Copyright (c) 2026 MrJulsen
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package de.mrjulsen.mcdragonlib.client.model.mesh;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1087;
import net.minecraft.class_1921;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_5819;
import net.minecraft.class_777;
import org.jetbrains.annotations.Nullable;

import com.google.common.collect.ListMultimap;
import com.google.common.collect.MultimapBuilder.ListMultimapBuilder;
import de.mrjulsen.mcdragonlib.client.model.DLBlockModelRegistry;
import de.mrjulsen.mcdragonlib.client.model.IDynamicBakedModel;
import de.mrjulsen.mcdragonlib.client.model.ModelCacheKey;
import de.mrjulsen.mcdragonlib.client.model.ModelContext;
import de.mrjulsen.mcdragonlib.util.DLColor;

public abstract class DLModel {

    public static enum ModelType {
        BLOCK(false),
        ITEM(true);

        final boolean isItem;

        private ModelType(boolean b) {
            this.isItem = b;
        }

        public static ModelType isItem(boolean b) {
            return b ? ITEM : BLOCK;
        }
    }

    private final Map<ModelCacheKey, Map<DirectionKey, ListMultimap<class_1921, class_777>>> cachedBlockQuads = new ConcurrentHashMap<>();
    private final Set<class_1921> knownRenderTypes = new HashSet<>();
    private volatile List<class_1921> renderTypes = null;

    /**
     * Creates the key for the cache of this model. This method is not called for item models.
     * @param state
     * @param random
     * @param contex
     * @return
     */
    protected ModelCacheKey createCacheKey(class_2680 state, class_5819 random, ModelContext contex) {
        return new ModelCacheKey(contex, state);
    }

    protected boolean invalidateCacheFor(ModelType type, class_2680 state, class_5819 random, ModelContext context) {
        return false;
    }

    public void clearCache() {
        cachedBlockQuads.clear();
        synchronized (knownRenderTypes) {
            knownRenderTypes.clear();
            renderTypes = null;
        }
    }

    public void clearCache(ModelCacheKey key) {
        cachedBlockQuads.remove(key);
    }

    /**
     * Enabled or disables ambient occlusion for this model.
     * 
     * @return {@code true} if ambient occlusion should be used, {@code false}
     *         otherwise. If the model's default behaviour should be kept, return
     *         {@code null}.
     */
    public @Nullable Boolean useAmbientOcclusion() {
        return null;
    }

    protected abstract Mesh getMesh(ModelType type, class_1087 originalModel, class_2680 state, class_5819 random, ModelContext context);


    private static class DirectionKey {
        private static final HashMap<class_2350, DirectionKey> keys;
        static {
            keys = new HashMap<>(class_2350.values().length + 1);
            for (class_2350 dir : class_2350.values()) {
                keys.put(dir, new DirectionKey());
            }
            keys.put(null, new DirectionKey());
        }

        private DirectionKey() {
        }

        public static DirectionKey of(class_2350 direction) {
            return keys.get(direction);
        }
    }

    public final List<class_777> getQuads(ModelType type, class_1087 originalModel, class_2680 state, class_5819 random, class_1921 renderType, class_2350 cullface, ModelContext context) {
        boolean isItem = type == ModelType.ITEM;
        ModelCacheKey key = !isItem ? createCacheKey(state, random, context) : new ModelCacheKey(context);

        if (invalidateCacheFor(type, state, random, context)) {
            cachedBlockQuads.remove(key);
        }

        Map<DirectionKey, ListMultimap<class_1921, class_777>> quadsByCullface = cachedBlockQuads.get(key);
        if (quadsByCullface == null) {
            quadsByCullface = buildQuads(type, originalModel, state, random, key.context());
            Map<DirectionKey, ListMultimap<class_1921, class_777>> existing = cachedBlockQuads.putIfAbsent(key, quadsByCullface);
            if (existing != null) {
                quadsByCullface = existing;
            }
        }

        ListMultimap<class_1921, class_777> quadsByRenderType = quadsByCullface.get(DirectionKey.of(cullface));
        if (quadsByRenderType == null) {
            return List.of();
        }

        if (isItem) {
            return new ArrayList<>(quadsByRenderType.values());
        }

        if (!quadsByRenderType.containsKey(renderType)) {
            return List.of();
        }
        return quadsByRenderType.get(renderType);
    }

    private Map<DirectionKey, ListMultimap<class_1921, class_777>> buildQuads(ModelType type, class_1087 originalModel, class_2680 state, class_5819 random, ModelContext context) {
        Mesh mesh = getMesh(type, originalModel, state, random, context);

        Map<DirectionKey, ListMultimap<class_1921, class_777>> map = new HashMap<>(6);
        for (Face face : mesh.getFaces()) {
            DirectionKey cullfaceKey = DirectionKey.of(face.getCullface());
            ListMultimap<class_1921, class_777> mm = map.computeIfAbsent(cullfaceKey,
                    x -> ListMultimapBuilder.hashKeys(class_1921.method_22720().size())
                            .arrayListValues().build());
            mm.putAll(face.getRenderType(), face.build());
        }

        synchronized (knownRenderTypes) {
            boolean changed = false;
            for (ListMultimap<class_1921, class_777> mm : map.values()) {
                changed |= knownRenderTypes.addAll(mm.keySet());
            }
            if (changed || renderTypes == null) {
                renderTypes = List.copyOf(knownRenderTypes);
            }
        }
        return map;
    }

    public final List<class_1921> getSupportedRenderTypes() {
        List<class_1921> types = renderTypes;
        return cachedBlockQuads.isEmpty() || types == null ? class_1921.method_22720() : types;
    }





    public static class_1087 getModel(class_2680 state) {
        return class_310.method_1551().method_1554().method_4743().method_3335(state);
    }

    public static boolean hasDynamicModel(class_2680 state) {
        class_1087 model = getModel(state);
        return model instanceof IDynamicBakedModel;
    }

    public static Optional<DLModel> of(class_2680 state) {
        if (!hasDynamicModel(state)) return Optional.empty();
        return Optional.ofNullable(((IDynamicBakedModel)getModel(state)).getModel());
    }

    public static void renderModel(class_4587.class_4665 pose, class_4588 consumer, @Nullable class_2680 state, ModelContext context) {
        of(state).ifPresent(x -> x.render(pose, consumer, state, context));
    }

    public static void renderModel(class_4587.class_4665 pose, class_4588 consumer, ModelType type, @Nullable class_2680 state, ModelContext context, DLColor color, int packedLight, int packedOverlay) {
        of(state).ifPresent(x -> x.render(pose, consumer, type, state, context, color, packedLight, packedOverlay));
    }

    public void render(class_4587.class_4665 pose, class_4588 consumer, @Nullable class_2680 state, ModelContext context) {
        render(pose, consumer, ModelType.BLOCK, state, context, DLColor.WHITE, 0, 0);
    }

    public void render(class_4587.class_4665 pose, class_4588 consumer, ModelType type, @Nullable class_2680 state, ModelContext context, DLColor color, int packedLight, int packedOverlay) {
        class_5819 randomSource = class_5819.method_43047();
        long seed = 42L;
        class_1087 originalModel = DLBlockModelRegistry.getOriginalModel(type, state);
        for (class_1921 renderType : getSupportedRenderTypes()) {
            for (class_2350 direction : class_2350.values()) {
                randomSource.method_43052(seed);
                renderQuadList(pose, consumer, color, getQuads(type, originalModel, state, randomSource, renderType, direction, context), packedLight, packedOverlay);
            }
            randomSource.method_43052(seed);
            renderQuadList(pose, consumer, color, getQuads(type, originalModel, state, randomSource, renderType, null, context), packedLight, packedOverlay);
        }
        
    }

    private static void renderQuadList(class_4587.class_4665 pose, class_4588 consumer, DLColor color, List<class_777> quads, int packedLight, int packedOverlay) {
        class_777 bakedQuad;
        float r;
        float g;
        float b;
        float a;
        for (Iterator<class_777> iterator = quads.iterator(); iterator.hasNext(); consumer.method_22919(pose, bakedQuad, r, g, b, a, packedLight, packedOverlay)) {
            bakedQuad = (class_777)iterator.next();
            if (bakedQuad.method_3360()) {
                r = class_3532.method_15363(color.getRedF(), 0.0F, 1.0F);
                g = class_3532.method_15363(color.getGreenF(), 0.0F, 1.0F);
                b = class_3532.method_15363(color.getBlueF(), 0.0F, 1.0F);
                a = class_3532.method_15363(color.getAlphaF(), 0.0F, 1.0F);
            } else {
                r = 1.0F;
                g = 1.0F;
                b = 1.0F;
                a = 1.0F;
            }
        }

    }
}
