package de.mrjulsen.trafficcraft.fabric;


import de.mrjulsen.mcdragonlib.DragonLib;
import de.mrjulsen.trafficcraft.TrafficCraft;
import de.mrjulsen.trafficcraft.config.ModCommonConfig;
import dev.architectury.registry.menu.MenuRegistry;
import fuzs.forgeconfigapiport.fabric.impl.core.NeoForgeConfigRegistryImpl;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1703;
import net.minecraft.class_3917;
import net.minecraft.class_3929;
import net.minecraft.class_3936;
import net.minecraft.class_437;
import net.neoforged.fml.config.ModConfig;

public final class CrossPlatformImpl {
    
    public static void registerConfig() {
        NeoForgeConfigRegistryImpl.INSTANCE.register(DragonLib.MODID, ModConfig.Type.COMMON, ModCommonConfig.SPEC, TrafficCraft.MOD_ID + "-common.toml");
    }
    
    @Environment(EnvType.CLIENT)
    public static <H extends class_1703, S extends class_437 & class_3936<H>> void registerScreenFactory(class_3917<? extends H> type, MenuRegistry.ScreenFactory<H, S> factory) {
        class_3929.method_17542(type, factory::create);
    }
}
