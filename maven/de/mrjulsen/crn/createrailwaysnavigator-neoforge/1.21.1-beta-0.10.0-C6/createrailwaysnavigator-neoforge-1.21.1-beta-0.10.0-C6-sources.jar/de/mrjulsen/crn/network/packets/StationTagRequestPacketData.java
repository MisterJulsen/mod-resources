package de.mrjulsen.crn.network.packets;

import de.mrjulsen.crn.data.settings.StationTag;
import de.mrjulsen.crn.data.settings.GlobalSettings;
import de.mrjulsen.mcdragonlib.data.DLStatus;
import de.mrjulsen.mcdragonlib.network.NetworkPacketContext;
import de.mrjulsen.mcdragonlib.network.NetworkPacketData;
import net.minecraft.nbt.CompoundTag;

public class StationTagRequestPacketData {

    private static final String NBT_DATA = "Data";

    public static class Request extends NetworkPacketData {
        private String name;

        public Request(DLStatus status) {
            super(status);
        }

        public Request(String name) {
            super(DLStatus.OK);
            this.name = name;
        }

        @Override
        protected void write(CompoundTag nbt) {
            nbt.putString(NBT_DATA, name);
        }

        @Override
        protected void read(CompoundTag nbt) {
            this.name = nbt.getString(NBT_DATA);
        }
    }

    public static class Response extends NetworkPacketData {
        private StationTag tag;

        public Response(DLStatus status) {
            super(status);
        }

        public Response(StationTag tag) {
            super(DLStatus.OK);
            this.tag = tag;
        }

        @Override
        protected void write(CompoundTag nbt) {
            nbt.put(NBT_DATA, tag.toNbt());
        }

        @Override
        protected void read(CompoundTag nbt) {
            this.tag = StationTag.fromNbt(nbt.getCompound(NBT_DATA), null);
        }

        public StationTag getTag() {
            return tag;
        }
    }

    public static Response handle(Request packet, NetworkPacketContext context) {
        return new Response(GlobalSettings.getInstance().getOrCreateStationTagFor(packet.name));
    }
    
}
