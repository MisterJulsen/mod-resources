package de.mrjulsen.crn.client.gui.windows;

import java.util.List;
import java.util.Optional;

import com.simibubi.create.AllItems;
import com.simibubi.create.content.trains.schedule.condition.TimedWaitCondition.TimeUnit;
import com.simibubi.create.foundation.gui.AllIcons;
import com.simibubi.create.foundation.utility.CreateLang;

import de.mrjulsen.crn.Constants;
import de.mrjulsen.crn.CreateRailwaysNavigator;
import de.mrjulsen.crn.client.CRNGui;
import de.mrjulsen.crn.client.ClientWrapper;
import de.mrjulsen.crn.client.gui.CreateDynamicWidgets;
import de.mrjulsen.crn.client.gui.CreateDynamicWidgets.BarColor;
import de.mrjulsen.crn.client.gui.CreateDynamicWidgets.ContainerColor;
import de.mrjulsen.crn.client.gui.CreateDynamicWidgets.FooterSize;
import de.mrjulsen.crn.client.gui.ModGuiIcons;
import de.mrjulsen.crn.client.gui.widgets.IconSlotWidget;
import de.mrjulsen.crn.client.gui.widgets.ModularWidgetContainer;
import de.mrjulsen.crn.client.gui.widgets.autocomplete.StationsAutocomplete;
import de.mrjulsen.crn.client.gui.widgets.create.CreateButton;
import de.mrjulsen.crn.client.gui.widgets.create.CreateItemPicker;
import de.mrjulsen.crn.client.gui.widgets.create.CreateScrollNumberInput;
import de.mrjulsen.crn.client.gui.widgets.create.CreateTextBox;
import de.mrjulsen.crn.data.ETimeSource;
import de.mrjulsen.crn.data.schedule.condition.TrainSeparationCondition;
import de.mrjulsen.crn.data.schedule.condition.ETrainFilter;
import de.mrjulsen.mcdragonlib.DragonLib;
import de.mrjulsen.mcdragonlib.client.gui.events.DLGuiStandardEvents;
import de.mrjulsen.mcdragonlib.client.gui.widgets.base.DLWindow;
import de.mrjulsen.mcdragonlib.client.gui.widgets.base.DLWindowManager;
import de.mrjulsen.mcdragonlib.client.gui.widgets.components.*;
import de.mrjulsen.mcdragonlib.client.gui.widgets.layout.FlowLayout;
import de.mrjulsen.mcdragonlib.client.util.DLGuiGraphics;
import de.mrjulsen.mcdragonlib.client.util.GuiUtils;
import de.mrjulsen.mcdragonlib.data.ETextAlignment;
import de.mrjulsen.mcdragonlib.util.TextUtils;
import de.mrjulsen.mcdragonlib.util.math.Rectangle;
import de.mrjulsen.mcdragonlib.util.time.DLTime;
import de.mrjulsen.mcdragonlib.util.time.DLTimeUnit;
import de.mrjulsen.mcdragonlib.util.time.TimePool;
import de.mrjulsen.mcdragonlib.util.time.VanillaTimeSystem;
import net.createmod.catnip.gui.element.GuiGameElement;
import net.createmod.catnip.gui.widget.AbstractSimiWidget;
import net.minecraft.ChatFormatting;
import net.minecraft.Util;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.world.item.ItemStack;

public class TrainSeparationSettingsWindow extends DLWindow {

    private static final MutableComponent title = TextUtils.translate(CreateRailwaysNavigator.MOD_ID + ".schedule.condition.train_separation.settings");
    private static final MutableComponent txtCustomStationFilter = TextUtils.translate(CreateRailwaysNavigator.MOD_ID + ".schedule.condition.train_separation.custom_station_filter").withStyle(s -> s.withColor(AbstractSimiWidget.HEADER_RGB.getRGB()));
    private static final MutableComponent txtCustomStationFilterDescription = TextUtils.translate(CreateRailwaysNavigator.MOD_ID + ".schedule.condition.train_separation.custom_station_filter.description").withStyle(ChatFormatting.GRAY);

	private static final ItemStack DISPLAY_ITEM = new ItemStack(AllItems.SCHEDULE.get());
    private static final int GUI_WIDTH = 212;
    private static final FooterSize headerSize = FooterSize.DEFAULT;
    private static final FooterSize footerSize = FooterSize.SMALL;

    private ModularWidgetContainer commonSettingsContainer;

    private final CompoundTag nbt;

    private DLTime currentTime = Constants.NULL_TIME;
    private ETrainFilter filter = ETrainFilter.ANY;
    private ETimeSource timeSource = ETimeSource.REAL_LIFE;
    private String stationFilterText = "";


    public TrainSeparationSettingsWindow(DLWindowManager manager, CompoundTag nbt) {
        super(manager);
        setWidth(GUI_WIDTH);
        windowSpawnPosition.set(WindowPosition.PARENT_CENTER);
        this.nbt = nbt;

        this.currentTime = DLTime.fromTicks(nbt.contains(TrainSeparationCondition.NBT_TICKS) ? nbt.getInt(TrainSeparationCondition.NBT_TICKS) : nbt.getInt(TrainSeparationCondition.NBT_TIME) * TimeUnit.values()[nbt.getInt(TrainSeparationCondition.NBT_TIME_UNIT)].ticksPer, VanillaTimeSystem.INSTANCE);
        this.filter = ETrainFilter.getByIndex(nbt.getByte(TrainSeparationCondition.NBT_TRAIN_FILTER));
        this.timeSource = ETimeSource.getByIndex(nbt.getByte(TrainSeparationCondition.NBT_TIME_SOURCE));
        this.stationFilterText = nbt.getString(TrainSeparationCondition.NBT_STATION_FILTER);


        CreateButton backButton = addComponent(new CreateButton(width() - 7 - CreateButton.WIDTH, height() - 6 - CreateButton.HEIGHT, AllIcons.I_CONFIRM));
        backButton.addEventListener(DLGuiStandardEvents.ClickEvent.class, (s, e) -> {
            getWindowManager().closeWindow(this);
            return false;
        });

        CreateButton helpButton = addComponent(new CreateButton(width() - 17 - CreateButton.WIDTH * 2, height() - 6 - CreateButton.HEIGHT, ModGuiIcons.HELP.getAsCreateIcon()));
        helpButton.addEventListener(DLGuiStandardEvents.ClickEvent.class, (s, e) -> {
            ClientWrapper.openUrl(Constants.HELP_PAGE_TRAIN_SEPARATION);
            return false;
        });
        helpButton.tooltip.set(new DLTooltip(List.of(Constants.TEXT_HELP), 200));


        commonSettingsContainer = addComponent(new ModularWidgetContainer(3, headerSize.size() + 1, width() - 6, 100));
        int minHeight = headerSize.size() + footerSize.size() + 2;

        initGui();

        setHeight(minHeight);
        commonSettingsContainer.addEventListener(ModularWidgetContainer.ContentLayoutUpdatedEvent.class, (s, e) -> {
            commonSettingsContainer.setHeight(e.layoutResult().contentHeight());
            setHeight(minHeight + e.layoutResult().contentHeight());
            backButton.setPosition(width() - 7 - CreateButton.WIDTH, height() - 6 - CreateButton.HEIGHT);
            helpButton.setPosition(width() - 17 - CreateButton.WIDTH * 2, height() - 6 - CreateButton.HEIGHT);
            setY(getWindowManager().getScreenHeight() / 2 - height() / 2);
            return false;
        });
    }

    private void initGui() {
        commonSettingsContainer.clearLines();

        DLPanel lineTimes = commonSettingsContainer.addLine("times");
        IconSlotWidget timesIcon = lineTimes.addComponent(new IconSlotWidget(0, 0));
        timesIcon.icon.set(ModGuiIcons.TIME.getAsSprite(16, 16));

        switch (timeSource) {
            case IN_GAME -> {
                TimePool pool = this.currentTime.asPool();

                CreateScrollNumberInput daysBox = lineTimes.addComponent(new CreateScrollNumberInput(0, 0, 22));
                daysBox.title.set(CreateLang.translateDirect("generic.unit.days"));
                daysBox.shiftStep.set(5D);
                daysBox.min.set(0D);
                daysBox.max.set(49D);
                daysBox.value.set((double)pool.extractGameDays(VanillaTimeSystem.INSTANCE));
                daysBox.addEventListener(DLNumberPicker.ValueChangedEvent.class, (s, e) -> {
                    TimePool p = this.currentTime.asPool();
                    int days = (int)p.extractGameDays(VanillaTimeSystem.INSTANCE);
                    int hours = (int)p.extractGameHours(VanillaTimeSystem.INSTANCE);
                    int minutes = (int)p.extractGameMinutes(VanillaTimeSystem.INSTANCE);
                    this.currentTime = DLTime.builder()
                            .gameDays((int)e.value(), VanillaTimeSystem.INSTANCE)
                            .gameHours(hours, VanillaTimeSystem.INSTANCE)
                            .gameMinutes(minutes, VanillaTimeSystem.INSTANCE)
                            .build();
                    return false;
                });

                CreateScrollNumberInput hoursBox = lineTimes.addComponent(new CreateScrollNumberInput(0, 0, 22));
                hoursBox.title.set(CreateLang.translateDirect("generic.unit.hours"));
                hoursBox.shiftStep.set(8D);
                hoursBox.min.set(0D);
                hoursBox.max.set(23D);
                hoursBox.value.set((double)pool.extractGameHours(VanillaTimeSystem.INSTANCE));
                hoursBox.addEventListener(DLNumberPicker.ValueChangedEvent.class, (s, e) -> {
                    TimePool p = this.currentTime.asPool();
                    int days = (int)p.extractGameDays(VanillaTimeSystem.INSTANCE);
                    int hours = (int)p.extractGameHours(VanillaTimeSystem.INSTANCE);
                    int minutes = (int)p.extractGameMinutes(VanillaTimeSystem.INSTANCE);
                    this.currentTime = DLTime.builder()
                            .gameDays(days, VanillaTimeSystem.INSTANCE)
                            .gameHours((int)e.value(), VanillaTimeSystem.INSTANCE)
                            .gameMinutes(minutes, VanillaTimeSystem.INSTANCE)
                            .build();
                    return false;
                });

                CreateScrollNumberInput minutesBox = lineTimes.addComponent(new CreateScrollNumberInput(0, 0, 22));
                minutesBox.title.set(CreateLang.translateDirect("generic.unit.minutes"));
                minutesBox.shiftStep.set(5D);
                minutesBox.min.set(0D);
                minutesBox.max.set(59D);
                minutesBox.value.set((double)pool.extractGameMinutes(VanillaTimeSystem.INSTANCE));
                minutesBox.addEventListener(DLNumberPicker.ValueChangedEvent.class, (s, e) -> {
                    TimePool p = this.currentTime.asPool();
                    int days = (int)p.extractGameDays(VanillaTimeSystem.INSTANCE);
                    int hours = (int)p.extractGameHours(VanillaTimeSystem.INSTANCE);
                    int minutes = (int)p.extractGameMinutes(VanillaTimeSystem.INSTANCE);
                    this.currentTime = DLTime.builder()
                            .gameDays(days, VanillaTimeSystem.INSTANCE)
                            .gameHours(hours, VanillaTimeSystem.INSTANCE)
                            .gameMinutes((int)e.value(), VanillaTimeSystem.INSTANCE)
                            .build();
                    return false;
                });
            }
            default -> {
                TimePool pool = this.currentTime.asPool();

                CreateScrollNumberInput minutesBox = lineTimes.addComponent(new CreateScrollNumberInput(0, 0, 30));
                minutesBox.title.set(CreateLang.translateDirect("generic.unit.minutes"));
                minutesBox.shiftStep.set(10D);
                minutesBox.min.set(0D);
                minutesBox.max.set(999D);
                minutesBox.value.set((double)pool.extractMinutes());
                minutesBox.addEventListener(DLNumberPicker.ValueChangedEvent.class, (s, e) -> {
                    TimePool p = this.currentTime.asPool();
                    int minutes = (int)p.extractMinutes();
                    int seconds = (int)p.extractSeconds();
                    this.currentTime = DLTime.builder()
                            .real((int)e.value(), DLTimeUnit.MINUTES)
                            .real(seconds, DLTimeUnit.SECONDS)
                            .build();
                    return false;
                });

                CreateScrollNumberInput secondsBox = lineTimes.addComponent(new CreateScrollNumberInput(0, 0, 30));
                secondsBox.title.set(CreateLang.translateDirect("generic.unit.seconds"));
                secondsBox.shiftStep.set(10D);
                secondsBox.min.set(0D);
                secondsBox.max.set(59D);
                secondsBox.value.set((double)pool.extractSeconds());
                secondsBox.addEventListener(DLNumberPicker.ValueChangedEvent.class, (s, e) -> {
                    TimePool p = this.currentTime.asPool();
                    int minutes = (int)p.extractMinutes();
                    int seconds = (int)p.extractSeconds();
                    this.currentTime = DLTime.builder()
                            .real(minutes, DLTimeUnit.MINUTES)
                            .real((int)e.value(), DLTimeUnit.SECONDS)
                            .build();
                    return false;
                });

            }
        }

        CreateItemPicker<ETimeSource> timeSourcePicker = lineTimes.addComponent(new CreateItemPicker<>(0, 0, 80));
        timeSourcePicker.title.set(ETimeSource.IN_GAME.getEnumTranslation());
        timeSourcePicker.hint.set(ETimeSource.IN_GAME.getEnumDescriptionTranslation());
        timeSourcePicker.formatter.set(item -> item == null ? TextUtils.empty() : item.getValueTranslation());
        timeSourcePicker.items.addAll(ETimeSource.values());
        timeSourcePicker.selectedItem.set(Optional.ofNullable(timeSource));

        timeSourcePicker.addEventListener(DLCycleButton.SelectedItemChanged.class, (s, e) -> {
            timeSourcePicker.selectedItem.get().ifPresent(i -> timeSource = i);
            initGui();
            return false;
        });




        DLPanel lineFilter = commonSettingsContainer.addLine("filter");
        IconSlotWidget filterIcon = lineFilter.addComponent(new IconSlotWidget(0, 0));
        filterIcon.icon.set(ModGuiIcons.TRAIN.getAsSprite(16, 16));

        CreateItemPicker<ETrainFilter> filterType = lineFilter.addComponent(new CreateItemPicker<>(0, 0, 120));
        filterType.renderArrow.set(true);
        filterType.title.set(ETrainFilter.ANY.getEnumTranslation());
        filterType.hint.set(ETrainFilter.ANY.getEnumDescriptionTranslation());
        filterType.formatter.set(item -> item == null ? TextUtils.empty() : item.getValueTranslation());
        filterType.items.addAll(ETrainFilter.values());
        filterType.selectedItem.set(Optional.ofNullable(filter));

        filterType.addEventListener(DLCycleButton.SelectedItemChanged.class, (s, e) -> {
            filterType.selectedItem.get().ifPresent(i -> filter = i);
            return false;
        });

        DLPanel lineStationFilter = commonSettingsContainer.addLine("stationFilter");
        IconSlotWidget textIcon = lineStationFilter.addComponent(new IconSlotWidget(0, 0));
        textIcon.icon.set(ModGuiIcons.TEXT.getAsSprite(16, 16));

        CreateTextBox stationText = lineStationFilter.addComponent(new CreateTextBox(0, 0, 120));
        stationText.text.get().set(stationFilterText);
        stationText.autocompleteManager.set(new StationsAutocomplete(List::of));
        stationText.layoutContraint.set(FlowLayout.FlowConstraint.FILL);
        stationText.tooltip.set(new DLTooltip(List.of(txtCustomStationFilter, txtCustomStationFilterDescription), 200));
        stationText.addEventListener(DLRichTextLabel.TextChangedEvent.class, (s, e) -> {
            this.stationFilterText = e.text().getPlainText();
            return false;
        });
    }

    @Override
    public void close() {
        nbt.putInt(TrainSeparationCondition.NBT_TICKS, (int)currentTime.toTicks(VanillaTimeSystem.INSTANCE));
        nbt.putByte(TrainSeparationCondition.NBT_TIME_SOURCE, timeSource.getIndex());
        nbt.putByte(TrainSeparationCondition.NBT_TRAIN_FILTER, filter.getIndex());
        nbt.putString(TrainSeparationCondition.NBT_STATION_FILTER, stationFilterText);
    }

    @Override
    public Rectangle getRenderBounds() {
        return Rectangle.withSize(0, 0, 1000, 1000);
    }

    @Override
    public void renderMainLayer(DLGuiGraphics graphics, double mouseX, double mouseY, Rectangle renderBounds) {
        CreateDynamicWidgets.renderWindow(graphics, 0, 0, width(), height(), ContainerColor.PURPLE, BarColor.GOLD, BarColor.GRAY, headerSize.size(), footerSize.size(), true);
        CreateDynamicWidgets.renderVerticalSeparator(graphics, width() - 31, height() - footerSize.size() + 2, footerSize.size() - 4, BarColor.GRAY);
        GuiUtils.drawString(graphics, graphics.defaultFont(), 6, 4, title, DragonLib.VANILLA_UI_FONT_COLOR, ETextAlignment.LEFT, false);

        GuiUtils.drawTexture(CRNGui.GUI, graphics, width() - 3, height() - 24, 11, 18, 0, 12);
        GuiGameElement.of(DISPLAY_ITEM).<GuiGameElement
			.GuiRenderBuilder>at(width() + 11, height() - 48, -200)
			.scale(4f)
			.render(graphics.graphics());

    }
}