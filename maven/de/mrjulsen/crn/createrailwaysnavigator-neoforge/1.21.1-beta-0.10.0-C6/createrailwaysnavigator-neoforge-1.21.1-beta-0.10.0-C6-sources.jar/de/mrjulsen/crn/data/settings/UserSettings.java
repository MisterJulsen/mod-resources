package de.mrjulsen.crn.data.settings;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collectors;

import de.mrjulsen.crn.CreateRailwaysNavigator;
import de.mrjulsen.crn.config.ModCommonConfig;
import de.mrjulsen.crn.core.navigator.RoutingStrategy;
import de.mrjulsen.crn.core.navigator.Waypoint;
import de.mrjulsen.crn.event.ModCommonEvents;
import de.mrjulsen.crn.exceptions.RuntimeSideException;
import de.mrjulsen.crn.network.packets.SaveUserSettingsPacketData;
import de.mrjulsen.crn.registry.ModNetworkManager;
import de.mrjulsen.crn.util.EDepartureBoardTrainFilter;
import de.mrjulsen.crn.util.ModUtils;
import de.mrjulsen.mcdragonlib.network.NetworkDirection;
import de.mrjulsen.mcdragonlib.util.DLUtils;
import de.mrjulsen.mcdragonlib.util.TextUtils;
import dev.architectury.platform.Platform;
import dev.architectury.utils.Env;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtIo;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.world.level.storage.LevelResource;
import net.minecraft.nbt.NbtAccounter;
import java.nio.file.Files;
import java.nio.file.Path;

public class UserSettings {

    private static final String FILENAME = CreateRailwaysNavigator.SHORT_MOD_ID + "_usersettings_";
    private static final int VERSION = 1;

    private static final String NBT_VERSION = "Version";
    private static final String NBT_DEPARTURE_IN = "DepartureIn";
    private static final String NBT_TRANSFER_TIME = "TransferTime";
    private static final String NBT_NAV_DIRECT_ONLY = "DirectOnly";
    private static final String NBT_NAV_ROUTING_STRATEGY = "RoutingStrategy";
    private static final String NBT_NAV_WAYPOINTS = "Waypoints";
    private static final String NBT_WAYPOINT_STATION = "Station";
    private static final String NBT_WAYPOINT_MIN_STAY = "MinStay";
    private static final String NBT_MAX_RESULTS = "MaxResults";
    private static final String NBT_TRAIN_CATEGORIES = "ExcludedTrainCategories";
    private static final String NBT_SAVED_ROUTES = "SavedRoutes";
    private static final String NBT_SEARCH_DEPARTURE_TIME = "SearchDepartureIn";
    private static final String NBT_SEARCH_TRAIN_CATEGORIES = "SearchExcludedTrainCategories";
    private static final String NBT_RECENT_SEARCH_QUERIES = "RecentSearchQueries";
    private static final String NBT_DEPARTURE_TRAIN_FILTER = "DepartureBoardTrainFilter";

    private static final Map<UUID, UserSettings> settingsInstances = new LinkedHashMap<>();

    private final Collection<UserSetting<?>> allSettings = new ArrayList<>();
    private final UUID owner;
    private final boolean readOnly;

    public final UserSetting<Integer> navigationDepartureInTicks = registerSetting(new UserSetting<>(() -> 0, NBT_DEPARTURE_IN, (nbt, val, name) -> nbt.putInt(name, val), CompoundTag::getInt, (val) -> ModUtils.formatDuration(val)));
    public final UserSetting<Integer> navigationTransferTime = registerSetting(new UserSetting<>(() -> 1000, NBT_TRANSFER_TIME, (nbt, val, name) -> nbt.putInt(name, val), CompoundTag::getInt, (val) -> ModUtils.formatDuration(val)));
    public final UserSetting<Integer> navigationMaxResults = registerSetting(new UserSetting<>(() -> 6, NBT_MAX_RESULTS, (nbt, val, name) -> nbt.putInt(name, Math.max(1, val)), (nbt, name) -> nbt.contains(name) ? Math.max(1, nbt.getInt(name)) : 6, String::valueOf));
    public final UserSetting<Boolean> navigationDirectOnly = registerSetting(new UserSetting<>(() -> false, NBT_NAV_DIRECT_ONLY, (nbt, val, name) -> nbt.putBoolean(name, val), CompoundTag::getBoolean, v -> (v ? CommonComponents.GUI_YES : CommonComponents.GUI_NO).getString()));
    public final UserSetting<RoutingStrategy> navigationRoutingStrategy = registerSetting(new UserSetting<>(() -> RoutingStrategy.FASTEST, NBT_NAV_ROUTING_STRATEGY, (nbt, val, name) -> nbt.putString(name, val.getId()), (nbt, name) -> RoutingStrategy.fromId(nbt.getString(name)), (val) -> val.getValueTranslation().getString()));

    public final UserSetting<List<Waypoint>> navigationWaypoints = registerSetting(new UserSetting<>(ArrayList::new, NBT_NAV_WAYPOINTS,
    (nbt, val, name) -> {
        ListTag list = new ListTag();
        for (Waypoint waypoint : val) {
            CompoundTag tag = new CompoundTag();
            tag.putString(NBT_WAYPOINT_STATION, waypoint.station());
            tag.putLong(NBT_WAYPOINT_MIN_STAY, waypoint.minStay());
            list.add(tag);
        }
        nbt.put(name, list);
    }, (nbt, name) -> {
        List<Waypoint> result = new ArrayList<>();
        for (Tag tag : nbt.getList(name, Tag.TAG_COMPOUND)) {
            CompoundTag compound = (CompoundTag) tag;
            result.add(new Waypoint(compound.getString(NBT_WAYPOINT_STATION), compound.getLong(NBT_WAYPOINT_MIN_STAY)));
        }
        return result;
    }, (val) -> val.isEmpty()
        ? TextUtils.translate("gui." + CreateRailwaysNavigator.MOD_ID + ".search_options.waypoints.none").getString()
        : TextUtils.translate("gui." + CreateRailwaysNavigator.MOD_ID + ".search_options.waypoints.count", val.size()).getString()));

    public final UserSetting<Set<UUID>> navigationExcludedTrainCategories = registerSetting(new UserSetting<>(HashSet::new, NBT_TRAIN_CATEGORIES,
    (nbt, val, name) -> {
        ListTag list = new ListTag();
        list.addAll(val.stream().map(x -> StringTag.valueOf(x.toString())).toList());
        nbt.put(name, list);
    }, (nbt, name) -> {
        return nbt.getList(name, Tag.TAG_STRING).stream().filter(x -> GlobalSettings.hasInstance() ? GlobalSettings.getInstance().trainCategoryExists(deserializeUuidString(x.getAsString())) : true).map(x -> deserializeUuidString(x.getAsString())).collect(Collectors.toSet());
    },(val) -> val.isEmpty() ? TextUtils.translate("gui." + CreateRailwaysNavigator.MOD_ID + ".search_options.train_categories.all").getString() : TextUtils.translate("gui." + CreateRailwaysNavigator.MOD_ID + ".search_options.train_categories.excluded", val.size()).getString()));

    public final UserSetting<Set<CompoundTag>> savedRoutes = registerSetting(new UserSetting<>(HashSet::new, NBT_SAVED_ROUTES, (nbt, val, name) -> {
        ListTag list = new ListTag();
        list.addAll(val);
        nbt.put(name, list);
    }, (nbt, name) -> {
        return nbt.getList(name, Tag.TAG_COMPOUND).stream().map(x -> (CompoundTag)x).collect(Collectors.toSet());
    },(val) -> TextUtils.translate("gui." + CreateRailwaysNavigator.MOD_ID + ".saved_routes.saved", val.size()).getString()));

    public final UserSetting<Integer> searchDepartureInTicks = registerSetting(new UserSetting<>(() -> 0, NBT_SEARCH_DEPARTURE_TIME, (nbt, val, name) -> nbt.putInt(name, val), (nbt, name) -> nbt.getInt(name), (val) -> ModUtils.formatDuration(val)));
    public final UserSetting<Set<UUID>> searchExcludedTrainCaegories = registerSetting(new UserSetting<>(HashSet::new, NBT_SEARCH_TRAIN_CATEGORIES,
    (nbt, val, name) -> {
        ListTag list = new ListTag();
        list.addAll(val.stream().map(x -> StringTag.valueOf(x.toString())).toList());
        nbt.put(name, list);
    }, (nbt, name) -> {
        return nbt.getList(name, Tag.TAG_STRING).stream().filter(x -> !GlobalSettings.hasInstance() || GlobalSettings.getInstance().trainCategoryExists(deserializeUuidString(x.getAsString()))).map(x -> deserializeUuidString(x.getAsString())).collect(Collectors.toSet());
    },(val) -> val.isEmpty() ? TextUtils.translate("gui." + CreateRailwaysNavigator.MOD_ID + ".search_options.train_categories.all").getString() : TextUtils.translate("gui." + CreateRailwaysNavigator.MOD_ID + ".search_options.train_categories.excluded", val.size()).getString()));

    public final UserSetting<EDepartureBoardTrainFilter> searchTrainFilter = registerSetting(new UserSetting<>(() -> EDepartureBoardTrainFilter.ARRIVAL_AND_DEPARTURE, NBT_DEPARTURE_TRAIN_FILTER, (nbt, val, name) -> nbt.putByte(name, val.getIndex()), (nbt, name) -> EDepartureBoardTrainFilter.getByIndex(nbt.getByte(name)), (val) -> val.getValueTranslation().getString()));

    public final UserSetting<RecentSearchQueries> recentSearchQueries = registerSetting(new UserSetting<>(RecentSearchQueries::new, NBT_RECENT_SEARCH_QUERIES,
    (nbt, val, name) -> {;
        nbt.put(name, val.toNbt());
    }, (nbt, name) -> {
        return RecentSearchQueries.fromNbt(nbt.getCompound(name));
    },(val) -> String.valueOf(val.queriesSize() + val.pinnedSize())));


    public UserSettings(UUID playerId, boolean readOnly) {
        this.owner = playerId;
        this.readOnly = readOnly;
    }

    public UUID getOwnerId() {
        return owner;
    }

    public boolean isReadOnly() {
        return readOnly;
    }

    private void checkReadOnly() {
        if (isReadOnly()) {
            throw new IllegalAccessError("This instance of the user settings is read-only!");
        }
    }

    private static UUID deserializeUuidString(String str) {
        try {
            return UUID.fromString(str);
        } catch (Exception e) {
            return TrainCategory.genMD5Uuid(str);
        }
    }

    private static void update(UserSettings settings) {
        if (settingsInstances.containsKey(settings.getOwnerId())) {
            settingsInstances.get(settings.getOwnerId()).checkReadOnly();
        }
        settingsInstances.put(settings.getOwnerId(), settings);
    }

    protected <T extends UserSetting<?>> T registerSetting(T setting) {
        allSettings.add(setting);
        return setting;
    }


    public static UserSettings getSettingsFor(UUID playerId, boolean readOnly) {
        return settingsInstances.computeIfAbsent(playerId, x -> UserSettings.load(x, readOnly));
    }

    public final void clientSave(Runnable andThen) throws RuntimeSideException {
        if (Platform.getEnvironment() == Env.SERVER) {
            throw new RuntimeSideException(true);
        }
        checkReadOnly();
        ModNetworkManager.SAVE_USER_SETTINGS.send(NetworkDirection.toServer(), new SaveUserSettingsPacketData(this), (response) -> DLUtils.doIfNotNull(andThen, x -> x.run()), () -> {});
    }

    public final synchronized void save() throws RuntimeSideException {
        if (!ModCommonEvents.hasServer()) {
            throw new RuntimeSideException(false);
        }
        checkReadOnly();
        UserSettings.update(this);
        CompoundTag nbt = this.toNbt();
        try {
            NbtIo.writeCompressed(nbt, ModCommonEvents.getCurrentServer().get().getWorldPath(new LevelResource("data/" + FILENAME + getOwnerId() + ".nbt")));
            if (ModCommonConfig.ADVANCED_LOGGING.get()) CreateRailwaysNavigator.LOGGER.info("Saved user settings.");
        } catch (IOException e) {
            CreateRailwaysNavigator.LOGGER.error("Unable to save user settings.", e);
        }
    }

    public static UserSettings load(UUID playerId, boolean readOnly) throws RuntimeSideException {
        if (!ModCommonEvents.hasServer()) {
            throw new RuntimeSideException(false);
        }

        Path settingsPath = ModCommonEvents.getCurrentServer().get().getWorldPath(new LevelResource("data/" + FILENAME + playerId + ".nbt"));

        if (Files.exists(settingsPath)) {
            try {
                return UserSettings.fromNbt(NbtIo.readCompressed(settingsPath, NbtAccounter.unlimitedHeap()), playerId, readOnly);
            } catch (IOException e) {
                CreateRailwaysNavigator.LOGGER.error("Cannot load user settings for player: " + playerId, e);
            }
        }
        return new UserSettings(playerId, readOnly);
    }

    public final CompoundTag toNbt() {
        CompoundTag nbt = new CompoundTag();
        allSettings.forEach(x -> x.serialize(nbt));
        nbt.putInt(NBT_VERSION, VERSION);
        return nbt;
    }

    public final static UserSettings fromNbt(CompoundTag nbt, UUID playerId, boolean readOnly) {
        UserSettings settings = new UserSettings(playerId, readOnly);
        @SuppressWarnings("unused") final int version = nbt.getInt(NBT_VERSION);
        settings.allSettings.forEach(x -> x.deserialize(nbt));
        return settings;
    }

    public static class UserSetting<T> {
        private T value;
        private final String serializationName;
        private final Supplier<T> defaultValue;
        private final ISerializationContext<T> serializer;
        private final BiFunction<CompoundTag, String, T> deserializer;
        private final Function<T, String> stringRepresentation;

        public UserSetting(Supplier<T> defaultValue, String serializationName, ISerializationContext<T> serializer, BiFunction<CompoundTag, String, T> deserializer, Function<T, String> stringRepresentation) {
            this.defaultValue = defaultValue;
            this.serializer = serializer;
            this.serializationName = serializationName;
            this.deserializer = deserializer;
            this.stringRepresentation = stringRepresentation;
            this.value = defaultValue.get();
        }

        public T getValue() {
            return value;
        }

        public void setValue(T value) {
            this.value = value;
        }

        public void setToDefault() {
            this.value = getDefault();
        }

        public T getDefault() {
            return defaultValue.get();
        }

        private void serialize(CompoundTag nbt) {
            serializer.execute(nbt, value, getSerializationName());
        }

        private T deserialize(CompoundTag nbt) {
            return value = deserializer.apply(nbt, getSerializationName());
        }

        private String getSerializationName() {
            return serializationName;
        }

        @Override
        public String toString() {
            return stringRepresentation.apply(value);
        }
    }

    @FunctionalInterface
    private static interface ISerializationContext<T> {
        void execute(CompoundTag nbt, T value, String serializationName);
    }
}
