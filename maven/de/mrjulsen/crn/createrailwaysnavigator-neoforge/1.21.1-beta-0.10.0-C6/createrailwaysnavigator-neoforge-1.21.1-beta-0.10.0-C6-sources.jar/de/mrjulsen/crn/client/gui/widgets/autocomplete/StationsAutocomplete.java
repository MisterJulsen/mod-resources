package de.mrjulsen.crn.client.gui.widgets.autocomplete;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

import de.mrjulsen.crn.registry.ModNetworkManager;
import de.mrjulsen.mcdragonlib.client.gui.widgets.base.DLWindowManager;
import de.mrjulsen.mcdragonlib.client.gui.widgets.components.DLRichTextEditBox;
import de.mrjulsen.mcdragonlib.client.gui.widgets.richtext.autocomplete.DLAutocompleteWindow;
import de.mrjulsen.mcdragonlib.client.gui.widgets.richtext.autocomplete.IAutocompletionManager;
import de.mrjulsen.mcdragonlib.network.NetworkDirection;
import net.minecraft.client.Minecraft;

public class StationsAutocomplete implements IAutocompletionManager<String> {

    private final List<String> names = new ArrayList<>();
    private final Supplier<List<String>> ignoreList;

    public StationsAutocomplete(Supplier<List<String>> ignoreList) {
        this.ignoreList = ignoreList;
    }

    @Override
    public DLAutocompleteWindow<String> createWindow(DLWindowManager windowManager, DLRichTextEditBox textBox) {
        DLAutocompleteWindow<String> window = IAutocompletionManager.super.createWindow(windowManager, textBox);
        ModNetworkManager.GET_ALL_STATION_NAMES.send(NetworkDirection.toServer(), (result) -> {
            Minecraft.getInstance().execute(() -> {
                List<String> filteredNames = new ArrayList<>(result.getStations());
                filteredNames.removeAll(ignoreList.get());
                names.clear();
                names.addAll(filteredNames
                        .stream()
                        .distinct()
                        .sorted(String::compareToIgnoreCase)
                        .toList());
                configureWindow(window, textBox);
            });
        }, () -> {});
        return window;
    }

    @Override
    public void configureWindow(DLAutocompleteWindow<String> window, DLRichTextEditBox textBox) {
        window.suggestions.set(names);
        window.filter.set(tag -> tag.toLowerCase().contains(textBox.text.get().getPlainText().toLowerCase()));
    }

    @Override
    public void closeWindow(DLAutocompleteWindow<String> window, DLRichTextEditBox textBox) {
        names.clear();
        IAutocompletionManager.super.closeWindow(window, textBox);
    }
    
}
