package de.mrjulsen.crn.data.navigation;

import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import java.util.Map;
import java.util.Queue;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.HashMap;

import com.google.common.collect.ImmutableList;

import de.mrjulsen.crn.CreateRailwaysNavigator;
import de.mrjulsen.crn.config.ModCommonConfig;
import de.mrjulsen.crn.data.train.ClientTrainStop;
import de.mrjulsen.crn.data.train.RoutePartProgressState;
import de.mrjulsen.crn.data.train.TrainStop;
import de.mrjulsen.crn.data.train.ClientTrainStop.TrainStopRealTimeData;
import de.mrjulsen.crn.data.train.TrainStatus.CompiledTrainStatus;
import de.mrjulsen.crn.util.IListenable;
import de.mrjulsen.mcdragonlib.util.Cache;
import de.mrjulsen.mcdragonlib.util.Holder.MutableHolder;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceLocation;

public class ClientRoutePart extends RoutePart implements ITrainListenerClient<ClientRoutePart.TrainRealTimeData>, IListenable<ClientRoutePart.ListenerNotificationData> {

    public static record ListenerNotificationData(ClientRoutePart part, ClientTrainStop trainStop) {}
    public static record QueuedAnnouncementEvent(Runnable callback, ClientTrainStop trainStop) {}

    public static final String EVENT_UPDATE = "update2";
    public static final String EVENT_ANNOUNCE_START = "announce_start";
    public static final String EVENT_ARRIVAL_AT_START = "arrival_at_start";
    public static final String EVENT_DEPARTURE_FROM_START = "departure_at_start";
    public static final String EVENT_WHILE_TRANSIT = "while_transit";
    public static final String EVENT_NEXT_STOP_ANNOUNCED = "next_stop_announced";
    public static final String EVENT_ARRIVAL_AT_STOPOVER = "arrival_at_stopover";
    public static final String EVENT_DEPARTURE_FROM_STOPOVER = "departure_at_stopover";
    public static final String EVENT_LAST_STOP_ANNOUNCED = "last_stop_announced";
    public static final String EVENT_ARRIVAL_AT_LAST_STOP = "arrival_at_last_stop";
    public static final String EVENT_DEPARTURE_FROM_LAST_STOP = "departure_at_last_stop";
    public static final String EVENT_FIRST_STOP_STATION_CHANGED = "first_stop_station_changed";
    public static final String EVENT_FIRST_STOP_DELAYED = "first_stop_delayed";
    public static final String EVENT_LAST_STOP_STATION_CHANGED = "last_stop_station_changed";
    public static final String EVENT_LAST_STOP_DELAYED = "last_stop_delayed";
    public static final String EVENT_ANY_STOP_ANNOUNCED = "any_stop_announced";
    public static final String EVENT_ARRIVAL_AT_ANY_STOP = "arrival_at_any_stop";
    public static final String EVENT_DEPARTURE_FROM_ANY_STOP = "departure_at_any_stop";
    public static final String EVENT_SCHEDULE_CHANGED = "schedule_changed";
    public static final String EVENT_TRAIN_CANCELLED = "train_cancelled";
    
    private final Map<String, IdentityHashMap<Object, Consumer<ListenerNotificationData>>> listeners = new HashMap<>();

    // state    
    private RoutePartProgressState progressState = RoutePartProgressState.BEFORE;
    private ClientTrainStop nextStop;
    private final Queue<QueuedAnnouncementEvent> queuedAnnouncements = new ConcurrentLinkedQueue<>();

    private final Cache<List<ClientTrainStop>> clientTrainStops = new Cache<>(() -> getAllStops().stream().filter(x -> x instanceof ClientTrainStop).map(x -> (ClientTrainStop)x).toList());
    private final Cache<List<ClientTrainStop>> clientJourneyStops = new Cache<>(() -> getAllJourneyStops().stream().filter(x -> x instanceof ClientTrainStop).map(x -> (ClientTrainStop)x).toList());


    public ClientRoutePart(UUID sessionId, UUID trainId, List<TrainStop> routeStops, List<TrainStop> allStops) {
        super(sessionId, trainId, routeStops, allStops);
        this.nextStop = getFirstClientStop();

        createEvent(EVENT_UPDATE);
        createEvent(EVENT_ANNOUNCE_START);
        createEvent(EVENT_ARRIVAL_AT_START);
        createEvent(EVENT_DEPARTURE_FROM_START);
        createEvent(EVENT_WHILE_TRANSIT);
        createEvent(EVENT_NEXT_STOP_ANNOUNCED);
        createEvent(EVENT_ARRIVAL_AT_STOPOVER);
        createEvent(EVENT_DEPARTURE_FROM_STOPOVER);
        createEvent(EVENT_LAST_STOP_ANNOUNCED);
        createEvent(EVENT_ARRIVAL_AT_LAST_STOP);
        createEvent(EVENT_DEPARTURE_FROM_LAST_STOP);
        createEvent(EVENT_FIRST_STOP_STATION_CHANGED);
        createEvent(EVENT_FIRST_STOP_DELAYED);
        createEvent(EVENT_LAST_STOP_STATION_CHANGED);
        createEvent(EVENT_LAST_STOP_DELAYED);
        createEvent(EVENT_ANY_STOP_ANNOUNCED);
        createEvent(EVENT_ARRIVAL_AT_ANY_STOP);
        createEvent(EVENT_DEPARTURE_FROM_ANY_STOP);
        createEvent(EVENT_SCHEDULE_CHANGED);
        createEvent(EVENT_TRAIN_CANCELLED);

        getFirstClientStop().listen(ClientTrainStop.EVENT_ANNOUNCE_NEXT_STOP, this, x -> {
            notifyListeners(EVENT_ANNOUNCE_START, new ListenerNotificationData(this, x));
        });
        getFirstClientStop().listen(ClientTrainStop.EVENT_STATION_REACHED, this, x -> {
            progressState = RoutePartProgressState.AT_START;
            notifyListeners(EVENT_ARRIVAL_AT_START, new ListenerNotificationData(this, x));
            notifyListeners(EVENT_ARRIVAL_AT_ANY_STOP, new ListenerNotificationData(this, x));
        });
        getFirstClientStop().listen(ClientTrainStop.EVENT_STATION_LEFT, this, x -> {
            progressState = RoutePartProgressState.TRAVELING;
            notifyListeners(EVENT_DEPARTURE_FROM_START, new ListenerNotificationData(this, x));
            notifyListeners(EVENT_DEPARTURE_FROM_ANY_STOP, new ListenerNotificationData(this, x));
        });
        getFirstClientStop().listen(ClientTrainStop.EVENT_DELAY, this, x -> {
            notifyListeners(EVENT_FIRST_STOP_DELAYED, new ListenerNotificationData(this, x));
        });
        getFirstClientStop().listen(ClientTrainStop.EVENT_STATION_CHANGED, this, x -> {
            notifyListeners(EVENT_FIRST_STOP_STATION_CHANGED, new ListenerNotificationData(this, x));
        });

        for (ClientTrainStop stop : getClientStopovers()) {
            stop.listen(ClientTrainStop.EVENT_ANNOUNCE_NEXT_STOP, this, x -> {
                queuedAnnouncements.add(new QueuedAnnouncementEvent(() -> {
                    progressState = RoutePartProgressState.NEXT_STOP_ANNOUNCED;
                    notifyListeners(EVENT_NEXT_STOP_ANNOUNCED, new ListenerNotificationData(this, x));
                    notifyListeners(EVENT_ANY_STOP_ANNOUNCED, new ListenerNotificationData(this, x));
                }, x));
            });
            stop.listen(ClientTrainStop.EVENT_STATION_REACHED, this, x -> {
                progressState = RoutePartProgressState.AT_STOPOVER;
                notifyListeners(EVENT_ARRIVAL_AT_STOPOVER, new ListenerNotificationData(this, x));
                notifyListeners(EVENT_ARRIVAL_AT_ANY_STOP, new ListenerNotificationData(this, x));
            });
            stop.listen(ClientTrainStop.EVENT_STATION_LEFT, this, x -> {
                progressState = RoutePartProgressState.TRAVELING;
                notifyListeners(EVENT_DEPARTURE_FROM_STOPOVER, new ListenerNotificationData(this, x));
                notifyListeners(EVENT_DEPARTURE_FROM_ANY_STOP, new ListenerNotificationData(this, x));
            });
        }

        getLastClientStop().listen(ClientTrainStop.EVENT_ANNOUNCE_NEXT_STOP, this, x -> {
            queuedAnnouncements.add(new QueuedAnnouncementEvent(() -> {
                progressState = RoutePartProgressState.END_ANNOUNCED;
                notifyListeners(EVENT_LAST_STOP_ANNOUNCED, new ListenerNotificationData(this, x));
                notifyListeners(EVENT_ANY_STOP_ANNOUNCED, new ListenerNotificationData(this, x));
            }, x));
        });
        getLastClientStop().listen(ClientTrainStop.EVENT_STATION_REACHED, this, x -> {
            progressState = RoutePartProgressState.AT_END;
            queuedAnnouncements.clear();
            notifyListeners(EVENT_ARRIVAL_AT_LAST_STOP, new ListenerNotificationData(this, x));
            notifyListeners(EVENT_ARRIVAL_AT_ANY_STOP, new ListenerNotificationData(this, x));
        });
        getLastClientStop().listen(ClientTrainStop.EVENT_STATION_LEFT, this, x -> {
            progressState = RoutePartProgressState.AFTER;
            queuedAnnouncements.clear();
            notifyListeners(EVENT_DEPARTURE_FROM_LAST_STOP, new ListenerNotificationData(this, x));
            notifyListeners(EVENT_DEPARTURE_FROM_ANY_STOP, new ListenerNotificationData(this, x));
            close();
        });
        getLastClientStop().listen(ClientTrainStop.EVENT_DELAY, this, x -> {
            notifyListeners(EVENT_LAST_STOP_DELAYED, new ListenerNotificationData(this, x));
        });
        getLastClientStop().listen(ClientTrainStop.EVENT_STATION_CHANGED, this, x -> {
            notifyListeners(EVENT_LAST_STOP_STATION_CHANGED, new ListenerNotificationData(this, x));
        });

        

        getAllClientStops().forEach(x -> {
            x.listen(ClientTrainStop.EVENT_SCHEDULE_CHANGED, this, a -> {
                notifyListeners(EVENT_SCHEDULE_CHANGED, new ListenerNotificationData(this, a));
            });
        });


        // TEST
        listen(EVENT_DEPARTURE_FROM_ANY_STOP, this, (p) -> {
            int idx = routeStops.indexOf(p.trainStop());
            if (idx < 0 || idx >= routeStops.size() - 1) {
                nextStop = p.trainStop();
            } else {
                nextStop = (ClientTrainStop)routeStops.get(idx + 1);
            }
        });
    }

    @Override
    public Map<String, IdentityHashMap<Object, Consumer<ListenerNotificationData>>> getListeners() {
        return listeners;
    }

    public List<ClientTrainStop> getAllJourneyClientStops() {
        return clientJourneyStops.get();
    }

    public List<ClientTrainStop> getAllClientStops() {
        return clientTrainStops.get();
    }

    public List<ClientTrainStop> getClientStopovers() {
        return getAllClientStops().size() <= 2 ? List.of() : ImmutableList.copyOf(getAllClientStops().subList(1, routeStops.size() - 1));
    }

    public ClientTrainStop getFirstClientStop() {
        return getAllClientStops().get(0);
    }

    public ClientTrainStop getLastClientStop() {
        return getAllClientStops().get(getAllClientStops().size() - 1);
    }

    public ClientTrainStop getNextStop() {
        return nextStop;
    }

    public int getNextStopIndex() {
        return routeStops.indexOf(nextStop);
    }

    public RoutePartProgressState getProgressState() {
        return progressState;
    }

    @Override
    public void update(TrainRealTimeData data) {
        if (isCancelled()) {
            return;
        }

        status.clear();
        if (!data.sessionId().equals(getSessionId())) {
            cancelled = true;
        }

        MutableHolder<Boolean> shouldRenderStatus = new MutableHolder<>(false);

        List<ClientTrainStop> allStops = getAllClientStops();
        synchronized (allStops) {
            for (ClientTrainStop stop : allStops) {
                if (data.stationData().containsKey(stop.getScheduleIndex())) {
                    stop.update(data.stationData().get(stop.getScheduleIndex()));
                    if (stop.shouldRenderRealTime())  {
                        shouldRenderStatus.set(true);
                    }
                }
            }
        }
        List<ClientTrainStop> allJourneyStops = getAllJourneyClientStops();
        synchronized (allJourneyStops) {
            for (ClientTrainStop stop : allJourneyStops) {
                if (data.stationData().containsKey(stop.getScheduleIndex())) {
                    stop.update(data.stationData().get(stop.getScheduleIndex()));
                }
            }
        }

        if (shouldRenderStatus.get() || data.cancelled()) {
            status.addAll(data.statusInfo());
        }

        this.cancelled = this.cancelled || data.cancelled();

        notifyListeners(EVENT_UPDATE, new ListenerNotificationData(this, nextStop));
        if (getProgressState() == RoutePartProgressState.TRAVELING) {
            notifyListeners(EVENT_WHILE_TRANSIT, new ListenerNotificationData(this, nextStop));

            while (!queuedAnnouncements.isEmpty()) {
                QueuedAnnouncementEvent event = queuedAnnouncements.peek();
                if (routeStops.indexOf(event.trainStop()) > getNextStopIndex()) {
                    break;
                }
                event = queuedAnnouncements.poll();
                if (getNextStop() != event.trainStop()) {
                    continue;
                }
                event.callback().run();
                break;
            }
        }

        if (isCancelled()) {
            if (ModCommonConfig.ADVANCED_LOGGING.get()) CreateRailwaysNavigator.LOGGER.info("Train got cancelled. Closing route...");
            notifyListeners(EVENT_TRAIN_CANCELLED, new ListenerNotificationData(this, nextStop));
            close();
        }
    }

    public static RoutePart fromNbt(CompoundTag nbt) {
        return new ClientRoutePart(
            nbt.m_128441_(NBT_SESSION_ID) ? nbt.m_128342_(NBT_SESSION_ID) : new UUID(0, 0),
            nbt.m_128342_(NBT_TRAIN_ID),
            nbt.m_128437_(NBT_STOPS, Tag.f_178203_).stream().map(x -> ClientTrainStop.fromNbt((CompoundTag)x)).toList(),
            nbt.m_128437_(NBT_JOURNEY, Tag.f_178203_).stream().map(x -> ClientTrainStop.fromNbt((CompoundTag)x)).toList()
        );
    }

    @Override
    public void close() {
        List<ClientTrainStop> allStops = getAllClientStops();
        synchronized (allStops) {
            for (ClientTrainStop stop : allStops) {
                stop.stopListeningAll(this);
                stop.close();
            }
        }
        List<ClientTrainStop> allJourneyStops = getAllJourneyClientStops();
        synchronized (allJourneyStops) {
            for (ClientTrainStop stop : allJourneyStops) {
                stop.stopListeningAll(this);
                stop.close();
            }
        }
        stopListeningAll(this);

    }


    public static class TrainRealTimeData {
        
        private static final String NBT_SESSION_ID = "SessionId";
        private static final String NBT_STATUS_INFOS = "Status";
        private static final String NBT_CANCELLED = "Cancelled";

        private final UUID sessionId;
        private final Map<Integer, TrainStopRealTimeData> stationData;
        private final Set<ResourceLocation> statusLocations;
        private final Set<CompiledTrainStatus> status;
        private final boolean cancelled;

        private TrainRealTimeData(UUID sessionId, Map<Integer, TrainStopRealTimeData> stationData, Set<ResourceLocation> statusLocations, Set<CompiledTrainStatus> status, boolean cancelled) {
            this.sessionId = sessionId;
            this.stationData = stationData;
            this.statusLocations = statusLocations;
            this.status = status;
            this.cancelled = cancelled;
        }

        public static TrainRealTimeData createServer(UUID sessionId, Map<Integer, TrainStopRealTimeData> stationData, Set<ResourceLocation> statusLocations, boolean cancelled) {
            return new TrainRealTimeData(sessionId, stationData, statusLocations, null, cancelled);
        }

        private static TrainRealTimeData createClient(UUID sessionId, Map<Integer, TrainStopRealTimeData> stationData, Set<CompiledTrainStatus> status, boolean cancelled) {
            return new TrainRealTimeData(sessionId, stationData, null, status, cancelled);
        }

        public CompoundTag toNbt() {
            CompoundTag nbt = new CompoundTag();
            nbt.m_128362_(NBT_SESSION_ID, sessionId);
            ListTag statusList = new ListTag();
            for (ResourceLocation s : statusLocations) {
                statusList.add(StringTag.m_129297_(s.toString()));
            }
            nbt.m_128365_(NBT_STATUS_INFOS, statusList);
            nbt.m_128379_(NBT_CANCELLED, cancelled);

            for (Map.Entry<Integer, TrainStopRealTimeData> e : stationData.entrySet()) {
                nbt.m_128365_("" + e.getKey(), e.getValue().toNbt());
            }
            return nbt;
        }

        public static TrainRealTimeData fromNbt(CompoundTag nbt) {
            return createClient(
                nbt.m_128342_(NBT_SESSION_ID),
                nbt.m_128431_().stream().filter(x -> { try { Integer.parseInt(x); return true; } catch (Exception e) { return false; } }).collect(Collectors.toMap(x -> Integer.parseInt(x), x -> TrainStopRealTimeData.fromNbt(nbt.m_128469_(x)))),
                nbt.m_128437_(NBT_STATUS_INFOS, Tag.f_178201_).stream().map(x -> CompiledTrainStatus.load(new ResourceLocation(((StringTag)x).m_7916_()))).collect(Collectors.toSet()),
                nbt.m_128471_(NBT_CANCELLED)
            );
        }

        public UUID sessionId() {
            return sessionId;
        }

        public Map<Integer, TrainStopRealTimeData> stationData() {
            return stationData;
        }

        public Set<CompiledTrainStatus> statusInfo() {
            return status;
        }

        public boolean cancelled() {
            return cancelled;
        }
    }
}
