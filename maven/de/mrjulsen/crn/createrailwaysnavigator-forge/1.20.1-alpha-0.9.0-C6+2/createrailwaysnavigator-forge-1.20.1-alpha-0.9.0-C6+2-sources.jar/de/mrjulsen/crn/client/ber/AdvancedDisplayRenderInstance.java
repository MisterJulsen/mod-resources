package de.mrjulsen.crn.client.ber;

import com.mojang.math.Axis;

import de.mrjulsen.crn.block.AbstractAdvancedDisplayBlock;
import de.mrjulsen.crn.block.AbstractAdvancedSidedDisplayBlock;
import de.mrjulsen.crn.block.blockentity.AdvancedDisplayBlockEntity;
import de.mrjulsen.crn.block.blockentity.AdvancedDisplayBlockEntity.EUpdateReason;
import de.mrjulsen.crn.block.properties.ESide;
import de.mrjulsen.crn.client.AdvancedDisplaysRegistry;
import de.mrjulsen.crn.client.AdvancedDisplaysRegistry.DisplayTypeResourceKey;
import de.mrjulsen.crn.client.ber.variants.AbstractAdvancedDisplayRenderer;
import de.mrjulsen.mcdragonlib.client.ber.AbstractBlockEntityRenderInstance;
import de.mrjulsen.mcdragonlib.client.ber.BERGraphics;
import de.mrjulsen.mcdragonlib.util.Pair;
import de.mrjulsen.mcdragonlib.util.Tripple;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

public class AdvancedDisplayRenderInstance extends AbstractBlockEntityRenderInstance<AdvancedDisplayBlockEntity> {

    public AbstractAdvancedDisplayRenderer<?> renderSubtype;
    private DisplayTypeResourceKey lastType;
    private int lastXSize = 0;

    public AdvancedDisplayRenderInstance(AdvancedDisplayBlockEntity blockEntity) {
        super(blockEntity);
    }

    @Override
    public void render(BERGraphics<AdvancedDisplayBlockEntity> graphics, float partialTick) {
        
        if (!graphics.blockEntity().isController() || renderSubtype == null) {
            return;
        }
        
        final int light = graphics.blockEntity().isGlowing() ? LightTexture.f_173040_ : graphics.packedLight();
        BlockState state = graphics.blockEntity().m_58900_();

        if (state.m_60734_() instanceof AbstractAdvancedDisplayBlock) {

            renderSubtype.renderTick(Minecraft.m_91087_().m_91297_());
            
            Tripple<Float, Float, Float> rotation = graphics.blockEntity().renderRotation.get();
            Pair<Float, Float> offset = graphics.blockEntity().renderOffset.get();
            Pair<Float, Float> zOffset = graphics.blockEntity().renderZOffset.get();
            float scale = graphics.blockEntity().renderScale.get();

            graphics.poseStack().m_85836_();
            graphics.poseStack().m_252880_(offset.getFirst(), offset.getSecond(), zOffset.getFirst());
            graphics.poseStack().m_252781_(Axis.f_252529_.m_252977_(rotation.getFirst()));
            graphics.poseStack().m_252781_(Axis.f_252436_.m_252977_(rotation.getSecond()));
            graphics.poseStack().m_252781_(Axis.f_252403_.m_252977_(rotation.getThird()));
            graphics.poseStack().m_85841_(scale, scale, 1);   
            renderSubtype.render(graphics, partialTick, this, light, false);
            graphics.poseStack().m_85849_();

            if (!(state.m_60734_() instanceof AbstractAdvancedSidedDisplayBlock) || state.m_61143_(AbstractAdvancedSidedDisplayBlock.SIDE) == ESide.BOTH) {
                graphics.poseStack().m_85836_();
                graphics.poseStack().m_252781_(Axis.f_252436_.m_252977_(180));
                graphics.poseStack().m_252880_(-graphics.blockEntity().getXSize() * 16, 0, -16);
                graphics.poseStack().m_252880_(offset.getFirst(), offset.getSecond(), zOffset.getSecond());
                graphics.poseStack().m_252781_(Axis.f_252529_.m_252977_(rotation.getFirst()));
                graphics.poseStack().m_252781_(Axis.f_252436_.m_252977_(rotation.getSecond()));
                graphics.poseStack().m_252781_(Axis.f_252403_.m_252977_(rotation.getThird()));
                graphics.poseStack().m_85841_(scale, scale, 1);
                renderSubtype.render(graphics, partialTick, this, light, true);
                graphics.poseStack().m_85849_();
            }
        }
    }

    @Override
    public void tick(Level level, BlockPos pos, BlockState state, AdvancedDisplayBlockEntity blockEntity) {
        renderSubtype.tick(level, pos, state, blockEntity, this);

        if (blockEntity.getXSizeScaled() != lastXSize) {
            update(level, pos, state, blockEntity, EUpdateReason.LAYOUT_CHANGED);
        }
        lastXSize = blockEntity.getXSizeScaled();
    }

    @Override
    public void update(Level level, BlockPos pos, BlockState state, AdvancedDisplayBlockEntity blockEntity, Object data) {
        EUpdateReason reason = (EUpdateReason)data;
        DisplayTypeResourceKey type = blockEntity.getDisplayType();
        if (lastType == null || !lastType.equals(type)) {
            renderSubtype = AdvancedDisplaysRegistry.createRenderer(type);
        }

        lastType = type;

        renderSubtype.update(level, pos, state, blockEntity, this, reason);
    }
}
