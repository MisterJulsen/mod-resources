package de.mrjulsen.crn.block.properties;

import java.util.Arrays;

import de.mrjulsen.crn.CreateRailwaysNavigator;
import de.mrjulsen.crn.client.gui.ModGuiIcons;
import de.mrjulsen.mcdragonlib.data.ITranslatableEnum;

public enum EDisplayType implements ITranslatableEnum {
	TRAIN_DESTINATION((byte)0, "train_destination", ModGuiIcons.TRAIN_DESTINATION, EDisplayTypeDataSource.TRAIN_INFORMATION),
    PASSENGER_INFORMATION((byte)1, "passenger_information", ModGuiIcons.PASSENGER_INFORMATION, EDisplayTypeDataSource.TRAIN_INFORMATION),
	PLATFORM((byte)2, "platform", ModGuiIcons.PLATFORM_INFORMATION, EDisplayTypeDataSource.PLATFORM),
	DEPARTURE_BOARD((byte)3, "departure_board", ModGuiIcons.PLATFORM_INFORMATION, EDisplayTypeDataSource.PLATFORM),
	STATIC_TEXT((byte)4, "static_text", ModGuiIcons.TEXT, EDisplayTypeDataSource.NONE);
	
	private String name;
	private byte id;
	private ModGuiIcons icon;
	private EDisplayTypeDataSource source;
	
	private EDisplayType(byte id, String name, ModGuiIcons icon, EDisplayTypeDataSource source) {
		this.name = name;
		this.id = id;
		this.icon = icon;
		this.source = source;
	}
	
	public String getInfoTypeName() {
		return this.name;
	}

	public byte getId() {
		return this.id;
	}	

	public ModGuiIcons getIcon() {
		return icon;
	}

	public EDisplayTypeDataSource getSource() {
		return source;
	}

	public static EDisplayType getTypeById(int id) {
		return Arrays.stream(values()).filter(x -> x.getId() == (byte)id).findFirst().orElse(EDisplayType.TRAIN_DESTINATION);
	}

	public static EDisplayType getTypeByName(String name) {
		return Arrays.stream(values()).filter(x -> x.name.equals(name)).findFirst().orElse(EDisplayType.TRAIN_DESTINATION);
	}

    @Override
    public String m_7912_() {
        return name;
    }

	@Override
	public Data getTranslationData() {
		return new Data(CreateRailwaysNavigator.MOD_ID, "display_type", name);
	} 

	public static enum EDisplayTypeDataSource {
		TRAIN_INFORMATION(0),
		PLATFORM(1),
		NONE(2);

		private int index;

		EDisplayTypeDataSource(int index) {
			this.index = index;
		}

		public int getIndex() {
			return index;
		}

		public static EDisplayTypeDataSource getByIndex(int index) {
			return Arrays.stream(EDisplayTypeDataSource.values()).filter(x -> x.getIndex() == index).findFirst().orElse(PLATFORM);
		}
	}
}
