package de.mrjulsen.crn.network.packets.pain;

import java.util.Optional;
import java.util.UUID;
import de.mrjulsen.crn.data.TrainCategory;
import de.mrjulsen.crn.data.storage.GlobalSettings;
import de.mrjulsen.mcdragonlib.data.DLStatus;
import de.mrjulsen.mcdragonlib.network.NetworkPacketContext;
import de.mrjulsen.mcdragonlib.network.NetworkPacketData;
import net.minecraft.nbt.CompoundTag;

public class GetTrainCategoryPacketData {

    private static final String NBT_DATA = "Data";
    
    private static final String NBT_ID = "Id";

    public static class Request extends NetworkPacketData {
        
        private UUID id;

        public Request(DLStatus status) {
            super(status);
        }

        public Request(UUID id) {
            super(DLStatus.OK);
            this.id = id;
        }

        @Override
        protected void write(CompoundTag nbt) {
            nbt.m_128362_(NBT_ID, id);
        }

        @Override
        protected void read(CompoundTag nbt) {
            this.id = nbt.m_128342_(NBT_ID);
        }
    }

    public static class Response extends NetworkPacketData {
        private Optional<TrainCategory> category;

        public Response(DLStatus status) {
            super(status);
        }

        public Response(Optional<TrainCategory> category) {
            super(DLStatus.OK);
            this.category = category;
        }

        @Override
        protected void write(CompoundTag nbt) {
            this.category.ifPresent(x -> nbt.m_128365_(NBT_DATA, x.toNbt()));
        }

        @Override
        protected void read(CompoundTag nbt) {
            if (nbt.m_128441_(NBT_DATA)) {
                this.category = Optional.ofNullable(TrainCategory.fromNbt(nbt.m_128469_(NBT_DATA)));
            } else {
                this.category = Optional.empty();
            }
        }

        public Optional<TrainCategory> getCategory() {
            return category;
        }
    }

    public static Response handle(Request packet, NetworkPacketContext context) {
        return new Response(GlobalSettings.getInstance().getTrainCategory(packet.id));
    }
    
}
