package de.mrjulsen.crn.registry.forge;

import com.simibubi.create.foundation.block.connected.ConnectedTextureBehaviour;
import com.simibubi.create.foundation.data.CreateRegistrate;
import com.tterrag.registrate.builders.BlockBuilder;
import com.tterrag.registrate.util.nullness.NonNullUnaryOperator;
import de.mrjulsen.crn.block.AbstractAdvancedDisplayBlock;
import de.mrjulsen.crn.forge.client.ClientWrapperForge;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;

public class BuilderTransformerImpl {

    public static <B extends AbstractAdvancedDisplayBlock, P> NonNullUnaryOperator<BlockBuilder<B, P>> copycatDisplay(ConnectedTextureBehaviour ctDisplay, ConnectedTextureBehaviour ctFrame, ResourceLocation copycatTexture) {
        return b -> b
                .addLayer(() -> RenderType::m_110451_)
                .addLayer(() -> RenderType::m_110463_)
                .addLayer(() -> RenderType::m_110457_)
                .color(() -> AbstractAdvancedDisplayBlock::getDisplayColor)
                .onRegister(CreateRegistrate.blockModel(() -> ClientWrapperForge.copycatModel(ctDisplay, ctFrame, copycatTexture)))
                ;
    }
}
