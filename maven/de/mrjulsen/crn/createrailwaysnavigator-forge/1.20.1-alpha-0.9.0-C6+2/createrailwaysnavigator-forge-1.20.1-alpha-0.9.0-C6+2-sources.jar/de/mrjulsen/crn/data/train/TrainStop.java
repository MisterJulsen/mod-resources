package de.mrjulsen.crn.data.train;

import java.util.UUID;
import com.simibubi.create.content.trains.entity.TrainIconType;

import de.mrjulsen.crn.Constants;
import de.mrjulsen.crn.config.ModCommonConfig;
import de.mrjulsen.crn.data.StationTag;
import de.mrjulsen.crn.data.TagName;
import de.mrjulsen.crn.data.StationTag.ClientStationTag;
import de.mrjulsen.crn.data.storage.GlobalSettings;
import de.mrjulsen.crn.data.train.TrainData.SimulationResult;
import de.mrjulsen.crn.exceptions.RuntimeSideException;
import de.mrjulsen.crn.util.ModUtils;
import de.mrjulsen.crn.data.TrainInfo;
import de.mrjulsen.mcdragonlib.DragonLib;
import de.mrjulsen.mcdragonlib.util.DLColor;
import de.mrjulsen.mcdragonlib.util.time.ConfiguredTimeSystem;
import de.mrjulsen.mcdragonlib.util.time.ITimeSystem;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;

/**
 * A small variant of the {@code NewTrainPrediction} class, representing a stop of a train on its route with some important information.
 */
public class TrainStop implements Comparable<TrainStop> {

    protected static final String NBT_SCHEDULE_INDEX = "ScheduleIndex";
    protected static final String NBT_SECTION_INDEX = "SectionIndex";
    protected static final String NBT_TRAIN_ID = "TrainId";
    protected static final String NBT_TRAIN_NAME = "TrainName";
    protected static final String NBT_TRAIN_ICON = "TrainIcon";
    protected static final String NBT_TRAIN_INFO = "TrainInfo";
    protected static final String NBT_SCHEDULE_TITLE = "ScheduleTitle";
    protected static final String NBT_TERMINUS_TEXT = "TerminusText";
    protected static final String NBT_STAY_DURATION = "StayDuration";
    protected static final String NBT_IS_CUSTOM_TITLE = "IsCustomTitle";
    protected static final String NBT_SIMULATED_TIME = "SimulationTime";

    protected static final String NBT_SCHEDULED_DEPARTURE_TIME = "ScheduledDeparture";
    protected static final String NBT_SCHEDULED_ARRIVAL_TIME = "ScheduledArrival";
    protected static final String NBT_CYCLE = "Cycle";
    protected static final String NBT_TAG = "StationTag";

    protected static final String NBT_REAL_TIME_ARRIVAL_TIME = "RealArrival";
    protected static final String NBT_REAL_TIME_DEPARTURE_TIME = "RealDeparture";
    protected static final String NBT_REAL_CYCLE = "RealCycle";
    protected static final String NBT_REAL_TIME_TAG = "RealTimeTag";
    protected static final String NBT_STATE = "State";

    protected final int scheduleIndex;
    protected final int sectionIndex;
    protected final UUID trainId;
    protected final String trainName;
    protected final TrainIconType trainIcon;
    protected final TrainInfo trainInfo;
    protected final String scheduleTitle;
    protected final String terminusText;
    protected final int stayDuration;
    protected final boolean isCustomTitle;

    protected boolean simulated;
    protected long simulationTime;

    protected long scheduledDepartureTime;
    protected long scheduledArrivalTime;
    protected int cycle; // Der Zyklus, für den dieser Eintrag gültig ist. Wenn der real-time Zyklus kleiner ist, dann ist der Zug noch nicht vorhersagbar, falls größer, ist er abgefahren.
    protected ClientStationTag tag;

    protected long realTimeArrivalTime;
    protected long realTimeDepartureTime;
    protected int realTimeCycle = -1;
    protected ClientStationTag realTimeTag;

    protected int realTimeTicksUntilArrival = -1;


    // state
    protected TrainState trainState = TrainState.BEFORE;
    

    public TrainStop(int scheduleIndex, int sectionIndex, UUID trainId, String trainName, TrainIconType trainIcon, TrainInfo trainInfo,
            String scheduleTitle, boolean isCustomTitle, String terminusText, int stayDuration, boolean simulated,
            long scheduledDepartureTime, long scheduledArrivalTime, int cycle, ClientStationTag tag, long realTimeArrivalTime,
            long realTimeDepartureTime, int realTimeCycle, ClientStationTag realTimeTag,
            int realTimeTicksUntilArrival, TrainState trainPosition) {
        this.scheduleIndex = scheduleIndex;
        this.sectionIndex = sectionIndex;
        this.trainId = trainId;
        this.trainName = trainName;
        this.trainIcon = trainIcon;
        this.trainInfo = trainInfo;
        this.scheduleTitle = scheduleTitle;
        this.isCustomTitle = isCustomTitle;
        this.terminusText = terminusText;
        this.stayDuration = stayDuration;
        this.simulated = simulated;
        this.scheduledDepartureTime = scheduledDepartureTime;
        this.scheduledArrivalTime = scheduledArrivalTime;
        this.cycle = cycle;
        this.tag = tag;
        this.realTimeArrivalTime = realTimeArrivalTime;
        this.realTimeDepartureTime = realTimeDepartureTime;
        this.realTimeCycle = realTimeCycle;
        this.realTimeTag = realTimeTag;
        this.realTimeTicksUntilArrival = realTimeTicksUntilArrival;
        this.trainState = trainPosition;
    }

    public TrainStop(TrainPrediction prediction) {
        this(prediction.getStationTag(), prediction, false);
    }

    public TrainStop(StationTag tag, TrainPrediction prediction, boolean lastCycle) {
        this(
            prediction.getEntryIndex(), 
            prediction.getSection().getScheduleIndex(),
            prediction.getData().getTrainId(), 
            prediction.getData().getTrain().name.getString(),             
            prediction.getData().getTrain().icon,
            prediction.getData().getTrainInfoWithArrivalContext(prediction.getEntryIndex(), true),//!prediction.getData().isAtStation()),
            prediction.getTitle(),
            prediction.hasCustomTitle(),
            prediction.getSectionDestinationText(), 
            (int)prediction.scheduled().stayDuration(), 
            false,
            lastCycle ? prediction.getPreviousScheduledDepartureTime() : prediction.scheduled().departureTime(), 
            lastCycle ? prediction.getPreviousScheduledArrivalTime() : prediction.scheduled().arrivalTime(), 
            prediction.getCurrentCycle() - (lastCycle ? 1 : 0), 
            GlobalSettings.getInstance().getOrCreateStationTagFor(prediction.getScheduledStationName()).getClientTag(prediction.getScheduledStationName()),
            lastCycle ? prediction.getPreviousRealTimeArrivalTime() : prediction.realTime().arrivalTime(), 
            lastCycle ? prediction.getPreviousRealTimeDepartureTime() : prediction.realTime().departureTime(),
            prediction.getCurrentCycle() - (lastCycle ? 1 : 0), 
            GlobalSettings.getInstance().getOrCreateStationTagFor(prediction.getRealTimeStationName()).getClientTag(prediction.getRealTimeStationName()),
            (int)prediction.realTime().arrivalIn(), 
            TrainState.BEFORE
        );
        //updateRealTime(prediction);
    }

    public TrainStop copy() {
        return new TrainStop(
            this.scheduleIndex,
            this.sectionIndex,
            this.trainId,
            this.trainName,
            this.trainIcon,
            this.trainInfo,
            this.scheduleTitle,
            this.isCustomTitle,
            this.terminusText,
            this.stayDuration,
            this.simulated,
            this.scheduledDepartureTime,
            this.scheduledArrivalTime,
            this.cycle,
            this.tag,
            this.realTimeArrivalTime,
            this.realTimeDepartureTime,
            this.realTimeCycle,
            this.realTimeTag,
            this.realTimeTicksUntilArrival,
            this.trainState
        );
    }

    public void simulateTicks(long ticks) {
        if (ModCommonConfig.EXPERIMENT_SIMULATION_ALGORITHM.get()) {
            simulateTicksNew(ticks);
        } else {
            simulateTicksLegacy(ticks);
        }
    }

    private void simulateTicksLegacy(long ticks) {
        this.simulated = true;
        int totalDuration = TrainListener.getTrainData(getTrainId()).map(TrainData::getTotalDuration).orElse(-1);
        if (totalDuration <= 0) {
            return;
        }

        long scheduledTimeUntilArrival = getScheduledArrivalTime() - ModUtils.getTransformedWorldTime();
        int simulationCycles = (int)(ticks / totalDuration);
        long simulationRemaining = ticks % totalDuration;
        if (simulationRemaining > 0 && simulationRemaining >= scheduledTimeUntilArrival) {
            simulationCycles++;
        }
        
        this.cycle += simulationCycles;
        this.scheduledArrivalTime += simulationCycles * totalDuration;
        this.scheduledDepartureTime += simulationCycles * totalDuration;
        
        this.realTimeArrivalTime += simulationCycles * totalDuration;
        this.realTimeDepartureTime += simulationCycles * totalDuration;
        this.realTimeTicksUntilArrival = -1;
        this.simulationTime += ticks;
    }

    private void simulateTicksNew(long ticks) {
        this.simulated = true;
        SimulationResult res = TrainListener.getTrainData(getTrainId()).get().simulate(scheduleIndex, ticks);
        
        this.cycle += res.cycles();
        this.scheduledArrivalTime = res.arrivalTime();
        this.scheduledDepartureTime = res.departureTime();
        
        this.realTimeArrivalTime = res.arrivalTime();
        this.realTimeDepartureTime = res.departureTime();
        this.realTimeTicksUntilArrival = -1;
        this.simulationTime += ticks;
    }

    public void simulateCycles(int cycles) {
        if (cycles == 0) {
            return;
        }
        TrainListener.getTrainData(getTrainId()).ifPresent(x -> simulateTicks(cycles * x.getTotalDuration()));
    }

    
    public static TrainStop simulateCyclesBack(TrainPrediction prediction) {
        return new TrainStop(prediction.getStationTag(), prediction, true);
    }

    public boolean isSimulated() {
        return simulated;
    }

    public long getSimulationTime() {
        return simulationTime;
    }

    public UUID getTrainId() {
        return trainId;
    }    

    public String getTrainName() {
        return trainName;
    }

    public TrainIconType getTrainIcon() {
        return trainIcon;
    }

    public TrainInfo getTrainInfo() {
        return trainInfo;
    }

    public int getScheduleIndex() {
        return scheduleIndex;
    }

    public int getSectionIndex() {
        return sectionIndex;
    }

    public String getTerminusText() {
        return terminusText;
    }

    public boolean hasCustomTitle() {
        return isCustomTitle;
    }

    public String getScheduleTitle() {
        return scheduleTitle;
    }

    public String getDisplayTitle() {
        return hasCustomTitle() || getTerminusText() == null || getTerminusText().isEmpty() ? getScheduleTitle() : getTerminusText();
    }    

    public String getTrainDisplayName() {
        return getTrainInfo() == null || getTrainInfo().line() == null || getTrainInfo().line().getLineName().isEmpty() ? getTrainName() : getTrainInfo().line().getLineName();
    }

    public DLColor getTrainDisplayColor() {
        if (getTrainInfo() != null && getTrainInfo().line() != null && !getTrainInfo().line().getColor().isTransparent()) {
            return getTrainInfo().line().getColor();
        } else if (getTrainInfo() != null && getTrainInfo().category() != null && !getTrainInfo().category().getColor().isTransparent()) {
            return getTrainInfo().category().getColor();
        }
        return Constants.COLOR_TRAIN_BACKGROUND;
    }

    public int getStayTime() {
        return stayDuration;
    }

    public StationTag getTag() throws RuntimeSideException {
        if (!DragonLib.hasServer()) {
            throw new RuntimeSideException(false);
        }
        return GlobalSettings.getInstance().getStationTag(getRealTimeStationTag().tagId()).orElse(GlobalSettings.getInstance().getOrCreateStationTagFor(TagName.of(getRealTimeStationTag().tagName())));
    }

    public ClientStationTag getScheduledStationTag() {
        return tag;
    }

    public int getScheduledCycle() {
        return cycle;
    }

    public int getRealTimeCycle() {
        return realTimeCycle;
    }

    public ClientStationTag getRealTimeStationTag() {
        return realTimeTag;
    }

    public long getScheduledDepartureTime() {
        return scheduledDepartureTime;
    }

    public long getScheduledArrivalTime() {
        return scheduledArrivalTime;
    }

    public long getRealTimeArrivalTime() {
        return realTimeArrivalTime;
    }

    public long getRealTimeDepartureTime() {
        return realTimeDepartureTime;
    }

    public long getArrivalTimeDeviation() {
        return getRealTimeArrivalTime() - getScheduledArrivalTime();
    }

    public long getDepartureTimeDeviation() {
        return getRealTimeDepartureTime() - getScheduledDepartureTime();
    }

    public int getTicksUntilArrival() {
        return realTimeTicksUntilArrival;
    }    

    public long getScheduledArrivalDay() {
        ITimeSystem system = new ConfiguredTimeSystem();
        return getScheduledArrivalTime() / system.getTicksPerDay();
    }
    
    public long getScheduledDepartureDay() {
        ITimeSystem system = new ConfiguredTimeSystem();
        return getScheduledDepartureDay() / system.getTicksPerDay();
    }
    
    public long getRealTimeArrivalDay() {
        ITimeSystem system = new ConfiguredTimeSystem();
        return getRealTimeArrivalTime() / system.getTicksPerDay();
    }
    
    public long getRealTimeDepartureDay() {
        ITimeSystem system = new ConfiguredTimeSystem();
        return getRealTimeDepartureTime() / system.getTicksPerDay();
    }

    /**
     * The state of this train at this station.
     */
    public TrainState getState() {
        return trainState;
    }
    
    public boolean isArrivalDelayed() {
        return getArrivalTimeDeviation() >= ModCommonConfig.SCHEDULE_DEVIATION_THRESHOLD.get();
    }

    public boolean isDepartureDelayed() {
        return getDepartureTimeDeviation() >= ModCommonConfig.SCHEDULE_DEVIATION_THRESHOLD.get();
    }

    public boolean isAnyDelayed() {
        return isArrivalDelayed() || isDepartureDelayed();
    }

    public boolean hasTrackChanged() {
        return !realTimeTag.info().equals(tag.info());
    }

    public boolean shouldRenderRealTime() {
        return getRealTimeCycle() >= getScheduledCycle();
    }

    public boolean isStationInfoChanged() {
        return !getScheduledStationTag().info().equals(getRealTimeStationTag().info());
    }

    public boolean isDeparted() {
        return trainState == TrainState.AFTER;
    }

    @Override
    public int compareTo(TrainStop o) {
        return Long.compare(getScheduledArrivalTime(), o.getScheduledArrivalTime());
    }

    public CompoundTag toNbt(boolean includeRealTime) {
        CompoundTag nbt = new CompoundTag();
        nbt.m_128405_(NBT_SCHEDULE_INDEX, scheduleIndex);
        nbt.m_128405_(NBT_SECTION_INDEX, sectionIndex);
        nbt.m_128362_(NBT_TRAIN_ID, trainId);
        nbt.m_128359_(NBT_TRAIN_NAME, trainName);
        nbt.m_128359_(NBT_TRAIN_ICON, trainIcon.getId().toString());
        nbt.m_128365_(NBT_TRAIN_INFO, trainInfo.toNbt());
        nbt.m_128359_(NBT_SCHEDULE_TITLE, scheduleTitle);
        nbt.m_128359_(NBT_TERMINUS_TEXT, terminusText);
        nbt.m_128405_(NBT_STAY_DURATION, stayDuration);
        nbt.m_128379_(NBT_IS_CUSTOM_TITLE, isCustomTitle);
        nbt.m_128365_(NBT_TAG, tag.toNbt());
        nbt.m_128356_(NBT_SIMULATED_TIME, simulationTime);
        nbt.m_128356_(NBT_SCHEDULED_ARRIVAL_TIME, scheduledArrivalTime);
        nbt.m_128356_(NBT_SCHEDULED_DEPARTURE_TIME, scheduledDepartureTime);
        nbt.m_128405_(NBT_CYCLE, cycle);     
        nbt.m_128356_(NBT_REAL_TIME_ARRIVAL_TIME, realTimeArrivalTime);
        nbt.m_128356_(NBT_REAL_TIME_DEPARTURE_TIME, realTimeDepartureTime);
        nbt.m_128405_(NBT_REAL_CYCLE, realTimeCycle);
        nbt.m_128365_(NBT_REAL_TIME_TAG, realTimeTag.toNbt());
        return nbt;
    }

    public static TrainStop fromNbt(CompoundTag nbt) {
        return new TrainStop(
            nbt.m_128451_(NBT_SCHEDULE_INDEX),
            nbt.m_128451_(NBT_SECTION_INDEX),
            nbt.m_128342_(NBT_TRAIN_ID), 
            nbt.m_128461_(NBT_TRAIN_NAME), 
            TrainIconType.byId(new ResourceLocation(nbt.m_128461_(NBT_TRAIN_ICON))), 
            TrainInfo.fromNbt(nbt.m_128469_(NBT_TRAIN_INFO)),
            nbt.m_128461_(NBT_SCHEDULE_TITLE), 
            nbt.m_128471_(NBT_IS_CUSTOM_TITLE), 
            nbt.m_128461_(NBT_TERMINUS_TEXT), 
            nbt.m_128451_(NBT_STAY_DURATION),
            nbt.m_128454_(NBT_SIMULATED_TIME) != 0, 
            nbt.m_128454_(NBT_SCHEDULED_DEPARTURE_TIME), 
            nbt.m_128454_(NBT_SCHEDULED_ARRIVAL_TIME),
            nbt.m_128451_(NBT_CYCLE), 
            ClientStationTag.fromNbt(nbt.m_128469_(NBT_TAG)),
            nbt.m_128454_(NBT_REAL_TIME_ARRIVAL_TIME),
            nbt.m_128454_(NBT_REAL_TIME_DEPARTURE_TIME),
            nbt.m_128451_(NBT_REAL_CYCLE),
            ClientStationTag.fromNbt(nbt.m_128469_(NBT_REAL_TIME_TAG)),
            0,
            TrainState.BEFORE
        );
    }
}
