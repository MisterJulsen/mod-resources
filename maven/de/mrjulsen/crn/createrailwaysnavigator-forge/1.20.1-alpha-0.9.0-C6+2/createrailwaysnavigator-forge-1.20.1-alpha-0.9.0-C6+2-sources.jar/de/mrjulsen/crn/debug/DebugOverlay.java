package de.mrjulsen.crn.debug;

import de.mrjulsen.mcdragonlib.events.EventListenerId;
import org.lwjgl.glfw.GLFW;

import com.simibubi.create.content.trains.entity.Carriage;

import java.lang.StringBuilder;
import java.util.Arrays;

import de.mrjulsen.crn.data.train.TrainData;
import de.mrjulsen.crn.data.train.TrainListener;
import de.mrjulsen.crn.data.train.TrainPrediction;
import de.mrjulsen.crn.data.train.ScheduleSection;
import de.mrjulsen.crn.mixin.ScheduleRuntimeAccessor;
import de.mrjulsen.crn.mixin.TrainStatusAccessor;
import de.mrjulsen.crn.util.ESpeedUnit;
import de.mrjulsen.crn.util.ModUtils;
import de.mrjulsen.mcdragonlib.client.DLOverlayManager;
import de.mrjulsen.mcdragonlib.client.gui.events.DLGuiStandardEvents;
import de.mrjulsen.mcdragonlib.client.gui.widgets.base.DLWindow;
import de.mrjulsen.mcdragonlib.client.gui.widgets.base.DLWindowManager;
import de.mrjulsen.mcdragonlib.client.util.DLGuiGraphics;
import de.mrjulsen.mcdragonlib.client.util.GuiUtils;
import de.mrjulsen.mcdragonlib.data.ETextAlignment;
import de.mrjulsen.mcdragonlib.util.DLColor;
import de.mrjulsen.mcdragonlib.util.TextUtils;
import de.mrjulsen.mcdragonlib.util.math.Rectangle;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;

public class DebugOverlay extends DLWindow {  

    private static DebugOverlay instance;
    private final EventListenerId event;
    
    public DebugOverlay(DLWindowManager manager) {
        super(manager);
        fullscreen.set(true);

        event = getWindowManager().addEventListener(DLGuiStandardEvents.KeyPressEvent.class, (s, e) -> {
            if (e.keyCode() == GLFW.GLFW_KEY_K) {
                trainIndex++;
                return true;
            }
            return false;
        });
    }

    @Override
    public void close() throws Exception {
        getWindowManager().removeEventListener(DLGuiStandardEvents.KeyPressEvent.class, event);
        super.close();
    }

    public static void toggle() {
        if (instance != null) {
            DLOverlayManager.getWindowManager().ifPresent(w -> w.closeWindow(instance));
            instance = null;
        } else {
            DLOverlayManager.addOverlay(mgr -> instance = new DebugOverlay(mgr));
        }
    }

    int line = 0;
    int trainIndex = 0;

    int lastKey = -1;

    @Override
    public void renderMainLayer(DLGuiGraphics graphics, double mouseX, double mouseY, Rectangle renderBounds) {
        graphics.poseStack().m_85836_();
        graphics.poseStack().m_85841_(0.75f, 0.75f, 0.75f);
        line = 0;
        if (!TrainListener.getAllTrainData().isEmpty()) {
            trainIndex %= TrainListener.getAllTrainData().size();
            TrainData data = TrainListener.getAllTrainData().stream().skip(trainIndex).findFirst().get();  
            drawLine(graphics, data.getTrain().name.getString() + " (" + (data.isPreInitializationPhase() ? "PREPARING" : (data.isInitialized() ? "READY" : "INITIALIZING")) + ") Train Id: " + data.getTrainId() + ", SessionId: " + data.getSessionId());    
            drawLine(graphics, "Display: " + data.getCurrentSection().getDisplayText() + ", Title: " + data.getCurrentTitle() + ", IsDynamic: " + data.isDynamic());
            drawLine(graphics, "Track: " + !((TrainStatusAccessor)data.getTrain().status).crn$track() + ", Conductor: " + !((TrainStatusAccessor)data.getTrain().status).crn$conductor() + ", Navigation: " + !((TrainStatusAccessor)data.getTrain().status).crn$navigation() + ", Paused: " + data.getTrain().runtime.paused + ", Auto: " + data.getTrain().runtime.isAutoSchedule + ", Manual: " + data.isManualControlled + ", Cancelled: " + data.isCancelled());
            drawLine(graphics, "Duration: " + data.getTotalDuration() + ", Ticks: " + data.getTransitTicks() + "/" + data.waitingAtStationTicks() + "/" + data.waitingForSignalTicks + "/" + data.ticksToNextStop + ", Station: " + data.getTrain().currentStation + ", Dest: " + (data.getTrain().navigation.destination == null ? "(at station)" : (data.getTrain().navigation.destination.name + ", DestID: " + data.getTrain().navigation.destination.id)) + ", Delay: " + data.getHighestDeviation() + " (-" + data.getDeviationDelayOffset() + "), Status: " + data.debug_statusInfoCount());

            boolean stalled = false;
            for (int i = 0; i < data.getTrain().carriages.size(); i++) {
			    Carriage carriage = data.getTrain().carriages.get(i);
                if (carriage.stalled) {
                    stalled = true;
                    break;
                }
            }
            drawLine(graphics, TextUtils.text("Speed: " + (int)ModUtils.calcSpeed(data.getTrain().speed, ESpeedUnit.MS) + " / " + (int)ModUtils.calcSpeed(data.getTrain().targetSpeed, ESpeedUnit.MS) + ", Waiting: " + (data.getTrain().navigation.waitingForSignal == null ? "No" : data.getTrain().navigation.waitingForSignal.getSecond()) + " (" + data.getTrain().navigation.ticksWaitingForSignal + "/" + data.waitingForSignalId + "), Stalled: " + stalled + " (" + data.getTrain().speedBeforeStall + ")").m_130940_(data.getTrain().navigation.waitingForSignal == null ? ChatFormatting.RESET : ChatFormatting.RED));
            
            drawLine(graphics, TextUtils.text("Predictions:").m_130940_(ChatFormatting.UNDERLINE));
            data.getPredictions().forEach(a -> {
                drawLine(graphics, TextUtils.text(" - ").m_7220_(a.formattedText()));
            });

            StringBuilder builder = new StringBuilder();
            builder.append("[ " + data.getCurrentScheduleIndex() + " ]: ");
            data.getPredictionsChronologically().forEach(a -> {   
                if (a == null) {
                    return;
                }
                builder.append(" > " + a.getTargetedStationName() + " (" + a.realTime().arrivalIn() + ")");
            });
            drawLine(graphics, builder.toString());

            drawLine(graphics, TextUtils.text("Transit Times:").m_130940_(ChatFormatting.UNDERLINE));
            for (TrainPrediction prediction : data.getPredictions()) {
                String suffix = String.join(" | ", Arrays.stream(prediction.transitTime().history()).map(x -> String.valueOf(x)).toList());
                drawLine(graphics, " - [ " + prediction.getEntryIndex() + " ]: C: " + prediction.transitTime().value() + ", L: " + prediction.transitTime().measuredValue() + ", H: [" + suffix + "]");
            }
            drawLine(graphics, "C: " + String.join(" | ", ((ScheduleRuntimeAccessor)data.getTrain().runtime).crn$getTransitTicks().stream().map(x -> String.valueOf(x)).toList()));
            
            drawLine(graphics, TextUtils.text("Sections:").m_130940_(ChatFormatting.UNDERLINE));
            for (ScheduleSection section : data.getSections()) {                
                drawLine(graphics, " - [ " + section.getScheduleIndex() + " ]: " + section.getDisplayText() + " (" + section.getStartStationName() + " -> " + section.getDestinationStationName() + "), Category: " + section.getTrainCategory().map(x -> x.getCategoryName()).orElse("none") + ", Line: " + section.getTrainLine().map(x -> x.getLineName()).orElse("none") + ", Include: " + section.shouldIncludeNextStationOfNextSection() + ", Navigable: " + section.isUsable() + ", Next: " + section.nextSection().getScheduleIndex());
            }
            drawLine(graphics, "[ " + data.getCurrentSection().getScheduleIndex() + " ]");
        }
        drawLine(graphics, TextUtils.text("Press K to switch train.").m_130940_(ChatFormatting.AQUA));  
        
        graphics.poseStack().m_85849_();
    }
    
    private void drawLine(DLGuiGraphics graphics, String str) {
        drawLine(graphics, TextUtils.text(str));
    }
    
    private void drawLine(DLGuiGraphics graphics, Component str) {
        int x = 2;
        int y = 2;
        GuiUtils.fill(graphics, x - 1, y - 1 + line * (graphics.defaultFont().f_92710_ + 2), graphics.defaultFont().m_92852_(str) + 2, graphics.defaultFont().f_92710_ + 2, DLColor.fromInt(0x44000000));
        GuiUtils.drawString(graphics, graphics.defaultFont(), x, y + 1 + line * (graphics.defaultFont().f_92710_ + 2), str, DLColor.WHITE, ETextAlignment.LEFT, true);
        line++;
    } 

}
