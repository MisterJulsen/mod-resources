package de.mrjulsen.crn.client.ber;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.simibubi.create.foundation.blockEntity.renderer.SafeBlockEntityRenderer;
import de.mrjulsen.crn.block.NavigatorLecternBlock;
import de.mrjulsen.crn.block.blockentity.NavigatorLecternBlockEntity;
import de.mrjulsen.crn.registry.ModItems;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.core.Direction;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

public class NavigatorLecternBlockEntityRenderer extends SafeBlockEntityRenderer<NavigatorLecternBlockEntity> {

    public NavigatorLecternBlockEntityRenderer(BlockEntityRendererProvider.Context context) {
    }

    @Override
    protected void renderSafe(NavigatorLecternBlockEntity be, float partialTicks, PoseStack ms, MultiBufferSource buffer, int light, int overlay) {
        ItemStack stack = ModItems.NAVIGATOR.asStack();
        Direction facing = be.m_58900_().m_61143_(NavigatorLecternBlock.f_54465_);

        ms.m_85836_();
        ms.m_85837_(0.5, 0.894f, 0.5);
        ms.m_85836_();
        ms.m_85841_(0.75f, 0.75f, 0.75f);
        ms.m_252781_(Axis.f_252436_.m_252977_((facing.m_122434_() == Direction.Axis.Z ? facing.m_122424_() : facing).m_122435_()));
        ms.m_252781_(Axis.f_252529_.m_252977_(-22.5f + 90));
        ms.m_85837_(0, 0, -0.3);
        Minecraft.m_91087_().m_91291_().m_269128_(stack, ItemDisplayContext.FIXED, light, overlay, ms, buffer, be.m_58904_(), 0);
        ms.m_85849_();
        ms.m_85849_();
    }

}