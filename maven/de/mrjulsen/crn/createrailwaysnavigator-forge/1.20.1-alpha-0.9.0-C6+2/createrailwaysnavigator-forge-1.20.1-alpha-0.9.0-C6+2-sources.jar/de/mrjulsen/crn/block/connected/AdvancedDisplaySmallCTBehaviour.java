package de.mrjulsen.crn.block.connected;

import com.simibubi.create.foundation.block.connected.CTSpriteShiftEntry;
import com.simibubi.create.foundation.block.connected.ConnectedTextureBehaviour;

import de.mrjulsen.crn.block.IBlockGetter;
import de.mrjulsen.crn.block.blockentity.AdvancedDisplayBlockEntity;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Direction.Axis;
import net.minecraft.core.Direction.AxisDirection;
import net.minecraft.world.level.BlockAndTintGetter;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.state.BlockState;

public class AdvancedDisplaySmallCTBehaviour extends ConnectedTextureBehaviour.Base {
    protected CTSpriteShiftEntry topShift;
	protected CTSpriteShiftEntry layerShift;

	public AdvancedDisplaySmallCTBehaviour(CTSpriteShiftEntry layerShift) {
		this(layerShift, null);
	}

	public AdvancedDisplaySmallCTBehaviour(CTSpriteShiftEntry layerShift, CTSpriteShiftEntry topShift) {
		this.layerShift = layerShift;
		this.topShift = topShift;
	}

	@Override
	public CTSpriteShiftEntry getShift(BlockState state, Direction direction, TextureAtlasSprite sprite) {
		return layerShift;
	}
    
    @Override
	public boolean connectsTo(BlockState state, BlockState other, BlockAndTintGetter reader, BlockPos pos, BlockPos otherPos, Direction face, Direction primaryOffset, Direction secondaryOffset) {
		return reader.m_7702_(pos) instanceof AdvancedDisplayBlockEntity blockEntity && blockEntity.connectable(new IBlockGetter.WorldBlockGetter(reader), pos, otherPos);
	}

	@Override
	protected boolean isBeingBlocked(BlockState state, BlockAndTintGetter reader, BlockPos pos, BlockPos otherPos, Direction face) {
		if (!state.m_61138_(HorizontalDirectionalBlock.f_54117_)) {
			return super.isBeingBlocked(state, reader, pos, otherPos, face);
		}
		return (state.m_61143_(HorizontalDirectionalBlock.f_54117_) == face && super.isBeingBlocked(state, reader, pos, otherPos, face));
	}

	@Override
	protected boolean reverseUVs(BlockState state, Direction face) {
		if (state.m_61138_(HorizontalDirectionalBlock.f_54117_)) {
			Axis axis = state.m_61143_(HorizontalDirectionalBlock.f_54117_).m_122434_();
			if (axis == Axis.X)
				return face.m_122421_() == AxisDirection.NEGATIVE && face.m_122434_() != Axis.X;
			if (axis == Axis.Z)
				return face != Direction.NORTH && face.m_122421_() != AxisDirection.POSITIVE;
		}
		return super.reverseUVs(state, face);
	}

	@Override
	protected boolean reverseUVsHorizontally(BlockState state, Direction face) {
		return super.reverseUVsHorizontally(state, face);
	}

	@Override
	protected boolean reverseUVsVertically(BlockState state, Direction face) {
		if (state.m_61138_(HorizontalDirectionalBlock.f_54117_)) {
			Axis axis = state.m_61143_(HorizontalDirectionalBlock.f_54117_).m_122434_();
			if (axis == Axis.X && face == Direction.NORTH)
				return false;
			if (axis == Axis.Z && face == Direction.WEST)
				return false;
		}
		return super.reverseUVsVertically(state, face);
	}

	@Override
	protected Direction getUpDirection(BlockAndTintGetter reader, BlockPos pos, BlockState state, Direction face) {
		if (state.m_61138_(HorizontalDirectionalBlock.f_54117_)) {
			Axis axis = state.m_61143_(HorizontalDirectionalBlock.f_54117_).m_122434_();
			if (axis == Axis.Y)
				return super.getUpDirection(reader, pos, state, face);
			boolean alongX = axis == Axis.X;
			if (face.m_122434_().m_122478_() && alongX)
				return super.getUpDirection(reader, pos, state, face).m_122427_();
			if (face.m_122434_() == axis || face.m_122434_().m_122478_())
				return super.getUpDirection(reader, pos, state, face);
			return Direction.m_122387_(axis, alongX ? AxisDirection.POSITIVE : AxisDirection.NEGATIVE);
		}
		return super.getUpDirection(reader, pos, state, face);
	}

	@Override
	protected Direction getRightDirection(BlockAndTintGetter reader, BlockPos pos, BlockState state, Direction face) {
		if (state.m_61138_(HorizontalDirectionalBlock.f_54117_)) {
			Axis axis = state.m_61143_(HorizontalDirectionalBlock.f_54117_).m_122434_();
			if (axis == Axis.Y)
				return super.getRightDirection(reader, pos, state, face);
			if (face.m_122434_().m_122478_() && axis == Axis.X)
				return super.getRightDirection(reader, pos, state, face).m_122427_();
			if (face.m_122434_() == axis || face.m_122434_().m_122478_())
				return super.getRightDirection(reader, pos, state, face);
			return Direction.m_122387_(Axis.Y, face.m_122421_());
		}
		return super.getRightDirection(reader, pos, state, face);
	}
}
