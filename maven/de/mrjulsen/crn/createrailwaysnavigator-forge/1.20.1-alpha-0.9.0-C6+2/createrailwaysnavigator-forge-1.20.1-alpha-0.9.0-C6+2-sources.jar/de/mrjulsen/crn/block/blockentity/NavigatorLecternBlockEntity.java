package de.mrjulsen.crn.block.blockentity;

import com.simibubi.create.foundation.blockEntity.SmartBlockEntity;
import com.simibubi.create.foundation.blockEntity.behaviour.BlockEntityBehaviour;

import de.mrjulsen.crn.block.NavigatorLecternBlock;
import de.mrjulsen.crn.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

import java.util.List;

public class NavigatorLecternBlockEntity extends SmartBlockEntity {

    private static final String NBT_NAVIGATOR = "Navigator";
    private CompoundTag navigatorNbt = new CompoundTag();

    public NavigatorLecternBlockEntity(BlockEntityType<?> type, BlockPos pos, BlockState state) {
        super(type, pos, state);
    }

    @Override
    public void addBehaviours(List<BlockEntityBehaviour> behaviours) { }

    @Override
    protected void write(CompoundTag compound, boolean clientPacket) {
        super.write(compound, clientPacket);
        if (navigatorNbt != null) compound.m_128365_(NBT_NAVIGATOR, navigatorNbt);
    }

    @Override
    public void writeSafe(CompoundTag compound) {
        super.writeSafe(compound);
        if (navigatorNbt != null) compound.m_128365_(NBT_NAVIGATOR, navigatorNbt);
    }

    @Override
    protected void read(CompoundTag compound, boolean clientPacket) {
        super.read(compound, clientPacket);
        navigatorNbt = compound.m_128441_(NBT_NAVIGATOR) ? compound.m_128469_(NBT_NAVIGATOR) : new CompoundTag();
    }

    public void setNavigator(ItemStack newNavigator) {
        if (newNavigator != null) {
            this.navigatorNbt = newNavigator.m_41784_();
            f_58857_.m_5594_(null, m_58899_(), SoundEvents.f_12013_, SoundSource.BLOCKS, 0.8F, 1.0F);
        }
    }

    public void swapControllers(ItemStack stack, Player player, InteractionHand hand, BlockState state) {
        ItemStack newController = stack.m_41777_();
        stack.m_41764_(0);
        if (player.m_21120_(hand).m_41619_()) {
            player.m_21008_(hand, createNavigator());
        } else {
            dropController(state);
        }
        setNavigator(newController);
    }

    public void dropController(BlockState state) {
        Direction dir = state.m_61143_(NavigatorLecternBlock.f_54465_);
        double x = f_58858_.m_123341_() + 0.5 + 0.25 * dir.m_122429_();
        double y = f_58858_.m_123342_() + 1;
        double z = f_58858_.m_123343_() + 0.5 + 0.25 * dir.m_122431_();
        ItemEntity itementity = new ItemEntity(f_58857_, x, y, z, createNavigator());
        itementity.m_32060_();
        f_58857_.m_7967_(itementity);
        navigatorNbt = new CompoundTag();
        f_58857_.m_5594_(null, m_58899_(), SoundEvents.f_12016_, SoundSource.BLOCKS, 0.8F, 1.0F);
    }

    public static boolean playerInRange(Player player, Level world, BlockPos pos) {
        //double modifier = world.isRemote ? 0 : 1.0;
        double reach = 5;// + modifier;
        return player.m_20238_(Vec3.m_82512_(pos)) < reach * reach;
    }

    private ItemStack createNavigator() {
        ItemStack stack = ModItems.NAVIGATOR.asStack();
        stack.m_41751_(navigatorNbt == null ? new CompoundTag() : navigatorNbt);
        return stack;
    }

}
