package de.mrjulsen.crn.data;

import net.minecraft.nbt.CompoundTag;

public record TrainInfo(TrainLine line, TrainCategory category) {

    private static final String NBT_TRAIN_CATEGORY = "Category";
    private static final String NBT_TRAIN_LINE = "Line";

    public CompoundTag toNbt() {
        CompoundTag nbt = new CompoundTag();
        if (category != null) nbt.m_128365_(NBT_TRAIN_CATEGORY, category.toNbt());
        if (line != null) nbt.m_128365_(NBT_TRAIN_LINE, line.toNbt());

        return nbt;
    }

    public static TrainInfo fromNbt(CompoundTag nbt) {
        return new TrainInfo(
            nbt.m_128441_(NBT_TRAIN_LINE) ? TrainLine.fromNbt(nbt.m_128469_(NBT_TRAIN_LINE)) : null, 
            nbt.m_128441_(NBT_TRAIN_CATEGORY) ? TrainCategory.fromNbt(nbt.m_128469_(NBT_TRAIN_CATEGORY)) : null
        );
    }

    public static TrainInfo empty() {
        return new TrainInfo(null, null);
    }
}
