package de.mrjulsen.crn.network.packets.pain;

import java.util.List;
import java.util.UUID;
import de.mrjulsen.crn.CreateRailwaysNavigator;
import de.mrjulsen.crn.data.StationTag;
import de.mrjulsen.crn.data.storage.GlobalSettings;
import de.mrjulsen.crn.data.train.ClientTrainStop;
import de.mrjulsen.crn.data.train.TrainStop;
import de.mrjulsen.crn.data.train.TrainUtils;
import de.mrjulsen.mcdragonlib.data.DLStatus;
import de.mrjulsen.mcdragonlib.network.NetworkPacketContext;
import de.mrjulsen.mcdragonlib.network.NetworkPacketData;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;

public class GetDeparturesAtPacketData {

    private static final String NBT_STATION_TAG_ID = "StationTagId";
    private static final String NBT_TRAIN_ID = "TrainId";
    private static final String NBT_REAL_TIME_ONLY = "RealTimeOnly";
    private static final String NBT_ALLOW_DUPLICATES = "AllowDuplicates";
    private static final String NBT_DATA = "Data";

    public static class Request extends NetworkPacketData {
        
        private UUID stationTagId;
        private UUID trainId;
        private boolean realTimeOnly;
        private boolean allowDuplicates;

        public Request(DLStatus status) {
            super(status);
        }

        public Request(UUID stationTagId, UUID trainId, boolean realTimeOnly, boolean allowDuplicates) {
            super(DLStatus.OK);
            this.stationTagId = stationTagId;
            this.trainId = trainId;
            this.realTimeOnly = realTimeOnly;
            this.allowDuplicates = allowDuplicates;
        }

        @Override
        protected void write(CompoundTag nbt) {
            nbt.m_128362_(NBT_STATION_TAG_ID, stationTagId);
            nbt.m_128362_(NBT_TRAIN_ID, trainId);
            nbt.m_128379_(NBT_REAL_TIME_ONLY, realTimeOnly);
            nbt.m_128379_(NBT_ALLOW_DUPLICATES, allowDuplicates);
        }

        @Override
        protected void read(CompoundTag nbt) {
            this.stationTagId = nbt.m_128342_(NBT_STATION_TAG_ID);
            this.trainId = nbt.m_128342_(NBT_TRAIN_ID);
            this.realTimeOnly = nbt.m_128471_(NBT_REAL_TIME_ONLY);
            this.allowDuplicates = nbt.m_128471_(NBT_ALLOW_DUPLICATES);
        }
    }

    public static class Response extends NetworkPacketData {
        private List<TrainStop> rawData;
        private List<ClientTrainStop> data;

        public Response(DLStatus status) {
            super(status);
        }

        public Response(List<TrainStop> rawData) {
            super(DLStatus.OK);
            this.rawData = rawData;
        }

        @Override
        protected void write(CompoundTag nbt) {
            ListTag list = new ListTag();
            for (TrainStop data : rawData) {
                list.add(data.toNbt(true));
            }
            nbt.m_128365_(NBT_DATA, list);
        }

        @Override
        protected void read(CompoundTag nbt) {
            this.data = nbt.m_128437_(NBT_DATA, Tag.f_178203_).stream().map(x -> (ClientTrainStop)ClientTrainStop.fromNbt((CompoundTag)x)).toList();
        }

        public List<ClientTrainStop> getData() {
            return data;
        }
    }

    public static Response handle(Request packet, NetworkPacketContext context) {
        try {
            if (!GlobalSettings.getInstance().stationTagExists(packet.stationTagId)) {
                return new Response(List.of());
            }
            StationTag tag = GlobalSettings.getInstance().getStationTag(packet.stationTagId).get();
            return new Response(TrainUtils.getDeparturesAt(tag, packet.trainId, packet.realTimeOnly, packet.allowDuplicates));
        } catch (Exception e) {
            CreateRailwaysNavigator.LOGGER.error("Next connections error.", e);
        }
        return new Response(List.of());
    }
    
}
