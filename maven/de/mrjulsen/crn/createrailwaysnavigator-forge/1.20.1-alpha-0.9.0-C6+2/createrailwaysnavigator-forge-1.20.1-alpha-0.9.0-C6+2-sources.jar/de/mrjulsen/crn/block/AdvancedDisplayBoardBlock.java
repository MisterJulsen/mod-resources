package de.mrjulsen.crn.block;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import de.mrjulsen.crn.block.properties.EBlockAlignment;
import de.mrjulsen.mcdragonlib.util.Pair;
import de.mrjulsen.mcdragonlib.util.Tripple;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Direction.Axis;
import net.minecraft.core.Direction.AxisDirection;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition.Builder;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

public class AdvancedDisplayBoardBlock extends AbstractAdvancedSidedDisplayBlock {
    
	public static final EnumProperty<EBlockAlignment> Z_ALIGN = EnumProperty.m_61587_("z_alignment", EBlockAlignment.class);

    private static final Map<ShapeKey, VoxelShape> SHAPES = Map.ofEntries(
        Map.entry(new ShapeKey(Direction.SOUTH, EBlockAlignment.NEGATIVE), Block.m_49796_(0 , 0 , 8 , 16, 16, 16)),
        Map.entry(new ShapeKey(Direction.NORTH, EBlockAlignment.NEGATIVE), Block.m_49796_(0 , 0 , 0 , 16, 16, 8 )),
        Map.entry(new ShapeKey(Direction.EAST,  EBlockAlignment.NEGATIVE), Block.m_49796_(8 , 0 , 0 , 16, 16, 16)),
        Map.entry(new ShapeKey(Direction.WEST,  EBlockAlignment.NEGATIVE), Block.m_49796_(0 , 0 , 0 , 8 , 16, 16)),
        
        Map.entry(new ShapeKey(Direction.SOUTH, EBlockAlignment.CENTER),   Block.m_49796_(0 , 0 , 3 , 16, 16, 13)),
        Map.entry(new ShapeKey(Direction.NORTH, EBlockAlignment.CENTER),   Block.m_49796_(0 , 0 , 3 , 16, 16, 13)),
        Map.entry(new ShapeKey(Direction.EAST,  EBlockAlignment.CENTER),   Block.m_49796_(3 , 0 , 0 , 13, 16, 16)),
        Map.entry(new ShapeKey(Direction.WEST,  EBlockAlignment.CENTER),   Block.m_49796_(3 , 0 , 0 , 13, 16, 16)),
        
        Map.entry(new ShapeKey(Direction.SOUTH, EBlockAlignment.POSITIVE), Block.m_49796_(0 , 0 , 0 , 16, 16, 8 )),
        Map.entry(new ShapeKey(Direction.NORTH, EBlockAlignment.POSITIVE), Block.m_49796_(0 , 0 , 8 , 16, 16, 16)),
        Map.entry(new ShapeKey(Direction.EAST,  EBlockAlignment.POSITIVE), Block.m_49796_(0 , 0 , 0 , 8 , 16, 16)),
        Map.entry(new ShapeKey(Direction.WEST,  EBlockAlignment.POSITIVE), Block.m_49796_(8 , 0 , 0 , 16, 16, 16))
    );

    private static final Map<Direction, VoxelShape> SUPPORT_SHAPES = Map.ofEntries(        
        Map.entry(Direction.SOUTH, Shapes.m_83110_(Block.m_49796_(0 , 0 , 0 , 1 , 16, 16), Block.m_49796_(15, 0 , 0 , 16, 16, 16))),
        Map.entry(Direction.NORTH, Shapes.m_83110_(Block.m_49796_(0 , 0 , 0 , 1 , 16, 16), Block.m_49796_(15, 0 , 0 , 16, 16, 16))),
        Map.entry(Direction.EAST,  Shapes.m_83110_(Block.m_49796_(0 , 0 , 0 , 16, 16, 1 ), Block.m_49796_(0 , 0 , 15, 16, 16, 16))),
        Map.entry(Direction.WEST,  Shapes.m_83110_(Block.m_49796_(0 , 0 , 0 , 16, 16, 1 ), Block.m_49796_(0 , 0 , 15, 16, 16, 16)))
    );

    public AdvancedDisplayBoardBlock(Properties properties) {
        super(properties);        
		m_49959_(m_49966_()
            .m_61124_(Z_ALIGN, EBlockAlignment.CENTER)
        );
    }

    @Override
    public VoxelShape m_7947_(BlockState state, BlockGetter reader, BlockPos pos) {
        return state.m_61143_(Z_ALIGN) == EBlockAlignment.CENTER ? SUPPORT_SHAPES.get(state.m_61143_(FACING)) : SHAPES.get(new ShapeKey(state.m_61143_(FACING), state.m_61143_(Z_ALIGN)));
    }
    
    @Override
    public Collection<Property<?>> getExcludedProperties() {
        return List.of(Z_ALIGN);
    }

    @Override
    public VoxelShape m_5940_(BlockState pState, BlockGetter pLevel, BlockPos pPos, CollisionContext pContext) {
        return SHAPES.get(new ShapeKey(pState.m_61143_(FACING), pState.m_61143_(Z_ALIGN)));
    }

    @Override
    public BlockState getDefaultPlacementState(BlockPlaceContext context, BlockState state, BlockState other) {
        BlockState stateForPlacement = super.getDefaultPlacementState(context, state, other);
		Direction direction = context.m_43719_();
        Direction looking = context.m_8125_();
        Axis axis = looking.m_122434_();
        AxisDirection axisDirection = looking.m_122421_();

        double xzPos = 0.5f;
        if (axis == Axis.X) {
            xzPos = context.m_43720_().f_82479_ - context.m_8083_().m_123341_();
        } else if (axis == Axis.Z) {            
            xzPos = context.m_43720_().f_82481_ - context.m_8083_().m_123343_();
        }

        EBlockAlignment zAlign = EBlockAlignment.CENTER;

        if (direction == context.m_43723_().m_6350_().m_122424_() || (axisDirection == AxisDirection.POSITIVE ? xzPos > 0.66666666D : xzPos < 0.33333333D)) {
			zAlign = EBlockAlignment.POSITIVE;
        } else if (direction == context.m_43723_().m_6350_() || (axisDirection == AxisDirection.POSITIVE ? xzPos < 0.33333333D : xzPos > 0.66666666D)) {
            zAlign = EBlockAlignment.NEGATIVE;
        }

		return stateForPlacement
            .m_61124_(Z_ALIGN, zAlign)
        ;
    }

    @Override
    public BlockState appendOnPlace(BlockPlaceContext context, BlockState state, BlockState other) {
        return super.appendOnPlace(context, state, other)
            .m_61124_(Z_ALIGN, other.m_61143_(Z_ALIGN))
        ;
    }

	@Override
	protected void m_7926_(Builder<Block, BlockState> pBuilder) {
		super.m_7926_(pBuilder.m_61104_(Z_ALIGN));
	}
    
    @Override
    public boolean canConnectWithBlock(IBlockGetter level, BlockState selfState, BlockState otherState) {
		return super.canConnectWithBlock(level, selfState, otherState) &&
            selfState.m_61143_(Z_ALIGN) == otherState.m_61143_(Z_ALIGN)
		;
	}

    @Override
    protected boolean canConnect(LevelAccessor level, BlockPos pos, BlockState state, BlockState other) {
        return super.canConnect(level, pos, state, other) &&
            state.m_61143_(Z_ALIGN) == other.m_61143_(Z_ALIGN)
        ;
    }

    @Override
    public Pair<Float, Float> getRenderAspectRatio(Level level, BlockState blockState, BlockPos pos) {
        return Pair.of(1.0F, 1.0F);
    }

    @Override
    public Pair<Float, Float> getRenderOffset(Level level, BlockState blockState, BlockPos pos) {
        return Pair.of(0.0f, 0.0f);
    }

    @Override
    public Pair<Float, Float> getRenderZOffset(Level level, BlockState blockState, BlockPos pos) {
        float z1;
        float z2;
        switch (blockState.m_61143_(Z_ALIGN)) {
            case NEGATIVE:
                z1 = 16.05f;
                z2 = 8.05f;
                break;
            case POSITIVE:
                z1 = 8.05f;
                z2 = 16.05f;
                break;
            default:
                z1 = 13.05f;
                z2 = 13.05f;
                break;
        }
        return Pair.of(z1, z2);
    }

    @Override
    public Tripple<Float, Float, Float> getRenderRotation(Level level, BlockState blockState, BlockPos pos) {
        return Tripple.of(0.0F, 0.0F, 0.0F);
    }

    @Override
    public boolean isSingleLined() {
        return false;
    }
    
    private static final class ShapeKey {
        private final Direction facing;
        private final EBlockAlignment zAlign;
    
        public ShapeKey(Direction facing, EBlockAlignment zAlign) {
            this.facing = facing;
            this.zAlign = zAlign;
        }

        @Override
        public boolean equals(Object o) {
            if (o instanceof ShapeKey other) {
                return facing == other.facing && zAlign == other.zAlign;
            }
            return false;
        }
    
        @Override
        public int hashCode() {
            return Objects.hash(facing, zAlign);
        }
    }
}
