package de.mrjulsen.crn.client.gui.overlay.pages;

import de.mrjulsen.crn.data.navigation.ClientRoute;
import de.mrjulsen.mcdragonlib.client.gui.widgets.base.DLGuiComponent;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;

public abstract class AbstractRouteDetailsPage extends DLGuiComponent {

    protected final Font font = Minecraft.m_91087_().f_91062_;
    protected final ClientRoute route;

    public AbstractRouteDetailsPage(ClientRoute route) {
        super(0, 0, 220, 62);
        this.route = route;
    }

    public abstract boolean isImportant();
    
}
