package de.mrjulsen.crn.block;

import com.simibubi.create.api.schematic.requirement.SpecialBlockItemRequirement;
import com.simibubi.create.content.schematics.requirement.ItemRequirement;
import com.simibubi.create.foundation.block.IBE;
import de.mrjulsen.crn.api.client.Screens;
import de.mrjulsen.crn.block.blockentity.NavigatorLecternBlockEntity;
import de.mrjulsen.crn.registry.ModBlockEntities;
import de.mrjulsen.crn.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LecternBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

import java.util.ArrayList;

public class NavigatorLecternBlock extends LecternBlock implements IBE<NavigatorLecternBlockEntity>, SpecialBlockItemRequirement {

    public NavigatorLecternBlock(Properties properties) {
        super(properties);
        m_49959_(m_49966_().m_61124_(f_54467_, true));
    }

    @Override
    public Class<NavigatorLecternBlockEntity> getBlockEntityClass() {
        return NavigatorLecternBlockEntity.class;
    }

    @Override
    public BlockEntityType<? extends NavigatorLecternBlockEntity> getBlockEntityType() {
        return ModBlockEntities.NAVIGATOR_LECTERN_BLOCK_ENTITY.get();
    }

    @Override
    public BlockEntity m_142194_(BlockPos pos, BlockState state) {
        return IBE.super.m_142194_(pos, state);
    }

    @Override
    public InteractionResult m_6227_(BlockState state, Level world, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (!player.m_6144_() && NavigatorLecternBlockEntity.playerInRange(player, world, pos)) {
            if (world.f_46443_) {
                Screens.showNavigatorScreen(null, true);
            }
            return InteractionResult.SUCCESS;
        }

        if (player.m_6144_()) {
            if (!world.f_46443_) {
                replaceWithLectern(state, world, pos);
            }
            return InteractionResult.SUCCESS;
        }

        return InteractionResult.PASS;
    }

    @Override
    public void m_6810_(BlockState state, Level world, BlockPos pos, BlockState newState, boolean isMoving) {
        if (!state.m_60713_(newState.m_60734_())) {
            if (!world.f_46443_)
                withBlockEntityDo(world, pos, be -> be.dropController(state));

            super.m_6810_(state, world, pos, newState, isMoving);
        }
    }

    @Override
    public int m_6782_(BlockState state, Level world, BlockPos pos) {
        return 15;
    }

    public void replaceLectern(BlockState lecternState, Level world, BlockPos pos, ItemStack navigator) {
        world.m_46597_(pos, m_49966_()
                .m_61124_(f_54465_, lecternState.m_61143_(f_54465_))
                .m_61124_(f_54466_, lecternState.m_61143_(f_54466_))
        );
        withBlockEntityDo(world, pos, be -> be.setNavigator(navigator));
    }

    public void replaceWithLectern(BlockState state, Level world, BlockPos pos) {
        world.m_46597_(pos, Blocks.f_50624_.m_49966_()
                .m_61124_(f_54465_, state.m_61143_(f_54465_))
                .m_61124_(f_54466_, state.m_61143_(f_54466_)));
    }

    @Override
    public ItemStack m_7397_(BlockGetter level, BlockPos pos, BlockState state) {
        return Blocks.f_50624_.m_7397_(level, pos, state);
    }

    @Override
    public ItemRequirement getRequiredItems(BlockState state, BlockEntity be) {
        ArrayList<ItemStack> requiredItems = new ArrayList<>();
        requiredItems.add(new ItemStack(Blocks.f_50624_));
        requiredItems.add(new ItemStack(ModItems.NAVIGATOR.get()));
        return new ItemRequirement(ItemRequirement.ItemUseType.CONSUME, requiredItems);
    }
}
