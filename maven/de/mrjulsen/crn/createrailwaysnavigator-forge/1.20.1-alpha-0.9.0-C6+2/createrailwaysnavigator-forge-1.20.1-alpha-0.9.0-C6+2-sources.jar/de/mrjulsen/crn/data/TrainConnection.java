package de.mrjulsen.crn.data;

import java.util.UUID;

import de.mrjulsen.crn.data.StationTag.StationInfo;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;

public record TrainConnection(String trainName, UUID trainId, ResourceLocation trainIconId, int ticks, String scheduleTitle, StationInfo stationDetails) {

    private static final String NBT_TRAIN_NAME = "TrainName";
    private static final String NBT_TRAIN_ID = "Id";
    private static final String NBT_TRAIN_ICON = "Icon";
    private static final String NBT_TICKS = "Ticks";
    private static final String NBT_SCHEDULE_TITLE = "Title";

    public CompoundTag toNbt() {
        CompoundTag nbt = new CompoundTag();

        nbt.m_128359_(NBT_TRAIN_NAME, trainName);
        nbt.m_128362_(NBT_TRAIN_ID, trainId);
        nbt.m_128359_(NBT_TRAIN_ICON, trainIconId.m_135815_());
        nbt.m_128405_(NBT_TICKS, ticks);
        nbt.m_128359_(NBT_SCHEDULE_TITLE, scheduleTitle);
        stationDetails().writeNbt(nbt);

        return nbt;
    }

    public static TrainConnection fromNbt(CompoundTag nbt) {
        return new TrainConnection(
            nbt.m_128461_(NBT_TRAIN_NAME),
            nbt.m_128342_(NBT_TRAIN_ID),
            new ResourceLocation(nbt.m_128461_(NBT_TRAIN_ICON)),
            nbt.m_128451_(NBT_TICKS),
            nbt.m_128461_(NBT_SCHEDULE_TITLE),
            StationInfo.fromNbt(nbt)
        );
    }
}
