package de.mrjulsen.crn.client.gui.overlay.pages;

import de.mrjulsen.crn.Constants;
import de.mrjulsen.crn.client.gui.ModGuiIcons;
import de.mrjulsen.crn.client.gui.overlay.pages.RouteOverviewPage.RoutePathIcons;
import de.mrjulsen.crn.client.lang.CustomLanguage;
import de.mrjulsen.crn.data.StationTag.StationInfo;
import de.mrjulsen.crn.data.navigation.ClientRoute;
import de.mrjulsen.crn.data.navigation.TransferConnection;
import de.mrjulsen.crn.util.ModUtils;
import de.mrjulsen.mcdragonlib.client.util.DLGuiGraphics;
import de.mrjulsen.mcdragonlib.client.util.GuiUtils;
import de.mrjulsen.mcdragonlib.data.ETextAlignment;
import de.mrjulsen.mcdragonlib.util.DLColor;
import de.mrjulsen.mcdragonlib.util.TextUtils;
import de.mrjulsen.mcdragonlib.util.math.Rectangle;
import de.mrjulsen.mcdragonlib.util.time.DLTime;
import de.mrjulsen.mcdragonlib.util.time.TimeContext;
import de.mrjulsen.mcdragonlib.util.time.VanillaTimeSystem;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.components.MultiLineLabel;
import net.minecraft.network.chat.Component;

public class TransferPage extends AbstractRouteDetailsPage {

    private static final String keyScheduleTransfer = "gui.createrailwaysnavigator.route_overview.schedule_transfer";
    private static final String keyTransfer = "gui.createrailwaysnavigator.route_overview.transfer";
    private static final String keyTransferWithPlatform = "gui.createrailwaysnavigator.route_overview.transfer_with_platform";
    private static final String keyTimeNow = "gui.createrailwaysnavigator.time.now";

    private final TransferConnection connection;
    private MultiLineLabel messageLabel;

    public TransferPage(ClientRoute route, TransferConnection connection) {
        super(route);
        this.connection = connection;

        String terminus = connection.getDepartureStation().getDisplayTitle();
        StationInfo info = connection.getDepartureStation().getRealTimeStationTag().info();
        this.messageLabel = MultiLineLabel.m_94341_(font,
        info.platform() == null || info.platform().isBlank() ?
        CustomLanguage.translate(keyTransfer,
            connection.getDepartureStation().getTrainDisplayName(),
            terminus
        ) : 
        CustomLanguage.translate(keyTransferWithPlatform,
        connection.getDepartureStation().getTrainDisplayName(),
            terminus,
            info.platform()
        ), width() - (15 + ModGuiIcons.ICON_SIZE));
    }

    @Override
    public boolean isImportant() {
        return true;
    }

    @Override
    public void renderMainLayer(DLGuiGraphics graphics, double mouseX, double mouseY, Rectangle renderBounds) {
        int y = 0;
        RouteOverviewPage.renderStation(graphics, -4, width(), font, connection.getDepartureStation(), RoutePathIcons.START, true, connection.isConnectionMissed());
        y += 16;
        GuiUtils.fill(graphics, 0, y, width(), 1, DLColor.WHITE);
        
        // Title
        ModGuiIcons.WALK.render(graphics, 5, y + 3);        
        long transferTime = connection.getDepartureStation().getRealTimeDepartureTime() - ModUtils.getTransformedWorldTime();
        Component transferTimeText = TextUtils.text(new DLTime(transferTime, VanillaTimeSystem.INSTANCE).format(Constants.DEFAULT_VERBOSE_GAME_DURATION_FORMAT, TimeContext.INGAME, DLTime.defaultTimeSystem()));
        GuiUtils.drawString(graphics, font, 10 + ModGuiIcons.ICON_SIZE, y + 3 + ModGuiIcons.ICON_SIZE / 2 - font.f_92710_ / 2, CustomLanguage.translate(keyScheduleTransfer).m_130946_(" ").m_7220_(transferTime > 0 ? transferTimeText : CustomLanguage.translate(keyTimeNow)).m_130940_(ChatFormatting.BOLD), DLColor.WHITE, ETextAlignment.LEFT, false);
        y += 5 + ModGuiIcons.ICON_SIZE;
        
        // Details
        this.messageLabel.m_6508_(graphics.graphics(), 10 + ModGuiIcons.ICON_SIZE, y, font.f_92710_, 0xFFDBDBDB);
    }
    
}
