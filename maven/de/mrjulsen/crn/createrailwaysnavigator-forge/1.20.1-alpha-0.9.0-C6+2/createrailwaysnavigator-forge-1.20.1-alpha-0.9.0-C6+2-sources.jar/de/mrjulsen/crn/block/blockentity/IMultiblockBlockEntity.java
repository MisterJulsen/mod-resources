package de.mrjulsen.crn.block.blockentity;

import java.util.function.Consumer;

import de.mrjulsen.crn.CreateRailwaysNavigator;
import de.mrjulsen.crn.block.IBlockGetter;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos.MutableBlockPos;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

@SuppressWarnings("unchecked")
public interface IMultiblockBlockEntity<T extends BlockEntity & IMultiblockBlockEntity<T, B>, B extends Block> {
       
    byte getWidth();
    byte getHeight();
    byte getMaxWidth();
    byte getMaxHeight();
    boolean isController();
    Class<B> getBlockType();
    Class<T> getBlockEntityType();

    default T getBlockEntityCasted(IBlockGetter level, BlockPos otherpos) {
        if (!getBlockEntityType().isInstance(level.getBlockEntity(otherpos))) {
            return null;
        }
        return getBlockEntityType().cast(level.getBlockEntity(otherpos));
    }

    boolean connectable(IBlockGetter getter, BlockPos a, BlockPos b);

    @Deprecated(forRemoval = true)
    default void applyToAll(Consumer<T> apply) {
        T be = (T)this;
        applyToAll(apply, new IBlockGetter.WorldBlockGetter(be.m_58904_()));
	}
    default void applyToAll(Consumer<T> apply, IBlockGetter level) {
        T be = (T)this;

		BlockState blockState = be.m_58900_();
		if (!getBlockType().isInstance(blockState.m_60734_())) {
            return;
        }

		MutableBlockPos pos = be.m_58899_().m_122032_();
		Direction side = blockState.m_61143_(HorizontalDirectionalBlock.f_54117_).m_122428_();

		for (int i = 0; i < getWidth() && i < getMaxWidth(); i++) {
            BlockPos newPos = pos.m_5484_(side, i);
            for (int j = 0; j < getHeight() && j < getMaxHeight(); j++) {
                BlockPos newPos2 = newPos.m_5484_(Direction.DOWN, j);
                T otherBlockEntity = getBlockEntityCasted(level, newPos2);
                if (otherBlockEntity != null) {
                    apply.accept(otherBlockEntity);
                } else {
                    CreateRailwaysNavigator.LOGGER.error(String.format("BlockEntity at %s does not exist!", newPos2));
                }
            }
		}
	}
}
