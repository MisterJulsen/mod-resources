package de.mrjulsen.crn.registry.data;

import java.util.UUID;

import net.minecraft.nbt.CompoundTag;

public record NextConnectionsRequestData(String stationName, UUID selfTrainId, boolean allowDuplicates) {
    public static final String NBT_STATION_NAME = "StationName";
    public static final String NBT_TRAIN_ID = "TrainId";
    public static final String NBT_ALLOW_DUPLICATES = "AllowDuplicates";

    public CompoundTag toNbt() {
        CompoundTag nbt = new CompoundTag();
        nbt.m_128359_(NBT_STATION_NAME, stationName());
        nbt.m_128362_(NBT_TRAIN_ID, selfTrainId());
        nbt.m_128379_(NBT_ALLOW_DUPLICATES, allowDuplicates);
        return nbt;
    }

    public static NextConnectionsRequestData fromNbt(CompoundTag nbt) {
        return new NextConnectionsRequestData(
            nbt.m_128461_(NBT_STATION_NAME),
            nbt.m_128342_(NBT_TRAIN_ID),
            nbt.m_128471_(NBT_ALLOW_DUPLICATES)
        );
    }
}
