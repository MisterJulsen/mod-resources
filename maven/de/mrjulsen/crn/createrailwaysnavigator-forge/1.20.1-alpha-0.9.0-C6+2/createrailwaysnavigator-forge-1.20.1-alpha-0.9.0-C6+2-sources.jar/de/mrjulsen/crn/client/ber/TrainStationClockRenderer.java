package de.mrjulsen.crn.client.ber;

import org.joml.Vector3f;

import com.mojang.math.Axis;

import de.mrjulsen.crn.CreateRailwaysNavigator;
import de.mrjulsen.crn.block.TrainStationClockBlock;
import de.mrjulsen.crn.block.blockentity.TrainStationClockBlockEntity;
import de.mrjulsen.crn.util.ModUtils;
import de.mrjulsen.mcdragonlib.client.ber.AbstractBlockEntityRenderInstance;
import de.mrjulsen.mcdragonlib.client.ber.BERGraphics;
import de.mrjulsen.mcdragonlib.client.util.RenderUtils;
import de.mrjulsen.mcdragonlib.util.DLColor;
import de.mrjulsen.mcdragonlib.util.time.DLTime;
import de.mrjulsen.mcdragonlib.util.time.DLTimeOfDay;
import de.mrjulsen.mcdragonlib.util.time.ITimeSystem;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;

public class TrainStationClockRenderer extends AbstractBlockEntityRenderInstance<TrainStationClockBlockEntity> {

    private static final ResourceLocation DIAL_TEXTURE = new ResourceLocation(CreateRailwaysNavigator.MOD_ID, "textures/block/dial.png");

    public TrainStationClockRenderer(TrainStationClockBlockEntity blockEntity) {
        super(blockEntity);
    }

    @Override
    public void render(BERGraphics<TrainStationClockBlockEntity> graphics, float partialTick) {
        RenderUtils.initRenderEngine();
        
        graphics.poseStack().m_85836_();
        renderInternal(graphics, partialTick);
        graphics.poseStack().m_85849_();

        if (graphics.blockEntity().m_58900_().m_61143_(TrainStationClockBlock.DOUBLE)) {
            graphics.poseStack().m_85836_();
            graphics.poseStack().m_252880_(8, 8, 8);
            graphics.poseStack().m_252781_(Axis.f_252436_.m_252977_(90));
            graphics.poseStack().m_252880_(-8, -8, -8);
            renderInternal(graphics, partialTick);
            graphics.poseStack().m_85849_();
        }
        
    }

    private void renderInternal(BERGraphics<TrainStationClockBlockEntity> graphics, float partialTicks) {
        float z = graphics.blockEntity().m_58900_().m_61143_(TrainStationClockBlock.DOUBLE) ? 7.25f : 3.25f;

        graphics.poseStack().m_252880_(8, 8, 8 + z);
        RenderUtils.renderTexture(
            DIAL_TEXTURE, graphics,
            new Vector3f(-7, -7, -0.2f),
            14, 14,
            0, 0,
            1, 1,
            graphics.blockEntity().m_58900_().m_61143_(HorizontalDirectionalBlock.f_54117_),
            graphics.blockEntity().getColor(),
            graphics.blockEntity().isGlowing() ? LightTexture.f_173040_ : graphics.packedLight(),
            !graphics.blockEntity().isGlowing()
        );

        ITimeSystem timeSystem = DLTime.defaultTimeSystem();
        DLTime time = new DLTime(graphics.blockEntity().m_58904_(), timeSystem);
        DLTimeOfDay timeOfDay = new DLTimeOfDay(time, timeSystem);

        graphics.poseStack().m_85836_();
        graphics.poseStack().m_252781_(Axis.f_252403_.m_252977_(-90 + ModUtils.clockHandDegrees(timeOfDay.getHourOfDay(timeSystem), 12)));
        RenderUtils.fillColor(graphics, new Vector3f(-0.5f, -0.5f, 0), 6, 1, DLColor.fromInt(0xFF191919), graphics.blockEntity().m_58900_().m_61143_(HorizontalDirectionalBlock.f_54117_));
        graphics.poseStack().m_85849_();

        graphics.poseStack().m_85836_();
        graphics.poseStack().m_252781_(Axis.f_252403_.m_252977_(-90 + ModUtils.clockHandDegrees(timeOfDay.getMinuteOfHour(timeSystem), 60)));
        RenderUtils.fillColor(graphics, new Vector3f(-0.5f, -0.5f, 0.1f), 7, 1, DLColor.fromInt(0xFF222222), graphics.blockEntity().m_58900_().m_61143_(HorizontalDirectionalBlock.f_54117_));
        graphics.poseStack().m_85849_();

        graphics.poseStack().m_252880_(0, 0, -z * 2);
        graphics.poseStack().m_85836_();
        graphics.poseStack().m_252781_(Axis.f_252436_.m_252977_(180));
        RenderUtils.renderTexture(DIAL_TEXTURE, graphics, new Vector3f(-7, -7, -0.2f), 14, 14, 0, 0, 1, 1, graphics.blockEntity().m_58900_().m_61143_(HorizontalDirectionalBlock.f_54117_).m_122424_(), graphics.blockEntity().getColor(), graphics.blockEntity().isGlowing() ? LightTexture.f_173040_ : graphics.packedLight(), !graphics.blockEntity().isGlowing());
        graphics.poseStack().m_85849_();

        graphics.poseStack().m_85836_();
        graphics.poseStack().m_252781_(Axis.f_252393_.m_252977_(-90 + ModUtils.clockHandDegrees(timeOfDay.getHourOfDay(timeSystem), 12)));
        graphics.poseStack().m_252781_(Axis.f_252436_.m_252977_(180));
        RenderUtils.fillColor(graphics, new Vector3f(-0.5f, -0.5f, 0), 6, 1, DLColor.fromInt(0xFF191919), graphics.blockEntity().m_58900_().m_61143_(HorizontalDirectionalBlock.f_54117_));
        graphics.poseStack().m_85849_();

        graphics.poseStack().m_85836_();
        graphics.poseStack().m_252781_(Axis.f_252393_.m_252977_(-90 + ModUtils.clockHandDegrees(timeOfDay.getMinuteOfHour(timeSystem), 60)));
        graphics.poseStack().m_252781_(Axis.f_252436_.m_252977_(180));
        RenderUtils.fillColor(graphics, new Vector3f(-0.5f, -0.5f, 0.1f), 7, 1, DLColor.fromInt(0xFF222222), graphics.blockEntity().m_58900_().m_61143_(HorizontalDirectionalBlock.f_54117_));
        graphics.poseStack().m_85849_();
    }
}
