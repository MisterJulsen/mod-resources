package de.mrjulsen.crn.network.packets.pain;

import java.util.Optional;
import java.util.UUID;
import de.mrjulsen.crn.data.TrainLine;
import de.mrjulsen.crn.data.storage.GlobalSettings;
import de.mrjulsen.crn.util.Owner;
import de.mrjulsen.mcdragonlib.data.DLStatus;
import de.mrjulsen.mcdragonlib.network.NetworkPacketContext;
import de.mrjulsen.mcdragonlib.network.NetworkPacketData;
import net.minecraft.nbt.CompoundTag;

public class UpdateTrainLineNamePacketData {

    private static final String NBT_DATA = "Data";    
    private static final String NBT_ID = "Id";

    public static class Request extends NetworkPacketData {
        
        private UUID id;
        private String name;

        public Request(DLStatus status) {
            super(status);
        }

        public Request(UUID id, String name) {
            super(DLStatus.OK);
            this.id = id;
            this.name = name;
        }

        @Override
        protected void write(CompoundTag nbt) {
            nbt.m_128362_(NBT_ID, id);
            nbt.m_128359_(NBT_DATA, name);
        }

        @Override
        protected void read(CompoundTag nbt) {
            this.id = nbt.m_128342_(NBT_ID);
            this.name = nbt.m_128461_(NBT_DATA);
        }
    }

    public static class Response extends NetworkPacketData {
        private Optional<TrainLine> line;

        public Response(DLStatus status) {
            super(status);
        }

        public Response(Optional<TrainLine> line) {
            super(DLStatus.OK);
            this.line = line;
        }

        @Override
        protected void write(CompoundTag nbt) {
            this.line.ifPresent(x -> nbt.m_128365_(NBT_DATA, x.toNbt()));
        }

        @Override
        protected void read(CompoundTag nbt) {
            if (nbt.m_128441_(NBT_DATA)) {
                this.line = Optional.ofNullable(TrainLine.fromNbt(nbt.m_128469_(NBT_DATA)));
            } else {
                this.line = Optional.empty();
            }
        }

        public Optional<TrainLine> getLine() {
            return line;
        }

    }

    public static Response handle(Request packet, NetworkPacketContext context) {
        return new Response(Optional.ofNullable(GlobalSettings.getInstance().getTrainLine(packet.id).map((x) -> {
            if (!x.getOwner().isAllowed(new Owner(context.getPlayer())) || !GlobalSettings.modificationsAllowed(context.getPlayer())) {
                return null;
            }
            x.setName(packet.name);
            return x;
        })).orElse(null));
    }
    
}
