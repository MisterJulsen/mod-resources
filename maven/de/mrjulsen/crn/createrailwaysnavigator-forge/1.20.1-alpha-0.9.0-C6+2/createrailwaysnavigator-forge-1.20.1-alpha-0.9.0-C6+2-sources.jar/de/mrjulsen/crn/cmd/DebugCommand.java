package de.mrjulsen.crn.cmd;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import de.mrjulsen.crn.CreateRailwaysNavigator;
import de.mrjulsen.crn.data.train.DepartureHistory;
import de.mrjulsen.crn.data.train.TrainListener;
import de.mrjulsen.crn.debug.DebugOverlay;
import de.mrjulsen.crn.network.packets.pain.ShowTrainDebugScreenPacketData;
import de.mrjulsen.crn.registry.ModNetworkManager;
import de.mrjulsen.mcdragonlib.network.NetworkDirection;
import de.mrjulsen.mcdragonlib.util.TextUtils;
import dev.architectury.platform.Platform;
import dev.architectury.utils.Env;
import net.minecraft.Util;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.Commands.CommandSelection;

public class DebugCommand {

    private static final String CMD_NAME = CreateRailwaysNavigator.MOD_ID;
    
    private static final String SUB_DEBUG = "debug";
    private static final String SUB_DISCORD = "discord";
    private static final String SUB_GITHUB = "github";

    private static final String SUB_RESET = "resetTrainPredictions";
    private static final String SUB_HARD_RESET = "hardResetTrainPredictions";
    private static final String SUB_TRAIN_DEBUG_OVERLAY = "trainDebugOverlay";
    private static final String SUB_TRAIN_OVERVIEW = "trainOverview";
    private static final String SUB_CLEAR_DEPARTURE_HISTORY = "clearDepartureHistory";
    
    @SuppressWarnings("all")
    public static void register(CommandDispatcher<CommandSourceStack> dispatcher, CommandSelection selection) {        
        
        LiteralArgumentBuilder<CommandSourceStack> builder = Commands.m_82127_(CMD_NAME)
            .then(Commands.m_82127_(SUB_DEBUG)
                .requires(x -> x.m_6761_(3))
                .then(Commands.m_82127_(SUB_HARD_RESET)
                    .executes(x -> hardReset(x.getSource()))
                )
                .then(Commands.m_82127_(SUB_RESET)
                    .executes(x -> reset(x.getSource()))
                )
                .then(Commands.m_82127_(SUB_TRAIN_DEBUG_OVERLAY)
                    .executes(x -> showTrainObservationOverlay(x.getSource()))
                )
                .then(Commands.m_82127_(SUB_TRAIN_OVERVIEW)
                    .executes(x -> showTrainDebugScreen(x.getSource()))
                )
                .then(Commands.m_82127_(SUB_CLEAR_DEPARTURE_HISTORY)
                    .executes(x -> clearDepartureHistory(x.getSource()))
                )
            )
            .then(Commands.m_82127_(SUB_DISCORD)
                .executes(x -> discord(x.getSource()))
            )
            .then(Commands.m_82127_(SUB_GITHUB)
                .executes(x -> github(x.getSource()))
            )
        ;

        dispatcher.register(builder);
    }

    private static int discord(CommandSourceStack cmd) throws CommandSyntaxException {
        cmd.m_288197_(() -> TextUtils.text("Redirecting to the discord server..."), false);
        Util.m_137581_().m_137646_(CreateRailwaysNavigator.DISCORD);
        return 1;
    }

    private static int github(CommandSourceStack cmd) throws CommandSyntaxException {
        cmd.m_288197_(() -> TextUtils.text("Redirecting to the github repository..."), false);
        Util.m_137581_().m_137646_(CreateRailwaysNavigator.GITHUB);
        return 1;
    }

    private static int hardReset(CommandSourceStack cmd) throws CommandSyntaxException {
        cmd.m_288197_(() -> TextUtils.text("All train predictions have been deleted."), false);
        TrainListener.resetTrainData();
        return 1;
    }

    private static int reset(CommandSourceStack cmd) throws CommandSyntaxException {
        cmd.m_288197_(() -> TextUtils.text("All train predictions have been reset."), false);
        TrainListener.getAllTrainData().forEach(x -> x.softResetPredictions());
        return 1;
    }

    private static int showTrainObservationOverlay(CommandSourceStack cmd) throws CommandSyntaxException {
        if (Platform.getEnvironment() == Env.CLIENT) {            
            cmd.m_288197_(() -> TextUtils.text("Visibility of the train debug overlay has been toggled."), false);
            DebugOverlay.toggle();
            return 1;
        } else {            
            cmd.m_81352_(TextUtils.text("Cannot open the train debug overlay in multiplayer."));  
        }
        return 0;
    }

    private static int showTrainDebugScreen(CommandSourceStack cmd) throws CommandSyntaxException {
        cmd.m_288197_(() -> TextUtils.empty(), false);
        ModNetworkManager.SHOW_TRAIN_DEBUG_SCREEN.send(NetworkDirection.toPlayer(cmd.m_81375_()), new ShowTrainDebugScreenPacketData());
        return 1;
    }

    private static int clearDepartureHistory(CommandSourceStack cmd) throws CommandSyntaxException {
        cmd.m_288197_(() -> TextUtils.text("The departure history has been deleted."), false);
        DepartureHistory.clear();
        return 1;
    }
}