package de.mrjulsen.crn.block;

import com.simibubi.create.content.equipment.wrench.IWrenchable;
import com.simibubi.create.foundation.block.IBE;

import de.mrjulsen.crn.CreateRailwaysNavigator;
import de.mrjulsen.crn.block.blockentity.TrainStationClockBlockEntity;
import de.mrjulsen.crn.config.ModClientConfig;
import de.mrjulsen.crn.registry.ModBlockEntities;
import de.mrjulsen.mcdragonlib.util.DLColor;
import de.mrjulsen.mcdragonlib.util.TextUtils;
import de.mrjulsen.mcdragonlib.util.time.DLTime;
import de.mrjulsen.mcdragonlib.util.time.TimeContext;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.DyeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition.Builder;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

public class TrainStationClockBlock extends Block implements IWrenchable, IBE<TrainStationClockBlockEntity> {

	public static final DirectionProperty FACING = HorizontalDirectionalBlock.f_54117_;
    public static final BooleanProperty DOUBLE = BooleanProperty.m_61465_("double");
	
    private static final VoxelShape SHAPE_SN = Block.m_49796_(0, 0, 4, 16, 16, 12);
    private static final VoxelShape SHAPE_EW = Block.m_49796_(4, 0, 0, 12, 16, 16);

    public TrainStationClockBlock(Properties properties) {
        super(properties
            .m_60955_()
        );

        this.m_49959_(this.f_49792_.m_61090_()
            .m_61124_(FACING, Direction.NORTH)
            .m_61124_(DOUBLE, false)
        );
    }

    @Override
    public InteractionResult m_6227_(BlockState pState, Level pLevel, BlockPos pPos, Player pPlayer, InteractionHand pHand, BlockHitResult pHit) {
        
        ItemStack heldItem = pPlayer.m_21120_(pHand);
        TrainStationClockBlockEntity blockEntity = ((TrainStationClockBlockEntity)pLevel.m_7702_(pPos));

		if (heldItem.m_41720_() instanceof DyeItem dyeItem) {
			DyeColor dye = dyeItem.m_41089_();        
			if (dye != null) {
				pLevel.m_5594_(null, pPos, SoundEvents.f_144133_, SoundSource.BLOCKS, 1.0F, 1.0F);
				blockEntity.setColor(DLColor.fromInt(dye == DyeColor.ORANGE ? 0xFFFF9900 : dye.m_284406_().f_283871_));

				if (pLevel.f_46443_) {
					blockEntity.getRenderer().update(pLevel, pPos, pState, blockEntity, null);
				}

				return InteractionResult.SUCCESS;
			}
		}
       
		if (heldItem.m_150930_(Items.f_151056_)) {
			pLevel.m_5594_(null, pPos, SoundEvents.f_144153_, SoundSource.BLOCKS, 1.0F, 1.0F);
			blockEntity.setGlowing(true);
			
			if (pLevel.f_46443_) {
				blockEntity.getRenderer().update(pLevel, pPos, pState, blockEntity, null);
			}

            return InteractionResult.SUCCESS;
		}

		if (!pPlayer.m_21120_(pHand).m_150930_(this.m_5456_()) && pLevel.f_46443_) {
            pPlayer.m_5661_(TextUtils.translate("gui." + CreateRailwaysNavigator.MOD_ID + ".time", new DLTime(pLevel, DLTime.defaultTimeSystem()).format(ModClientConfig.TIME_FORMAT.get().getFormat(), TimeContext.INGAME, DLTime.defaultTimeSystem())), true);
            return InteractionResult.SUCCESS;
        }
        return InteractionResult.PASS;
    }

	@Override
    public VoxelShape m_5940_(BlockState pState, BlockGetter pLevel, BlockPos pPos, CollisionContext pContext) {
        if (pState.m_61143_(DOUBLE)) {
            return Shapes.m_83144_();
        }
        return pState.m_61143_(FACING) == Direction.NORTH || pState.m_61143_(FACING) == Direction.SOUTH ? SHAPE_SN : SHAPE_EW;
    }

    @Override
    public BlockState m_6843_(BlockState pState, Rotation pRotation) {
        return pState.m_61124_(FACING, pRotation.m_55954_(pState.m_61143_(FACING)));
    }    

    @Override
    public BlockState m_6943_(BlockState pState, Mirror pMirror) {
        return pState.m_60717_(pMirror.m_54846_(pState.m_61143_(FACING)));
    }
    
    @Override
    protected void m_7926_(Builder<Block, BlockState> pBuilder) {
        super.m_7926_(pBuilder);
        pBuilder.m_61104_(FACING, DOUBLE);
    }

    @Override
	public BlockState m_5573_(BlockPlaceContext context) {
        BlockState blockState = context.m_43725_().m_8055_(context.m_8083_());
		if (blockState.m_60713_(this)) {
			return blockState.m_61124_(DOUBLE, true);
		}
		return this.m_49966_().m_61124_(FACING, context.m_8125_().m_122424_());
	}

    public boolean m_6864_(BlockState state, BlockPlaceContext useContext) {
		if (useContext.m_43722_().m_150930_(this.m_5456_()) && !state.m_61143_(DOUBLE)) {
            return true;
		} 
        return false;
	}

    @Override
    public RenderShape m_7514_(BlockState pState) {
        return RenderShape.MODEL;
    }

    @Override
    public Class<TrainStationClockBlockEntity> getBlockEntityClass() {
        return TrainStationClockBlockEntity.class;
    }

    @Override
    public BlockEntity m_142194_(BlockPos pos, BlockState state) {
        return new TrainStationClockBlockEntity(getBlockEntityType(), pos, state);
    }

    @Override
    public BlockEntityType<? extends TrainStationClockBlockEntity> getBlockEntityType() {
       return ModBlockEntities.TRAIN_STATION_CLOCK_BLOCK_ENTITY.get();
    }
}
