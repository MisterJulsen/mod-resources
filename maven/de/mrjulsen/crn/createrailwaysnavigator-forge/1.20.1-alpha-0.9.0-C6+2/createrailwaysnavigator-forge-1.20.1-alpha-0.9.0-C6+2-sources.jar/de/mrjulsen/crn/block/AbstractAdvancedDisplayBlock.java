package de.mrjulsen.crn.block;

import java.util.Collection;
import java.util.List;

import com.simibubi.create.AllBlocks;
import com.simibubi.create.content.decoration.copycat.CopycatBlock;
import com.simibubi.create.content.decoration.copycat.CopycatBlockEntity;
import com.simibubi.create.content.equipment.clipboard.ClipboardEntry;
import com.simibubi.create.content.equipment.wrench.IWrenchable;
import com.simibubi.create.content.kinetics.base.KineticBlockEntity;
import com.simibubi.create.foundation.block.IBE;

import com.simibubi.create.foundation.blockEntity.SmartBlockEntity;
import com.simibubi.create.foundation.blockEntity.SmartBlockEntityTicker;
import com.simibubi.create.foundation.utility.AdventureUtil;
import de.mrjulsen.crn.block.blockentity.AdvancedDisplayBlockEntity;
import de.mrjulsen.crn.block.blockentity.AdvancedDisplayBlockEntity.EUpdateReason;
import de.mrjulsen.crn.block.display.properties.BasicDisplaySettings;
import de.mrjulsen.crn.block.display.properties.SimpleStaticTextDisplaySettings;
import de.mrjulsen.crn.block.display.properties.StaticTextDisplaySettings;
import de.mrjulsen.crn.block.display.properties.StaticTextDisplaySettings.TextComponent;
import de.mrjulsen.crn.block.properties.ESide;
import de.mrjulsen.crn.client.ClientWrapper;
import de.mrjulsen.crn.network.packets.cts.AdvancedDisplayUpdatePacketData;
import de.mrjulsen.crn.registry.ModBlockEntities;
import de.mrjulsen.crn.registry.ModDisplayTypes;
import de.mrjulsen.crn.registry.ModNetworkManager;
import de.mrjulsen.mcdragonlib.data.ETextAlignment;
import de.mrjulsen.mcdragonlib.network.NetworkDirection;
import de.mrjulsen.mcdragonlib.util.DLColor;
import de.mrjulsen.mcdragonlib.util.Pair;
import de.mrjulsen.mcdragonlib.util.Tripple;
import net.createmod.catnip.data.Iterate;
import net.minecraft.client.Minecraft;
import net.minecraft.client.color.block.BlockColor;
import net.minecraft.core.BlockPos;
import net.minecraft.core.BlockPos.MutableBlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Direction.Axis;
import net.minecraft.core.Direction.AxisDirection;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.*;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition.Builder;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.ticks.LevelTickAccess;
import org.jetbrains.annotations.Nullable;

public abstract class AbstractAdvancedDisplayBlock extends CopycatBlock implements IWrenchable {

	public static final DLColor DEFAULT_DISPLAY_COLOR = DLColor.fromInt(0xFF404040);

    public static final DirectionProperty FACING = HorizontalDirectionalBlock.f_54117_;
    
	public static final BooleanProperty UP = BooleanProperty.m_61465_("up");
	public static final BooleanProperty DOWN = BooleanProperty.m_61465_("down");

    public AbstractAdvancedDisplayBlock(Properties properties) {
        super(properties.m_284180_(MapColor.f_283906_));

        this.m_49959_(this.f_49792_.m_61090_()
            .m_61124_(UP, false)
            .m_61124_(DOWN, false)
            .m_61124_(FACING, Direction.NORTH)
        );
    }

	@Override
	public @Nullable BlockState getAcceptedBlockState(Level pLevel, BlockPos pPos, ItemStack item, Direction face) {
		if (!(item.m_41720_() instanceof BlockItem bi))
			return null;

		Block block = bi.m_40614_();
		if (block instanceof CopycatBlock)
			return null;

		BlockState appliedState = block.m_49966_();
		if (block instanceof HalfTransparentBlock || !appliedState.m_60815_()) {
			return null;
		}
		return super.getAcceptedBlockState(pLevel, pPos, item, face);
	}

	@Override
	public boolean canConnectTexturesToward(BlockAndTintGetter reader, BlockPos fromPos, BlockPos toPos, BlockState state) {
		return true;
	}

	@Override
	public @Nullable CopycatBlockEntity getBlockEntity(BlockGetter worldIn, BlockPos pos) {
		BlockEntity blockEntity = worldIn.m_7702_(pos);

		if (blockEntity == null)
			return null;
		if (!(blockEntity instanceof CopycatBlockEntity))
			return null;

		return (CopycatBlockEntity)blockEntity;
	}

	@Override
	public @Nullable <S extends BlockEntity> BlockEntityTicker<S> m_142354_(Level p_153212_, BlockState p_153213_, BlockEntityType<S> p_153214_) {
		return new SmartBlockEntityTicker<>();
	}

	public static BlockColor getDisplayColor() {
		return (state, world, pos, tintIndex) -> {
			if (tintIndex == 1) {
				if (world == null || pos == null) {
					return DEFAULT_DISPLAY_COLOR.getAsARGB();
				}
				if (world.m_7702_(pos) instanceof AdvancedDisplayBlockEntity be) {
					return be.getSettingsAs(BasicDisplaySettings.class).map(x -> {
						DLColor color = x.getBackColor();
						return color.isTransparent() ? null : color;
					}).orElse(DEFAULT_DISPLAY_COLOR).getAsARGB();
				}
				return DEFAULT_DISPLAY_COLOR.getAsARGB();
			}
			if (world == null || pos == null) {
				return GrassColor.m_46415_(0.5D, 1.0D);
			}
			return Minecraft.m_91087_().m_91298_().m_92577_(getMaterial(world, pos), world, pos, tintIndex);
		};
	}


    @Override
    public BlockState m_6843_(BlockState pState, Rotation pRotation) {
        return pState.m_61124_(FACING, pRotation.m_55954_(pState.m_61143_(FACING)));
    }    

    @Override
    public BlockState m_6943_(BlockState pState, Mirror pMirror) {
        return pState.m_60717_(pMirror.m_54846_(pState.m_61143_(FACING)));
    }
    
    @Override
    protected void m_7926_(Builder<Block, BlockState> pBuilder) {
        super.m_7926_(pBuilder);
        pBuilder.m_61104_(UP, DOWN, FACING);
    }

    @Override
	public BlockState m_5573_(BlockPlaceContext context) {
		Direction face = context.m_43719_();
		BlockPos clickedPos = context.m_8083_();
		BlockPos placedOnPos = clickedPos.m_121945_(face.m_122424_());
		Level level = context.m_43725_();
		BlockState otherState = level.m_8055_(placedOnPos);
		BlockState stateForPlacement = this.m_49966_().m_61124_(FACING, context.m_8125_().m_122424_());

		if ((otherState.m_60734_() != this) || (context.m_43723_() != null && context.m_43723_().m_6144_())) {
			stateForPlacement = getDefaultPlacementState(context, stateForPlacement, otherState);
		} else { // Clicked on existing block
			stateForPlacement = appendOnPlace(context, stateForPlacement, otherState);
		}

		return updateColumn(level, clickedPos, stateForPlacement, true);
	}

	public BlockState appendOnPlace(BlockPlaceContext context, BlockState state, BlockState other) {
		Direction otherFacing = other.m_61143_(FACING);
		state = state
			.m_61124_(FACING, otherFacing)
		;
		return state;
	}

	public BlockState getDefaultPlacementState(BlockPlaceContext context, BlockState state, BlockState other) {
		return super.m_5573_(context).m_61124_(FACING, context.m_8125_().m_122424_());
	}

    protected BlockState updateColumn(Level level, BlockPos pos, BlockState state, boolean present) {
		MutableBlockPos currentPos = new MutableBlockPos();
		Axis axis = getConnectionAxis(state);

		for (Direction connection : Iterate.directionsInAxis(Axis.Y)) {
			boolean connect = true;

			Move: for (Direction movement : Iterate.directionsInAxis(axis)) {
				currentPos.m_122190_(pos);
				for (int i = 0; i < 1000; i++) {
					if (!level.m_46749_(currentPos))
						break;

					BlockPos otherPos = currentPos.m_121945_(connection);
					BlockState other1 = currentPos.equals(pos) ? state : level.m_8055_(currentPos);
					BlockState other2 = level.m_8055_(otherPos);
					boolean col1 = canConnect(level, pos, state, other1);
					boolean col2 = canConnect(level, pos, state, other2);
					currentPos.m_122173_(movement);

					if (!col1 && !col2)
						break;
					if (col1 && col2)
						continue;

					connect = false;
					break Move;
				}
			}
			state = setConnection(state, connection, connect);
		}
		return state;
	}

	@Override
	public void m_6807_(BlockState pState, Level pLevel, BlockPos pPos, BlockState pOldState, boolean pIsMoving) {
		if (pOldState.m_60734_() == this)
			return;
		LevelTickAccess<Block> blockTicks = pLevel.m_183326_();
		if (!blockTicks.m_183582_(pPos, this))
			pLevel.m_186460_(pPos, this, 1);

		updateNeighbours(pState, pLevel, pPos);

		if (pLevel.f_46443_) {
			withBlockEntityDo(pLevel, pPos, be -> {
				if (be instanceof AdvancedDisplayBlockEntity dbe) {
					dbe.getController(new IBlockGetter.WorldBlockGetter(pLevel)).getRenderer().update(pLevel, pPos, pState, dbe, EUpdateReason.LAYOUT_CHANGED);
				}
			});
		}
	}

	public <T extends Comparable<T>> BlockState getPropertyFromNeighbours(BlockState pState, Level pLevel, BlockPos pPos, Property<T> property) {
		Direction leftDirection = pState.m_61143_(HorizontalDirectionalBlock.f_54117_).m_122427_();
		BlockState newState = null;
		BlockPos relPos = pPos.m_121945_(leftDirection);
		if ((newState = getPropertyFromNeighbour(pState, pLevel, pPos, relPos, property)) != null) {
			return newState;
		}
		relPos = pPos.m_121945_(Direction.UP);        
		if ((newState = getPropertyFromNeighbour(pState, pLevel, pPos, relPos, property)) != null) {
			return newState;
		}
		relPos = pPos.m_121945_(leftDirection.m_122424_());
		if ((newState = getPropertyFromNeighbour(pState, pLevel, pPos, relPos, property)) != null) {
			return newState;
		}
		relPos = pPos.m_121945_(Direction.DOWN);        
		if ((newState = getPropertyFromNeighbour(pState, pLevel, pPos, relPos, property)) != null) {
			return newState;
		}
		return pState;
	}

	public <T extends Comparable<T>> BlockState getPropertyFromNeighbour(BlockState pState, Level pLevel, BlockPos pPos, BlockPos relPos, Property<T> property) {
		if (canConnectWithBlock(new IBlockGetter.WorldBlockGetter(pLevel), pState, pLevel.m_8055_(relPos))) {
			return pState.m_61124_(property, pLevel.m_8055_(relPos).m_61143_(property));
		}
		return null;
	}

	public void updateNeighbours(BlockState pState, Level pLevel, BlockPos pPos) {
		Direction leftDirection = pState.m_61143_(HorizontalDirectionalBlock.f_54117_).m_122427_();
		BlockPos relPos = pPos.m_121945_(leftDirection);
		if (updateNeighbour(pState, pLevel, pPos, relPos)) {
			return;
		}
		relPos = pPos.m_121945_(Direction.UP);        
		if (updateNeighbour(pState, pLevel, pPos, relPos)) {
			return;
		}
		relPos = pPos.m_121945_(leftDirection.m_122424_());
		if (updateNeighbour(pState, pLevel, pPos, relPos)) {
			return;
		}
		relPos = pPos.m_121945_(Direction.DOWN);        
		if (updateNeighbour(pState, pLevel, pPos, relPos)) {
			return;
		}
	}

    @Override
	public void m_213897_(BlockState pState, ServerLevel pLevel, BlockPos pPos, RandomSource pRandom) {
		if (pState.m_60734_() != this)
			return;
		BlockPos belowPos = pPos.m_121945_(Direction.m_122387_(getConnectionAxis(pState), AxisDirection.NEGATIVE));
		BlockState belowState = pLevel.m_8055_(belowPos);
		if (!canConnect(pLevel, pPos, pState, belowState))
			KineticBlockEntity.switchToBlockState(pLevel, pPos, updateColumn(pLevel, pPos, pState, true));
	}

    @Override
	public BlockState m_7417_(BlockState state, Direction pDirection, BlockState pNeighborState, LevelAccessor pLevel, BlockPos pCurrentPos, BlockPos pNeighborPos) {
		return updatedShapeInner(state, pDirection, pNeighborState, pLevel, pCurrentPos, pNeighborPos);
	}

	private BlockState updatedShapeInner(BlockState state, Direction pDirection, BlockState pNeighborState, LevelAccessor pLevel, BlockPos pCurrentPos, BlockPos pNeighborPos) {
		if (!canConnect(pLevel, pCurrentPos, state, pNeighborState))
			return setConnection(state, pDirection, false);
		if (pDirection.m_122434_() == getConnectionAxis(state))
			return applyPropertiesOf(state, pNeighborState);
		return setConnection(state, pDirection, getConnection(pNeighborState, pDirection.m_122424_()));
	}

	public BlockState applyPropertiesOf(BlockState current, BlockState state) {
        BlockState blockState = this.m_49966_();
        for (Property<?> property : state.m_60734_().m_49965_().m_61092_()) {
            if (!blockState.m_61138_(property))
				continue;

			if (getExcludedProperties().contains(property)) {
				blockState = copyPropertyOf(current, blockState, property);
				continue;
			}
			
            blockState = copyPropertyOf(state, blockState, property);
        }
        return blockState;
    }

	private static <T extends Comparable<T>> BlockState copyPropertyOf(BlockState sourceState, BlockState targetState, Property<T> property) {
        return (BlockState)targetState.m_61124_(property, sourceState.m_61143_(property));
    }

    protected boolean canConnect(LevelAccessor level, BlockPos pos, BlockState state, BlockState other) {
		return other.m_60734_() == this && state.m_61143_(FACING) == other.m_61143_(FACING);
	}

	public boolean canConnectWithBlock(IBlockGetter level, BlockState selfState, BlockState otherState) {
		return selfState.m_60734_() instanceof AbstractAdvancedDisplayBlock && otherState.m_60734_() instanceof AbstractAdvancedDisplayBlock &&
			selfState.m_60734_() == otherState.m_60734_() &&
			selfState.m_61143_(FACING) == otherState.m_61143_(FACING)
		;
	}

	protected Axis getConnectionAxis(BlockState state) {
		return state.m_61143_(FACING).m_122427_().m_122434_();
	}

	public static boolean getConnection(BlockState state, Direction side) {
		BooleanProperty property = side == Direction.DOWN ? DOWN : side == Direction.UP ? UP : null;
		return property != null && state.m_61143_(property);
	}

	public static BlockState setConnection(BlockState state, Direction side, boolean connect) {
		BooleanProperty property = side == Direction.DOWN ? DOWN : side == Direction.UP ? UP : null;
		if (property != null)
			state = state.m_61124_(property, connect);
			
		return state;
	}

	@SuppressWarnings("deprecation")
	@Override
	public void m_6810_(BlockState pState, Level pLevel, BlockPos pPos, BlockState pNewState, boolean pIsMoving) {
		super.m_6810_(pState, pLevel, pPos, pNewState, pIsMoving);
		if (pIsMoving || pNewState.m_60734_() == this)
			return;
		for (Direction d : Iterate.directionsInAxis(getConnectionAxis(pState))) {
			BlockPos relative = pPos.m_121945_(d);
			BlockState adjacent = pLevel.m_8055_(relative);
			if (canConnect(pLevel, pPos, pState, adjacent))
				KineticBlockEntity.switchToBlockState(pLevel, relative, updateColumn(pLevel, relative, adjacent, false));
		}
	}

    @Override
    public InteractionResult m_6227_(BlockState pState, Level pLevel, BlockPos pPos, Player pPlayer, InteractionHand pHand, BlockHitResult pHit) {
        ItemStack heldItem = pPlayer.m_21120_(pHand);
        AdvancedDisplayBlockEntity blockEntity = ((AdvancedDisplayBlockEntity)pLevel.m_7702_(pPos)).getController(new IBlockGetter.WorldBlockGetter(pLevel));

		if (heldItem.m_41720_() instanceof DyeItem dyeItem) {
			DyeColor dye = dyeItem.m_41089_();        
			if (dye != null) {
				pLevel.m_5594_(null, pPos, SoundEvents.f_144133_, SoundSource.BLOCKS, 1.0F, 1.0F);
				DLColor dyeColor = DLColor.fromInt(dye == DyeColor.ORANGE ? 0xFFFF9900 : dye.m_41071_());
				
				blockEntity.applyToAll(be -> {
					be.getSettingsAs(BasicDisplaySettings.class).ifPresent(x -> {
						if (pPlayer.m_6144_()) {
							x.setBackColor(dyeColor);
						} else {
							x.setFontColor(dyeColor);
						}
						be.notifyUpdate();
					});
				});

				if (pLevel.f_46443_) {
					blockEntity.getRenderer().update(pLevel, pPos, pState, blockEntity, EUpdateReason.LAYOUT_CHANGED);
				}

				return InteractionResult.SUCCESS;
			}
		} else if (heldItem.m_150930_(Items.f_151056_)) {
			pLevel.m_5594_(null, pPos, SoundEvents.f_144153_, SoundSource.BLOCKS, 1.0F, 1.0F);
			blockEntity.applyToAll(be -> {
                be.setGlowing(true);
				be.notifyUpdate();
            });
			
			if (pLevel.f_46443_) {
				blockEntity.getRenderer().update(pLevel, pPos, pState, blockEntity, EUpdateReason.LAYOUT_CHANGED);
			}

            return InteractionResult.SUCCESS;
		} else if (heldItem.m_41720_() == Items.f_42656_ && heldItem.m_41788_() && pLevel.f_46443_) {
			AdvancedDisplayBlockEntity controller = blockEntity.getController(new IBlockGetter.WorldBlockGetter(pLevel));
            if (controller != null) {
				SimpleStaticTextDisplaySettings settings = new SimpleStaticTextDisplaySettings();				
				settings.setStaticText(heldItem.m_41786_().getString());
				boolean doubleSided = false;
				if (controller.m_58900_().m_60734_() instanceof AbstractAdvancedSidedDisplayBlock) {
					doubleSided = controller.m_58900_().m_61143_(AbstractAdvancedSidedDisplayBlock.SIDE) == ESide.BOTH;
				}
				
				ModNetworkManager.ADVANCED_DISPLAY_UPDATE_PACKET.send(NetworkDirection.toServer(), new AdvancedDisplayUpdatePacketData(controller.m_58904_(), controller.m_58899_(), null, ModDisplayTypes.SIMPLE_TEXT, doubleSided, settings));
				return InteractionResult.SUCCESS;
            }
		} else if (AllBlocks.CLIPBOARD.isIn(heldItem) && pLevel.f_46443_) {
			AdvancedDisplayBlockEntity controller = blockEntity.getController(new IBlockGetter.WorldBlockGetter(pLevel));
            if (controller != null) {
				StaticTextDisplaySettings settings = new StaticTextDisplaySettings();			
				List<ClipboardEntry> entries = ClipboardEntry.getLastViewedEntries(heldItem);
				int line = 0;
				entryLoop: for (ClipboardEntry entry : entries) {
					for (String string : entry.text.getString().split("\n")) {
						TextComponent component = new TextComponent(string);
						component.setTextAlignment(ETextAlignment.LEFT);
						component.setXScale(0.4f);
						component.setMinXScale(0.4f);
						component.setYScale(0.4f);
						component.setY(line * 5.5f);
						if (line >= settings.getComponentsCount()) {
							settings.addComponent(component);
						} else {
							settings.setComponent(line, component);
						}
						line++;
						if (line >= controller.getYSize() * 3 - 1) {
							break entryLoop;
						}
					}
				}
				boolean doubleSided = false;
				if (controller.m_58900_().m_60734_() instanceof AbstractAdvancedSidedDisplayBlock) {
					doubleSided = controller.m_58900_().m_61143_(AbstractAdvancedSidedDisplayBlock.SIDE) == ESide.BOTH;
				}

				ModNetworkManager.ADVANCED_DISPLAY_UPDATE_PACKET.send(NetworkDirection.toServer(), new AdvancedDisplayUpdatePacketData(controller.m_58904_(), controller.m_58899_(), null, ModDisplayTypes.RICH_TEXT, doubleSided, settings));
				return InteractionResult.SUCCESS;
            }
		}

		return useCopycat(pState, pLevel, pPos, pPlayer, pHand, pHit);
    }

	public InteractionResult useCopycat(BlockState pState, Level pLevel, BlockPos pPos, Player pPlayer, InteractionHand pHand, BlockHitResult pHit) {
		if (pPlayer == null || AdventureUtil.isAdventure(pPlayer))
			return InteractionResult.PASS;

		Direction face = pHit.m_82434_();
		ItemStack itemInHand = pPlayer.m_21120_(pHand);
		BlockState materialIn = getAcceptedBlockState(pLevel, pPos, itemInHand, face);

		if (materialIn != null)
			materialIn = prepareMaterial(pLevel, pPos, pState, pPlayer, pHand, pHit, materialIn);
		if (materialIn == null)
			return InteractionResult.PASS;

		BlockState material = materialIn;
		return onBlockEntityUse(pLevel, pPos, ufte -> {
			if (ufte.getMaterial().m_60713_(material.m_60734_())) {
				if (!ufte.cycleMaterial())
					return InteractionResult.PASS;
				ufte.m_58904_().m_5594_(null, ufte.m_58899_(), SoundEvents.f_12013_, SoundSource.BLOCKS, .75f, .95f);
				return InteractionResult.SUCCESS;
			}
			if (ufte.hasCustomMaterial())
				return InteractionResult.PASS;

			ufte.setMaterial(material);
			ufte.setConsumedItem(itemInHand);
			ufte.m_58904_().m_5594_(null, ufte.m_58899_(), material.m_60827_().m_56777_(), SoundSource.BLOCKS, 1, .75f);

			if (pPlayer.m_7500_())
				return InteractionResult.SUCCESS;

			itemInHand.m_41774_(1);
			if (itemInHand.m_41619_())
				pPlayer.m_21008_(pHand, ItemStack.f_41583_);
			return InteractionResult.SUCCESS;
		});
	}
	
    protected boolean updateNeighbour(BlockState pState, Level pLevel, BlockPos pPos, BlockPos neighbourPos) {
        if (pLevel.m_8055_(neighbourPos).m_60713_(this) && pLevel.m_7702_(neighbourPos) instanceof AdvancedDisplayBlockEntity otherBe && pLevel.m_7702_(pPos) instanceof AdvancedDisplayBlockEntity be) {
	    	be.copyFrom(otherBe);
            return true;
        }
		return false;
    }

	@Override
	public InteractionResult onWrenched(BlockState state, UseOnContext context) {
		Level level = context.m_43725_();
		if (!context.m_43723_().m_6144_() && level.m_7702_(context.m_8083_()) instanceof AdvancedDisplayBlockEntity be) {
			AdvancedDisplayBlockEntity controller = be.getController(new IBlockGetter.WorldBlockGetter(context.m_43725_()));
			if (controller != null) {
				if (level.f_46443_) {
					ClientWrapper.showAdvancedDisplaySettingsScreen(controller, null);
				}
				return InteractionResult.SUCCESS;
			}
		}
		return super.onWrenched(state, context);
	}

	@Override
	public InteractionResult onSneakWrenched(BlockState state, UseOnContext context) {
		InteractionResult res = super.onWrenched(state, context);
		if (res.m_19077_()) {
			return res;
		}
		return super.onSneakWrenched(state, context);
	}

    @Override
    public RenderShape m_7514_(BlockState pState) {
        return RenderShape.MODEL;
    }


    @Override
    public BlockEntityType<? extends AdvancedDisplayBlockEntity> getBlockEntityType() {
        return ModBlockEntities.ADVANCED_DISPLAY_BLOCK_ENTITY.get();
    }

	@Override
	public @Nullable BlockEntity m_142194_(BlockPos pos, BlockState state) {
		return new AdvancedDisplayBlockEntity(getBlockEntityType(), pos, state);
	}

	public abstract boolean isSingleLined();

    public abstract Tripple<Float, Float, Float> getRenderRotation(Level level, BlockState blockState, BlockPos pos);
    public abstract Pair<Float, Float> getRenderOffset(Level level, BlockState blockState, BlockPos pos);
    /** First value: Front side, Second value: Back side */ public abstract Pair<Float, Float> getRenderZOffset(Level level, BlockState blockState, BlockPos pos);
    public abstract Pair<Float, Float> getRenderAspectRatio(Level level, BlockState blockState, BlockPos pos);

	public Collection<Property<?>> getExcludedProperties() {
		return List.of();
	}
}
