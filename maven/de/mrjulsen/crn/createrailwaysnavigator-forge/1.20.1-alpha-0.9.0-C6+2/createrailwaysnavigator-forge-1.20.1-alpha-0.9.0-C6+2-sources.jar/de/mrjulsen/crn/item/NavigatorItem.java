package de.mrjulsen.crn.item;

import com.mojang.blaze3d.vertex.PoseStack;
import de.mrjulsen.crn.client.ClientWrapper;
import de.mrjulsen.crn.registry.ModBlocks;
import de.mrjulsen.mcdragonlib.client.render.ICustomItemRenderer;
import de.mrjulsen.mcdragonlib.client.util.DLGraphics;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LecternBlock;
import net.minecraft.world.level.block.state.BlockState;

public class NavigatorItem extends Item implements ICustomItemRenderer {

    public static final String NBT_BACKGROUND_ID = "BackgroundId";

    public NavigatorItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResult m_6225_(UseOnContext context) {
        Player player = context.m_43723_();
        if (player == null) return InteractionResult.PASS;
        Level level = context.m_43725_();
        BlockPos pos = context.m_8083_();
        BlockState state = level.m_8055_(pos);
        ItemStack stack = context.m_43722_();

        if (player.m_36326_()) {            
            if (player.m_6144_()) {
                if (ModBlocks.NAVIGATOR_LECTERN.has(state)) {
                    if (!level.f_46443_) {
                        ModBlocks.NAVIGATOR_LECTERN.get().withBlockEntityDo(level, pos, be -> be.swapControllers(stack, player, context.m_43724_(), state));
                    }
                    return InteractionResult.SUCCESS;
                }
            } else {
                if (state.m_60713_(Blocks.f_50624_) && !state.m_61143_(LecternBlock.f_54467_)) {
                    if (!level.f_46443_) {
                        ItemStack lecternStack = player.m_7500_() ? stack.m_41777_() : stack.m_41620_(1);
                        ModBlocks.NAVIGATOR_LECTERN.get().replaceLectern(state, level, pos, lecternStack);
                    }
                    return InteractionResult.SUCCESS;
                }

                if (ModBlocks.NAVIGATOR_LECTERN.has(state))
                    return InteractionResult.PASS;
            }
        }

        return player.m_6144_() ? InteractionResult.FAIL : m_7203_(level, player, context.m_43724_()).m_19089_();
    }

    @Override
    public InteractionResultHolder<ItemStack> m_7203_(Level pLevel, Player pPlayer, InteractionHand pUsedHand) {
        if (pLevel.f_46443_) {
            ClientWrapper.showNavigatorGui();
            return InteractionResultHolder.m_19090_(pPlayer.m_21120_(pUsedHand));
        }        
        return super.m_7203_(pLevel, pPlayer, pUsedHand);
    }

    @Override
    public void renderAdditional(DLGraphics graphics, ItemStack itemStack, ItemDisplayContext context, boolean leftHand, PoseStack poseStack, MultiBufferSource buffer, int combinedLight, int combinedOverlay, BakedModel model) {
        ClientWrapper.renderNavigatorItem(graphics, itemStack, context, leftHand, poseStack, buffer, combinedLight, combinedOverlay, model);
    }
}
