package de.mrjulsen.crn.block.display.properties;

import de.mrjulsen.crn.block.display.properties.components.*;
import de.mrjulsen.crn.block.properties.ETimeDisplay;
import de.mrjulsen.crn.client.gui.widgets.modular.GuiBuilderContext;
import net.minecraft.nbt.CompoundTag;

public class PassengerInformationDetailedSettings extends BasicDisplaySettings implements
    ITimeDisplaySetting,
    IShowTrainStatsSetting,
    IShowExitDirectionSetting,
    ICarriageIndexSetting,
    IShowNextConnections,
    ITrainTextSetting,
    IShowLineColorSetting,
    IShowDoNotBoardText,
    IShowTrainMultipleTimes
{

    protected ETimeDisplay timeDisplay = ETimeDisplay.ABS;
    protected boolean showStats = true;
    protected boolean showExit = true;
    protected boolean showConnections = true;
    protected byte carriageIndexOffset = 0;
    protected boolean overwriteCarriageIndex = false;
    protected ETrainTextComponents trainTextComponents = ETrainTextComponents.TRAIN_NAME;
    protected boolean showLineColor = false;
    protected boolean showDoNotBoardText = true;
    protected boolean showTrainMultipleTimes = true;

    @Override
    public void deserializeNbt(CompoundTag nbt) {
        super.deserializeNbt(nbt);
        if (nbt.m_128441_(NBT_TIME_DISPLAY)) this.timeDisplay = ETimeDisplay.getById(nbt.m_128445_(NBT_TIME_DISPLAY));
        if (nbt.m_128441_(NBT_SHOW_STATS)) this.showStats = nbt.m_128471_(NBT_SHOW_STATS);
        if (nbt.m_128441_(NBT_SHOW_EXIT)) this.showExit = nbt.m_128471_(NBT_SHOW_EXIT);
        if (nbt.m_128441_(NBT_SHOW_CONNECTIONS)) this.showConnections = nbt.m_128471_(NBT_SHOW_CONNECTIONS);
        if (nbt.m_128441_(NBT_CARRIAGE_INDEX)) this.carriageIndexOffset = nbt.m_128445_(NBT_CARRIAGE_INDEX);
        if (nbt.m_128441_(NBT_OVERWRITE_CARRIAGE_INDEX)) this.overwriteCarriageIndex = nbt.m_128471_(NBT_OVERWRITE_CARRIAGE_INDEX);
        if (nbt.m_128441_(NBT_TRAIN_TEXT)) this.trainTextComponents = ETrainTextComponents.getById(nbt.m_128445_(NBT_TRAIN_TEXT));
        if (nbt.m_128441_(NBT_SHOW_LINE_COLOR)) this.showLineColor = nbt.m_128471_(NBT_SHOW_LINE_COLOR);
        if (nbt.m_128441_(NBT_SHOW_DO_NOT_BOARD_TEXT)) this.showDoNotBoardText = nbt.m_128471_(NBT_SHOW_DO_NOT_BOARD_TEXT);
        if (nbt.m_128441_(NBT_SHOW_TRAIN_MULTIPLE_TIMES)) this.showDoNotBoardText = nbt.m_128471_(NBT_SHOW_TRAIN_MULTIPLE_TIMES);

    }

    @Override
    public void serializeNbt(CompoundTag nbt) {
        super.serializeNbt(nbt);
        nbt.m_128344_(NBT_TIME_DISPLAY, timeDisplay.getId());
        nbt.m_128379_(NBT_SHOW_STATS, showStats);
        nbt.m_128379_(NBT_SHOW_EXIT, showExit);
        nbt.m_128379_(NBT_SHOW_CONNECTIONS, showConnections);
        nbt.m_128344_(NBT_CARRIAGE_INDEX, carriageIndexOffset);
        nbt.m_128379_(NBT_OVERWRITE_CARRIAGE_INDEX, overwriteCarriageIndex);
        nbt.m_128344_(NBT_TRAIN_TEXT, trainTextComponents.getId());
        nbt.m_128379_(NBT_SHOW_LINE_COLOR, showLineColor);
        nbt.m_128379_(NBT_SHOW_DO_NOT_BOARD_TEXT, showDoNotBoardText);
        nbt.m_128379_(NBT_SHOW_TRAIN_MULTIPLE_TIMES, showTrainMultipleTimes);
    }

    @Override
    public void buildGui(GuiBuilderContext context) {
        super.buildGui(context);
        this.buildTimeDisplayGui(context);
        this.buildShowStatsGui(context);
        this.buildShowExitGui(context);
        this.buildShowConnectionGui(context);
        this.buildShowLineColorGui(context);
        this.buildShowDoNotBoardTextGui(context);
        this.buildShowTrainMultipleTimesGui(context);
        this.buildCarriageIndexGui(context);
        this.buildTrainTextGui(context);
    }

    @Override
    public void onChangeSettings(IDisplaySettings oldSettings) {
        super.onChangeSettings(oldSettings);
        copyTimeDisplaySetting(oldSettings);
        copyShowExitSetting(oldSettings);
        copyShowStatsSetting(oldSettings);
        copyShowConnectionSetting(oldSettings);
        copyCarriageIndexSetting(oldSettings);
        copyTrainTextSetting(oldSettings);
        copyShowLineColorSetting(oldSettings);
        copyShowDoNotBoardTextSetting(oldSettings);
        copyShowTrainMultipleTimesSetting(oldSettings);
    }

    @Override
    public boolean showStats() {
        return showStats;
    }

    @Override
    public void setShowStats(boolean b) {
        this.showStats = b;
    }

    @Override
    public boolean showExit() {
        return showExit;
    }

    @Override
    public void setShowExit(boolean b) {
        this.showExit = b;
    }

    @Override
    public boolean showConnections() {
        return showConnections;
    }

    @Override
    public void setShowConnection(boolean b) {
        this.showConnections = b;
    }

    @Override
    public boolean showTrainMultipleTimes() {
        return showTrainMultipleTimes;
    }

    @Override
    public void setShowTrainMultipleTimes(boolean b) {
        this.showTrainMultipleTimes = b;
    }

    @Override
    public byte getCarriageIndex() {
        return carriageIndexOffset;
    }

    @Override
    public boolean shouldOverwriteCarriageIndex() {
        return overwriteCarriageIndex;
    }

    @Override
    public boolean showLineColor() {
        return showLineColor;
    }

    @Override
    public void setShowLineColor(boolean b) {
        this.showLineColor = b;
    }

    @Override
    public void setCarriageIndex(byte b) {
        this.carriageIndexOffset = b;
    }

    @Override
    public void setOverwriteCarriageIndex(boolean b) {
        this.overwriteCarriageIndex = b;
    }

    @Override
    public ETimeDisplay getTimeDisplay() {
        return timeDisplay;
    }

    @Override
    public void setTimeDisplay(ETimeDisplay display) {
        this.timeDisplay = display;
    }

    @Override
    public ETrainTextComponents getTrainTextComponents() {
        return trainTextComponents;
    }

    @Override
    public void setTrainTextComponents(ETrainTextComponents v) {
        this.trainTextComponents = v;
    }

    @Override
    public boolean showDoNotBoardText() {
        return showDoNotBoardText;
    }

    @Override
    public void setShowDoNotBoardText(boolean b) {
        this.showDoNotBoardText = b;
    }
}
