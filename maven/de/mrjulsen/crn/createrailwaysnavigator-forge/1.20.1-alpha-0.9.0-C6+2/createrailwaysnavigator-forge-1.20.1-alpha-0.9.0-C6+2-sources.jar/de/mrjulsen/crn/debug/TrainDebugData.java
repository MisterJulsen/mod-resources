package de.mrjulsen.crn.debug;

import java.util.List;
import java.util.UUID;

import de.mrjulsen.crn.data.train.TrainData;
import de.mrjulsen.mcdragonlib.util.NbtUtils;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;

public record TrainDebugData(
    UUID sessionId,
    UUID trainId,
    String trainName,
    int totalDuration,
    int predictionsCount,
    int predictionsInitialized,
    TrainDebugState state,
    BlockPos pos,
    ResourceLocation dimension
) {

    private static final String NBT_SESSION_ID = "SessionId";
    private static final String NBT_ID = "Id";
    private static final String NBT_NAME = "Name";
    private static final String NBT_DURATION = "Duration";
    private static final String NBT_PREDICTIONS = "Predictions";
    private static final String NBT_INITIALIZED_PREDICTIONS = "InitializedPredictions";
    private static final String NBT_STATE = "State";
    private static final String NBT_POSITION = "Position";
    private static final String NBT_DIMENSION = "Dimension";

    public CompoundTag toNbt() {
        CompoundTag nbt = new CompoundTag();
        nbt.m_128362_(NBT_SESSION_ID, sessionId);
        nbt.m_128362_(NBT_ID, trainId);
        nbt.m_128359_(NBT_NAME, trainName);
        nbt.m_128405_(NBT_DURATION, totalDuration);
        nbt.m_128405_(NBT_PREDICTIONS, predictionsCount);
        nbt.m_128405_(NBT_INITIALIZED_PREDICTIONS, predictionsInitialized);
        nbt.m_128344_(NBT_STATE, state.getId());
        NbtUtils.putNbtPos(nbt, NBT_POSITION, pos);
        nbt.m_128359_(NBT_DIMENSION, dimension.toString());
        return nbt;
    } 

    public static TrainDebugData fromNbt(CompoundTag nbt) {
        return new TrainDebugData(
                nbt.m_128342_(NBT_SESSION_ID),
                nbt.m_128342_(NBT_ID),
                nbt.m_128461_(NBT_NAME),
                nbt.m_128451_(NBT_DURATION),
                nbt.m_128451_(NBT_PREDICTIONS),
                nbt.m_128451_(NBT_INITIALIZED_PREDICTIONS),
                TrainDebugState.getStateById(nbt.m_128445_(NBT_STATE)),
                NbtUtils.getNbtBlockPos(nbt, NBT_POSITION),
                ResourceLocation.m_135820_(nbt.m_128461_(NBT_DIMENSION))
        );
    }

    public static TrainDebugData fromTrain(TrainData train) {
        BlockPos pos = BlockPos.f_121853_;
        ResourceLocation dimension = ResourceLocation.m_214293_("unknown", "unknown");
        if (train.getTrain() != null) {
            List<ResourceKey<Level>> dimensions = train.getTrain().getPresentDimensions();
            if (!dimensions.isEmpty()) {
                dimension = dimensions.get(0).m_135782_();
                pos = train.getTrain().getPositionInDimension(dimensions.get(0)).orElse(BlockPos.f_121853_);
            }
        }
        return new TrainDebugData(
                train.getSessionId(),
                train.getTrainId(),
                train.getTrainName(),
                train.getTotalDuration(),
                train.getPredictionsMap().size(),
                train.debug_initializedStationsCount(),
                train.isPreInitializationPhase() ? TrainDebugState.PREPARING : (train.isInitialized() ? TrainDebugState.READY : TrainDebugState.INITIALIZING),
                pos,
                dimension
        );
    }
}
