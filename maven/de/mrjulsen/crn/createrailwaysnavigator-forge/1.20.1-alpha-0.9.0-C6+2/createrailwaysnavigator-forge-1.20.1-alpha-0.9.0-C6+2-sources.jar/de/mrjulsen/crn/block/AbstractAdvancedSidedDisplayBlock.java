package de.mrjulsen.crn.block;

import de.mrjulsen.crn.block.properties.ESide;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition.Builder;
import net.minecraft.world.level.block.state.properties.EnumProperty;

public abstract class AbstractAdvancedSidedDisplayBlock extends AbstractAdvancedDisplayBlock {

    public static final EnumProperty<ESide> SIDE = EnumProperty.m_61587_("side", ESide.class);

    public AbstractAdvancedSidedDisplayBlock(Properties properties) {
        super(properties);

        this.m_49959_(this.f_49792_.m_61090_()
            .m_61124_(SIDE, ESide.FRONT)
        );
    }
    
    @Override
    protected void m_7926_(Builder<Block, BlockState> pBuilder) {
        super.m_7926_(pBuilder);
        pBuilder.m_61104_(SIDE);
    }

    @Override
	public BlockState m_5573_(BlockPlaceContext context) {
		Direction face = context.m_43719_();
		BlockPos clickedPos = context.m_8083_();
		BlockPos placedOnPos = clickedPos.m_121945_(face.m_122424_());
		Level level = context.m_43725_();
		BlockState otherState = level.m_8055_(placedOnPos);
		BlockState stateForPlacement = this.m_49966_().m_61124_(FACING, context.m_8125_().m_122424_());

		if ((otherState.m_60734_() != this) || (context.m_43723_() != null && context.m_43723_().m_6144_())) {
			stateForPlacement = getDefaultPlacementState(context, stateForPlacement, otherState);
			stateForPlacement = getPropertyFromNeighbours(stateForPlacement, level, clickedPos, SIDE);
		} else { // Clicked on existing block
			stateForPlacement = appendOnPlace(context, stateForPlacement, otherState);
		}

		return updateColumn(level, clickedPos, stateForPlacement, true);
	}

	public BlockState appendOnPlace(BlockPlaceContext context, BlockState state, BlockState other) {
		state = super.appendOnPlace(context, state, other)		
			.m_61124_(SIDE, other.m_61143_(SIDE))
		;
		return state;
	}
}
