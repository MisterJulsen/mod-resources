package de.mrjulsen.crn.data.schedule.instruction;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import com.simibubi.create.content.trains.graph.DiscoveredPath;
import com.simibubi.create.content.trains.schedule.ScheduleRuntime;
import com.simibubi.create.content.trains.schedule.destination.ScheduleInstruction;
import com.simibubi.create.foundation.gui.ModularGuiLineBuilder;

import de.mrjulsen.crn.Constants;
import de.mrjulsen.crn.CreateRailwaysNavigator;
import de.mrjulsen.crn.client.ClientWrapper;
import de.mrjulsen.crn.data.settings.TrainCategory;
import de.mrjulsen.crn.data.settings.TrainLine;
import de.mrjulsen.crn.network.packets.GetTrainCategoryPacketData;
import de.mrjulsen.crn.network.packets.GetTrainLinePacketData;
import de.mrjulsen.crn.registry.ModBlocks;
import de.mrjulsen.crn.registry.ModNetworkManager;
import de.mrjulsen.mcdragonlib.network.NetworkDirection;
import de.mrjulsen.mcdragonlib.util.TextUtils;
import net.createmod.catnip.data.Pair;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class TravelSectionInstruction extends ScheduleInstruction {

    @Deprecated
    public static final String LEGACY_NBT_TRAIN_CATEGORY = "TrainGroup";

    public static final String NBT_TRAIN_CATEGORY = "TrainCategory";
    public static final String NBT_TRAIN_LINE = "TrainLine";
    public static final String NBT_INCLUDE_PREVIOUS_STATION = "IncludePreviousStation";
    public static final String NBT_USABLE = "Usable";

    private final MutableComponent txtNone = TextUtils.translate("gui." + CreateRailwaysNavigator.MOD_ID + ".section_settings.none").m_130940_(ChatFormatting.GRAY);
    private final MutableComponent txtLoading = TextUtils.empty().m_7220_(Constants.TEXT_LOADING).m_130940_(ChatFormatting.GRAY).m_130940_(ChatFormatting.ITALIC);

    private UUID lastCategoryId = null;
    private UUID lastLineId = null;
    private TrainCategory category;
    private TrainLine line;

    public TravelSectionInstruction() {
    }

    @Override
    protected void readAdditional(CompoundTag tag) {
        super.readAdditional(tag);
        if (!tag.m_128441_(NBT_INCLUDE_PREVIOUS_STATION)) tag.m_128379_(NBT_INCLUDE_PREVIOUS_STATION, false);
        if (!tag.m_128441_(NBT_USABLE)) tag.m_128379_(NBT_USABLE, true);
    }

    @Override
    public Pair<ItemStack, Component> getSummary() {
        return Pair.of(new ItemStack(ModBlocks.ADVANCED_DISPLAY.get()), TextUtils.translate(CreateRailwaysNavigator.MOD_ID + ".schedule.instruction." + getId().m_135815_()).m_130940_(ChatFormatting.AQUA));
    }

    @Override
    public ResourceLocation getId() {
        return new ResourceLocation(CreateRailwaysNavigator.MOD_ID, "travel_section");
    }

    @Override
    public boolean supportsConditions() {
        return false;
    }

    @Override
    public DiscoveredPath start(ScheduleRuntime runtime, Level level) {
        runtime.state = ScheduleRuntime.State.PRE_TRANSIT;
        runtime.currentEntry++;
        return null;
    }

    private void requestCategory(UUID categoryId) {
        this.lastCategoryId = null;
        this.category = null;
        if (categoryId == null) return;

        ModNetworkManager.GET_TRAIN_CATEGORY.send(NetworkDirection.toServer(), new GetTrainCategoryPacketData.Request(categoryId), (response) -> {
            this.lastCategoryId = categoryId;
            this.category = response.getCategory().orElse(null);
        }, () -> {});
    }

    private void requestLine(UUID lineId) {
        this.lastLineId = null;
        this.line = null;
        if (lineId == null) return;

        ModNetworkManager.GET_TRAIN_LINE.send(NetworkDirection.toServer(), new GetTrainLinePacketData.Request(lineId), (response) -> {
            this.lastLineId = lineId;
            this.line = response.getLine().orElse(null);
        }, () -> {});
    }

    @Override
	public List<Component> getTitleAs(String type) {

        UUID categoryId = null;
        UUID lineId = null;

        if (data.m_128441_(LEGACY_NBT_TRAIN_CATEGORY)) {
            if (data.m_128435_(LEGACY_NBT_TRAIN_CATEGORY) == Tag.f_178201_) {
                categoryId = TrainCategory.genMD5Uuid(data.m_128461_(LEGACY_NBT_TRAIN_CATEGORY));
            } else {
                categoryId = data.m_128342_(LEGACY_NBT_TRAIN_CATEGORY);
            }
        } else if (data.m_128441_(NBT_TRAIN_CATEGORY)) {
            categoryId = data.m_128342_(NBT_TRAIN_CATEGORY);
        }
        if (data.m_128441_(NBT_TRAIN_LINE)) {
            if (data.m_128435_(NBT_TRAIN_LINE) == Tag.f_178201_) {
                lineId = TrainLine.genMD5Uuid(data.m_128461_(NBT_TRAIN_LINE));
            } else {
                lineId = data.m_128342_(NBT_TRAIN_LINE);
            }
        }
        if (lastCategoryId == null || categoryId == null || !lastCategoryId.equals(categoryId)) {
            requestCategory(categoryId);
        }
        if (lastLineId == null || lineId == null || !lastLineId.equals(lineId)) {
            requestLine(lineId);
        }

		List<Component> lines = new ArrayList<>();
        lines.add(TextUtils.translate(CreateRailwaysNavigator.MOD_ID + ".schedule." + type + "." + getId().m_135815_()).m_130940_(ChatFormatting.GOLD));
        lines.add(TextUtils.translate(CreateRailwaysNavigator.MOD_ID + ".schedule." + type + "." + getId().m_135815_() + ".description").m_130940_(ChatFormatting.GRAY));

        lines.add(
            TextUtils.translate(CreateRailwaysNavigator.MOD_ID + ".schedule." + type + "." + getId().m_135815_() + ".train_category").m_130940_(ChatFormatting.DARK_AQUA)
                .m_7220_(lastCategoryId == null && category != null ? txtLoading : (category == null ? txtNone : TextUtils.text(category.getCategoryName()).m_130940_(ChatFormatting.WHITE))));
        lines.add(
            TextUtils.translate(CreateRailwaysNavigator.MOD_ID + ".schedule." + type + "." + getId().m_135815_() + ".train_line").m_130940_(ChatFormatting.DARK_AQUA)
                .m_7220_(lastLineId == null && line != null ? txtLoading : (line == null ? txtNone : TextUtils.text(line.getLineName()).m_130940_(ChatFormatting.WHITE))));
        if (data.m_128441_(NBT_INCLUDE_PREVIOUS_STATION)) lines.add(TextUtils.translate(CreateRailwaysNavigator.MOD_ID + ".schedule." + type + "." + getId().m_135815_() + ".include_previous_station").m_130940_(ChatFormatting.DARK_AQUA).m_7220_((data.m_128471_(NBT_INCLUDE_PREVIOUS_STATION) ? CommonComponents.f_130657_ : CommonComponents.f_130658_)));
        if (data.m_128441_(NBT_USABLE)) lines.add(TextUtils.translate(CreateRailwaysNavigator.MOD_ID + ".schedule." + type + "." + getId().m_135815_() + ".usable").m_130940_(ChatFormatting.DARK_AQUA).m_7220_((data.m_128471_(NBT_USABLE) ? CommonComponents.f_130657_ : CommonComponents.f_130658_)));
        return lines;
	}

	@Override
	public void initConfigurationWidgets(ModularGuiLineBuilder builder) {
        ClientWrapper.initScheduleSectionInstruction(this, builder);
	}

    public UUID getTrainCategoryId() {
        String categoryNbtKey = this.data.m_128441_(LEGACY_NBT_TRAIN_CATEGORY) ? LEGACY_NBT_TRAIN_CATEGORY : NBT_TRAIN_CATEGORY;
        if (!this.data.m_128441_(categoryNbtKey)) {
            return null;
        }
        if (this.data.m_128435_(categoryNbtKey) == Tag.f_178201_) {
            return TrainCategory.genMD5Uuid(this.data.m_128461_(categoryNbtKey));
        }
        if (this.data.m_128435_(categoryNbtKey) == Tag.f_178204_) {
            return this.data.m_128342_(categoryNbtKey);
        }
        return null;
    }

    public UUID getTrainLineId() {
        if (!this.data.m_128441_(NBT_TRAIN_LINE)) {
            return null;
        }
        if (this.data.m_128435_(NBT_TRAIN_LINE) == Tag.f_178201_) {
            return TrainLine.genMD5Uuid(this.data.m_128461_(NBT_TRAIN_LINE));
        }
        if (this.data.m_128435_(NBT_TRAIN_LINE) == Tag.f_178204_) {
            return this.data.m_128342_(NBT_TRAIN_LINE);
        }
        return null;
    }

    public boolean shouldIncludePreviousStationStop() {
        return this.data.m_128471_(NBT_INCLUDE_PREVIOUS_STATION);
    }

    public boolean isSectionUsable() {
        return !this.data.m_128441_(NBT_USABLE) || this.data.m_128471_(NBT_USABLE);
    }

}