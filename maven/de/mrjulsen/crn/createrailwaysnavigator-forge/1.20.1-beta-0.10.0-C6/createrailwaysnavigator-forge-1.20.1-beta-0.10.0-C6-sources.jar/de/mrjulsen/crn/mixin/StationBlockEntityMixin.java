package de.mrjulsen.crn.mixin;

import java.util.List;
import java.util.Map;
import com.simibubi.create.api.equipment.goggles.IHaveGoggleInformation;
import com.simibubi.create.foundation.utility.CreateLang;
import org.spongepowered.asm.mixin.Mixin;

import com.simibubi.create.content.trains.station.StationBlockEntity;

import de.mrjulsen.crn.CRNPlatformSpecific;
import de.mrjulsen.crn.CreateRailwaysNavigator;
import de.mrjulsen.crn.core.history.DepartureStats;
import de.mrjulsen.crn.network.packets.GetStationDepartureHistoryPacketData;
import de.mrjulsen.crn.registry.ModNetworkManager;
import de.mrjulsen.mcdragonlib.network.NetworkDirection;
import de.mrjulsen.mcdragonlib.util.TextUtils;
import de.mrjulsen.mcdragonlib.util.time.DLTime;
import de.mrjulsen.mcdragonlib.util.time.TimeContext;
import de.mrjulsen.mcdragonlib.util.time.VanillaTimeSystem;
import de.mrjulsen.mcdragonlib.util.time.format.TimeFormatDigitalDuration;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

@Mixin(StationBlockEntity.class)
public class StationBlockEntityMixin implements IHaveGoggleInformation {

    private static final int MAX_ENTRIES = 5;

    private StationBlockEntity self() {
        return (StationBlockEntity)(Object)this;
    }

    private DepartureStats stats;

    @Override
    public boolean addToGoggleTooltip(List<Component> tooltip, boolean isPlayerSneaking) {
        if (CRNPlatformSpecific.getStationFromBlockEntity(self()) == null) {
            return false;
        }

        if (Minecraft.m_91087_().f_91073_.m_46467_() % 100 == 0) {
            ModNetworkManager.GET_STATIONDEPARTURE_HISTORY.send(NetworkDirection.toServer(), new GetStationDepartureHistoryPacketData.Request(CRNPlatformSpecific.getStationFromBlockEntity(self()).name), (response) -> {
                this.stats = response.getHistory();
            }, () -> {});
        }
        
        CreateLang.builder(CreateRailwaysNavigator.MOD_ID)
            .add(TextUtils.translate("goggles." + CreateRailwaysNavigator.MOD_ID + ".train_listener.departures.title"))
            .forGoggles(tooltip);

        

        if (this.stats == null || this.stats.isEmpty()) {
            CreateLang.builder(CreateRailwaysNavigator.MOD_ID)
                .add(TextUtils.translate("goggles." + CreateRailwaysNavigator.MOD_ID + ".train_listener.departures.nothing").m_130940_(ChatFormatting.RED))
                .forGoggles(tooltip);
            return false;
        }

        CreateLang.builder(CreateRailwaysNavigator.MOD_ID)
            .add(TextUtils.translate("goggles." + CreateRailwaysNavigator.MOD_ID + ".train_listener.departures.any").m_130940_(ChatFormatting.GRAY))
            .forGoggles(tooltip);
        CreateLang.builder(CreateRailwaysNavigator.MOD_ID)
            .add(formatTime(Minecraft.m_91087_().f_91073_.m_46467_() - stats.lastDeparture()))
            .forGoggles(tooltip, 1);
          
        if (!stats.departuresByCategory().isEmpty()) {
            CreateLang.builder(CreateRailwaysNavigator.MOD_ID)
                .add(TextUtils.translate("goggles." + CreateRailwaysNavigator.MOD_ID + ".train_listener.departures.category").m_130940_(ChatFormatting.GRAY))
                .forGoggles(tooltip);
                             
            Map<String, Long> data = stats.departuresByCategory();
            int i = 0;
            for (Map.Entry<String, Long> d : data.entrySet()) {
                CreateLang.builder(CreateRailwaysNavigator.MOD_ID)
                    .add(TextUtils.empty().m_7220_(TextUtils.text(d.getKey() + ": ").m_130940_(ChatFormatting.DARK_AQUA)).m_7220_(formatTime(Minecraft.m_91087_().f_91073_.m_46467_() - d.getValue())))
                    .forGoggles(tooltip, 1);

                i++;
                if (i >= MAX_ENTRIES) {
                    break;
                }
            }
            if (data.size() > MAX_ENTRIES) {
                CreateLang.builder(CreateRailwaysNavigator.MOD_ID)
                    .add(TextUtils.translate("goggles." + CreateRailwaysNavigator.MOD_ID + ".train_listener.departures.has_more", data.size() - MAX_ENTRIES).m_130940_(ChatFormatting.GRAY))
                    .forGoggles(tooltip);
            }
        }
        
        if (!stats.departuresByLine().isEmpty()) {
            CreateLang.builder(CreateRailwaysNavigator.MOD_ID)
                .add(TextUtils.translate("goggles." + CreateRailwaysNavigator.MOD_ID + ".train_listener.departures.line").m_130940_(ChatFormatting.GRAY))
                .forGoggles(tooltip);   
                             
            Map<String, Long> data = stats.departuresByLine();
            int i = 0;
            for (Map.Entry<String, Long> d : data.entrySet()) {
                CreateLang.builder(CreateRailwaysNavigator.MOD_ID)
                    .add(TextUtils.empty().m_7220_(TextUtils.text(d.getKey() + ": ").m_130940_(ChatFormatting.DARK_AQUA)).m_7220_(formatTime(Minecraft.m_91087_().f_91073_.m_46467_() - d.getValue())))
                    .forGoggles(tooltip, 1);

                i++;
                if (i >= MAX_ENTRIES) {
                    break;
                }
            }
            if (data.size() > MAX_ENTRIES) {
                CreateLang.builder(CreateRailwaysNavigator.MOD_ID)
                    .add(TextUtils.translate("goggles." + CreateRailwaysNavigator.MOD_ID + ".train_listener.departures.has_more", data.size() - MAX_ENTRIES).m_130940_(ChatFormatting.GRAY))
                    .forGoggles(tooltip);
            }
        }
        
        if (!stats.departuresByName().isEmpty()) {
            CreateLang.builder(CreateRailwaysNavigator.MOD_ID)
                .add(TextUtils.translate("goggles." + CreateRailwaysNavigator.MOD_ID + ".train_listener.departures.name").m_130940_(ChatFormatting.GRAY))
                .forGoggles(tooltip);   
                             
            Map<String, Long> data = stats.departuresByName();
            int i = 0;
            for (Map.Entry<String, Long> d : data.entrySet()) {
                CreateLang.builder(CreateRailwaysNavigator.MOD_ID)
                    .add(TextUtils.empty().m_7220_(TextUtils.text(d.getKey() + ": ").m_130940_(ChatFormatting.DARK_AQUA)).m_7220_(formatTime(Minecraft.m_91087_().f_91073_.m_46467_() - d.getValue())))
                    .forGoggles(tooltip, 1);

                i++;
                if (i >= MAX_ENTRIES) {
                    break;
                }
            }
            if (data.size() > MAX_ENTRIES) {
                CreateLang.builder(CreateRailwaysNavigator.MOD_ID)
                    .add(TextUtils.translate("goggles." + CreateRailwaysNavigator.MOD_ID + ".train_listener.departures.has_more", data.size() - MAX_ENTRIES).m_130940_(ChatFormatting.GRAY))
                    .forGoggles(tooltip);
            }
        }


        CreateLang.builder(CreateRailwaysNavigator.MOD_ID)
            .add(TextUtils.text(" "))
            .forGoggles(tooltip);

        CreateLang.builder(CreateRailwaysNavigator.MOD_ID)
            .add(TextUtils.translate("goggles." + CreateRailwaysNavigator.MOD_ID + ".train_listener.departures.press_shift_for_in_game_time").m_130940_(ChatFormatting.DARK_GRAY).m_130940_(ChatFormatting.ITALIC))
            .forGoggles(tooltip);

        return true;
    }

    private MutableComponent formatTime(long ticks) {
        DLTime time = new DLTime(ticks, VanillaTimeSystem.INSTANCE);
        return TextUtils.text(Minecraft.m_91087_().f_91074_.m_6144_()
                ? time.format(TimeFormatDigitalDuration.DEFAULT_GAME_INSTANCE, TimeContext.INGAME, VanillaTimeSystem.INSTANCE)
                : time.format(TimeFormatDigitalDuration.DEFAULT_REAL_INSTANCE, TimeContext.REAL, VanillaTimeSystem.INSTANCE)
        ).m_130940_(ChatFormatting.AQUA);
    }
}
