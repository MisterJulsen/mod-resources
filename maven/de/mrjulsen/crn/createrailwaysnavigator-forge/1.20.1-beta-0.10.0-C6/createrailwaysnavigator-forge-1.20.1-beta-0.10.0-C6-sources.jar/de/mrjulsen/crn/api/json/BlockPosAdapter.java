package de.mrjulsen.crn.api.json;

import java.lang.reflect.Type;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;

import net.minecraft.core.BlockPos;

final class BlockPosAdapter implements JsonSerializer<BlockPos>, JsonDeserializer<BlockPos> {

    @Override
    public JsonElement serialize(BlockPos value, Type type, JsonSerializationContext context) {
        JsonObject json = new JsonObject();
        json.addProperty("x", value.m_123341_());
        json.addProperty("y", value.m_123342_());
        json.addProperty("z", value.m_123343_());
        return json;
    }

    @Override
    public BlockPos deserialize(JsonElement element, Type type, JsonDeserializationContext context) {
        JsonObject json = element.getAsJsonObject();
        return new BlockPos(json.get("x").getAsInt(), json.get("y").getAsInt(), json.get("z").getAsInt());
    }
}
