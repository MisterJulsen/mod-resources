package de.mrjulsen.crn.config;

import de.mrjulsen.crn.CreateRailwaysNavigator;
import de.mrjulsen.crn.client.gui.overlay.OverlayPosition;
import de.mrjulsen.crn.client.lang.CustomLanguage;
import de.mrjulsen.crn.util.ESpeedUnit;
import de.mrjulsen.crn.util.ETimeFormat;
import net.minecraftforge.common.ForgeConfigSpec;

public class ModClientConfig {
    public static final ForgeConfigSpec.Builder BUILDER = new ForgeConfigSpec.Builder();
    public static final ForgeConfigSpec SPEC;

    public static final ForgeConfigSpec.ConfigValue<Integer> DISPLAY_REFRESH_RATE;
    public static final ForgeConfigSpec.ConfigValue<Double> OVERLAY_SCALE;
    public static final ForgeConfigSpec.ConfigValue<Boolean> ROUTE_NOTIFICATIONS;
    public static final ForgeConfigSpec.ConfigValue<OverlayPosition> ROUTE_OVERLAY_POSITION;
    public static final ForgeConfigSpec.ConfigValue<ETimeFormat> TIME_FORMAT;
    public static final ForgeConfigSpec.ConfigValue<Boolean> REALTIME_DURATIONS;
    public static final ForgeConfigSpec.ConfigValue<String> LANGUAGE;
    public static final ForgeConfigSpec.ConfigValue<ESpeedUnit> SPEED_UNIT;

    public static final double MIN_SCALE = 0.25f;
    public static final double MAX_SCALE = 2.0f;

    static {
        BUILDER.push(CreateRailwaysNavigator.MOD_ID + "_client_config");

        DISPLAY_REFRESH_RATE = BUILDER.comment("[in Ticks]", "The interval in which the displays are updated with new information. Lower values can decrease performance and increase the network traffic, while larger values reduce the reaction speed of the displays. (Default: 50, Recommended: 50 - 100)")
            .defineInRange("general.display_refresh_rate", 50, 20, 200);

        OVERLAY_SCALE = BUILDER.comment("Scale of the route overlay UI. (Default: 0.75)")
            .defineInRange("route_overlay.scale", 0.75f, MIN_SCALE, MAX_SCALE);
        ROUTE_NOTIFICATIONS = BUILDER.comment("If active, you will receive short toasts about important events on your trip, e.g. delays, changes, ... (Default: ON)")
            .define("route_overlay.notifications", true);
        ROUTE_OVERLAY_POSITION = BUILDER.comment("The position on your screen where you want the overlay to appear. (Default: Top Left)")
            .defineEnum("route_overlay.position", OverlayPosition.TOP_LEFT);

        LANGUAGE = BUILDER.comment("The local code of the language that should be used for train specific UIs (example: en_us, de_de). Can be different from the game's language settings. (Default: <empty>)")
            .define("language", "");
        SPEED_UNIT = BUILDER.comment("The unit to be used to represent speed. (Default: KMH)")
            .defineEnum("speed_unit", ESpeedUnit.KMH);
        TIME_FORMAT = BUILDER.comment("Display Time Format. (Default: Hours 24)")
            .defineEnum("time_format", ETimeFormat.HOURS_24);
        REALTIME_DURATIONS = BUILDER.comment("Whether countdowns or durations in the UI (e.g. time until departure or transfer time) are shown as real time duration or in-game duration. OFF = in-game, ON = real life (Default: OFF)")
            .define("general.realtime_durations", false);

        BUILDER.pop();
        SPEC = BUILDER.build();
    }

    public static void resetSearchSettings() {
    }
}
