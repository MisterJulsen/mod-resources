package de.mrjulsen.crn.network.packets;

import java.util.Optional;
import java.util.UUID;

import de.mrjulsen.crn.api.core.snapshot.JourneySnapshot;
import de.mrjulsen.crn.api.core.RailwayBackendApi;
import de.mrjulsen.crn.api.core.snapshot.TrainSnapshot;
import de.mrjulsen.mcdragonlib.data.DLStatus;
import de.mrjulsen.mcdragonlib.network.NetworkPacketContext;
import de.mrjulsen.mcdragonlib.network.NetworkPacketData;
import net.minecraft.nbt.CompoundTag;

public class GetTrainRealtimePacketData {

    private static final String NBT_TRAIN_ID = "TrainId";
    private static final String NBT_INCLUDE_JOURNEY = "IncludeJourney";
    private static final String NBT_TRAIN = "Train";
    private static final String NBT_JOURNEY = "Journey";

    public static class Request extends NetworkPacketData {

        private UUID trainId;
        private boolean includeJourney;

        public Request(DLStatus status) {
            super(status);
        }

        public Request(UUID trainId, boolean includeJourney) {
            super(DLStatus.OK);
            this.trainId = trainId;
            this.includeJourney = includeJourney;
        }

        @Override
        protected void write(CompoundTag nbt) {
            nbt.m_128362_(NBT_TRAIN_ID, trainId);
            nbt.m_128379_(NBT_INCLUDE_JOURNEY, includeJourney);
        }

        @Override
        protected void read(CompoundTag nbt) {
            this.trainId = nbt.m_128342_(NBT_TRAIN_ID);
            this.includeJourney = nbt.m_128471_(NBT_INCLUDE_JOURNEY);
        }
    }

    public static class Response extends NetworkPacketData {

        private Optional<TrainSnapshot> train = Optional.empty();
        private Optional<JourneySnapshot> journey = Optional.empty();

        public Response(DLStatus status) {
            super(status);
        }

        public Response(Optional<TrainSnapshot> train, Optional<JourneySnapshot> journey) {
            super(DLStatus.OK);
            this.train = train;
            this.journey = journey;
        }

        @Override
        protected void write(CompoundTag nbt) {
            train.ifPresent(x -> nbt.m_128365_(NBT_TRAIN, x.toNbt()));
            journey.ifPresent(x -> nbt.m_128365_(NBT_JOURNEY, x.toNbt()));
        }

        @Override
        protected void read(CompoundTag nbt) {
            this.train = nbt.m_128441_(NBT_TRAIN) ? Optional.of(TrainSnapshot.fromNbt(nbt.m_128469_(NBT_TRAIN))) : Optional.empty();
            this.journey = nbt.m_128441_(NBT_JOURNEY) ? Optional.of(JourneySnapshot.fromNbt(nbt.m_128469_(NBT_JOURNEY))) : Optional.empty();
        }

        public Optional<TrainSnapshot> getTrain() {
            return train;
        }

        public Optional<JourneySnapshot> getJourney() {
            return journey;
        }
    }

    public static Response handle(Request packet, NetworkPacketContext context) {
        return new Response(
            RailwayBackendApi.getTrain(packet.trainId),
            packet.includeJourney ? RailwayBackendApi.getJourney(packet.trainId) : Optional.empty()
        );
    }
}
