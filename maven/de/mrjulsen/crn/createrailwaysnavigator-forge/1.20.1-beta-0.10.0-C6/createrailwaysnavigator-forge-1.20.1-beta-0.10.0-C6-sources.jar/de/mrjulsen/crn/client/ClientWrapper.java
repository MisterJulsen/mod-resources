package de.mrjulsen.crn.client;

import com.simibubi.create.foundation.utility.CreateLang;
import de.mrjulsen.crn.client.gui.windows.*;
import net.createmod.catnip.data.Pair;
import net.minecraft.Util;
import net.minecraft.client.gui.screens.ConfirmLinkScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.SectionPos;
import org.joml.Vector3f;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.simibubi.create.content.contraptions.AbstractContraptionEntity;
import com.simibubi.create.content.trains.schedule.ScheduleScreen;
import com.simibubi.create.content.trains.schedule.condition.TimedWaitCondition.TimeUnit;
import com.simibubi.create.foundation.gui.ModularGuiLineBuilder;

import de.mrjulsen.crn.Constants;
import de.mrjulsen.crn.CreateRailwaysNavigator;
import de.mrjulsen.crn.api.client.Screens;
import de.mrjulsen.crn.block.blockentity.AdvancedDisplayBlockEntity;
import de.mrjulsen.crn.client.gui.NavigatorToast;
import de.mrjulsen.crn.client.gui.widgets.vanilla.ResizableButton;
import de.mrjulsen.crn.client.lang.CustomLanguage;
import de.mrjulsen.crn.config.ModClientConfig;
import de.mrjulsen.crn.data.schedule.condition.DynamicDelayCondition;
import de.mrjulsen.crn.data.schedule.condition.TrainSeparationCondition;
import de.mrjulsen.crn.data.schedule.instruction.PrioritizedDestinationInstruction;
import de.mrjulsen.crn.data.schedule.instruction.ResetTimingsInstruction;
import de.mrjulsen.crn.data.schedule.instruction.TravelSectionInstruction;
import de.mrjulsen.crn.item.NavigatorItem;
import de.mrjulsen.crn.mixin.ModularGuiLineBuilderAccessor;
import de.mrjulsen.crn.mixin.ScheduleScreenAccessor;
import de.mrjulsen.crn.network.packets.ServerErrorPacketData;
import de.mrjulsen.crn.util.Owner;
import de.mrjulsen.mcdragonlib.client.gui.widgets.base.DLWindow;
import de.mrjulsen.mcdragonlib.client.util.DLGraphics;
import de.mrjulsen.mcdragonlib.client.util.DLGuiGraphics;
import de.mrjulsen.mcdragonlib.client.util.RenderUtils;
import de.mrjulsen.mcdragonlib.data.ETextAlignment;
import de.mrjulsen.mcdragonlib.network.NetworkPacketContext;
import de.mrjulsen.mcdragonlib.util.DLColor;
import de.mrjulsen.mcdragonlib.util.TextUtils;
import de.mrjulsen.mcdragonlib.util.time.DLTime;
import de.mrjulsen.mcdragonlib.util.time.TimeContext;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.components.MultiLineLabel;
import net.minecraft.client.gui.components.toasts.SystemToast;
import net.minecraft.client.gui.components.toasts.SystemToast.SystemToastIds;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.resources.language.LanguageInfo;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.client.resources.model.ModelResourceLocation;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class ClientWrapper {

    public static final ModelResourceLocation NAVIGATOR_WORLD_MODEL = new ModelResourceLocation(CreateRailwaysNavigator.MOD_ID, "navigator_world", "inventory");

    private static CustomLanguage currentLanguage = CustomLanguage.createDefault();

    public static void showNavigatorGui() {
        Screens.showNavigatorScreen(null, false);
    }


    public static void setSectionDirty(SectionPos pos) {
        Minecraft.m_91087_().execute(() -> {
            Minecraft.m_91087_().f_91060_.m_109770_(pos.m_123341_(), pos.m_123342_(), pos.m_123343_());
        });
    }

    public static Level getClientLevel() {
        return Minecraft.m_91087_().f_91073_;
    }

    public static void handleErrorMessagePacket(ServerErrorPacketData packet, NetworkPacketContext ctx) {
        Minecraft.m_91087_().m_91300_().m_94922_(new SystemToast(SystemToastIds.PERIODIC_NOTIFICATION, Constants.TEXT_SERVER_ERROR, TextUtils.text(packet.message)));
    }

    public static void showAdvancedDisplaySettingsScreen(AdvancedDisplayBlockEntity blockEntity, AbstractContraptionEntity contraption) {
        DLWindow.openWindow(mgr -> new AdvancedDisplaySettingsWindow(mgr, blockEntity, contraption));
    }

    public static void updateLanguage(String localeCode, boolean force) {
        if (currentLanguage.getCode().equals(localeCode) && !force) {
            return;
        }

        currentLanguage = CustomLanguage.load(localeCode);
        if (currentLanguage.isDefault()) {
            CreateRailwaysNavigator.LOGGER.info("Updated custom language to: (Default)");
        } else {
            String name = currentLanguage.getLanguageInfo().map(LanguageInfo::f_118945_).orElse(localeCode);
            CreateRailwaysNavigator.LOGGER.info("Updated custom language to: {}", name);
        }
    }

    public static CustomLanguage getCurrentLanguage() {
        return currentLanguage;
    }


    public static void sendCRNNotification(Component title, Component description) {
        if (ModClientConfig.ROUTE_NOTIFICATIONS.get()) {
            Minecraft.m_91087_().m_91300_().m_94922_(NavigatorToast.multiline(title, description));
        }
    }

    public static int renderMultilineLabelSafe(DLGuiGraphics graphics, int x, int y, Font font, Component text, int maxWidth, DLColor color) {
        MultiLineLabel label = MultiLineLabel.m_94341_(font, text, maxWidth);
        label.m_6516_(graphics.graphics(), x, y, font.f_92710_, color.getAsARGB());
        return font.f_92710_ * label.m_5770_();
    }

    public static int getTextBlockHeight(Font font, Component text, int maxWidth) {
        int lines = font.m_92923_(text, maxWidth).size();
        return lines * font.f_92710_;
    }

    public static void initPrioritizedDestinationInstruction(PrioritizedDestinationInstruction instruction, ModularGuiLineBuilder builder) {

        ModularGuiLineBuilderAccessor accessor = (ModularGuiLineBuilderAccessor)builder;

        ResizableButton btn = new ResizableButton(accessor.crn$getX(), accessor.crn$getY() - 4, 121, 16, TextUtils.translate(CreateRailwaysNavigator.MOD_ID + ".schedule.instruction.configure"),
        (b) -> {
            if (Minecraft.m_91087_().f_91080_ instanceof ScheduleScreen scheduleScreen) {
                ((ScheduleScreenAccessor)scheduleScreen).crn$getOnEditorClose().accept(true);
                builder.customArea(0, 0).speechBubble();
                DLWindow.openWindow(mgr -> new PrioritizedDestinationInstructionSettingsWindow(mgr, instruction, instruction.getData()));
            }
        }) {
        };
		accessor.crn$getTarget().add(Pair.of(btn, "config_btn"));
    }

    public static void initScheduleSectionInstruction(TravelSectionInstruction instruction, ModularGuiLineBuilder builder) {

        ModularGuiLineBuilderAccessor accessor = (ModularGuiLineBuilderAccessor)builder;
        ResizableButton btn = new ResizableButton(accessor.crn$getX(), accessor.crn$getY() - 4, 121, 16, TextUtils.translate(CreateRailwaysNavigator.MOD_ID + ".schedule.instruction.configure"),
        (b) -> {
            if (Minecraft.m_91087_().f_91080_ instanceof ScheduleScreen scheduleScreen) {
                ((ScheduleScreenAccessor)scheduleScreen).crn$getOnEditorClose().accept(true);
                builder.customArea(0, 0).speechBubble();
                DLWindow.openWindow(mgr -> new TrainSectionSettingsWindow(mgr, instruction.getData()));
            }
        });
		accessor.crn$getTarget().add(Pair.of(btn, "config_btn"));
    }

    public static void initResetTimingsInstruction(ResetTimingsInstruction instruction, ModularGuiLineBuilder builder) {
    }

    public static void initDynamicDelayCondition(DynamicDelayCondition condition, ModularGuiLineBuilder builder) {

        builder.addScrollInput(0, 26, (i, l) -> {
			i.titled(TextUtils.translate(CreateRailwaysNavigator.MOD_ID + ".schedule.condition." + condition.getId().m_135815_() + ".min_duration"))
				.withShiftStep(15)
				.withRange(0, 121);
			i.lockedTooltipX = -15;
			i.lockedTooltipY = 35;
		}, DynamicDelayCondition.NBT_MIN);

		builder.addScrollInput(26, 26, (i, l) -> {
			i.titled(CreateLang.translateDirect("generic.duration"))
				.withShiftStep(15)
				.withRange(0, 121);
			i.lockedTooltipX = -15;
			i.lockedTooltipY = 35;
		}, "Value");

		builder.addSelectionScrollInput(52, 58, (i, l) -> {
			i.forOptions(TimeUnit.translatedOptions())
				.titled(CreateLang.translateDirect("generic.timeUnit"));
		}, "TimeUnit");


        ModularGuiLineBuilderAccessor accessor = (ModularGuiLineBuilderAccessor)builder;
    }

    @SuppressWarnings("resource")
    public static void initTimingAdjustmentGui(TrainSeparationCondition condition, ModularGuiLineBuilder builder) {

        ModularGuiLineBuilderAccessor accessor = (ModularGuiLineBuilderAccessor)builder;
        ResizableButton btn = new ResizableButton(accessor.crn$getX(), accessor.crn$getY() - 4, 121, 16, TextUtils.translate(CreateRailwaysNavigator.MOD_ID + ".schedule.instruction.configure"),
        (b) -> {
            if (Minecraft.m_91087_().f_91080_ instanceof ScheduleScreen scheduleScreen) {
                ((ScheduleScreenAccessor)scheduleScreen).crn$getOnEditorClose().accept(true);
                builder.customArea(0, 0).speechBubble();
                DLWindow.openWindow(mgr -> new TrainSeparationSettingsWindow(mgr, condition.getData()));
            }
        });
		accessor.crn$getTarget().add(Pair.of(btn, "config_btn"));
    }

    public static void renderNavigatorItem(DLGraphics graphics, ItemStack itemStack, ItemDisplayContext context, boolean leftHand, PoseStack poseStack, MultiBufferSource buffer, int combinedLight, int combinedOverlay, BakedModel model) {
        if (context != ItemDisplayContext.FIRST_PERSON_LEFT_HAND && context != ItemDisplayContext.FIRST_PERSON_RIGHT_HAND && context != ItemDisplayContext.FIXED) {
            return;
        }


        int backgroundId = itemStack.m_41784_().m_128451_(NavigatorItem.NBT_BACKGROUND_ID);
        DLTime time = new DLTime(Minecraft.m_91087_().f_91073_, DLTime.defaultTimeSystem());

        Font font = Minecraft.m_91087_().f_91062_;
        poseStack.m_252781_(Axis.f_252529_.m_252977_(90F));
        poseStack.m_252880_(4, 2, -1.26f);
        RenderUtils.renderTexture(new ResourceLocation(CreateRailwaysNavigator.MOD_ID, String.format("textures/item/navigator_backgrounds/%s.png", backgroundId)), graphics, new Vector3f(0), 8, 12, 0, 0, 1F / 12F * 8, 1F, Direction.UP, DLColor.WHITE, LightTexture.f_173040_, false);

        poseStack.m_252880_(0, 0, -0.01f);
        poseStack.m_85836_();
        poseStack.m_252880_(4, 0.8f, 0);
        poseStack.m_85841_(0.075f, 0.075f, 0.075f);
        RenderUtils.drawString(graphics, font, 0, 0, TextUtils.translate("gui." + CreateRailwaysNavigator.MOD_ID + ".journey_info.date", (long)time.toGameDays(DLTime.defaultTimeSystem())), DLColor.WHITE, ETextAlignment.CENTER, false, LightTexture.f_173040_);
        poseStack.m_85849_();

        poseStack.m_85836_();
        poseStack.m_252880_(4, 2, 0);
        poseStack.m_85841_(0.2f, 0.2f, 0.2f);
        RenderUtils.drawString(graphics, font, 0, 0, time.format(ModClientConfig.TIME_FORMAT.get().getFormat(), TimeContext.INGAME, DLTime.defaultTimeSystem()), DLColor.WHITE, ETextAlignment.CENTER, false, LightTexture.f_173040_);
        poseStack.m_85849_();
    }

    public static Owner getMe() {
        return new Owner(Minecraft.m_91087_().f_91074_);
    }

    public static Player getClientPlayer() {
        return Minecraft.m_91087_().f_91074_;
    }

    public static void openUrl(String url) {
        Screen previous = Minecraft.m_91087_().f_91080_;
        Minecraft.m_91087_().m_91152_(new ConfirmLinkScreen((b) -> {
            if (b) {
                Util.m_137581_().m_137646_(url);
            }
            Minecraft.m_91087_().m_91152_(previous);
        }, url, true));
    }
}
