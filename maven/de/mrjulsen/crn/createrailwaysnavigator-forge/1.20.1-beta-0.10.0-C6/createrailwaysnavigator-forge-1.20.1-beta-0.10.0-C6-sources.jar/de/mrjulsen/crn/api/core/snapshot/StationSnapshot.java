package de.mrjulsen.crn.api.core.snapshot;

import java.util.List;
import java.util.Set;
import java.util.UUID;

import de.mrjulsen.crn.api.core.ref.TrainCategoryRef;
import de.mrjulsen.crn.api.core.ref.LineRef;
import de.mrjulsen.crn.api.core.ref.StationRef;
import de.mrjulsen.crn.api.core.ref.StationTagRef;
import de.mrjulsen.crn.util.NbtHelper;
import de.mrjulsen.crn.web.annotation.ResponseAlwaysInclude;
import net.minecraft.nbt.CompoundTag;

/**
 * What is known about one station: which stationTags it belongs to, and which lines, categories and trains
 * call there. Only trains fit to be reported are counted.
 *
 * @param station     The station this describes.
 * @param tags        Every tag covering this station.
 * @param lines       The lines calling here.
 * @param categories  The categories calling here.
 * @param trainIds    The ids of the trains calling here.
 * @param blacklisted Whether the station is hidden from public boards and route searches.
 */
public record StationSnapshot(
    @ResponseAlwaysInclude StationRef station,
    List<StationTagRef> tags,
    List<LineRef> lines,
    List<TrainCategoryRef> categories,
    Set<UUID> trainIds,
    boolean blacklisted
) {

    private static final String NBT_STATION = "Station";
    private static final String NBT_TAGS = "Tags";
    private static final String NBT_LINES = "Lines";
    private static final String NBT_CATEGORIES = "Categories";
    private static final String NBT_TRAIN_IDS = "TrainIds";
    private static final String NBT_BLACKLISTED = "Blacklisted";

    public StationSnapshot {
        station = station == null ? StationRef.NONE : station;
        tags = tags == null ? List.of() : List.copyOf(tags);
        lines = lines == null ? List.of() : List.copyOf(lines);
        categories = categories == null ? List.of() : List.copyOf(categories);
        trainIds = trainIds == null ? Set.of() : Set.copyOf(trainIds);
    }

    /** The station's own name. */
    public String name() {
        return station.name();
    }

    /** Whether any train calls here at all. */
    public boolean isServed() {
        return !trainIds.isEmpty();
    }

    /** Whether the station belongs to at least one tag. */
    public boolean isTagged() {
        return !tags.isEmpty();
    }

    public CompoundTag toNbt() {
        CompoundTag nbt = new CompoundTag();
        nbt.m_128365_(NBT_STATION, station.toNbt());
        nbt.m_128365_(NBT_TAGS, NbtHelper.writeList(tags, StationTagRef::toNbt));
        nbt.m_128365_(NBT_LINES, NbtHelper.writeList(lines, LineRef::toNbt));
        nbt.m_128365_(NBT_CATEGORIES, NbtHelper.writeList(categories, TrainCategoryRef::toNbt));
        nbt.m_128365_(NBT_TRAIN_IDS, NbtHelper.writeUuids(trainIds));
        nbt.m_128379_(NBT_BLACKLISTED, blacklisted);
        return nbt;
    }

    public static StationSnapshot fromNbt(CompoundTag nbt) {
        return new StationSnapshot(
            StationRef.fromNbt(nbt.m_128469_(NBT_STATION)),
            NbtHelper.readList(nbt, NBT_TAGS, StationTagRef::fromNbt),
            NbtHelper.readList(nbt, NBT_LINES, LineRef::fromNbt),
            NbtHelper.readList(nbt, NBT_CATEGORIES, TrainCategoryRef::fromNbt),
            NbtHelper.readUuids(nbt, NBT_TRAIN_IDS),
            nbt.m_128471_(NBT_BLACKLISTED)
        );
    }
}
