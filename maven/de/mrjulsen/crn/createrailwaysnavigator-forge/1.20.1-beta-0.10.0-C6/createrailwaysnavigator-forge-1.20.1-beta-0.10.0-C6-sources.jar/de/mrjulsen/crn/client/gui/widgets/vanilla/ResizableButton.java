package de.mrjulsen.crn.client.gui.widgets.vanilla;

import de.mrjulsen.mcdragonlib.DragonLib;
import de.mrjulsen.mcdragonlib.client.util.DLGuiGraphics;
import de.mrjulsen.mcdragonlib.client.util.GuiUtils;
import de.mrjulsen.mcdragonlib.data.ETextAlignment;
import de.mrjulsen.mcdragonlib.util.DLColor;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;

public class ResizableButton extends Button {

    public ResizableButton(int x, int y, int width, int height, Component message, OnPress onPress) {
        super(x, y, width, height, message, onPress, f_252438_);
    }

    @Override
    public void m_87963_(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        DLGuiGraphics graphics = new DLGuiGraphics(guiGraphics, guiGraphics.m_280168_(), Minecraft.m_91087_().f_91062_, partialTick);
        DLColor j = m_142518_() ? DragonLib.VANILLA_BUTTON_ACTIVE_FONT_COLOR : DragonLib.VANILLA_BUTTON_DISABLED_FONT_COLOR;
        GuiUtils.drawString(graphics, Minecraft.m_91087_().f_91062_, this.m_252754_() + this.f_93618_ / 2, this.m_252907_() + (this.f_93619_ - 8) / 2, this.m_6035_(), j, ETextAlignment.CENTER, true);
    }
}
