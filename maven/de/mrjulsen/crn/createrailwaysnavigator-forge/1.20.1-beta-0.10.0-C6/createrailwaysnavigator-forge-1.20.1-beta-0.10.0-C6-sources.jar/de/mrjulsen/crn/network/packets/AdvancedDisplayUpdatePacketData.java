package de.mrjulsen.crn.network.packets;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import org.apache.commons.lang3.tuple.MutablePair;

import com.simibubi.create.content.contraptions.AbstractContraptionEntity;
import com.simibubi.create.content.contraptions.Contraption;
import com.simibubi.create.content.contraptions.behaviour.MovementContext;

import de.mrjulsen.crn.CRNPlatformSpecific;
import de.mrjulsen.crn.block.AbstractAdvancedSidedDisplayBlock;
import de.mrjulsen.crn.block.IBlockGetter;
import de.mrjulsen.crn.block.blockentity.AdvancedDisplayBlockEntity;
import de.mrjulsen.crn.block.blockentity.AdvancedDisplayBlockEntity.EUpdateReason;
import de.mrjulsen.crn.block.display.properties.IDisplaySettings;
import de.mrjulsen.crn.block.properties.ESide;
import de.mrjulsen.crn.client.AdvancedDisplaysRegistry;
import de.mrjulsen.crn.client.AdvancedDisplaysRegistry.DisplayTypeResourceKey;
import de.mrjulsen.crn.mixin.ContraptionAccessor;
import de.mrjulsen.mcdragonlib.data.DLStatus;
import de.mrjulsen.mcdragonlib.network.NetworkPacketContext;
import de.mrjulsen.mcdragonlib.network.NetworkPacketData;
import de.mrjulsen.mcdragonlib.util.NbtUtils;
import net.minecraft.core.BlockPos;
import net.minecraft.core.BlockPos.MutableBlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate.StructureBlockInfo;

public class AdvancedDisplayUpdatePacketData extends NetworkPacketData {

    private static final String NBT_POS = "Pos";
    private static final String NBT_ENTITY_ID = "EntityId";
    private static final String NBT_IS_ON_CONTRAPTION = "IsOnContraption";
    private static final String NBT_KEY = "Key";
    private static final String NBT_DOUBLE_SIDED = "DoubleSided";
    private static final String NBT_SETTINGS = "Settings";

    private BlockPos pos;
    private int entityId;
    private boolean isOnContraption;

    private DisplayTypeResourceKey key;
    private boolean doubleSided;
    private IDisplaySettings settings;

    public AdvancedDisplayUpdatePacketData(DLStatus status) {
        super(status);
    }

    public AdvancedDisplayUpdatePacketData(Level level, BlockPos pos, AbstractContraptionEntity contraption, DisplayTypeResourceKey key, boolean doubleSided, IDisplaySettings settings) {
        super(DLStatus.OK);
        this.pos = pos;
        this.isOnContraption = contraption != null;
        this.entityId = isOnContraption ? contraption.m_19879_() : 0;

        this.key = key;
        this.doubleSided = doubleSided;
        this.settings = settings;
        if (isOnContraption) {
            applyContraption(contraption, this);
        } else {
            apply(level, this);
        }
    }

    protected AdvancedDisplayUpdatePacketData(BlockPos pos, int entityId, boolean isOnContraption, DisplayTypeResourceKey key, boolean doubleSided, IDisplaySettings settings) {
        super(DLStatus.OK);
        this.pos = pos;
        this.entityId = entityId;
        this.isOnContraption = isOnContraption;

        this.key = key;
        this.doubleSided = doubleSided;
        this.settings = settings;
    }

    @Override
    protected void write(CompoundTag nbt) {
        CompoundTag tag = new CompoundTag();
        key.toNbt(tag);
        nbt.m_128365_(NBT_KEY, tag);

        NbtUtils.putNbtPos(nbt, NBT_POS, pos);
        nbt.m_128379_(NBT_DOUBLE_SIDED, doubleSided);
        nbt.m_128379_(NBT_IS_ON_CONTRAPTION, isOnContraption);
        nbt.m_128405_(NBT_ENTITY_ID, entityId);
        nbt.m_128365_(NBT_SETTINGS, settings.serializeNbt());

    }

    @Override
    protected void read(CompoundTag nbt) {
        this.key = DisplayTypeResourceKey.fromNbt(nbt.m_128469_(NBT_KEY));
        this.pos = NbtUtils.getNbtBlockPos(nbt, NBT_POS);
        this.doubleSided = nbt.m_128471_(NBT_DOUBLE_SIDED);
        this.isOnContraption = nbt.m_128471_(NBT_IS_ON_CONTRAPTION);
        this.entityId = nbt.m_128451_(NBT_ENTITY_ID);
        this.settings = AdvancedDisplaysRegistry.createSettings(key);
        this.settings.deserializeNbt(nbt.m_128469_(NBT_SETTINGS));
    }



    public static void handle(AdvancedDisplayUpdatePacketData packet, NetworkPacketContext context) {
        context.queue(() -> {
            Player player = context.getPlayer();
            if (player != null) {
                Level level = player.m_9236_();

                if (packet.isOnContraption) {
                    if (level.m_6815_(packet.entityId) instanceof AbstractContraptionEntity ce) {
                        applyContraption(ce, packet);
                    }
                } else {
                    apply(level, packet);
                }
            }
        });
    }



    private static void apply(Level level, AdvancedDisplayUpdatePacketData packet) {
        if (level.m_46749_(packet.pos)) {
            if (level.m_7702_(packet.pos) instanceof AdvancedDisplayBlockEntity blockEntity) {
                blockEntity.applyToAll(be -> {
                    be.setDisplayType(level, packet.key, packet.settings);
                    if (level.m_8055_(be.m_58899_()).m_60734_() instanceof AbstractAdvancedSidedDisplayBlock) {
                        BlockState state = level.m_8055_(be.m_58899_());
                        state = state.m_61124_(AbstractAdvancedSidedDisplayBlock.SIDE, packet.doubleSided ? ESide.BOTH : ESide.FRONT);
                        level.m_46597_(be.m_58899_(), state);
                    }
                    be.notifyUpdate();
                }, new IBlockGetter.WorldBlockGetter(level));
            }
        }
    }

    private static void applyContraption(AbstractContraptionEntity contraptionEntity, AdvancedDisplayUpdatePacketData packet) {
        Contraption contraption = contraptionEntity.getContraption();
        Level level = contraption.getContraptionWorld();
        Set<BlockPos> blockEntityPositions = new HashSet<>();

        MutableBlockPos pos = packet.pos.m_122032_();
        MutablePair<StructureBlockInfo, MovementContext> rootActor = contraption.getActorAt(pos);
        if (rootActor == null || rootActor.right == null)
            return;

        MovementContext rootCtx = rootActor.getRight();
        StructureBlockInfo rootInfo = contraption.getBlocks().get(pos);
        Direction side = rootCtx.state.m_61143_(HorizontalDirectionalBlock.f_54117_).m_122428_();
        byte width = rootCtx.blockEntityData.m_128445_(AdvancedDisplayBlockEntity.NBT_XSIZE);
        byte height = rootCtx.blockEntityData.m_128445_(AdvancedDisplayBlockEntity.NBT_YSIZE);
        Map<BlockPos, CompoundTag> updateTags = ((ContraptionAccessor) contraption).crn$updateTags();

        packet.key.toNbt(rootCtx.blockEntityData);
        packet.key.toNbt(rootCtx.data);
        packet.key.toNbt(rootInfo.f_74677_());
        rootCtx.blockEntityData.m_128365_(AdvancedDisplayBlockEntity.NBT_DISPLAY_TYPE_SETTINGS, packet.settings.serializeNbt());
        rootCtx.data.m_128365_(AdvancedDisplayBlockEntity.NBT_DISPLAY_TYPE_SETTINGS, packet.settings.serializeNbt());
        rootInfo.f_74677_().m_128365_(AdvancedDisplayBlockEntity.NBT_DISPLAY_TYPE_SETTINGS, packet.settings.serializeNbt());

        BlockPos immutableRootPos = new BlockPos(pos.m_123341_(), pos.m_123342_(), pos.m_123343_());
        updateTags.put(immutableRootPos, rootInfo.f_74677_().m_6426_());
        blockEntityPositions.add(immutableRootPos);

        if (rootInfo.f_74676_().m_60734_() instanceof AbstractAdvancedSidedDisplayBlock) {
            BlockState newState = rootInfo.f_74676_().m_61124_(AbstractAdvancedSidedDisplayBlock.SIDE, packet.doubleSided ? ESide.BOTH : ESide.FRONT);
            contraption.getBlocks().put(pos, new StructureBlockInfo(rootInfo.f_74675_(), newState, rootInfo.f_74677_()));
            contraption.resetClientContraption();
        }

        if (CRNPlatformSpecific.getClientContraptionBlockEntity(contraption, pos) instanceof AdvancedDisplayBlockEntity be) {
            be.setDisplayType(level, packet.key, packet.settings);
            be.m_155250_(contraption.getBlocks().get(pos).f_74676_());
        }

        for (int i = 0; i < width && i < AdvancedDisplayBlockEntity.MAX_XSIZE; i++) {
            BlockPos newPos = pos.m_5484_(side, i);
            for (int j = 0; j < height && j < AdvancedDisplayBlockEntity.MAX_YSIZE; j++) {
                BlockPos newPos2 = newPos.m_5484_(Direction.DOWN, j);

                MutablePair<StructureBlockInfo, MovementContext> actor = contraption.getActorAt(newPos2);
                if (actor == null || actor.right == null)
                    continue;

                blockEntityPositions.add(new BlockPos(newPos2.m_123341_(), newPos2.m_123342_(), newPos2.m_123343_()));

                MovementContext ctx = actor.getRight();
                StructureBlockInfo info = contraption.getBlocks().get(newPos2);
                packet.key.toNbt(ctx.blockEntityData);
                packet.key.toNbt(ctx.data);
                packet.key.toNbt(info.f_74677_());
                ctx.blockEntityData.m_128365_(AdvancedDisplayBlockEntity.NBT_DISPLAY_TYPE_SETTINGS, packet.settings.serializeNbt());
                ctx.data.m_128365_(AdvancedDisplayBlockEntity.NBT_DISPLAY_TYPE_SETTINGS, packet.settings.serializeNbt());
                info.f_74677_().m_128365_(AdvancedDisplayBlockEntity.NBT_DISPLAY_TYPE_SETTINGS, packet.settings.serializeNbt());

                BlockPos immutablePos = new BlockPos(newPos2.m_123341_(), newPos2.m_123342_(), newPos2.m_123343_());
                updateTags.put(immutablePos, info.f_74677_().m_6426_());

                if (CRNPlatformSpecific.getClientContraptionBlockEntity(contraption, newPos2) instanceof AdvancedDisplayBlockEntity be) {
                    be.setDisplayType(level, packet.key, packet.settings);
                    be.m_155250_(contraption.getBlocks().get(newPos2).f_74676_());
                }

                if (info.f_74676_().m_60734_() instanceof AbstractAdvancedSidedDisplayBlock) {
                    BlockState newState = info.f_74676_().m_61124_(AbstractAdvancedSidedDisplayBlock.SIDE, packet.doubleSided ? ESide.BOTH : ESide.FRONT);
                    contraption.getBlocks().put(newPos2, new StructureBlockInfo(newPos2, newState, info.f_74677_()));
                }
            }
        }

        IBlockGetter getter = new IBlockGetter.ContraptionBlockGetter(contraptionEntity);
        for (MutablePair<StructureBlockInfo, MovementContext> a : contraption.getActors()) {
            BlockEntity blockEntity = getter.getBlockEntity(a.getLeft().f_74675_());
            if (blockEntity instanceof AdvancedDisplayBlockEntity be) {
                be.updateControllerStatus2(getter);
                if (level.m_5776_()) {
                    be.getRenderer().update(level, a.getLeft().f_74675_(), be.m_58900_(), be, EUpdateReason.LAYOUT_CHANGED);
                }
                if (updateTags.containsKey(a.getLeft().f_74675_()))
                    be.writeClient(updateTags.get(a.getLeft().f_74675_()));
            }
        }
    }
}
