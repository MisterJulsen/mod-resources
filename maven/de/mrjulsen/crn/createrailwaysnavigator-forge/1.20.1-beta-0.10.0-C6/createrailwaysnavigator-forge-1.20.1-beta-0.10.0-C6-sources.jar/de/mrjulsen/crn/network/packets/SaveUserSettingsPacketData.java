package de.mrjulsen.crn.network.packets;

import de.mrjulsen.crn.data.settings.UserSettings;
import de.mrjulsen.mcdragonlib.data.DLStatus;
import de.mrjulsen.mcdragonlib.network.NetworkPacketContext;
import de.mrjulsen.mcdragonlib.network.NetworkPacketData;
import net.minecraft.nbt.CompoundTag;

public class SaveUserSettingsPacketData extends NetworkPacketData {

    private static final String NBT_DATA = "Data";
    private static final String NBT_ID = "Id";

    private UserSettings settings;

    public SaveUserSettingsPacketData(DLStatus status) {
        super(status);
    }

    public SaveUserSettingsPacketData(UserSettings settings) {
        super(DLStatus.OK);
        this.settings = settings;
    }

    @Override
    protected void write(CompoundTag nbt) {
        nbt.m_128365_(NBT_DATA, settings.toNbt());
        nbt.m_128362_(NBT_ID, settings.getOwnerId());
    }

    @Override
    protected void read(CompoundTag nbt) {
        this.settings = UserSettings.fromNbt(nbt.m_128469_(NBT_DATA), nbt.m_128342_(NBT_ID), false);
    }

    public static EmptyNetworkPacketData handle(SaveUserSettingsPacketData packet, NetworkPacketContext context) {
        if (packet.settings != null && context.getPlayer().m_20148_().equals(packet.settings.getOwnerId())) {
            packet.settings.save();
        }
        return new EmptyNetworkPacketData();
    }
    
}
