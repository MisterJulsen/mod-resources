package de.mrjulsen.crn.core.debug;

import java.util.List;
import java.util.Optional;

import de.mrjulsen.crn.data.settings.TrainCategory;
import de.mrjulsen.crn.data.settings.TrainLine;
import org.lwjgl.glfw.GLFW;

import de.mrjulsen.crn.core.RailwayBackend;
import de.mrjulsen.crn.core.TrainManager;
import de.mrjulsen.crn.api.core.CallDirection;
import de.mrjulsen.crn.api.core.snapshot.BoardEntry;
import de.mrjulsen.crn.api.core.query.BoardQuery;
import de.mrjulsen.crn.api.core.RailwayBackendApi;
import de.mrjulsen.crn.core.train.LiveTrainState;
import de.mrjulsen.crn.core.train.TrackedTrain;
import de.mrjulsen.crn.core.train.TrainLifecycleState;
import de.mrjulsen.crn.core.realtime.RealtimeTracker;
import de.mrjulsen.crn.core.realtime.SignalWait;
import de.mrjulsen.crn.core.schedule.JourneySection;
import de.mrjulsen.crn.core.schedule.JourneyStop;
import de.mrjulsen.crn.core.delay.DelayInstance;
import de.mrjulsen.crn.core.timing.StopTimings;
import de.mrjulsen.crn.util.ESpeedUnit;
import de.mrjulsen.crn.util.ModUtils;
import de.mrjulsen.mcdragonlib.client.DLOverlayManager;
import de.mrjulsen.mcdragonlib.client.gui.events.DLGuiStandardEvents;
import de.mrjulsen.mcdragonlib.client.gui.widgets.base.DLWindow;
import de.mrjulsen.mcdragonlib.client.gui.widgets.base.DLWindowManager;
import de.mrjulsen.mcdragonlib.client.util.DLGuiGraphics;
import de.mrjulsen.mcdragonlib.client.util.GuiUtils;
import de.mrjulsen.mcdragonlib.data.ETextAlignment;
import de.mrjulsen.mcdragonlib.events.EventListenerId;
import de.mrjulsen.mcdragonlib.util.DLColor;
import de.mrjulsen.mcdragonlib.util.TextUtils;
import de.mrjulsen.mcdragonlib.util.math.Rectangle;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

public class BackendDebugOverlay extends DLWindow {

    private static BackendDebugOverlay instance;
    private final EventListenerId event;

    private int trainIndex = 0;
    private int line = 0;

    public BackendDebugOverlay(DLWindowManager manager) {
        super(manager);
        fullscreen.set(true);

        event = getWindowManager().addEventListener(DLGuiStandardEvents.KeyPressEvent.class, (s, e) -> {
            if (e.keyCode() == GLFW.GLFW_KEY_K) {
                trainIndex++;
                return true;
            } else if (e.keyCode() == GLFW.GLFW_KEY_J) {
                trainIndex--;
                return true;
            }
            return false;
        });
    }

    @Override
    public void close() throws Exception {
        getWindowManager().removeEventListener(DLGuiStandardEvents.KeyPressEvent.class, event);
        super.close();
    }

    public static void toggle() {
        if (instance != null) {
            DLOverlayManager.getWindowManager().ifPresent(w -> w.closeWindow(instance));
            instance = null;
        } else {
            DLOverlayManager.addOverlay(mgr -> instance = new BackendDebugOverlay(mgr));
        }
    }

    @Override
    public void renderMainLayer(DLGuiGraphics graphics, double mouseX, double mouseY, Rectangle renderBounds) {
        graphics.poseStack().m_85836_();
        graphics.poseStack().m_85841_(0.75f, 0.75f, 0.75f);
        line = 0;

        if (!RailwayBackend.isActive()) {
            drawLine(graphics, TextUtils.text("CRN Backend is not active.").m_130940_(ChatFormatting.RED));
            graphics.poseStack().m_85849_();
            return;
        }

        List<TrackedTrain> trains = TrainManager.getInstance().getAllTrains().stream()
            .sorted((a, b) -> a.getTrainName().compareToIgnoreCase(b.getTrainName()))
            .toList();

        if (trains.isEmpty()) {
            drawLine(graphics, TextUtils.text("CRN Backend: no tracked trains.").m_130940_(ChatFormatting.YELLOW));
            graphics.poseStack().m_85849_();
            return;
        }

        trainIndex = ((trainIndex % trains.size()) + trains.size()) % trains.size();
        TrackedTrain train = trains.get(trainIndex);
        long now = ModUtils.getTransformedWorldTime();

        renderHeader(graphics, train, trains.size(), now);
        renderLiveData(graphics, train);
        renderStatuses(graphics, train, now);
        renderJourney(graphics, train, now);
        renderSections(graphics, train);

        drawLine(graphics, TextUtils.empty());
        drawLine(graphics, TextUtils.text("[K] next train   [J] previous train").m_130940_(ChatFormatting.AQUA));
        graphics.poseStack().m_85849_();
    }

    private void renderHeader(DLGuiGraphics graphics, TrackedTrain train, int trainCount, long now) {
        drawLine(graphics, TextUtils.text("CRN TRAIN TRACKING  ").m_130940_(ChatFormatting.BOLD).m_130940_(ChatFormatting.GOLD)
            .m_7220_(TextUtils.text("Train " + (trainIndex + 1) + "/" + trainCount + ", now=" + String.format("%,d", now)).m_130940_(ChatFormatting.GRAY)));

        MutableComponent title = TextUtils.text(train.getTrainName()).m_130940_(ChatFormatting.WHITE).m_130940_(ChatFormatting.BOLD);
        if (!train.getDisplayName().equals(train.getTrainName())) {
            title.m_7220_(TextUtils.text(" (" + train.getDisplayName() + ")").m_130940_(ChatFormatting.GRAY));
        }
        title.m_7220_(TextUtils.text(" [" + train.getLifecycleState() + "]").m_130940_(lifecycleColor(train.getLifecycleState())));
        title.m_7220_(TextUtils.text(" [" + train.getLiveState() + "]").m_130940_(liveStateColor(train.getLiveState())));
        drawLine(graphics, title);

        drawLine(graphics, TextUtils.text("Id: " + train.getTrainId() + ", Session: " + train.getSessionId()).m_130940_(ChatFormatting.DARK_GRAY));

        String sectionInfo = train.getCurrentSection().map(s ->
            "Section " + (s.getSectionIndex() + 1) + "/" + train.getJourney().getSections().size() + " -> " + s.getLastStop().toString()
            + "   Line: " + s.getTrainLine().map(x -> x.getLineName()).orElse("-")
            + "   Category: " + s.getTrainCategory().map(x -> x.getCategoryName()).orElse("-")
        ).orElse("Section: -");
        drawLine(graphics, TextUtils.text(sectionInfo
            + "   Cyclic: " + yesNo(train.getJourney().isCyclic())
            + "   FlexibleDwell: " + yesNo(train.getJourney().hasFlexibleDwellTimes())
            + "   Title: " + train.getCurrentStop().map(JourneyStop::getTitle).orElse("-")
        ).m_130940_(ChatFormatting.GRAY));
    }

    private void renderLiveData(DLGuiGraphics graphics, TrackedTrain train) {
        var rt = train.getRealtime();
        drawLine(graphics, TextUtils.text("Live: ")
            .m_7220_(TextUtils.text(", transit: " + rt.getTransitTicks() + "t").m_130940_(ChatFormatting.RESET).m_130940_(ChatFormatting.WHITE))
            .m_7220_(TextUtils.text(", dwell: " + rt.getDwellTicks() + "t").m_130940_(ChatFormatting.WHITE))
            .m_7220_(TextUtils.text(", signal: " + rt.getTotalSignalWaitTicks() + "t (" + rt.getSignalWaits().size() + " waits)").m_130940_(rt.getCurrentSignalId() != null ? ChatFormatting.RED : ChatFormatting.WHITE))
            .m_7220_(TextUtils.text(", stalled: " + rt.getStalledTicks() + "t").m_130940_(rt.getStalledTicks() > 0 ? ChatFormatting.RED : ChatFormatting.WHITE))
            .m_7220_(TextUtils.text(", speed: " + (int)ModUtils.calcSpeed(train.getTrain().speed, ESpeedUnit.MS) + "/" + (int)ModUtils.calcSpeed(train.getTrain().targetSpeed, ESpeedUnit.MS) + " " + ESpeedUnit.MS).m_130940_(ChatFormatting.WHITE))
            .m_7220_(TextUtils.text(", cycle: " + train.getTotalDuration() + "t").m_130940_(ChatFormatting.WHITE))
            .m_7220_(TextUtils.text(", separation: " + train.getSeparationHoldTicksRemaining() + "t").m_130940_(train.getSeparationHoldTicksRemaining() > 0 ? ChatFormatting.YELLOW : ChatFormatting.WHITE))
        );

        for (SignalWait wait : rt.getSignalWaits()) {
            drawLine(graphics, TextUtils.text("   - Signal " + shortId(wait.signalId()) + ": " + wait.waitTicks() + "t"
                + (wait.occupyingTrains().isEmpty() ? "" : "  blocked by: " + String.join(", ", wait.occupyingTrains()))).m_130940_(ChatFormatting.RED));
        }
    }

    private void renderStatuses(DLGuiGraphics graphics, TrackedTrain train, long now) {
        long deviation = train.getMaxDeviation();
        ChatFormatting devColor = train.isDelayed() ? ChatFormatting.RED : ChatFormatting.GREEN;
        drawLine(graphics, TextUtils.text("Delay: ").m_130940_(ChatFormatting.UNDERLINE)
            .m_7220_(TextUtils.text("  max +" + deviation + "t").m_130940_(ChatFormatting.RESET).m_130940_(devColor))
            .m_7220_(TextUtils.text("   carried-over " + train.getDelayOffset() + "t").m_130940_(ChatFormatting.GRAY))
            .m_7220_(TextUtils.text(train.isDelayed() ? "   DELAYED" : "   ON TIME").m_130940_(devColor).m_130940_(ChatFormatting.BOLD))
            .m_7220_(TextUtils.text(train.isCancelled() ? "   CANCELLED" : "").m_130940_(ChatFormatting.DARK_RED).m_130940_(ChatFormatting.BOLD))
        );

        List<DelayInstance> delays = train.getActiveDelays();
        if (delays.isEmpty()) {
            drawLine(graphics, TextUtils.text("   (no active status)").m_130940_(ChatFormatting.DARK_GRAY));
        }
        for (DelayInstance delay : delays) {
            drawLine(graphics, TextUtils.text("   ! " + delay.causeId().m_135815_()
                + (delay.hasArgs() ? ": " + String.join(", ", delay.argValues()) : "")
                + "  (since " + (now - delay.since()) + "t)").m_130940_(statusColor(delay)));
        }
    }

    private void renderJourney(DLGuiGraphics graphics, TrackedTrain train, long now) {
        List<JourneyStop> stops = train.getJourney().getStops();
        drawLine(graphics, TextUtils.text("Journey (" + stops.size() + " stops):").m_130940_(ChatFormatting.UNDERLINE));
        drawLine(graphics, TextUtils.text("     idx  station                     sched arr/dep    real arr/dep     dev a/d      leg (last | hist)         visits").m_130940_(ChatFormatting.DARK_GRAY));

        JourneyStop current = train.getCurrentStop().orElse(null);
        for (JourneyStop stop : stops) {
            StopTimings timing = train.getTimings(stop);
            boolean isCurrent = stop == current;

            String marker = isCurrent ? (train.getLiveState() == LiveTrainState.AT_STATION ? " ■ " : " ▶ ") : " □ ";
            String station = fit(stop.getStationName(), 26);
            String sched = "S: " + (timing == null ? "?" : String.format("%,d", timing.getScheduled().arrival()) + "/" + String.format("%,d", timing.getScheduled().departure()));
            String real = "R: " + (timing == null ? "?" : String.format("%,d", timing.getRealtime().arrival()) + "/" + String.format("%,d", timing.getRealtime().departure()));
            String dev = "D: " + (timing == null ? "?" : String.format("%+,d", timing.getArrivalDeviation()) + "/" + String.format("%+,d", timing.getDepartureDeviation()));
            String leg = timing == null ? "?" : timing.legDuration().get() + " (" + timing.legDuration().lastMeasurement() + " | "
                + String.join(",", timing.legDuration().getHistory().stream().map(String::valueOf).toList()) + ")";
            String visits = timing == null ? "?" : "x" + timing.getCompletedVisits();
            String residual = timing == null || timing.dwellResidualTicks() <= 0 ? "" : " +" + timing.dwellResidualTicks() + "t";

            ChatFormatting color = timing != null && timing.isDelayed(500) ? (isCurrent ? ChatFormatting.GOLD : ChatFormatting.RED)
                : isCurrent ? ChatFormatting.YELLOW
                : timing != null && timing.legDuration().isInitialized() ? ChatFormatting.WHITE
                : ChatFormatting.DARK_GRAY;

            drawLine(graphics, TextUtils.text(String.format("%s[%3d] %s  %-16s %-16s %-12s %-26s %s%s",
                marker, stop.entryIndex(), station, sched, real, dev, leg, visits, residual)).m_130940_(color));
        }
    }

    private void renderSections(DLGuiGraphics graphics, TrackedTrain train) {
        drawLine(graphics, TextUtils.text("Sections:").m_130940_(ChatFormatting.UNDERLINE));
        for (JourneySection section : train.getJourney().getSections()) {
            boolean isCurrent = train.getCurrentSection().map(x -> x == section).orElse(false);
            drawLine(graphics, TextUtils.text((isCurrent ? " ▶ " : " □ ")
                + "[" + section.entryIndex() + "] "
                + section.getFirstStop().map(JourneyStop::getStationFilter).orElse("?") + " -> " + section.getLastStop().map(JourneyStop::getStationFilter).orElse("?")
                + "   Line: " + section.getTrainLine().map(TrainLine::getLineName).orElse("-")
                + "   Category: " + section.getTrainCategory().map(TrainCategory::getCategoryName).orElse("-")
                + "   Usable: " + yesNo(section.isUsable())
                + "   IncludesNextStart: " + yesNo(section.includesNextSectionStart())
                + (section.isDefault() ? "   (default)" : "")
            ).m_130940_(isCurrent ? ChatFormatting.YELLOW : section.isUsable() ? ChatFormatting.WHITE : ChatFormatting.DARK_GRAY));
        }
    }

    private void renderDepartureBoardSample(DLGuiGraphics graphics, TrackedTrain train, long now) {
        Optional<JourneyStop> current = train.getCurrentStop();
        if (current.isEmpty()) {
            return;
        }
        String station = current.get().getStationName();
        drawLine(graphics, TextUtils.text("API sample - departures at '" + station + "':").m_130940_(ChatFormatting.UNDERLINE));
        try {
            List<BoardEntry> board = RailwayBackendApi.getBoard(station, BoardQuery.defaults().withLimit(4));
            if (board.isEmpty()) {
                drawLine(graphics, TextUtils.text("   (none)").m_130940_(ChatFormatting.DARK_GRAY));
            }
            for (BoardEntry entry : board) {
                drawLine(graphics, TextUtils.text("   " + fit(entry.displayName(CallDirection.DEPARTURE), 20)
                    + " -> " + fit(entry.destinationText(), 24)
                    + "  dep " + rel(entry.realtime().departure(), now)
                    + (entry.isDelayed() ? " (+" + entry.departureDeviation() + ")" : "")
                ).m_130940_(entry.isDelayed() ? ChatFormatting.RED : ChatFormatting.GREEN));
            }
        } catch (Exception e) {
            drawLine(graphics, TextUtils.text("   API error: " + e.getMessage()).m_130940_(ChatFormatting.RED));
        }
    }

    private static String rel(long time, long now) {
        if (time < 0) {
            return "?";
        }
        long diff = time - now;
        return (diff >= 0 ? "+" : "") + diff + "t";
    }

    private static String fit(String text, int length) {
        if (text == null) text = "";
        if (text.length() > length) {
            return text.substring(0, length - 1) + "…";
        }
        return String.format("%-" + length + "s", text);
    }

    private static String yesNo(boolean value) {
        return value ? "yes" : "no";
    }

    private static String shortId(java.util.UUID id) {
        return id == null ? "?" : id.toString().substring(0, 8);
    }

    private static ChatFormatting lifecycleColor(TrainLifecycleState state) {
        return switch (state) {
            case READY -> ChatFormatting.GREEN;
            case LEARNING -> ChatFormatting.YELLOW;
            case PREPARING -> ChatFormatting.GRAY;
            case IDLE -> ChatFormatting.DARK_GRAY;
            case CANCELLED -> ChatFormatting.RED;
        };
    }

    private static ChatFormatting liveStateColor(LiveTrainState state) {
        return switch (state) {
            case EN_ROUTE -> ChatFormatting.GREEN;
            case AT_STATION -> ChatFormatting.AQUA;
            case WAITING_FOR_SIGNAL, STALLED -> ChatFormatting.RED;
            case SCHEDULE_PAUSED, SCHEDULE_COMPLETED, NO_SCHEDULE, DERAILED -> ChatFormatting.DARK_RED;
        };
    }

    private static ChatFormatting statusColor(DelayInstance delay) {
        return switch (delay.severity()) {
            case INFO -> ChatFormatting.WHITE;
            case DELAY -> ChatFormatting.GOLD;
            case IMPORTANT -> ChatFormatting.RED;
        };
    }

    private void drawLine(DLGuiGraphics graphics, Component text) {
        int x = 2;
        int y = 2;
        GuiUtils.fill(graphics, x - 1, y - 1 + line * (graphics.defaultFont().f_92710_ + 2), graphics.defaultFont().m_92852_(text) + 2, graphics.defaultFont().f_92710_ + 2, DLColor.fromInt(0x44000000));
        GuiUtils.drawString(graphics, graphics.defaultFont(), x, y + 1 + line * (graphics.defaultFont().f_92710_ + 2), text, DLColor.WHITE, ETextAlignment.LEFT, true);
        line++;
    }
}
