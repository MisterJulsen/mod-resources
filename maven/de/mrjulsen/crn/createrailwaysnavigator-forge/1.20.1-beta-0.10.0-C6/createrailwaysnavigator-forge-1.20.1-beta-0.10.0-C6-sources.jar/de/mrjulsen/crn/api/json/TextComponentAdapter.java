package de.mrjulsen.crn.api.json;

import com.google.gson.*;
import net.minecraft.network.chat.Component;

import java.lang.reflect.Type;

final class TextComponentAdapter implements JsonSerializer<Component>, JsonDeserializer<Component> {

    @Override
    public JsonElement serialize(Component value, Type type, JsonSerializationContext context) {
        return new JsonPrimitive(Component.Serializer.m_130703_(value));
    }

    @Override
    public Component deserialize(JsonElement element, Type type, JsonDeserializationContext context) {
        return Component.Serializer.m_130691_(element);
    }
}
