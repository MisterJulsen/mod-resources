package de.mrjulsen.crn.block.blockentity;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.simibubi.create.content.contraptions.Contraption;
import com.simibubi.create.content.contraptions.ControlledContraptionEntity;
import com.simibubi.create.content.contraptions.elevator.ElevatorColumn;
import com.simibubi.create.content.contraptions.elevator.ElevatorContactBlockEntity;
import com.simibubi.create.content.contraptions.elevator.ElevatorContraption;
import com.simibubi.create.content.decoration.copycat.CopycatBlockEntity;
import com.simibubi.create.content.trains.display.FlapDisplayBlock;
import com.simibubi.create.content.trains.entity.CarriageContraption;
import com.simibubi.create.content.trains.entity.CarriageContraptionEntity;
import com.simibubi.create.foundation.blockEntity.behaviour.BlockEntityBehaviour;

import de.mrjulsen.crn.block.AbstractAdvancedDisplayBlock;
import de.mrjulsen.crn.block.IBlockGetter;
import de.mrjulsen.crn.block.properties.ETimeDisplay;
import de.mrjulsen.crn.block.display.properties.BasicDisplaySettings;
import de.mrjulsen.crn.block.display.properties.IDisplaySettings;
import de.mrjulsen.crn.block.display.properties.components.IPlatformWidthSetting;
import de.mrjulsen.crn.block.display.properties.components.ITimeDisplaySetting;
import de.mrjulsen.crn.block.display.properties.components.ITrainNameWidthSetting;
import de.mrjulsen.crn.block.properties.EDisplayInfo;
import de.mrjulsen.crn.block.properties.EDisplayType;
import de.mrjulsen.crn.block.properties.EDisplayType.EDisplayTypeDataSource;
import de.mrjulsen.crn.client.AdvancedDisplaysRegistry;
import de.mrjulsen.crn.client.AdvancedDisplaysRegistry.DisplayProperties;
import de.mrjulsen.crn.client.AdvancedDisplaysRegistry.DisplayTypeResourceKey;
import de.mrjulsen.crn.client.ber.AdvancedDisplayRenderInstance;
import de.mrjulsen.crn.config.ModClientConfig;
import de.mrjulsen.crn.data.CarriageData;
import de.mrjulsen.crn.data.ElevatorData;
import de.mrjulsen.crn.data.ElevatorMovementType;
import de.mrjulsen.crn.data.TrainExitSide;
import de.mrjulsen.crn.data.StationTag.ClientStationTag;
import de.mrjulsen.crn.data.StationTag.StationInfo;
import de.mrjulsen.crn.data.train.ETrainStopState;
import de.mrjulsen.crn.data.train.TrainUtils;
import de.mrjulsen.crn.data.train.portable.StationDisplayData;
import de.mrjulsen.crn.data.train.portable.TrainDisplayData;
import de.mrjulsen.crn.data.train.portable.TrainStopDisplayData;
import de.mrjulsen.crn.network.packets.pain.GetTrainDisplayDataPacketData;
import de.mrjulsen.crn.registry.ModDisplayTypes;
import de.mrjulsen.crn.registry.ModNetworkManager;
import de.mrjulsen.crn.util.ModUtils;
import de.mrjulsen.mcdragonlib.block.IBERInstance;
import de.mrjulsen.mcdragonlib.client.ber.IBlockEntityRendererInstance;
import de.mrjulsen.mcdragonlib.config.ECachingPriority;
import de.mrjulsen.mcdragonlib.network.NetworkDirection;
import de.mrjulsen.mcdragonlib.util.Cache;
import de.mrjulsen.mcdragonlib.util.DLColor;
import de.mrjulsen.mcdragonlib.util.DLListUtils;
import de.mrjulsen.mcdragonlib.util.Pair;
import de.mrjulsen.mcdragonlib.util.Tripple;
import dev.architectury.platform.Platform;
import dev.architectury.utils.Env;
import net.createmod.catnip.data.IntAttached;
import net.minecraft.core.BlockPos;
import net.minecraft.core.BlockPos.MutableBlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Vec3i;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.Connection;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.util.Mth;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

public class AdvancedDisplayBlockEntity extends CopycatBlockEntity implements
    IMultiblockBlockEntity<AdvancedDisplayBlockEntity, AbstractAdvancedDisplayBlock>,
    IContraptionBlockEntity<AdvancedDisplayBlockEntity>,
    IBERInstance<AdvancedDisplayBlockEntity>
{
    public static final String NBT_DISPLAY_TYPE_SETTINGS = "DisplaySettings";

    private static final String NBT_FILTER = "Filter";

    public static final String NBT_XSIZE = "XSize";
    public static final String NBT_YSIZE = "YSize";
    public static final String NBT_CONTROLLER = "IsController";
    private static final String NBT_GLOWING = "Glowing";
    
    private static final String NBT_LAST_REFRESH_TIME = "LastRefreshed";
    private static final String NBT_TRAIN_STOPS = "TrainStops";

    @Deprecated private static final String LEGACY_NBT_PLATFORM_WIDTH = "PlatformWidth";
    @Deprecated private static final String LEGACY_NBT_TRAIN_NAME_WIDTH = "TrainNameWidth";
    @Deprecated private static final String LEGACY_NBT_COLOR = "Color";
    @Deprecated private static final String LEGACY_NBT_TIME_DISPLAY = "TimeDisplay";
    @Deprecated private static final String LEGACY_NBT_DISPLAY_TYPE_KEY = "DisplayTypeKey";
    @Deprecated private static final String LEGACY_NBT_INFO_TYPE = "InfoType";
    @Deprecated private static final String LEGACY_NBT_DISPLAY_TYPE = "DisplayType";

    public static final byte MAX_XSIZE = 16;
    public static final byte MAX_YSIZE = 16;

    // DATA
    private DisplayTypeResourceKey displayTypeId = ModDisplayTypes.TRAIN_DESTINATION_SIMPLE;
    private byte xSize = 1;
	private byte ySize = 1;
    private boolean isController;
    private List<StationDisplayData> predictions;
    private boolean dataOrderChanged = false;
    private String stationNameFilter;
    private StationInfo stationInfo;
    private boolean glowing = false;
    private IDisplaySettings displayTypeSettings = AdvancedDisplaysRegistry.createSettings(ModDisplayTypes.TRAIN_DESTINATION_SIMPLE);
    
    // CLIENT DISPLAY ONLY - this data is not saved!
    public boolean assembledOnContraption = false;
    private long lastRefreshedTime;
    private TrainDisplayData trainData = TrainDisplayData.empty(0);
    private CarriageData carriageData = new CarriageData(0, Direction.NORTH, false);
    private ElevatorData elevatorData = new ElevatorData("", "", "", "", ElevatorMovementType.STANDING_STILL);
    
    // OTHER
    private int syncTicks = 0;
    private final Cache<IBlockEntityRendererInstance<AdvancedDisplayBlockEntity>> renderer = new Cache<>(() -> new AdvancedDisplayRenderInstance(this), ECachingPriority.ALWAYS);

    public final Cache<TrainExitSide> relativeExitDirection = new Cache<>(() -> {        
        if (getCarriageData() == null || !getTrainData().getNextStop().isPresent() || !(m_58900_().m_60734_() instanceof AbstractAdvancedDisplayBlock)) {
            return TrainExitSide.UNKNOWN;
        }
        TrainExitSide side = getTrainData().getNextStopExitSide();
        Direction blockFacing = m_58900_().m_61143_(HorizontalDirectionalBlock.f_54117_);
        if (!carriageData.isOppositeDirection()) {
            blockFacing = blockFacing.m_122424_();
        }

        TrainExitSide result = side;
        if (getCarriageData().assemblyDirection() == blockFacing) {
            result = result.getOpposite();
        } else if (getCarriageData().assemblyDirection().m_122424_() != blockFacing) {
            result = TrainExitSide.UNKNOWN;
        }
        return result;
    });

    public final Cache<Tripple<Float, Float, Float>> renderRotation = new Cache<>(() -> {
        if (m_58900_().m_60734_() instanceof AbstractAdvancedDisplayBlock block) {
            return block.getRenderRotation(f_58857_, m_58900_(), f_58858_);
        }
        return Tripple.of(0.0F, 0.0F, 0.0F);
    });

    public final Cache<Pair<Float, Float>> renderOffset = new Cache<>(() -> {
        if (m_58900_().m_60734_() instanceof AbstractAdvancedDisplayBlock block) {
            return block.getRenderOffset(f_58857_, m_58900_(), f_58858_);
        }
        return Pair.of(0.0F, 0.0F);
    });

    public final Cache<Pair<Float, Float>> renderZOffset = new Cache<>(() -> {
        if (m_58900_().m_60734_() instanceof AbstractAdvancedDisplayBlock block) {
            return block.getRenderZOffset(f_58857_, m_58900_(), f_58858_);
        }
        return Pair.of(0.0F, 0.0F);
    });

    public final Cache<Pair<Float, Float>> renderAspectRatio = new Cache<>(() -> {
        if (m_58900_().m_60734_() instanceof AbstractAdvancedDisplayBlock block) {
            Pair<Float, Float> raw = block.getRenderAspectRatio(f_58857_, m_58900_(), f_58858_);
            float scale = 1.0f / Math.min(raw.getFirst(), raw.getSecond());
            return Pair.of(raw.getFirst() * scale, raw.getSecond() * scale);
        }
        return Pair.of(1.0F, 1.0F);
    });

    public final Cache<Float> renderScale = new Cache<>(() -> {        
        return 1.0F / Math.max(this.renderAspectRatio.get().getFirst(), this.renderAspectRatio.get().getSecond());
    });



    public AdvancedDisplayBlockEntity(BlockEntityType<?> type, BlockPos pos, BlockState state) {
        super(type, pos, state);
        reset();
    }

    public TrainDisplayData getTrainData() {
        return trainData;
    }

    public CarriageData getCarriageData() {
        return carriageData;
    }

    public ElevatorData getElevatorData() {
        return elevatorData;
    }

    public long getLastRefreshedTime() {
        return lastRefreshedTime;
    }

    public byte getXSize() {
        return xSize;
    }

    public byte getXSizeScaled() {
        return (byte)(getXSize() * renderAspectRatio.get().getFirst());
    }

    public byte getYSize() {
        return ySize;
    }

    public byte getYSizeScaled() {
        return (byte)(getYSize() * renderAspectRatio.get().getSecond());
    }

    public boolean isController() {
        return isController;
    }

    public boolean isGlowing() {
        return glowing;
    }

    public DisplayTypeResourceKey getDisplayType() {
        return displayTypeId;
    }
    
    @Override
    public byte getMaxWidth() {
        return MAX_XSIZE;
    }

    @Override
    public byte getMaxHeight() {
        return MAX_YSIZE;
    }

    @Override
    public byte getWidth() {
        return xSize;
    }

    @Override
    public byte getHeight() {
        return ySize;
    }

    @Override
    public Class<AbstractAdvancedDisplayBlock> getBlockType() {
        return AbstractAdvancedDisplayBlock.class;
    }

    @Override
    public Class<AdvancedDisplayBlockEntity> getBlockEntityType() {
        return AdvancedDisplayBlockEntity.class;
    }

    public List<StationDisplayData> getStops() {
        return predictions;
    }

    public boolean isPlatformFixed() {
        return !ModUtils.isGlobPattern(stationNameFilter);
    }

    /**
     * The station info for this display.
     */
    public StationInfo getStationInfo() {
        return stationInfo;
    }

    /**
     * The station filter string of this display.
     */
    public String getStationNameFilter() {
        return stationNameFilter;
    }

    public boolean isAllowedOnDisplay(ClientStationTag tag) {
        return TrainUtils.stationMatches(tag.stationName(), getStationNameFilter());
    }

    public ClientStationTag getAllowedDisplayData(TrainStopDisplayData data) {
        if (isAllowedOnDisplay(data.getRealTimeStation())) {
            return data.getRealTimeStation();
        } else if (isAllowedOnDisplay(data.getScheduledStation())) {
            return data.getScheduledStation();
        }
        return ClientStationTag.empty();
    }

	public boolean isSingleLine() {
		if (m_58900_().m_60734_() instanceof AbstractAdvancedDisplayBlock block) {
			return block.isSingleLined() || AdvancedDisplaysRegistry.getProperties(displayTypeId).singleLined();
		}
        return false;		
	}

    public DisplayProperties getDisplayProperties() {
        return AdvancedDisplaysRegistry.getProperties(displayTypeId);
    }

    public void setGlowing(boolean glowing) {
		this.glowing = glowing;
        if (f_58857_.f_46443_) {
            getRenderer().update(f_58857_, f_58858_, m_58900_(), this, EUpdateReason.LAYOUT_CHANGED);
        }

    }

    
    /**
     * Updates the display type.
     * @param key The new display type key.
     * @param settings Custom display settings or {@code null} for default settings.
     */
    public void setDisplayType(DisplayTypeResourceKey key,  IDisplaySettings settings) {
        setDisplayType(m_58904_(), key, settings);
    }

    public void setDisplayType(Level level, DisplayTypeResourceKey key, IDisplaySettings settings) {
        this.displayTypeId = key;
        this.displayTypeSettings = settings == null ? AdvancedDisplaysRegistry.createSettings(key) : settings;
        if (level.f_46443_) {
            getRenderer().update(level, f_58858_, m_58900_(), this, EUpdateReason.LAYOUT_CHANGED);
        }
    }

    public void setData(List<StationDisplayData> predictions, String stationNameFilter, StationInfo staionInfo, long lastRefreshedTime) {
        this.dataOrderChanged = dataOrderChanged || !DLListUtils.compareCollections(this.predictions, predictions, StationDisplayData::equals);

        boolean clientUpdate = Platform.getEnvironment() == Env.CLIENT && !getStationInfo().equals(staionInfo);
        
        this.predictions = predictions;
        this.stationNameFilter = stationNameFilter;
        this.stationInfo = staionInfo;
        this.lastRefreshedTime = lastRefreshedTime;

        if (clientUpdate) {
            getRenderer().update(f_58857_, f_58858_, m_58900_(), this, EUpdateReason.DATA_CHANGED);
        }
    }
    
    @Override
    public boolean connectable(IBlockGetter getter, BlockPos a, BlockPos b) {
        if (getter == null || a == null || b == null) {
            return false;
        }

        if (getter.getBlockEntity(a) instanceof AdvancedDisplayBlockEntity be1 && getter.getBlockEntity(b) instanceof AdvancedDisplayBlockEntity be2 && be1.m_58900_().m_60734_() instanceof AbstractAdvancedDisplayBlock block1 && be2.m_58900_().m_60734_() instanceof AbstractAdvancedDisplayBlock block2) {
            return block1 == block2 &&
                be1.getDisplayType().equals(be2.getDisplayType()) &&
                block1.canConnectWithBlock(getter, getter.getBlockState(a), getter.getBlockState(b)) && block2.canConnectWithBlock(getter, getter.getBlockState(b), getter.getBlockState(a)) && 
                (!a.m_7494_().equals(b) || (be1.m_58900_().m_61143_(AbstractAdvancedDisplayBlock.UP) && !be1.isSingleLine())) &&
                (!a.m_7495_().equals(b) || (be1.m_58900_().m_61143_(AbstractAdvancedDisplayBlock.DOWN) && !be1.isSingleLine()))
            ;
        }
        return false;
    }    

    public AdvancedDisplayBlockEntity getController(IBlockGetter getter) {
		if (isController())
			return this;

		BlockState blockState = getter.getBlockState(f_58858_);
		if (!(blockState.m_60734_() instanceof AbstractAdvancedDisplayBlock))
			return null;

		MutableBlockPos pos = m_58899_().m_122032_();
		Direction side = blockState.m_61143_(AbstractAdvancedDisplayBlock.FACING).m_122427_();

        for (int i = 0; i < getMaxWidth(); i++) {
			if (connectable(getter, pos, pos.m_121945_(side))) {
				pos.m_122173_(side);
				continue;
			}

			BlockEntity found = getter.getBlockEntity(pos);
			if (found instanceof AdvancedDisplayBlockEntity flap && flap.isController())
				return flap;

			break;
		}

		for (int i = 0; i < getMaxHeight(); i++) {
            if (connectable(getter, pos, pos.m_121945_(Direction.UP))) {
				pos.m_122173_(Direction.UP);
				continue;
			}

			BlockEntity found = getter.getBlockEntity(pos);
			if (found instanceof AdvancedDisplayBlockEntity flap && flap.isController())
				return flap;

			break;
		}

		return null;
	}

    public void copyFrom(AdvancedDisplayBlockEntity other) {
        if (
            getDisplayType().equals(other.getDisplayType()) &&
            isGlowing() == other.isGlowing()
        ) {
            return;
        }

        glowing = other.isGlowing();
        displayTypeId = other.getDisplayType();
        displayTypeSettings = other.getSettings();
        notifyUpdate();
    }

    public void reset() {
        dataOrderChanged = true;

        predictions = List.of();
        stationNameFilter = "";
        xSize = 1;
        ySize = 1;
        isController = false;
        stationInfo = StationInfo.empty();
    }

    public void updateControllerStatus2(IBlockGetter getter) {
		BlockState blockState = getter.getBlockState(f_58858_);
		if (!(blockState.m_60734_() instanceof AbstractAdvancedDisplayBlock))
			return;

		Direction leftDirection = blockState.m_61143_(AbstractAdvancedDisplayBlock.FACING).m_122427_();
        boolean shouldBeController = !connectable(getter, f_58858_, f_58858_.m_121945_(leftDirection)) && !connectable(getter, f_58858_, f_58858_.m_7494_());
        

		byte newXSize = 1;
		byte newYSize = 1;

		if (shouldBeController) {
			for (int xOffset = 1; xOffset < getMaxWidth(); xOffset++) {
                BlockPos relPos = f_58858_.m_5484_(leftDirection.m_122424_(), xOffset);
				if (getter.getBlockState(relPos) != blockState) {
                    break;
                }

				newXSize++;
			}

            if (!isSingleLine()) {
                for (int yOffset = 0; yOffset < getMaxHeight(); yOffset++) {
                    BlockPos downPos = f_58858_.m_5484_(Direction.DOWN, yOffset);
                    
                    for (int i = 0; i < newXSize; i++) {
                        BlockPos relPos = downPos.m_5484_(leftDirection.m_122424_(), i);
                        if (getter.getBlockEntity(relPos) instanceof AdvancedDisplayBlockEntity be && be != this) {
                            be.copyFrom(this);
                            getter.updateBlockEntity(be, be.f_58858_);
                        }
                    }

                    if (!connectable(getter, downPos, downPos.m_7495_())) {
                        break;
                    }    
                    newYSize++;
                }
            }
		}

		if (isController == shouldBeController && newXSize == xSize && newYSize == ySize)
			return;
        
        isController = shouldBeController;
        xSize = newXSize;
        ySize = newYSize;

        if (!isController) {
            reset();
        }
        getter.updateBlockEntity(this, f_58858_);
        notifyUpdate();
	}    

    @Override
    public void tick() {
        if (f_58857_.f_46443_) {
            getRenderer().tick(f_58857_, m_58899_(), m_58900_(), this);
        }

        super.tick();

        if (getDisplayType().category().getSource() != EDisplayTypeDataSource.PLATFORM) {
            return;
        }

        syncTicks--;
        if (f_58857_.f_46443_ && syncTicks <= 0) {
            syncTicks = ModClientConfig.DISPLAY_REFRESH_RATE.get();
            boolean shouldUpdate = getStops().size() > 0 || dataOrderChanged;
            if (shouldUpdate) {
                getRenderer().update(f_58857_, m_58899_(), m_58900_(), this, dataOrderChanged ? EUpdateReason.LAYOUT_CHANGED : EUpdateReason.DATA_CHANGED);
                dataOrderChanged = false;
            }
        }
    }

    @Override
    public void lazyTick() {
        super.lazyTick();
        if (!f_58857_.m_5776_()) {
            updateControllerStatus2(new IBlockGetter.WorldBlockGetter(m_58904_()));
        }
    }

    public int getClosestFloor(ElevatorContraption ec) {
        double currentY = ec.entity.m_20186_();
        int currentFloorY = Mth.m_14143_(0.5f + (float)currentY) + ec.getContactYOffset();

        int closest = -1;
        int minDistance = Integer.MAX_VALUE;

        for (var entry : ec.namesList) {
            int contactY = entry.getFirst();
            int distance = Math.abs(contactY - currentFloorY);
            
            if (distance < minDistance) {
                minDistance = distance;
                closest = contactY;
            }
        }
        
        return closest;
    }

    @Override
    public void contraptionTick(Level level, BlockPos pos, BlockState state, Contraption contraption) {
        assembledOnContraption = true;
        getRenderer().tick(level, pos, state, this);

        if (!isController()) {
            return;
        }

        EDisplayTypeDataSource source = getDisplayType().category().getSource();
        if (source != EDisplayTypeDataSource.TRAIN_INFORMATION && source != EDisplayTypeDataSource.NONE) {
            return;
        }

        syncTicks--;
        if (level.f_46443_ && syncTicks <= 0) {
            syncTicks = ModClientConfig.DISPLAY_REFRESH_RATE.get();

            if (contraption instanceof ElevatorContraption elevator) {
                int targetY = elevator.clientYTarget;
                int closestY = getClosestFloor(elevator);
                
                String shortName = "", longName = "", shortNameDest = "", longNameDest = "";

                for (var entry : elevator.namesList) {
                    int contactY = entry.getFirst();
                    if (contactY == closestY) {
                        shortName = entry.getValue().getFirst();
                        longName = entry.getValue().getSecond();
                    }
                    if (contactY == targetY) {
                        shortNameDest = entry.getValue().getFirst();
                        longNameDest = entry.getValue().getSecond();
                    }
                }

                ElevatorMovementType directionSign = ElevatorMovementType.STANDING_STILL;
                if (!elevator.arrived) {
                    double actualY = elevator.entity.m_20186_() + elevator.getContactYOffset();
                    if (targetY > actualY + 0.5) directionSign = ElevatorMovementType.GOING_UP;
                    else if (targetY < actualY - 0.5) directionSign = ElevatorMovementType.GOING_DOWN;
                }

                ElevatorData newData = new ElevatorData(shortName.toString(), longName.toString(), shortNameDest.toString(), longNameDest.toString(), directionSign);
                
                if (!newData.equals(this.elevatorData)) {
                    this.elevatorData = newData;
                    getRenderer().update(level, pos, state, this, EUpdateReason.DATA_CHANGED);
                }
            }

            if (!(contraption.entity instanceof CarriageContraptionEntity carriageContraption)) {
                return;
            }
            if (!(contraption instanceof CarriageContraption carriage)) {
                return;
            }

            ModNetworkManager.GET_TRAIN_DISPLAY_DATA.send(NetworkDirection.toServer(), new GetTrainDisplayDataPacketData.Request(carriageContraption.trainId), (response) -> {
                TrainDisplayData data = response.getData();
                int carriagesCount = TrainUtils.getTrain(carriageContraption.trainId).map(x -> x.carriages.size()).orElse(0);
                this.trainData = TrainDisplayData.empty(carriagesCount);
                if (data.getState().isOutOfService() && this.trainData.getState().isOutOfService()) {
                    return;
                }

                boolean shouldUpdate = false;
                if (this.trainData != null && this.trainData.getNextStop().isPresent() && data.getNextStop().isPresent()) {
                    TrainStopDisplayData prediction = this.trainData.getNextStop().get();
                    ETrainStopState stopState = ETrainStopState.beforeArrival(data.isWaitingAtStation());

                    shouldUpdate = !this.trainData.getTrainData().getName(stopState).equals(data.getTrainData().getName(stopState)) ||
                        !prediction.getDestination().equals(data.getNextStop().get().getDestination()) ||
                        prediction.getStationEntryIndex() != data.getNextStop().get().getStationEntryIndex() ||
                        this.trainData.getNextStopExitSide() != data.getNextStopExitSide() ||
                        this.trainData.isWaitingAtStation() != data.isWaitingAtStation()
                    ;
                }
                boolean outOfService = data.getState().isOutOfService();
                if (outOfService) {
                    shouldUpdate = true;
                }
                this.trainData = outOfService ? TrainDisplayData.empty(carriagesCount) : data;
                this.carriageData = new CarriageData(carriageContraption.carriageIndex, carriage.getAssemblyDirection(), data.isOppositeDirection());
                this.relativeExitDirection.clear();
                
                getRenderer().update(level, pos, state, this, shouldUpdate ? EUpdateReason.LAYOUT_CHANGED : EUpdateReason.DATA_CHANGED);
            }, () -> {});
        }
    }    

    @Override
    protected void write(CompoundTag pTag, boolean clientPacket) {
        super.write(pTag, clientPacket);
        pTag.m_128344_(NBT_XSIZE, getXSize());
        pTag.m_128344_(NBT_YSIZE, getYSize());
        pTag.m_128379_(NBT_CONTROLLER, isController());
        pTag.m_128359_(NBT_FILTER, getStationNameFilter());
        pTag.m_128379_(NBT_GLOWING, isGlowing());
        pTag.m_128356_(NBT_LAST_REFRESH_TIME, getLastRefreshedTime());

        displayTypeId.toNbt(pTag);
        pTag.m_128365_(NBT_DISPLAY_TYPE_SETTINGS, displayTypeSettings.serializeNbt());

        getStationInfo().writeNbt(pTag);

        if (getStops() != null && !getStops().isEmpty()) {            
            ListTag list = new ListTag();
            for (StationDisplayData data : getStops()) {
                list.add(data.toNbt());
            }
            pTag.m_128365_(NBT_TRAIN_STOPS, list);
        }
    }

    @SuppressWarnings("deprecation")
    @Override
    public void read(CompoundTag pTag, boolean clientPacket) {
        boolean updateClient = false;
        IDisplaySettings oldDisplayTypeSettings = displayTypeSettings;
        StationInfo info = StationInfo.fromNbt(pTag);
        if (f_58857_ != null && m_58900_() != null && f_58857_.f_46443_) {
            if (
                isController() != pTag.m_128471_(NBT_CONTROLLER) ||
                getXSize() != pTag.m_128445_(NBT_XSIZE) ||
                getYSize() != pTag.m_128445_(NBT_YSIZE) ||
                !getStationInfo().equals(info) ||
                (getStops().isEmpty() ^ !pTag.m_128441_(NBT_TRAIN_STOPS))
            ) {
                updateClient = true;
            }
        }

        super.read(pTag, clientPacket);


        xSize = pTag.m_128445_(NBT_XSIZE);
        ySize = pTag.m_128445_(NBT_YSIZE);
        glowing = pTag.m_128471_(NBT_GLOWING);
        isController = pTag.m_128471_(NBT_CONTROLLER);

        Class<? extends IDisplaySettings> oldDisplaySettings = displayTypeSettings.getClass();
        DisplayTypeResourceKey oldDisplayType = displayTypeId;
        
        // ### Convert deprecated data
        if (pTag.m_128441_(LEGACY_NBT_INFO_TYPE) && pTag.m_128441_(LEGACY_NBT_DISPLAY_TYPE)) {
            displayTypeId = ModDisplayTypes.legacy_getKeyForType(EDisplayType.getTypeById(pTag.m_128451_(LEGACY_NBT_DISPLAY_TYPE)), EDisplayInfo.getTypeById(pTag.m_128451_(LEGACY_NBT_INFO_TYPE)));
            displayTypeSettings = AdvancedDisplaysRegistry.createSettings(displayTypeId);
        } else if (pTag.m_128441_(LEGACY_NBT_DISPLAY_TYPE_KEY)) {
            displayTypeId = DisplayTypeResourceKey.legacy_fromNbt(pTag.m_128469_(LEGACY_NBT_DISPLAY_TYPE_KEY));
            displayTypeSettings = AdvancedDisplaysRegistry.createSettings(displayTypeId);
        } else {
            displayTypeId = DisplayTypeResourceKey.fromNbt(pTag);
            displayTypeSettings = AdvancedDisplaysRegistry.createSettings(displayTypeId);
            displayTypeSettings.deserializeNbt(pTag.m_128469_(NBT_DISPLAY_TYPE_SETTINGS));
        }

        if (f_58857_ != null && f_58857_.f_46443_) {
            updateClient = updateClient || !oldDisplayTypeSettings.getClass().equals(displayTypeSettings.getClass());
        }
        
        if (pTag.m_128441_(LEGACY_NBT_COLOR)) {
            getSettingsAs(BasicDisplaySettings.class).ifPresent(x -> x.setFontColor(DLColor.fromInt(pTag.m_128451_(LEGACY_NBT_COLOR))));
        }
        if (displayTypeId.category().getSource() == EDisplayTypeDataSource.PLATFORM) {            
            if (pTag.m_128441_(LEGACY_NBT_PLATFORM_WIDTH)) {
                getSettingsAs(IPlatformWidthSetting.class).ifPresent(x -> x.setPlatformWidth(pTag.m_128445_(LEGACY_NBT_PLATFORM_WIDTH)));
            }
            if (pTag.m_128441_(LEGACY_NBT_TRAIN_NAME_WIDTH)) {
                getSettingsAs(ITrainNameWidthSetting.class).ifPresent(x -> x.setTrainNameWidth(pTag.m_128445_(LEGACY_NBT_TRAIN_NAME_WIDTH)));
            }
            if (pTag.m_128441_(LEGACY_NBT_TIME_DISPLAY)) {
                getSettingsAs(ITimeDisplaySetting.class).ifPresent(x -> x.setTimeDisplay(ETimeDisplay.getById(pTag.m_128445_(LEGACY_NBT_TIME_DISPLAY))));
            }
        }
        // ###

        setData(
            pTag.m_128441_(NBT_TRAIN_STOPS) ? new ArrayList<>(pTag.m_128437_(NBT_TRAIN_STOPS, Tag.f_178203_).stream().map(x -> StationDisplayData.fromNbt((CompoundTag)x)).toList()) : new ArrayList<>(),
            pTag.m_128461_(NBT_FILTER),
            info,
            pTag.m_128454_(NBT_LAST_REFRESH_TIME)
        );

        if (f_58857_ != null && m_58900_() != null && f_58857_.f_46443_ && (!oldDisplaySettings.isInstance(displayTypeSettings) || !oldDisplayType.equals(displayTypeId))) {
            updateClient = true;
        }

        if (updateClient) {
            getRenderer().update(f_58857_, f_58858_, m_58900_(), this, EUpdateReason.LAYOUT_CHANGED);
        }
    }

    @Override
    public AABB getRenderBoundingBox() {
        AABB aabb = new AABB(f_58858_);
        if (!isController)
            return aabb;
        Vec3i normal = getDirection().m_122427_().m_122436_();
        return aabb.m_82363_(normal.m_123341_() * getXSize(), -getYSize(), normal.m_123343_() * getXSize());
    }

    public Direction getDirection() {
		return m_58900_().m_61145_(FlapDisplayBlock.HORIZONTAL_FACING)
			.orElse(Direction.SOUTH)
			.m_122424_();
	}

    @Override
    public IBlockEntityRendererInstance<AdvancedDisplayBlockEntity> getRenderer() {
        return renderer.get();
    }

    public IDisplaySettings getSettings() {
        return displayTypeSettings;
    }

    public <S> Optional<S> getSettingsAs(Class<S> clazz) {
        return Optional.ofNullable(clazz.isInstance(getSettings()) ? clazz.cast(getSettings()) : null);
    }

	@Override
	protected AABB createRenderBoundingBox() {
		AABB aabb = new AABB(f_58858_);
		if (!isController)
			return aabb;
		Vec3i normal = getDirection().m_122427_().m_122436_();
		return aabb.m_82363_(normal.m_123341_() * xSize, -ySize, normal.m_123343_() * xSize);
	}

    @Override
    public void addBehaviours(List<BlockEntityBehaviour> behaviours) {}

    @Override
    public ClientboundBlockEntityDataPacket m_58483_() {
        return ClientboundBlockEntityDataPacket.m_195642_(this, BlockEntity::m_5995_);
    }

    @Override
    public CompoundTag m_5995_() {
        CompoundTag nbt = new CompoundTag();
        this.write(nbt, true);
        return nbt;
    }

    @Override
    public void onDataPacket(Connection net, ClientboundBlockEntityDataPacket pkt) {
        this.m_142466_(pkt.m_131708_());
        this.f_58857_.m_7260_(this.f_58858_, this.m_58900_(), this.m_58900_(), 512);
    }

    public static enum EUpdateReason {
        LAYOUT_CHANGED,
        DATA_CHANGED
    }

}