package de.mrjulsen.crn.fabric.client;

import com.simibubi.create.foundation.block.connected.CTModel;
import com.simibubi.create.foundation.block.connected.ConnectedTextureBehaviour;
import net.minecraft.class_1087;

public class WrappedCTModel extends CTModel {
    public WrappedCTModel(class_1087 originalModel, ConnectedTextureBehaviour behaviour) {
        super(originalModel, behaviour);
    }

}
