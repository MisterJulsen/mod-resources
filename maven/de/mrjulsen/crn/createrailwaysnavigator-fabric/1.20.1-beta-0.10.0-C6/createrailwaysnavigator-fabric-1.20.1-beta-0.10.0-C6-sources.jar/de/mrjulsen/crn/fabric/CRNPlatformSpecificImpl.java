package de.mrjulsen.crn.fabric;

import de.mrjulsen.crn.config.ModCommonConfig;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.server.MinecraftServer;
import net.minecraftforge.fml.config.ModConfig;

import java.nio.file.Path;

import com.simibubi.create.api.contraption.storage.fluid.MountedFluidStorageWrapper;
import com.simibubi.create.content.contraptions.Contraption;
import com.simibubi.create.content.contraptions.render.ClientContraption;
import com.simibubi.create.content.logistics.filter.FilterItemStack;
import com.simibubi.create.content.trains.entity.Carriage;
import com.simibubi.create.content.trains.entity.Train;
import com.simibubi.create.content.trains.station.GlobalStation;
import com.simibubi.create.content.trains.station.StationBlockEntity;
import com.simibubi.create.foundation.data.CreateBlockEntityBuilder;
import com.simibubi.create.foundation.data.CreateRegistrate;

import de.mrjulsen.crn.block.penalty.PenaltyAnchorBlockEntity;
import de.mrjulsen.crn.client.ber.PenaltyAnchorVisual;

import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.SlottedStorage;
import net.fabricmc.fabric.api.transfer.v1.storage.StorageUtil;
import net.fabricmc.fabric.api.transfer.v1.storage.base.CombinedSlottedStorage;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import io.github.fabricators_of_create.porting_lib.fluids.FluidStack;
import io.github.fabricators_of_create.porting_lib.transfer.TransferUtil;

import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import de.mrjulsen.crn.CreateRailwaysNavigator;
import de.mrjulsen.crn.config.ModClientConfig;
import de.mrjulsen.crn.config.ModServerConfig;
import de.mrjulsen.crn.mixin.ContraptionAccessor;
import dev.architectury.platform.Platform;
import dev.architectury.utils.Env;
import fuzs.forgeconfigapiport.impl.config.ForgeConfigRegistryImpl;
import io.github.fabricators_of_create.porting_lib.util.ServerLifecycleHooks;
import io.github.fabricators_of_create.porting_lib.util.UsernameCache;

public class CRNPlatformSpecificImpl {
    public static Path getConfigDirectory() {
        return FabricLoader.getInstance().getConfigDir();
    }

    public static MinecraftServer getServer() {
        return ServerLifecycleHooks.getCurrentServer();
    }

    public static void registerConfig() {        
        if (Platform.getEnvironment() == Env.CLIENT) {
            ForgeConfigRegistryImpl.INSTANCE.register(CreateRailwaysNavigator.MOD_ID, ModConfig.Type.CLIENT, ModClientConfig.SPEC, CreateRailwaysNavigator.MOD_ID + "-client.toml");
        }
        ForgeConfigRegistryImpl.INSTANCE.register(CreateRailwaysNavigator.MOD_ID, ModConfig.Type.COMMON, ModCommonConfig.SPEC, CreateRailwaysNavigator.MOD_ID + "-common.toml");
        ForgeConfigRegistryImpl.INSTANCE.register(CreateRailwaysNavigator.MOD_ID, ModConfig.Type.SERVER, ModServerConfig.SPEC, CreateRailwaysNavigator.MOD_ID + "-server.toml");
    }
    
    public static GlobalStation getStationFromBlockEntity(class_2586 be) {
        if (!(be instanceof StationBlockEntity stationBe))
			return null;
		
        return stationBe.getStation();
    }

    public static Optional<String> getLastKnownPlayerName(UUID uuid) {
        return Optional.ofNullable(UsernameCache.getLastKnownUsername(uuid));
    }
    
    public static Map<UUID, String> getAllKnownPlayers() {
        return UsernameCache.getMap();
    }

    public static class_2586 getClientContraptionBlockEntity(Contraption contraption, class_2338 localPos) {
        var maybeNullClientContraption = ((ContraptionAccessor)contraption).crn$clientContraption().getAcquire();
        if (maybeNullClientContraption == null) {
            return null;
        }
        return maybeNullClientContraption.getBlockEntity(localPos);
    }

    public static boolean trainCarriesFilteredCargo(class_1937 level, FilterItemStack filter, Train train) {
        for (Carriage carriage : train.carriages) {
            if (carriage.storage == null)
                continue;

            CombinedSlottedStorage<ItemVariant, ? extends SlottedStorage<ItemVariant>> inv = carriage.storage.getAllItems();
            MountedFluidStorageWrapper tank = carriage.storage.getFluids();

            try (Transaction t = TransferUtil.getTransaction()) {
                if (StorageUtil.findExtractableResource(inv, variant -> filter.test(level, variant.toStack()), t) != null
                    || StorageUtil.findExtractableResource(tank, variant -> filter.test(level, new FluidStack(variant, 1)), t) != null)
                    return true;
            }
        }
        return false;
    }

    public static CreateBlockEntityBuilder<PenaltyAnchorBlockEntity, CreateRegistrate> withPenaltyAnchorVisual(CreateBlockEntityBuilder<PenaltyAnchorBlockEntity, CreateRegistrate> builder) {
        return builder.visual(() -> PenaltyAnchorVisual::new);
    }
}
