package de.mrjulsen.crn.fabric.client;

import com.simibubi.create.foundation.block.connected.CTModel;
import com.simibubi.create.foundation.block.connected.ConnectedTextureBehaviour;
import net.minecraft.class_1087;

public class WrappedCTModel extends CTModel {
    public WrappedCTModel(class_1087 originalModel, ConnectedTextureBehaviour behaviour) {
        super(originalModel, behaviour);
    }

    /*
    @Override
    protected ModelData.Builder gatherModelData(ModelData.Builder builder, BlockAndTintGetter world, BlockPos pos, BlockState state, ModelData blockEntityData) {
        ModelData.Builder b = super.gatherModelData(builder, world, pos, state, blockEntityData);
        for (ModelProperty<?> v : blockEntityData.getProperties()) {
            b.with((ModelProperty<? super Object>) v, (Object)blockEntityData.get(v));
        }
        return b;
    }

     */


}
