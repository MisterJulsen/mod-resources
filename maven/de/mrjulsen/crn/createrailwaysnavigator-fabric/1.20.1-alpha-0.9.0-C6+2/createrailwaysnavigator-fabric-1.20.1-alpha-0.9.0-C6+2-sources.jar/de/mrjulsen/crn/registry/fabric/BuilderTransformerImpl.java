package de.mrjulsen.crn.registry.fabric;

import com.simibubi.create.foundation.block.connected.ConnectedTextureBehaviour;
import com.simibubi.create.foundation.data.CreateRegistrate;
import com.tterrag.registrate.builders.BlockBuilder;
import com.tterrag.registrate.util.nullness.NonNullUnaryOperator;
import de.mrjulsen.crn.block.AbstractAdvancedDisplayBlock;
import de.mrjulsen.crn.fabric.client.ClientWrapperFabric;
import net.minecraft.class_1921;
import net.minecraft.class_2960;

public class BuilderTransformerImpl {

    public static <B extends AbstractAdvancedDisplayBlock, P> NonNullUnaryOperator<BlockBuilder<B, P>> copycatDisplay(ConnectedTextureBehaviour ctDisplay, ConnectedTextureBehaviour ctFrame, class_2960 copycatTexture) {
        return b -> b
                .addLayer(() -> class_1921::method_23577)
                .addLayer(() -> class_1921::method_23581)
                .addLayer(() -> class_1921::method_23579)
                .color(() -> AbstractAdvancedDisplayBlock::getDisplayColor)
                .onRegister(CreateRegistrate.blockModel(() -> ClientWrapperFabric.copycatModel(ctDisplay, ctFrame, copycatTexture)))
                ;
    }
}
