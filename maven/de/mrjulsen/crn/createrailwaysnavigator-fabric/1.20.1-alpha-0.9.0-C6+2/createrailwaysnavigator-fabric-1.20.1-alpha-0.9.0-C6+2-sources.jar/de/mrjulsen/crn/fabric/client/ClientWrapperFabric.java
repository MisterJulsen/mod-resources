package de.mrjulsen.crn.fabric.client;

import com.simibubi.create.foundation.block.connected.ConnectedTextureBehaviour;
import com.tterrag.registrate.util.nullness.NonNullFunction;
import net.minecraft.class_1087;
import net.minecraft.class_2960;

public class ClientWrapperFabric {

    public static NonNullFunction<class_1087, ? extends class_1087> copycatModel(ConnectedTextureBehaviour ctDisplay, ConnectedTextureBehaviour ctFrame, class_2960 copycatTexture) {
        return (model) -> new CopycatDisplayModel(model, ctDisplay, ctFrame);
    }
}
