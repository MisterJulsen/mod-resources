package de.mrjulsen.paw.client.model;

import java.util.List;

import org.jetbrains.annotations.Nullable;

import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.renderer.block.model.ItemOverrides;
import net.minecraft.client.renderer.block.model.ItemTransforms;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.core.Direction;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.state.BlockState;

public class BakedModelExtension<T extends BakedModel> implements BakedModel {
    
    protected final T originalModel;

    public BakedModelExtension(T originalModel) {
        this.originalModel = originalModel;
    }

    @Override
    public List<BakedQuad> m_213637_(@Nullable BlockState state, @Nullable Direction side, RandomSource rand) {
        return originalModel.m_213637_(state, side, rand);
    }

    @Override
    public boolean m_7541_() {
        return originalModel.m_7541_();
    }

    @Override
    public boolean m_7539_() {
        return originalModel.m_7539_();
    }

    @Override
    public boolean m_7547_() {
        return originalModel.m_7547_();
    }

    @Override
    public boolean m_7521_() {
        return originalModel.m_7521_();
    }

    @Override
    public TextureAtlasSprite m_6160_() {
        return originalModel.m_6160_();
    }

    @Override
    public ItemTransforms m_7442_() {
        return originalModel.m_7442_();
    }

    @Override
    public ItemOverrides m_7343_() {
        return originalModel.m_7343_();
    }
}
