package de.mrjulsen.paw.mixin;

import de.mrjulsen.paw.block.abstractions.weathering.IAgingBlock;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.LevelEvent;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.gameevent.GameEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Optional;

@Mixin(AxeItem.class)
public class AxeItemMixin {

    @Inject(method = "useOn", at = @At("RETURN"), cancellable = true)
    private void onUseOn(UseOnContext context, CallbackInfoReturnable<InteractionResult> cir) {
        if (cir.getReturnValue() != InteractionResult.PASS) return;

        Level level = context.m_43725_();
        BlockPos blockPos = context.m_8083_();
        BlockState blockState = level.m_8055_(blockPos);

        if (!(blockState.m_60734_() instanceof IAgingBlock<?, ?> agingBlock)) return;

        Optional<BlockState> result;

        if (agingBlock.isWaxed()) {
            result = agingBlock.getWaxToggled(blockState);
            result.ifPresent($ -> {
                level.m_5594_(context.m_43723_(), blockPos, SoundEvents.f_144060_, SoundSource.BLOCKS, 1.0F, 1.0F);
                level.m_5898_(context.m_43723_(), LevelEvent.f_153625_, blockPos, 0);
            });
        } else {
            result = agingBlock.getPrevious(blockState);
            result.ifPresent($ -> {
                level.m_5594_(context.m_43723_(), blockPos, SoundEvents.f_144059_, SoundSource.BLOCKS, 1.0F, 1.0F);
                level.m_5898_(context.m_43723_(), LevelEvent.f_153626_, blockPos, 0);
            });
        }

        if (result.isEmpty()) return;

        Player player = context.m_43723_();
        ItemStack itemStack = context.m_43722_();
        BlockState newState = result.get();

        if (player instanceof ServerPlayer serverPlayer) {
            CriteriaTriggers.f_10562_.m_285767_(serverPlayer, blockPos, itemStack);
        }

        level.m_7731_(blockPos, newState, 11);
        level.m_220407_(GameEvent.f_157792_, blockPos, GameEvent.Context.m_223719_(player, newState));

        if (player != null) {
            itemStack.m_41622_(1, player, p -> p.m_21190_(context.m_43724_()));
        }

        cir.setReturnValue(InteractionResult.m_19078_(level.f_46443_));
    }
}