package de.mrjulsen.paw.blockentity;

import de.mrjulsen.wires.block.WireConnectorBlockEntity;
import de.mrjulsen.mcdragonlib.util.math.MathUtils;
import de.mrjulsen.paw.block.abstractions.AbstractRotatableBlock;
import de.mrjulsen.paw.block.abstractions.IMultiblock;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Direction.Axis;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

public class MultiblockWireConnectorBlockEntity extends WireConnectorBlockEntity implements IMultiblockBlockEntity {

    private static final String NBT_X_SIZE = "XSize";
    private static final String NBT_Y_SIZE = "YSize";
    private static final String NBT_Z_SIZE = "ZSize";

    private final int maxXSize;
    private final int maxYSize;
    private final int maxZSize;

    private int xOffset;
    private int yOffset;
    private int zOffset;

    private BlockPos rootPos;

    public MultiblockWireConnectorBlockEntity(BlockEntityType<?> type, BlockPos pos, BlockState state) {
        super(type, pos, state);
        if (m_58900_().m_60734_() instanceof IMultiblock mb) {
            Vec3 vec = mb.multiblockSize();
            maxXSize = (int)vec.f_82479_;
            maxYSize = (int)vec.f_82480_;
            maxZSize = (int)vec.f_82481_;
        } else {
            maxXSize = 1;
            maxYSize = 1;
            maxZSize = 1;
        }
    }

    public void setRootPos(BlockPos pos) {
        this.rootPos = pos;
    }

    public BlockPos getRootPos() {
        return rootPos;
    }

    public int getDistanceToRoot() {
        Direction direction = m_58900_().m_61143_(AbstractRotatableBlock.FACING);
        return direction.m_122434_() == Axis.X ? Math.abs(rootPos.m_123341_() - m_58899_().m_123341_()) : Math.abs(rootPos.m_123343_() - m_58899_().m_123343_());
    }

    public int getYDistanceToRoot() {
        return Math.abs(rootPos.m_123342_() - m_58899_().m_123342_());
    }

    @Override
    protected void m_183515_(CompoundTag nbt) {
        super.m_183515_(nbt);
        nbt.m_128405_(NBT_X_SIZE, xOffset);
        nbt.m_128405_(NBT_Y_SIZE, yOffset);
        nbt.m_128405_(NBT_Z_SIZE, zOffset);
    }

    @Override
    public void m_142466_(CompoundTag nbt) {
        super.m_142466_(nbt);
        xOffset = MathUtils.clamp(nbt.m_128451_(NBT_X_SIZE), 0, maxXSize - 1);
        yOffset = MathUtils.clamp(nbt.m_128451_(NBT_Y_SIZE), 0, maxYSize - 1);
        zOffset = MathUtils.clamp(nbt.m_128451_(NBT_Z_SIZE), 0, maxZSize - 1);
    }

    @Override
    public int getXOffset() {
        return xOffset;
    }

    @Override
    public int getYOffset() {
        return yOffset;
    }

    @Override
    public int getZOffset() {
        return zOffset;
    }

    @Override
    public int getXSize() {
        return maxXSize;
    }

    @Override
    public int getYSize() {
        return maxYSize;
    }

    @Override
    public int getZSize() {
        return maxZSize;
    }

    @Override
    public void setOffset(int x, int y, int z) {
        this.xOffset = MathUtils.clamp(x, 0, maxXSize - 1);
        this.yOffset = MathUtils.clamp(y, 0, maxYSize - 1);
        this.zOffset = MathUtils.clamp(z, 0, maxZSize - 1);
        notifyUpdate();
    }    
}
