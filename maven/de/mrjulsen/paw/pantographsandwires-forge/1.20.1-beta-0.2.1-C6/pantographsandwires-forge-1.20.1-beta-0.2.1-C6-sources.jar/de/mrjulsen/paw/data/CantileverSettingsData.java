package de.mrjulsen.paw.data;

import de.mrjulsen.paw.block.abstractions.AbstractCantileverBlock.ECantileverInsulatorsPlacement;
import de.mrjulsen.paw.block.abstractions.AbstractCantileverBlock.ECantileverRegistrationArmType;
import net.minecraft.nbt.CompoundTag;

public record CantileverSettingsData(float width, float height, float yOffset, float catenaryHeight, ECantileverRegistrationArmType cantileverType, ECantileverInsulatorsPlacement insulatorPlacement, boolean showBracing) {
    public CompoundTag toNbt() {
        CompoundTag nbt = new CompoundTag();
        nbt.m_128350_("Width", width);
        nbt.m_128350_("Height", height);
        nbt.m_128350_("YOffset", yOffset);
        nbt.m_128350_("CatenaryHeight", catenaryHeight);
        nbt.m_128405_("Type", cantileverType.ordinal());
        nbt.m_128405_("InsulatorPlacement", insulatorPlacement.ordinal());
        nbt.m_128379_("ShowBracing", showBracing);
        return nbt;
    }

    public static CantileverSettingsData fromNbt(CompoundTag nbt) {
        return new CantileverSettingsData(
            nbt.m_128457_("Width"),
            nbt.m_128457_("Height"),
            nbt.m_128457_("YOffset"),
            nbt.m_128457_("CatenaryHeight"),
            ECantileverRegistrationArmType.values()[nbt.m_128451_("Type")],
            ECantileverInsulatorsPlacement.values()[nbt.m_128451_("InsulatorPlacement")],
            nbt.m_128471_("ShowBracing")
        );
    }
}