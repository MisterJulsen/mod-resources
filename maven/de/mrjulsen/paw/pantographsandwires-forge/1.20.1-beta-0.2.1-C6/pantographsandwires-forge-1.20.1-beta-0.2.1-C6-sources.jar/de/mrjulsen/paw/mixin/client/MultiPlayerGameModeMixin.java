package de.mrjulsen.paw.mixin.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import de.mrjulsen.paw.block.abstractions.IRotatableBlock;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.Direction.Axis;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

/** Fix block placement on rotated blocks */
@Mixin(MultiPlayerGameMode.class)
public class MultiPlayerGameModeMixin {
    
    private LocalPlayer player;

    @Inject(method = "useItemOn", at = @At(value = "HEAD", ordinal = 0))
    private void onUseItemOn(LocalPlayer player, InteractionHand hand, BlockHitResult blockHitResult, CallbackInfoReturnable<InteractionResult> cir) {
        this.player = player;
    }

    @ModifyVariable(method = "useItemOn", at = @At(value = "HEAD", ordinal = 1))
    private BlockHitResult modifyHitResult(BlockHitResult hitResult) {
        if (hitResult.m_82434_().m_122434_() == Axis.Y) {
            return hitResult;
        }

        BlockState state = Minecraft.m_91087_().f_91073_.m_8055_(hitResult.m_82425_());
        if (state.m_60734_() instanceof IRotatableBlock rot) {
            hitResult = rot.checkClickedFace(Minecraft.m_91087_().f_91073_, player, hitResult);
            return hitResult;
        }
        return hitResult;
    }
}
