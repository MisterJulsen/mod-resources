package de.mrjulsen.paw.util;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.phys.Vec3;

public final class Utils {
    public static void putNbtVec3(CompoundTag compound, String name, Vec3 vec) {
        CompoundTag nbt = new CompoundTag();
        nbt.m_128347_("X", vec.m_7096_());
        nbt.m_128347_("Y", vec.m_7098_());
        nbt.m_128347_("Z", vec.m_7094_());
        compound.m_128365_(name, nbt);
    }

    public static Vec3 getNbtVec3(CompoundTag compound, String name) {
        CompoundTag nbt = compound.m_128469_(name);
        return new Vec3(nbt.m_128459_("X"), nbt.m_128459_("Y"), nbt.m_128459_("Z"));
    }

    public static String capitalize(String s) {
        if (s == null || s.isEmpty()) return s;
        return s.substring(0, 1).toUpperCase() + s.substring(1);
    }
}
