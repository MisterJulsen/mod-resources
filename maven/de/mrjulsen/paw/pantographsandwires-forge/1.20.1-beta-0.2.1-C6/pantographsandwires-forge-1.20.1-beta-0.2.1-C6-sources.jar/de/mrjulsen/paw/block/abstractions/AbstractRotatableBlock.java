package de.mrjulsen.paw.block.abstractions;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import de.mrjulsen.paw.util.VoxelShapeRotator;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Direction.Axis;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockAndTintGetter;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition.Builder;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.BooleanOp;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

public abstract class AbstractRotatableBlock extends Block implements IRotatableBlock {

    public static final int ROTATIONS = 2;
    public static final int ROTATION_OFFSET = ROTATIONS - 1;
    public static final int MAX_ROTATION_INDEX = ROTATIONS;
    public static final int MIN_ROTATION_INDEX = -ROTATIONS;
    public static final int ROTATION_STEPS_PER_SIDE = ROTATIONS * 2;
    public static final int TOTAL_ROTATION_STEPS = ROTATION_STEPS_PER_SIDE * 4;
    public static final int PROPERTY_MAX_ROTATION_INDEX  = ROTATIONS + ROTATION_OFFSET;
    public static final int PROPERTY_BASE_ROTATION_INDEX = ROTATION_OFFSET;

    public static final DirectionProperty FACING = HorizontalDirectionalBlock.f_54117_;
    public static final IntegerProperty ROTATION = IntegerProperty.m_61631_("rotation", 0, PROPERTY_MAX_ROTATION_INDEX);

    private final Map<Integer, VoxelShape> shapeCache = new ConcurrentHashMap<>();

    public AbstractRotatableBlock(Properties properties) {
        super(properties);
        this.m_49959_(this.f_49792_.m_61090_()
                .m_61124_(FACING, Direction.NORTH)
                .m_61124_(ROTATION, PROPERTY_BASE_ROTATION_INDEX));
    }

    @Override
    protected void m_7926_(Builder<Block, BlockState> pBuilder) {
        super.m_7926_(pBuilder);
        pBuilder.m_61104_(FACING, ROTATION);
    }

    @Override
    public BlockState m_6843_(BlockState state, Rotation rotation) {
        return state.m_61124_(FACING, rotation.m_55954_(state.m_61143_(FACING)));
    }

    @Override
    public BlockState m_6943_(BlockState state, Mirror mirror) {
        return state.m_60717_(mirror.m_54846_(state.m_61143_(FACING)));
    }

    @Override
    public BlockState m_5573_(BlockPlaceContext context) {
        Direction clickedFace = context.m_43719_();
        BlockPos clickedOnPos = context.m_8083_().m_121945_(clickedFace.m_122424_());
        Level level = context.m_43725_();
        BlockState clickedOnState = level.m_8055_(clickedOnPos);

        if (clickedOnState.m_60734_() instanceof AbstractRotatableBlock && clickedFace.m_122434_() == Axis.Y) {
            return m_49966_()
                    .m_61124_(FACING, clickedOnState.m_61143_(FACING))
                    .m_61124_(ROTATION, clickedOnState.m_61143_(ROTATION));
        }

        int rot = Mth.m_14143_((180.0f + context.m_7074_()) * (float) TOTAL_ROTATION_STEPS / 360.0f + 0.5f) & (TOTAL_ROTATION_STEPS - 1);
        final int stepsPerSide = TOTAL_ROTATION_STEPS / 4;
        Direction dir = Direction.m_122407_((rot + stepsPerSide / 2) / stepsPerSide);
        int fineIndex = stepsPerSide - 1 - ((rot + stepsPerSide / 2) % stepsPerSide);

        return m_49966_()
                .m_61124_(FACING, dir)
                .m_61124_(ROTATION, fineIndex);
    }

    @Override
    public VoxelShape getBaseShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return Shapes.m_83144_();
    }

    @Override
    public VoxelShape m_5940_(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return shapeCache.computeIfAbsent(
                shapeHash(level, pos, state),
                k -> buildRotatedShape(state, level, pos, context));
    }

    protected int shapeHash(BlockGetter level, BlockPos pos, BlockState state) {
        return state.hashCode();
    }

    public static int signedRotationIndex(BlockState state) {
        return state.m_61143_(ROTATION) - ROTATION_OFFSET;
    }

    @Deprecated
    public static int normalizedPropertyRotationIndex(BlockState state) {
        return signedRotationIndex(state);
    }

    @Override
    public float getRelativeYRotation(BlockState state) {
        return fineAngle(signedRotationIndex(state));
    }

    public static float getRelativeYRotation(BlockState state, boolean unused) {
        return fineAngle(signedRotationIndex(state));
    }

    @Override
    public float getYRotation(BlockState state) {
        return facingAngle(state.m_61143_(FACING)) + getRelativeYRotation(state);
    }

    public float rotationOfFacingDirection(BlockState state) {
        return facingAngle(state.m_61143_(FACING));
    }

    @Override
    public Vec2 rotatedPivotPoint(BlockState state) {
        Vec2 local = getRotationPivotPoint(state);
        Vec2 rotated = rotateVec2(local, facingAngle(state.m_61143_(FACING)));
        return new Vec2(rotated.f_82470_ + 0.5f, rotated.f_82471_ + 0.5f);
    }

    @Override
    public BlockHitResult checkClickedFace(Level level, Player player, BlockHitResult hit) {
        BlockPos pos = hit.m_82425_();
        BlockState state = level.m_8055_(pos);
        Direction targetDir = hit.m_82434_();

        if (targetDir.m_122434_() != Axis.Y) {
            Vec3 clicked = hit.m_82450_().m_82492_(pos.m_123341_(), pos.m_123342_(), pos.m_123343_());
            Vec2 pivot = rotatedPivotPoint(state);
            float angle = getRelativeYRotation(state);
            Vec2 offset = getOffset(state);

            float cx = (float)clicked.f_82479_ - offset.f_82470_;
            float cz = (float)clicked.f_82481_ - offset.f_82471_;
            float radians = (float) Math.toRadians(angle);
            float cos = (float) Math.cos(radians);
            float sin = (float) Math.sin(radians);
            float tx = cx - pivot.f_82470_;
            float tz = cz - pivot.f_82471_;
            float unrotX = tx * cos - tz * sin + pivot.f_82470_;
            float unrotZ = tx * sin + tz * cos + pivot.f_82471_;

            VoxelShape base = getBaseShape(state, level, pos, null);
            AABB aabb = base.m_83215_();
            targetDir = nearestFaceOfAABB(aabb, unrotX, unrotZ);
        }
        return hit.m_82432_(targetDir);
    }

    private Direction nearestFaceOfAABB(AABB aabb, float x, float z) {
        float dNorth = Math.abs(z - (float)aabb.f_82290_);
        float dSouth = Math.abs(z - (float)aabb.f_82293_);
        float dWest = Math.abs(x - (float)aabb.f_82288_);
        float dEast = Math.abs(x - (float)aabb.f_82291_);

        float min = Math.min(Math.min(dNorth, dSouth), Math.min(dWest, dEast));

        if (min == dNorth) return Direction.NORTH;
        if (min == dSouth) return Direction.SOUTH;
        if (min == dWest) return Direction.WEST;
        return Direction.EAST;
    }

    protected BlockPos relativeTo(BlockAndTintGetter level, BlockState state, BlockPos pos, Direction direction) {
        BlockPos result = pos.m_121945_(direction);
        if (level.m_8055_(pos).m_60713_(state.m_60734_()) && signedRotationIndex(state) >= ROTATIONS) {
            result = result.m_121945_(direction.m_122428_());
        }
        return result;
    }

    protected BlockPos getSupportBlockPos(BlockGetter level, BlockPos pos, BlockState state) {
        Direction facing = state.m_61143_(FACING);
        BlockPos relativePos = pos.m_121945_(facing.m_122424_());
        if (level.m_8055_(pos).m_60734_() instanceof AbstractRotatableBlock && getRelativeYRotation(state) > 30f) {
            relativePos = relativePos.m_121945_(facing.m_122427_());
        }
        return relativePos;
    }


    private VoxelShape buildRotatedShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        VoxelShape base = getBaseShape(state, level, pos, context);
        float yaw = getRelativeYRotation(state);
        Vec2 pivot = rotatedPivotPoint(state);
        Vec2 offset = getOffset(state);
        VoxelShape rotated = VoxelShapeRotator.rotateY(base, yaw, new Vec3(pivot.f_82470_, 0.5, pivot.f_82471_));
        if (offset.f_82470_ == 0f && offset.f_82471_ == 0f) {
            return rotated;
        }
        List<AABB> shifted = new ArrayList<>();
        for (AABB aabb : rotated.m_83299_()) {
            shifted.add(aabb.m_82386_(offset.f_82470_, 0, offset.f_82471_));
        }

        VoxelShape result = Shapes.m_83040_();
        for (AABB aabb : shifted) {
            result = Shapes.m_83148_(result, Shapes.m_83064_(aabb), BooleanOp.f_82695_);
        }
        return result.m_83296_();
    }

    private static float facingAngle(Direction facing) {
        return switch (facing) {
            case EAST -> 270f;
            case SOUTH -> 180f;
            case WEST -> 90f;
            default -> 0f;
        };
    }

    private static float fineAngle(int rotationIndex) {
        return (float) Math.toDegrees(Math.atan((double) rotationIndex / ROTATIONS));
    }

    private static Vec2 rotateVec2(Vec2 v, float angleDeg) {
        float rad = (float) Math.toRadians(angleDeg);
        float cos = (float) Math.cos(rad);
        float sin = (float) Math.sin(rad);
        return new Vec2(v.f_82470_ * cos + v.f_82471_ * sin, -v.f_82470_ * sin + v.f_82471_ * cos);
    }

    private static Direction nearestFace(VoxelShape baseShape, Vec3 point) {
        AABB outer = null;
        for (AABB box : baseShape.m_83299_()) {
            outer = (outer == null) ? box : outer.m_82367_(box);
        }
        if (outer == null) {
            outer = new AABB(0, 0, 0, 1, 1, 1);
        }

        double dNorth = Math.abs(point.f_82481_ - outer.f_82290_);
        double dSouth = Math.abs(point.f_82481_ - outer.f_82293_);
        double dWest = Math.abs(point.f_82479_ - outer.f_82288_);
        double dEast = Math.abs(point.f_82479_ - outer.f_82291_);
        double dDown = Math.abs(point.f_82480_ - outer.f_82289_);
        double dUp = Math.abs(point.f_82480_ - outer.f_82292_);

        double min = Math.min(Math.min(Math.min(dNorth, dSouth), Math.min(dWest, dEast)), Math.min(dDown, dUp));

        if (min == dNorth) return Direction.NORTH;
        if (min == dSouth) return Direction.SOUTH;
        if (min == dWest) return Direction.WEST;
        if (min == dEast) return Direction.EAST;
        if (min == dDown) return Direction.DOWN;
        return Direction.UP;
    }

    private static Direction rotateDirection(Direction dir, float[][] matrix) {
        Vec3 normal  = new Vec3(dir.m_122429_(), dir.m_122430_(), dir.m_122431_());
        Vec3 rotated = VoxelShapeRotator.applyMatrix(normal, matrix, Vec3.f_82478_);

        Direction best   = dir;
        double    bestDot = -Double.MAX_VALUE;
        for (Direction candidate : Direction.values()) {
            double dot = rotated.m_82526_(new Vec3(candidate.m_122429_(), candidate.m_122430_(), candidate.m_122431_()));
            if (dot > bestDot) {
                bestDot = dot;
                best    = candidate;
            }
        }
        return best;
    }
}