package de.mrjulsen.wires.block;

import de.mrjulsen.wires.graph.WireGraphManager;
import de.mrjulsen.wires.util.NodeId;

import java.util.Optional;

import org.joml.Vector3d;
import org.joml.Vector3f;

import com.simibubi.create.foundation.blockEntity.SyncedBlockEntity;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;

public class WireConnectorBlockEntity extends SyncedBlockEntity implements IBlockEntityExtension {

    private static final String NBT_NODE_ID = "NodeId";

    private boolean wasUnloaded = false;
    private NodeId nodeId;

    public WireConnectorBlockEntity(BlockEntityType<?> type, BlockPos pos, BlockState state) {
        super(type, pos, state);
    }
    

    @Override
    protected void m_183515_(CompoundTag tag) {
        super.m_183515_(tag);
        if (nodeId != null) tag.m_128365_(NBT_NODE_ID, nodeId.toNbt());
    }

    @Override
    public void m_142466_(CompoundTag tag) {
        super.m_142466_(tag);
        if (tag.m_128441_(NBT_NODE_ID)) this.nodeId = NodeId.fromNbt(tag.m_128469_(NBT_NODE_ID));
    }

    public boolean wasUnloaded() {
        return wasUnloaded;
    }

    @Override
    public void onChunkUnloaded() {
        wasUnloaded = true;
    }

    @Override
    public void onBlockEntityLoad() {
        super.onLoad();
        wasUnloaded = false;
    }

	@Override
	public void m_7651_() {
		super.m_7651_();
        if (!wasUnloaded() && !f_58857_.f_46443_) {
            if (nodeId != null) {
                WireGraphManager.get(f_58857_, nodeId.graphId()).removeNode(nodeId.id(), new Vector3d(m_58899_().m_123341_() + 0.5f, m_58899_().m_123342_() + 0.5f, m_58899_().m_123343_() + 0.5f), Optional.empty());
            }
        }
        wasUnloaded = false;
	} 

    public NodeId getNodeId() {
        return nodeId;
    }

    public void setNodeId(NodeId id) {
        this.nodeId = id;
        notifyUpdate();
    }
}
