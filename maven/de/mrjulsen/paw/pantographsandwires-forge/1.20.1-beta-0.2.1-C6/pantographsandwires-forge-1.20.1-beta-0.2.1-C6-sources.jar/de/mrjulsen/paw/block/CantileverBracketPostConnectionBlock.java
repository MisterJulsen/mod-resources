package de.mrjulsen.paw.block;

import java.util.function.Supplier;

import de.mrjulsen.paw.block.abstractions.IHorizontalExtensionConnectable;
import de.mrjulsen.paw.block.abstractions.IHorizontalExtensionConnectable.EPostType;
import de.mrjulsen.paw.block.abstractions.IWeatheringBlock;
import de.mrjulsen.paw.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.MapColor;

public class CantileverBracketPostConnectionBlock extends CantileverBracketBaseBlock<CantileverBracketPostConnectionBlock> {

    public CantileverBracketPostConnectionBlock(Properties properties, IWeatheringBlock.WeatherData<CantileverBracketPostConnectionBlock> weatheringData) {
        super(properties.m_284180_(MapColor.f_283906_), weatheringData);

        this.m_49959_(m_49966_()
        );
    }

    @Override
    public BlockState m_7417_(BlockState state, Direction direction, BlockState neighborState, LevelAccessor level, BlockPos currentPos, BlockPos neighborPos) {
        if (direction == state.m_61143_(FACING).m_122424_()) {
            BlockPos supportPos = currentPos.m_121945_(direction);
            BlockState supportState = level.m_8055_(supportPos);
            boolean supportIsPost = supportState.m_60734_() instanceof IHorizontalExtensionConnectable conn && conn.postConnectionType(level, supportState, supportPos, state, currentPos) == EPostType.LATTICE;
            
            if (!supportIsPost) {
                state = ModBlocks.CANTILEVER_BRACKET.get(new ModBlocks.OxidizingKey(getWeatheringData().ageState(), getWeatheringData().isWaxed())).getDefaultState()
                    .m_61124_(FACING, state.m_61143_(FACING))
                    .m_61124_(ROTATION, state.m_61143_(ROTATION))
                    .m_61124_(MULTIPART_SEGMENT, state.m_61143_(MULTIPART_SEGMENT))
                ;
            }
        }
        return state;
    }
}
