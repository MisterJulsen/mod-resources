package de.mrjulsen.paw.block;

import java.util.function.Supplier;

import de.mrjulsen.paw.block.abstractions.AbstractRotatableBlock;
import de.mrjulsen.paw.block.abstractions.IHorizontalExtensionConnectable;
import de.mrjulsen.paw.block.abstractions.IWeatheringBlock;
import de.mrjulsen.paw.block.extended.BlockPlaceContextExtension;
import de.mrjulsen.paw.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Direction.Axis;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition.Builder;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.jetbrains.annotations.NotNull;

public class CantileverBracketVerticalBlock extends AbstractRotatableBlock implements IHorizontalExtensionConnectable, IWeatheringBlock<CantileverBracketVerticalBlock> {

    private static final VoxelShape SHAPE = Block.m_49796_(6, 0, 6, 10, 16, 10);

    public static final DirectionProperty DIRECTION = BlockStateProperties.f_155997_;
    
    private final IWeatheringBlock.WeatherData<CantileverBracketVerticalBlock> weatheringData;

    public CantileverBracketVerticalBlock(Properties properties, IWeatheringBlock.WeatherData<CantileverBracketVerticalBlock> weatheringData) {
        super(properties.m_284180_(MapColor.f_283906_));

        this.weatheringData = weatheringData;

        this.m_49959_(m_49966_()
            .m_61124_(DIRECTION, Direction.DOWN)
        );

    }    

    @Override
    public ItemStack m_7397_(BlockGetter level, BlockPos pos, BlockState state) {
        return new ItemStack(ModBlocks.CANTILEVER_BRACKET.get(new ModBlocks.OxidizingKey(getWeatheringData().ageState(), getWeatheringData().isWaxed())).get());
    }
    
    @Override
    protected void m_7926_(Builder<Block, BlockState> pBuilder) {
        super.m_7926_(pBuilder);
        pBuilder.m_61104_(DIRECTION);
    }

    @Override
    public BlockState m_5573_(BlockPlaceContext context) {
        BlockPlaceContextExtension ctxExt = (BlockPlaceContextExtension)(Object)context;
        BlockState state = super.m_5573_(context);
        BlockState clickedOnState = ctxExt.getPlacedOnState();
        Direction clickedFace = context.m_43719_();
        
        if (clickedOnState.m_60713_(this) && clickedFace.m_122434_().m_122478_()) {
            state = state
                .m_61124_(DIRECTION, clickedFace)
            ;
        }

        return state;
    }

    @Override
    public boolean m_7898_(BlockState state, LevelReader level, BlockPos pos) {
        if (state.m_61143_(DIRECTION) == Direction.DOWN) {
            BlockState aboveState = level.m_8055_(pos.m_7494_());
            if (!(aboveState.m_60734_() instanceof CantileverBracketVerticalBlock) && (!(aboveState.m_60734_() instanceof CantileverBracketBlock) || aboveState.m_61143_(CantileverBracketBlock.MULTIPART_SEGMENT) != CantileverBracketBlock.DEFAULT_SEGMENT)) {
                return false;
            }
        } else if (state.m_61143_(DIRECTION) == Direction.UP) {
            BlockState belowState = level.m_8055_(pos.m_7495_());
            if (!(belowState.m_60734_() instanceof CantileverBracketVerticalBlock) && (!(belowState.m_60734_() instanceof CantileverBracketBlock) || belowState.m_61143_(CantileverBracketBlock.MULTIPART_SEGMENT) != CantileverBracketBlock.DEFAULT_SEGMENT)) {
                return false;
            }
        }
        return true;
    }

    @Override
    public BlockState m_7417_(BlockState state, Direction direction, BlockState neighborState, LevelAccessor level, BlockPos currentPos, BlockPos neighborPos) {
        if (direction.m_122434_() == Axis.Y) {
            if (!m_7898_(state, level, currentPos)) {
                return Blocks.f_50016_.m_49966_();
            }
        }
        return state;
    }

    @Override
    public VoxelShape getBaseShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return SHAPE;
    }

    @Override
    public Axis transformOnAxis(BlockState state) {
        return null;
    }

    @Override
    public EPostType postConnectionType(LevelReader level, BlockState state, BlockPos pos, BlockState extensionState, BlockPos extensionPos) {
        return EPostType.FENCE;
    }

    public void m_213898_(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        this.m_220947_(state, level, pos, random);
    }

    public boolean m_6724_(BlockState state) {
        return getNext().isPresent();
    }

    @Override
    public @NotNull IWeatheringBlock.WeatherData<CantileverBracketVerticalBlock> getWeatheringData() {
        return weatheringData;
    }

    @Override
    public float m_142377_() {
        if (getWeatheringData().isWaxed()) return 0;
        return IWeatheringBlock.super.m_142377_();
    }
}
