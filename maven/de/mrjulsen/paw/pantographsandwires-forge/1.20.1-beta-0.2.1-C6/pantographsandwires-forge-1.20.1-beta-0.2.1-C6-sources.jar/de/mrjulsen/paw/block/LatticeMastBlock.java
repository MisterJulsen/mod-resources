package de.mrjulsen.paw.block;

import java.util.function.Supplier;

import de.mrjulsen.paw.block.abstractions.AbstractMultipartPostBlock;
import de.mrjulsen.paw.block.abstractions.IWeatheringBlock;
import de.mrjulsen.paw.block.abstractions.weathering.IAgingBlock;
import de.mrjulsen.paw.block.property.EPostPart;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.jetbrains.annotations.NotNull;

public class LatticeMastBlock extends AbstractMultipartPostBlock implements IWeatheringBlock<LatticeMastBlock> {

    private final VoxelShape BASE_SHAPE = Block.m_49796_(2, 0, 2, 14, 16, 14);
    private final VoxelShape FOUNDATION_SHAPE = Shapes.m_83110_(BASE_SHAPE, Block.m_49796_(0.5d, -5, 0.5d, 15.5d, 4, 15.5d));

    private final WeatherData<LatticeMastBlock> weatheringData;

    public LatticeMastBlock(Properties properties, WeatherData<LatticeMastBlock> weatheringData) {
        super(properties
            .m_284180_(MapColor.f_283906_)
        );

        this.weatheringData = weatheringData;
    }
    
    @Override
    public VoxelShape getBaseShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return state.m_61143_(PART) == EPostPart.BOTTOM ? FOUNDATION_SHAPE : BASE_SHAPE;
    }

    @Override
    public EPostType postConnectionType(LevelReader level, BlockState state, BlockPos pos, BlockState cantileverState, BlockPos cantileverPos) {
        return EPostType.LATTICE;
    }

    public void m_213898_(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        this.m_220947_(state, level, pos, random);
    }

    public boolean m_6724_(BlockState state) {
        return getNext().isPresent();
    }

    @Override
    public @NotNull WeatherData<LatticeMastBlock> getWeatheringData() {
        return weatheringData;
    }

    @Override
    public float m_142377_() {
        if (getWeatheringData().isWaxed()) return 0;
        return IWeatheringBlock.super.m_142377_();
    }
}
