package de.mrjulsen.paw.block;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

public abstract class AbstractPlaceableStandingInsulatorBlock extends AbstractPlaceableInsulatorBlock {

    public AbstractPlaceableStandingInsulatorBlock(Properties properties) {
        super(properties);
    }

    @Override
    public BlockState m_5573_(BlockPlaceContext context) {
        BlockPos clickPos = context.m_8083_();
        Level level = context.m_43725_();
        BlockState state = super.m_5573_(context);
        BlockPos belowPos = clickPos.m_7495_();
        BlockState belowState = level.m_8055_(belowPos);
        
        if (belowState.m_60734_() instanceof PowerLineBracketBlock) {
            state = state
                .m_61124_(MULTIPART_SEGMENT, belowState.m_61143_(MULTIPART_SEGMENT))
                .m_61124_(FACING, belowState.m_61143_(FACING))
                .m_61124_(ROTATION, belowState.m_61143_(ROTATION))
            ;
        }
        return state;
    }

    @Override
    public boolean m_7898_(BlockState state, LevelReader level, BlockPos pos) {
        BlockPos belowPos = pos.m_7495_();
        BlockState belowState = level.m_8055_(belowPos);
        return m_49863_(level, belowPos, Direction.UP) || (belowState.m_60734_() instanceof PowerLineBracketBlock);
    }

    @SuppressWarnings("deprecation")
    public BlockState m_7417_(BlockState state, Direction direction, BlockState neighborState, LevelAccessor level, BlockPos currentPos, BlockPos neighborPos) {
        return !this.m_7898_(state, level, currentPos) ? Blocks.f_50016_.m_49966_() : super.m_7417_(state, direction, neighborState, level, currentPos, neighborPos);
    }
}
