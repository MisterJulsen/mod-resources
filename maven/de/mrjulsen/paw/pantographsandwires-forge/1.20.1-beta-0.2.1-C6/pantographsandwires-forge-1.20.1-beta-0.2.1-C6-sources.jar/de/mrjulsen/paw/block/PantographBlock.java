package de.mrjulsen.paw.block;

import com.simibubi.create.foundation.block.IBE;

import de.mrjulsen.paw.blockentity.PantographBlockEntity;
import de.mrjulsen.paw.registry.ModBlockEntities;
import de.mrjulsen.paw.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition.Builder;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

public class PantographBlock extends Block implements IBE<PantographBlockEntity> {

	public static final DirectionProperty FACING = HorizontalDirectionalBlock.f_54117_;

    private static final VoxelShape SHAPE = Block.m_49796_(-2, 0, -2, 18, 8, 18);

    public PantographBlock(Properties properties) {
        super(properties
            .m_60955_()
        );

        this.m_49959_(this.f_49792_.m_61090_()
            .m_61124_(FACING, Direction.NORTH)
        );
    }

    @Override
    public ItemStack m_7397_(BlockGetter level, BlockPos pos, BlockState state) {
        return ModItems.PANTOGRAPH.asStack();
    }

    @Override
    public InteractionResult m_6227_(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {        
		if (level.m_7702_(pos) instanceof PantographBlockEntity be) {
			be.toggleExpandable();
        }
        
        return InteractionResult.SUCCESS;
    }
    
    @Override
    public RenderShape m_7514_(BlockState state) {
        return RenderShape.ENTITYBLOCK_ANIMATED;
    }    

    @Override
    public BlockState m_6843_(BlockState pState, Rotation pRotation) {
        return pState.m_61124_(FACING, pRotation.m_55954_(pState.m_61143_(FACING)));
    }    

    @Override
    public BlockState m_6943_(BlockState pState, Mirror pMirror) {
        return pState.m_60717_(pMirror.m_54846_(pState.m_61143_(FACING)));
    }
    
    @Override
    protected void m_7926_(Builder<Block, BlockState> pBuilder) {
        super.m_7926_(pBuilder);
        pBuilder.m_61104_(FACING);
    }

    
    @Override
	public BlockState m_5573_(BlockPlaceContext context) {
        return super.m_49966_()        
            .m_61124_(FACING, context.m_8125_().m_122424_())
        ;
	}

    @Override
    public VoxelShape m_5940_(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return SHAPE;
    }

    @Override
    public Class<PantographBlockEntity> getBlockEntityClass() {
        return PantographBlockEntity.class;
    }

    @Override
    public BlockEntityType<? extends PantographBlockEntity> getBlockEntityType() {
        return ModBlockEntities.PANTOGRAPH_BLOCK_ENTITY.get();
    }
    
}
