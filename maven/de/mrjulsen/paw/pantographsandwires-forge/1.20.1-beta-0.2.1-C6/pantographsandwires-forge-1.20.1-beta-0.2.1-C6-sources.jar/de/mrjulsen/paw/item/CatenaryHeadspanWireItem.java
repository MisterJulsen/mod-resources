package de.mrjulsen.paw.item;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BiConsumer;

import de.mrjulsen.paw.registry.ModBlockTags;
import org.joml.Vector3d;

import de.mrjulsen.mcdragonlib.util.TextUtils;
import de.mrjulsen.paw.PantographsAndWires;
import de.mrjulsen.paw.client.gui.ModGuiIcons;
import de.mrjulsen.paw.config.ModServerConfig;
import de.mrjulsen.paw.data.WireHitResult;
import de.mrjulsen.paw.registry.ModWireRegistry;
import de.mrjulsen.wires.IWireType;
import de.mrjulsen.wires.WiresApi;
import de.mrjulsen.wires.graph.data.node.LatticeMastNodeData;
import de.mrjulsen.wires.graph.data.node.NodeData;
import de.mrjulsen.wires.graph.registry.DLStaticRegistryObject;
import de.mrjulsen.wires.graph.WireGraph;
import de.mrjulsen.wires.graph.WireGraphClient;
import de.mrjulsen.wires.graph.WireGraphManager;
import de.mrjulsen.wires.item.IPawWireItemBase;
import de.mrjulsen.wires.item.IWireItemBase;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;

public class CatenaryHeadspanWireItem implements IPawWireItemBase {
    
    public static final String NBT_UPPER_WIRE_HEIGHT = "UpperWireHeight";
    public static final String NBT_TOP_WIRE_HEIGHT = "TopWireHeight";
    
	private static final String KEY_HEIGHT_DIFFERENCE_TOO_SMALL = "item." + PantographsAndWires.MOD_ID + ".catenary_headspan.small_height_difference";
	private static final String KEY_HEIGHT_DIFFERENCE_TOO_LARGE = "item." + PantographsAndWires.MOD_ID + ".catenary_headspan.large_height_difference";


    @Override
    public InteractionResult interactWithWire(Level level, Player player, InteractionHand hand, WireHitResult hit) {
        return placeWire(level, player, hand, hit, (a, b) -> {});
    }

    @Override
    public IWireType getWireType(ItemStack stack) {
        return ModWireRegistry.CATENARY_HEADSPAN;
    }    

    @Override
    public DLStaticRegistryObject<IPawWireItemBase> getRegistryType() {
        return (DLStaticRegistryObject<IPawWireItemBase>)(Object)ModWireRegistry.CATENARY_HEADSPAN_ITEM_SUBTYPE;
    }  

    @Override
    public String getTranslationKey() {
        return "wire." + PantographsAndWires.MOD_ID + ".catenary_headspan";
    }

    @Override
    public ModGuiIcons getIcon() {
        return ModGuiIcons.CATENARY_HEADSPAN_WIRE;
    }

    @Override
    public NodeData createNodeData(Level level, Player player, InteractionHand hand, HitResult hit) {
        if (hit instanceof BlockHitResult h && level.m_8055_(h.m_82425_()).m_204343_().anyMatch(x -> x.equals(ModBlockTags.CATENARY_HEADSPAN_CONNECTABLE))) {
            return new LatticeMastNodeData(h.m_82425_());
        }
        return null;
    }

    @Override
    public InteractionResult placeWire(Level level, Player player, InteractionHand hand, HitResult hit, BiConsumer<CompoundTag, CompoundTag> metadata) { 
        if (level.m_5776_()) {
            return InteractionResult.PASS;
        }
        ItemStack stack = player.m_21120_(hand);
        if (!(stack.m_41720_() instanceof IWireItemBase)) {
            return InteractionResult.FAIL;
        }

        // --- Decode Item data ---
        CompoundTag itemData = IWireItemBase.getNbt(stack);
        CompoundTag customDataNbt = itemData.m_128469_(NBT_CUSTOM_DATA);
        List<CompoundTag> points = new ArrayList<>();        
        if (itemData.m_128441_(NBT_POINTS)) {
            points.addAll(itemData.m_128437_(NBT_POINTS, Tag.f_178203_).stream().map(x -> (CompoundTag)x).toList());
        }

        // --- Set data ---
        if (points.size() < 2) {
            if (!addNewPoint(level, player, hand, hit, metadata, stack, itemData, customDataNbt, points)) {
                IWireItemBase.clear(null, stack);
                return InteractionResult.FAIL;
            }
        } else if (!customDataNbt.m_128441_(NBT_UPPER_WIRE_HEIGHT) || !customDataNbt.m_128441_(NBT_TOP_WIRE_HEIGHT)) {
            CompoundTag startPointData = points.get(0);
            CompoundTag endPointData = points.get(1);
            NodeData nodeA = WiresApi.NODE_DATA_REGISTRY.load(startPointData);
            NodeData nodeB = WiresApi.NODE_DATA_REGISTRY.load(endPointData);

            if (nodeA instanceof LatticeMastNodeData nA && nodeB instanceof LatticeMastNodeData nB) {                
                if (hit instanceof BlockHitResult h && level.m_8055_(h.m_82425_()).m_204343_().anyMatch(x -> x.equals(ModBlockTags.CATENARY_HEADSPAN_CONNECTABLE))) {
                    if (!customDataNbt.m_128441_(NBT_UPPER_WIRE_HEIGHT)) {
                        int min = ModServerConfig.CATENARY_HEADSPAN_MIN_UPPER_TENSION_WIRE.get();
                        int max = ModServerConfig.CATENARY_HEADSPAN_MAX_UPPER_TENSION_WIRE.get();
                        float d = h.m_82425_().m_123342_() - nB.getBlockPos().m_123342_();
                        if (d < min) { 
                            player.m_5661_(TextUtils.translate(KEY_HEIGHT_DIFFERENCE_TOO_SMALL, min, max).m_130940_(ChatFormatting.RED), true);
                            IWireItemBase.clear(null, stack);
                            return InteractionResult.FAIL;
                        } else if (d > max) { 
                            player.m_5661_(TextUtils.translate(KEY_HEIGHT_DIFFERENCE_TOO_LARGE, min, max).m_130940_(ChatFormatting.RED), true);
                            IWireItemBase.clear(null, stack);
                            return InteractionResult.FAIL;
                        }
                        customDataNbt.m_128350_(NBT_UPPER_WIRE_HEIGHT, d);
                    } else if (!customDataNbt.m_128441_(NBT_TOP_WIRE_HEIGHT)) {
                        double p = customDataNbt.m_128457_(NBT_UPPER_WIRE_HEIGHT);
                        double min = p + calcSupportWireMinHeightDifference(new Vector3d(nA.getBlockPos().m_123341_(), nA.getBlockPos().m_123342_(), nA.getBlockPos().m_123343_()), new Vector3d(nB.getBlockPos().m_123341_(), nB.getBlockPos().m_123342_(), nB.getBlockPos().m_123343_()));
                        double max = min + ModServerConfig.CATENARY_HEADSPAN_MAX_TOP_SUPPORT_WIRE.get();
                        double d = h.m_82425_().m_123342_() - nB.getBlockPos().m_123342_() - p;
                        if (d < min) { 
                            player.m_5661_(TextUtils.translate(KEY_HEIGHT_DIFFERENCE_TOO_SMALL, min, max).m_130940_(ChatFormatting.RED), true);
                            IWireItemBase.clear(null, stack);
                            return InteractionResult.FAIL;
                        } else if (d > max) { 
                            player.m_5661_(TextUtils.translate(KEY_HEIGHT_DIFFERENCE_TOO_LARGE, min, max).m_130940_(ChatFormatting.RED), true);
                            IWireItemBase.clear(null, stack);
                            return InteractionResult.FAIL;
                        }
                        customDataNbt.m_128347_(NBT_TOP_WIRE_HEIGHT, d); // TODO was float
                    }
                }
            }
        }

        // --- Save data ---
        ListTag pointsList = new ListTag();
        for (CompoundTag p : points) {
            pointsList.add(p);
        }
        itemData.m_128365_(NBT_POINTS, pointsList);
        itemData.m_128365_(NBT_CUSTOM_DATA, customDataNbt);
        IWireItemBase.setNbt(stack, itemData);

        // --- Create wire ---
        if (canCreateWire(level, player, hand, hit, stack, itemData, customDataNbt, points)) {
            WireGraph.CreateEdgeResult result = createWire(level, player, hand, hit, stack, itemData, customDataNbt, points);
            if (result.success()) {
                removeWireItem(level, player, hand, hit, stack, result.edge().get().length());
            }
        }
        
        return InteractionResult.SUCCESS;
    }

    @Override
    public boolean canCreateWire(Level level, Player player, InteractionHand hand, HitResult hit, ItemStack stack, CompoundTag itemData, CompoundTag customDataNbt, List<CompoundTag> points) {
        return IPawWireItemBase.super.canCreateWire(level, player, hand, hit, stack, itemData, customDataNbt, points) && customDataNbt.m_128441_(NBT_UPPER_WIRE_HEIGHT) && customDataNbt.m_128441_(NBT_TOP_WIRE_HEIGHT);
    }

    @Override
    public Component createHudInfoText(ItemStack stack, Player player, HitResult hit) {
        if (!stack.m_41782_()) {
            return null;
        }
        
        CompoundTag itemData = IWireItemBase.getNbt(stack);
        ListTag list = itemData.m_128437_(NBT_POINTS, Tag.f_178203_);
        if (list.size() < 2) {
            return IPawWireItemBase.super.createHudInfoText(stack, player, hit);
        }

        WireGraphClient graph = WireGraphManager.getClient(player.m_9236_(), getWireType(stack).getGraphId(itemData));
        if (graph == null || list.isEmpty()) {
            return null;
        }

        

        CompoundTag customDataNbt = itemData.m_128469_(NBT_CUSTOM_DATA);
        CompoundTag startPointData = (CompoundTag)list.get(0);
        CompoundTag endPointData = (CompoundTag)list.get(1);
        NodeData nodeA = WiresApi.NODE_DATA_REGISTRY.load(startPointData);
        NodeData nodeB = WiresApi.NODE_DATA_REGISTRY.load(endPointData);
        Vector3d pos = nodeB.toWorldPos(graph);
        Vector3d targetPos;
        if (hit instanceof BlockHitResult r) {
            targetPos = new Vector3d(r.m_82450_().m_7096_(), r.m_82450_().m_7098_(), r.m_82450_().m_7094_());
        } else {
            targetPos = new Vector3d(player.m_146892_().m_7096_(), player.m_146892_().m_7098_(), player.m_146892_().m_7094_());
        }

        if (!customDataNbt.m_128441_(NBT_UPPER_WIRE_HEIGHT)) {
            int min = ModServerConfig.CATENARY_HEADSPAN_MIN_UPPER_TENSION_WIRE.get();
            int max = ModServerConfig.CATENARY_HEADSPAN_MAX_UPPER_TENSION_WIRE.get();
            int diff = (int)Math.floor(targetPos.y()) - (int)pos.y();
            return TextUtils.empty().m_130940_(ChatFormatting.WHITE)
                .m_7220_(TextUtils.text(String.format("Y: %s", (int)pos.y())).m_130940_(ChatFormatting.WHITE))
                .m_7220_(TextUtils.text(" \u25A0 ").m_130940_(ChatFormatting.GRAY))
                .m_7220_(TextUtils.text("Upper Tension Wire height difference").m_130940_(ChatFormatting.WHITE))
                .m_7220_(TextUtils.text(" \u25A0 ").m_130940_(ChatFormatting.GRAY))
                .m_7220_(TextUtils.text(String.format("%sm [%sm - %sm]", diff, min, max)).m_130940_(diff < min || diff > max ? ChatFormatting.RED : ChatFormatting.GREEN))
            ;
        } else if (!customDataNbt.m_128441_(NBT_TOP_WIRE_HEIGHT)) {
            double min = customDataNbt.m_128457_(NBT_UPPER_WIRE_HEIGHT) + calcSupportWireMinHeightDifference(nodeA.toWorldPos(graph), nodeB.toWorldPos(graph));
            double max = min + ModServerConfig.CATENARY_HEADSPAN_MAX_TOP_SUPPORT_WIRE.get();
            int diff = (int)(Math.floor(targetPos.y()) - pos.y() - min);
            return TextUtils.empty().m_130940_(ChatFormatting.WHITE)
                .m_7220_(TextUtils.text(String.format("Y: %s", (int)pos.y())).m_130940_(ChatFormatting.WHITE))
                .m_7220_(TextUtils.text(" \u25A0 ").m_130940_(ChatFormatting.GRAY))
                .m_7220_(TextUtils.text("Top Support Wire height difference").m_130940_(ChatFormatting.WHITE))
                .m_7220_(TextUtils.text(" \u25A0 ").m_130940_(ChatFormatting.GRAY))
                .m_7220_(TextUtils.text(String.format("%sm [%sm - %sm]", diff, min, max)).m_130940_(diff < min || diff > max ? ChatFormatting.RED : ChatFormatting.GREEN))
            ;
        }

        return TextUtils.empty();
    }

    public static int calcSupportWireMinHeightDifference(Vector3d a, Vector3d b) {
        return (int)(Math.floor(a.distance(b) / 16f));
    }
}
