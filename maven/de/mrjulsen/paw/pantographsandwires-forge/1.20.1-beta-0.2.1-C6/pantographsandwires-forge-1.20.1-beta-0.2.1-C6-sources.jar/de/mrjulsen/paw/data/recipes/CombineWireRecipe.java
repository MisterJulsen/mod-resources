package de.mrjulsen.paw.data.recipes;

import de.mrjulsen.paw.registry.ModItems;
import de.mrjulsen.paw.registry.ModRecipes;
import de.mrjulsen.wires.item.IPawWireItemBase;
import de.mrjulsen.wires.item.MultiWireItem;
import net.minecraft.core.NonNullList;
import net.minecraft.core.RegistryAccess;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.inventory.CraftingContainer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.CraftingBookCategory;
import net.minecraft.world.item.crafting.CustomRecipe;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.level.Level;

public class CombineWireRecipe extends CustomRecipe {

    public CombineWireRecipe(ResourceLocation id, CraftingBookCategory category) {
        super(id, category);
    }

    @Override
    public boolean matches(CraftingContainer container, Level level) {
        int wireCount = 0;
        Item wireType = null;

        for (int i = 0; i < container.m_6643_(); i++) {
            ItemStack stack = container.m_8020_(i);
            if (!stack.m_41619_()) {
                if (stack.m_41720_() instanceof MultiWireItem) {
                    if (wireType == null) {
                        wireType = stack.m_41720_();
                    } else if (wireType != stack.m_41720_()) {
                        return false;
                    }
                    wireCount++;
                } else {
                    return false;
                }
            }
        }

        return wireCount >= 2;
    }

    @Override
    public ItemStack assemble(CraftingContainer container, RegistryAccess registryAccess) {
        int totalWire = 0;
        ItemStack firstWire = ItemStack.f_41583_;

        for (int i = 0; i < container.m_6643_(); i++) {
            ItemStack stack = container.m_8020_(i);
            if (!stack.m_41619_() && stack.m_41720_() instanceof MultiWireItem) {
                totalWire += IPawWireItemBase.getRemainingWire(stack);
                if (firstWire.m_41619_()) {
                    firstWire = stack.m_41777_();
                }
            }
        }

        if (firstWire.m_41619_()) {
            return ItemStack.f_41583_;
        }

        int outputAmount = Math.min(totalWire, IPawWireItemBase.WIRE_LENGTH);
        firstWire.m_41764_(1);
        firstWire.m_41784_().m_128405_(IPawWireItemBase.NBT_WIRE_LENGTH, outputAmount);

        return firstWire;
    }

    @Override
    public boolean m_8004_(int width, int height) {
        return width * height >= 2;
    }

    @Override
    public NonNullList<ItemStack> getRemainingItems(CraftingContainer container) {
        NonNullList<ItemStack> remaining = NonNullList.m_122780_(container.m_6643_(), ItemStack.f_41583_);
        int totalWire = 0;

        for (int i = 0; i < container.m_6643_(); i++) {
            ItemStack stack = container.m_8020_(i);
            if (!stack.m_41619_() && stack.m_41720_() instanceof MultiWireItem) {
                totalWire += IPawWireItemBase.getRemainingWire(stack);
            }
        }

        int leftover = totalWire - IPawWireItemBase.WIRE_LENGTH;
        boolean skippedFirst = false;

        for (int i = 0; i < container.m_6643_(); i++) {
            ItemStack stack = container.m_8020_(i);
            if (!stack.m_41619_() && stack.m_41720_() instanceof MultiWireItem) {
                if (!skippedFirst) {
                    skippedFirst = true;
                    remaining.set(i, ItemStack.f_41583_);
                } else {
                    if (leftover > 0) {
                        int amount = Math.min(leftover, IPawWireItemBase.WIRE_LENGTH);
                        ItemStack remainingWire = new ItemStack(stack.m_41720_());
                        remainingWire.m_41784_().m_128405_(IPawWireItemBase.NBT_WIRE_LENGTH, amount);
                        remaining.set(i, remainingWire);
                        leftover -= amount;
                    } else {
                        remaining.set(i, ModItems.EMPTY_WIRE_COIL.asStack());
                    }
                }
            }
        }

        return remaining;
    }

    @Override
    public RecipeSerializer<?> m_7707_() {
        return ModRecipes.COMBINE_WIRE.get();
    }
}