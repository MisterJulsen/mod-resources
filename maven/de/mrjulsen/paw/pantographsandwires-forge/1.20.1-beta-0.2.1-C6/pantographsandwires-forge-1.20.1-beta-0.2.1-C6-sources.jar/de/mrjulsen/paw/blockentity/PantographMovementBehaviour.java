package de.mrjulsen.paw.blockentity;

import org.joml.Vector3d;

import com.simibubi.create.api.behaviour.movement.MovementBehaviour;
import com.simibubi.create.content.contraptions.behaviour.MovementContext;

import de.mrjulsen.paw.CrossPlatform;
import net.createmod.catnip.math.VecHelper;
import net.minecraft.core.Direction;
import net.minecraft.core.Direction.Axis;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.phys.Vec3;

public class PantographMovementBehaviour implements MovementBehaviour {

	@Override
	public void tick(MovementContext context) {       
        if (context.contraption.entity.m_9236_().m_5776_() && CrossPlatform.getClientContraptionBlockEntity(context.contraption, context.localPos) instanceof PantographBlockEntity be
        ) {
            Direction dir = context.state.m_61143_(HorizontalDirectionalBlock.f_54117_);
            if (dir.m_122434_() == Axis.X) {
                dir = dir.m_122424_();
            }
            final double yRot = dir.m_122435_();
            be.updateContraptionValues(new Vector3d(context.position.m_7096_(), context.position.m_7098_() - 0.5D + PantographBlockEntity.MIN_HEIGHT, context.position.m_7094_()), (v) -> {
                Vec3 r = VecHelper.rotate(new Vec3(v.x(), v.y(), v.z()), yRot, Axis.Y);
                r = context.rotation.apply(r);
                return new Vector3d(r.m_7096_(), r.m_7098_(), r.m_7094_());
            });
            be.contraptionTick();
        }
	}
}
