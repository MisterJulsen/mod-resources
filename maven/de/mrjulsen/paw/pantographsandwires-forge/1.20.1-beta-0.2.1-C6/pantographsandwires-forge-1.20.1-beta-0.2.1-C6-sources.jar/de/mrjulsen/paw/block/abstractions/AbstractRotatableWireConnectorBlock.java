package de.mrjulsen.paw.block.abstractions;

import com.simibubi.create.foundation.block.IBE;

import de.mrjulsen.wires.block.IWireConnector;
import de.mrjulsen.wires.block.WireConnectorBlockEntity;
import de.mrjulsen.wires.graph.data.provider.BasicConnectorDataProvider;
import de.mrjulsen.wires.graph.data.provider.ConnectorDataProvider;
import de.mrjulsen.wires.item.CustomData;
import net.createmod.catnip.math.VecHelper;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction.Axis;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.Vec3;

public abstract class AbstractRotatableWireConnectorBlock<T extends WireConnectorBlockEntity> extends AbstractRotatableBlock implements IBE<T>, IWireConnector {

    public AbstractRotatableWireConnectorBlock(Properties properties) {
        super(properties.m_284180_(MapColor.f_283906_).m_60955_());
    }

    @Override
    public RenderShape m_7514_(BlockState pState) {
        return RenderShape.MODEL;
    }

    protected Vec3 transformWireAttachPoint(Level level, BlockPos pos, BlockState state, CustomData itemData, int index, IWireRenderDataCallback func) {
        if (!(state.m_60734_() instanceof IWireConnector) || !(state.m_60734_() instanceof IRotatableBlock rot)) {
            return Vec3.f_82478_;
        }

        Vec2 pivot    = rot.getRotationPivotPoint(state);
        Vec2 rotPivot = rot.rotatedPivotPoint(state);
        Vec2 offset   = rot.getOffset(state);

        return VecHelper.rotate(
                        func.run(level, pos, state, itemData, index).m_82492_(pivot.f_82470_, 0, pivot.f_82471_),
                        getYRotation(state),
                        Axis.Y
                )
                .m_82520_(rotPivot.f_82470_, 0, rotPivot.f_82471_)
                .m_82520_(offset.f_82470_, 0, offset.f_82471_);
    }

    @Override
    public ConnectorDataProvider getConnectorData(Level level, BlockPos pos, CustomData customData, int connectionPointIndex) {
        return new BasicConnectorDataProvider(
                transformWireAttachPoint(level, pos, level.m_8055_(pos), customData, connectionPointIndex, this::defaultWireAttachPoint)
                        .m_252839_()
        );
    }

    protected abstract Vec3 defaultWireAttachPoint(Level level, BlockPos pos, BlockState state, CustomData itemData, int index);

    @FunctionalInterface
    protected interface IWireRenderDataCallback {
        Vec3 run(Level level, BlockPos pos, BlockState state, CustomData itemData, int index);
    }
}