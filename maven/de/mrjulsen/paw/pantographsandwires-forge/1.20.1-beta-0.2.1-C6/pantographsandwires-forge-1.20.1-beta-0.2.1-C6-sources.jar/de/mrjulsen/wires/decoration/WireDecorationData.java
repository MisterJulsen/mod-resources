package de.mrjulsen.wires.decoration;

import de.mrjulsen.paw.registry.ModWireRegistry;
import net.minecraft.nbt.CompoundTag;

public class WireDecorationData implements Comparable<WireDecorationData> {

    private static final String NBT_WIRE_NAME = "WireName";
    private static final String NBT_POS = "Pos";
    private static final String NBT_DATA = "Data";

    private final String wireName;
    private final double wirePos; // 1D Coordinate on the wire
    private final IWireDecoration<?> decoration;

    public WireDecorationData(String wireName, double wirePos, IWireDecoration<?> decoration) {
        this.wireName = wireName;
        this.wirePos = wirePos;
        this.decoration = decoration;
    }

    public String getWireName() {
        return wireName;
    }

    public double getPos() {
        return wirePos;
    }

    public IWireDecoration<?> getDecoration() {
        return decoration;
    }

    public CompoundTag toNbt() {
        CompoundTag nbt = new CompoundTag();
        nbt.m_128359_(NBT_WIRE_NAME, wireName);
        nbt.m_128347_(NBT_POS, wirePos);

        CompoundTag decorationNbt = decoration.getRegistryType().wrap(decoration);
        nbt.m_128365_(NBT_DATA, decorationNbt);
        return nbt;
    }

    public static WireDecorationData fromNbt(CompoundTag nbt) {
        IWireDecoration<?> decoration = ModWireRegistry.DECORATION_REGISTRY.load(nbt.m_128469_(NBT_DATA));

        return new WireDecorationData(
            nbt.m_128461_(NBT_WIRE_NAME),
            (nbt.m_128435_(NBT_POS) == CompoundTag.f_178198_) ? nbt.m_128457_(NBT_POS) : nbt.m_128459_(NBT_POS),
            decoration
        );
    }

    @Override
    public int compareTo(WireDecorationData o) {
        return Double.compare(wirePos, o.wirePos);
    }
}
