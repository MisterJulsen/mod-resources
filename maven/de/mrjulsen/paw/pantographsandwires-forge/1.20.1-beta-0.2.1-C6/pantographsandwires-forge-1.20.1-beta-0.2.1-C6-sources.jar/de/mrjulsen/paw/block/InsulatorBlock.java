package de.mrjulsen.paw.block;

import java.util.Objects;

import de.mrjulsen.paw.util.Const;
import de.mrjulsen.paw.util.ModMath;
import de.mrjulsen.wires.item.CustomData;
import de.mrjulsen.mcdragonlib.config.ECachingPriority;
import de.mrjulsen.mcdragonlib.util.MapCache;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Direction.Axis;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition.Builder;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.block.state.properties.Half;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

public class InsulatorBlock extends AbstractPlaceableInsulatorBlock {

    public static final EnumProperty<Half> HALF = BlockStateProperties.f_61402_;

    private static final VoxelShape SHAPE_BOTTOM = Block.m_49796_(5, 2, 5, 11, 16, 11);
    private static final VoxelShape SHAPE_TOP = Block.m_49796_(5, 0, 5, 11, 10, 11);

    
    protected static record TransformationShapeKeyExtension(Direction direction, int rotation, Half half, BlockState state) {
        @Override
        public final boolean equals(Object other) {
            if (other instanceof TransformationShapeKeyExtension o) {
                return direction().equals(o.direction()) && rotation() == o.rotation() && half() == o.half();
            }
            return false;
        }
        @Override
        public final int hashCode() {
            return Objects.hash(direction(), rotation(), half());
        }
    }

    private final MapCache<VoxelShape, TransformationShapeKeyExtension, TransformationShapeKeyExtension> shapesCache;

    public InsulatorBlock(Properties properties) {
        super(properties.m_284180_(MapColor.f_283906_)
            .m_60955_()
        );
        this.shapesCache = new MapCache<>((key) -> {
            VoxelShape baseShape = key.half() == Half.TOP ? SHAPE_TOP : SHAPE_BOTTOM;
            Direction direction = key.direction();
            VoxelShape result = ModMath.rotateShape(baseShape, Axis.Y, (int)direction.m_122424_().m_122435_());    
            return result;
        }, TransformationShapeKeyExtension::hashCode, ECachingPriority.ALWAYS);

        this.m_49959_(m_49966_()
            .m_61124_(HALF, Half.TOP)
        );
    }
    
    @Override
    protected void m_7926_(Builder<Block, BlockState> pBuilder) {
        super.m_7926_(pBuilder);
        pBuilder.m_61104_(HALF);
    }

    @Override
    public BlockState m_5573_(BlockPlaceContext context) {
        BlockPos clickPos = context.m_8083_();
        Level level = context.m_43725_();
        BlockState state = super.m_5573_(context);

        BlockPos abovePos = clickPos.m_7494_();
        BlockState aboveState = level.m_8055_(abovePos);
        BlockPos belowPos = clickPos.m_7495_();
        BlockState belowState = level.m_8055_(belowPos);
        
        if (aboveState.m_60734_() instanceof PowerLineBracketBlock) {
            state = state
                .m_61124_(MULTIPART_SEGMENT, aboveState.m_61143_(MULTIPART_SEGMENT))
                .m_61124_(FACING, aboveState.m_61143_(FACING))
                .m_61124_(ROTATION, aboveState.m_61143_(ROTATION))
                .m_61124_(HALF, Half.BOTTOM)
            ;
        } else if (belowState.m_60734_() instanceof PowerLineBracketBlock) {
            state = state
                .m_61124_(MULTIPART_SEGMENT, belowState.m_61143_(MULTIPART_SEGMENT))
                .m_61124_(FACING, belowState.m_61143_(FACING))
                .m_61124_(ROTATION, belowState.m_61143_(ROTATION))
                .m_61124_(HALF, Half.TOP)
            ;
        } else {
            state = state
                .m_61124_(HALF, context.m_43719_() == Direction.UP ? Half.TOP : Half.BOTTOM)
            ;
        }
        return state;
    }

    @Override
    public boolean m_7898_(BlockState state, LevelReader level, BlockPos pos) {
        BlockPos abovePos = pos.m_7494_();
        BlockState aboveState = level.m_8055_(abovePos);
        BlockPos belowPos = pos.m_7495_();
        BlockState belowState = level.m_8055_(belowPos);
        return switch (state.m_61143_(HALF)) {
            case TOP -> m_49863_(level, belowPos, Direction.UP) || (belowState.m_60734_() instanceof PowerLineBracketBlock && belowState.m_61143_(PowerLineBracketBlock.HALF) == Half.TOP);
            default -> m_49863_(level, abovePos, Direction.DOWN) || (aboveState.m_60734_() instanceof PowerLineBracketBlock && aboveState.m_61143_(PowerLineBracketBlock.HALF) == Half.BOTTOM);
        };
    }

    @SuppressWarnings("deprecation")
    public BlockState m_7417_(BlockState state, Direction direction, BlockState neighborState, LevelAccessor level, BlockPos currentPos, BlockPos neighborPos) {
        return !this.m_7898_(state, level, currentPos) ? Blocks.f_50016_.m_49966_() : super.m_7417_(state, direction, neighborState, level, currentPos, neighborPos);
    }

    @Override
    public VoxelShape getBaseShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        TransformationShapeKeyExtension key = new TransformationShapeKeyExtension(state.m_61143_(FACING), normalizedPropertyRotationIndex(state), state.m_61143_(HALF), state);
        return shapesCache.get(key, key);
    }

    @Override
    public Vec3 defaultWireAttachPoint(Level level, BlockPos pos, BlockState state, CustomData itemData, int index) {
        return state.m_61143_(HALF) == Half.TOP ? new Vec3(0, Const.PIXEL * 10f, 0) : new Vec3(0, Const.PIXEL * 3f, 0);
    }
}
