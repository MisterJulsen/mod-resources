package de.mrjulsen.wires.item;

import net.minecraft.nbt.CompoundTag;

public record CustomData(CompoundTag nbt) {
    
    public static final String NBT_POINTS = "CustomPointData";
    public static final String NBT_CUSTOM_DATA = "CustomData";

    public CompoundTag getCustomDataForPoint(int index) {
        if (nbt().m_128441_(NBT_POINTS)) {
            CompoundTag pointsNbt = nbt().m_128469_(NBT_POINTS);
            return pointsNbt.m_128441_(String.valueOf(index)) ? pointsNbt.m_128469_(String.valueOf(index)) : new CompoundTag();
        }
        return new CompoundTag();
    }
    
    public void setCustomDataForPoint(int index, CompoundTag nbt) {
        CompoundTag pointsNbt = new CompoundTag();
        if (nbt().m_128441_(NBT_POINTS)) {
            pointsNbt = nbt().m_128469_(NBT_POINTS);
        }            
        pointsNbt.m_128365_(String.valueOf(index), nbt);
        nbt().m_128365_(NBT_POINTS, pointsNbt);
    }

    public CompoundTag getCommonData() {
        if (nbt().m_128441_(NBT_CUSTOM_DATA)) {
            return nbt().m_128469_(NBT_CUSTOM_DATA);
        }
        return new CompoundTag();
    }

    public void setCommonData(CompoundTag nbt) {
        nbt().m_128365_(NBT_CUSTOM_DATA, nbt);
    }

    public boolean hasPoint(int index) {
        if (nbt().m_128441_(NBT_POINTS)) {
            CompoundTag pointsNbt = nbt().m_128469_(NBT_POINTS);
            return pointsNbt.m_128441_(String.valueOf(index));
        }
        return false;
    }
}
