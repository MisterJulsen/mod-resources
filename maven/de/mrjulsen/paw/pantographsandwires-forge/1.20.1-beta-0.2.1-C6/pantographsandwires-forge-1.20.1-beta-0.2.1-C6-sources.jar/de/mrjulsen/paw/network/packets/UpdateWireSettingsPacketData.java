package de.mrjulsen.paw.network.packets;

import de.mrjulsen.mcdragonlib.data.DLStatus;
import de.mrjulsen.mcdragonlib.network.NetworkPacketContext;
import de.mrjulsen.mcdragonlib.network.NetworkPacketData;
import de.mrjulsen.paw.PantographsAndWires;
import de.mrjulsen.paw.data.WireSettingsData;
import de.mrjulsen.wires.item.MultiWireItem;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.player.Player;

public class UpdateWireSettingsPacketData extends NetworkPacketData {

    private static final String NBT_DATA = "Data";

    private WireSettingsData data;

    public UpdateWireSettingsPacketData(DLStatus status) {
        super(status);
    }

    public UpdateWireSettingsPacketData(WireSettingsData data) {
        super(DLStatus.OK);
        this.data = data;

    }

    @Override
    protected void write(CompoundTag nbt) {
        CompoundTag compound = new CompoundTag();
        data.toNbt(compound);
        nbt.m_128365_(NBT_DATA, compound);
    }

    @Override
    protected void read(CompoundTag nbt) {
        this.data = WireSettingsData.fromNbt(nbt.m_128469_(NBT_DATA));
    }

    public static void handle(UpdateWireSettingsPacketData packet, NetworkPacketContext contextSupplier) {
        contextSupplier.queue(() -> {            
            Player player = contextSupplier.getPlayer();
            if (!MultiWireItem.setNbt(player.m_21205_(), packet.data)) {
                if (!MultiWireItem.setNbt(player.m_21206_(), packet.data)) {
                    PantographsAndWires.LOGGER.warn("Could not set NBT for 'mainhand=" + player.m_21205_() + ",offhand=" + player.m_21206_() + "'' because this item is not a MultiWireItem.");
                }
            }
        });
    }
    
}
