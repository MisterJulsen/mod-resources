package de.mrjulsen.paw.mixin;

import de.mrjulsen.paw.block.abstractions.weathering.IAgingBlock;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.HoneycombItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.LevelEvent;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.gameevent.GameEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Optional;

@Mixin(HoneycombItem.class)
public class HoneycombItemMixin {

    @Inject(method = "useOn", at = @At("RETURN"), cancellable = true)
    private void onUseOn(UseOnContext context, CallbackInfoReturnable<InteractionResult> cir) {
        if (cir.getReturnValue() != InteractionResult.PASS) return;

        Level level = context.m_43725_();
        BlockPos blockPos = context.m_8083_();
        BlockState blockState = level.m_8055_(blockPos);

        if (!(blockState.m_60734_() instanceof IAgingBlock<?, ?> agingBlock)) {
            return;
        }
        if (agingBlock.isWaxed()) {
            return;
        }

        Optional<BlockState> waxedState = agingBlock.getWaxToggled(blockState);
        if (waxedState.isEmpty()) {
            return;
        }

        Player player = context.m_43723_();
        ItemStack itemStack = context.m_43722_();

        if (player instanceof ServerPlayer serverPlayer) {
            CriteriaTriggers.f_10562_.m_285767_(serverPlayer, blockPos, itemStack);
        }

        itemStack.m_41774_(1);
        level.m_7731_(blockPos, waxedState.get(), 11);
        level.m_220407_(GameEvent.f_157792_, blockPos, GameEvent.Context.m_223719_(player, waxedState.get()));
        level.m_5898_(player, LevelEvent.f_153624_, blockPos, 0);

        cir.setReturnValue(InteractionResult.m_19078_(level.f_46443_));
    }
}