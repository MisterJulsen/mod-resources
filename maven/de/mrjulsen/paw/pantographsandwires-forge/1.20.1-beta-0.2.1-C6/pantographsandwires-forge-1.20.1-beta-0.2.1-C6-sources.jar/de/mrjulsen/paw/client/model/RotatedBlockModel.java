package de.mrjulsen.paw.client.model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat;

import de.mrjulsen.paw.block.abstractions.IConicalShape;
import de.mrjulsen.paw.block.abstractions.IRotatableBlock;
import net.createmod.catnip.math.VecHelper;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.core.Direction;
import net.minecraft.core.Direction.Axis;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.Vec3;

public class RotatedBlockModel extends BakedModelExtension<BakedModel> {

	public RotatedBlockModel(BakedModel originalModel) {
		super(originalModel);
	}

	@Override
	public List<BakedQuad> m_213637_(BlockState state, Direction side, RandomSource rand) {

		if (!(state.m_60734_() instanceof IRotatableBlock rot)) {
			return originalModel.m_213637_(state, side, rand);
		}

		List<BakedQuad> templateQuads = originalModel.m_213637_(state, side, rand);
		if (templateQuads.isEmpty())
			return templateQuads;

		double hAngle = rot.getRelativeYRotation(state);
		Vec2 pivot = rot.rotatedPivotPoint(state);

		Vec2 offset = (rot.getOffset(state));
		Vec3 verticalOffset = new Vec3(0.5f, 0.25f, 0.5f).m_82492_(pivot.f_82470_, 0, pivot.f_82471_);		

		int size = templateQuads.size();
		List<BakedQuad> quads = new ArrayList<>();
		for (int i = 0; i < size; i++) {
			BakedQuad quad = clone(templateQuads.get(i));
			int[] vertexData = quad.m_111303_();
			for (int j = 0; j < 4; j++) {
				Vec3 vec = getXYZ(vertexData, j);

				if (state.m_60734_() instanceof IConicalShape cone) {
					Vec2 coneTarget = cone.coneTarget(state);
					Vec2 coneOffset = cone.coneOffset(state);
					double sX = -Math.signum(vec.f_82479_ - coneTarget.f_82470_);
					double sZ = -Math.signum(vec.f_82481_ - coneTarget.f_82471_);
	
					vec = vec.m_82520_(sX * vec.f_82480_ * coneOffset.f_82470_, 0, sZ * vec.f_82480_ * coneOffset.f_82471_);
				}

				setXYZ(vertexData, j, transformVector(state, side, rand, rot, vec, hAngle, verticalOffset, quad.m_111305_(), offset, pivot));
			}
			quads.add(quad);
		}

		return quads;
	}

	private Vec3 transformVector(BlockState state, Direction side, RandomSource rand, IRotatableBlock rot, Vec3 v, double rotationAngle, Vec3 verticalOffset, int flags, Vec2 offset, Vec2 pivot) {
		ETransformationType transformationType = ETransformationType.getByIndex(flags);

		Axis axis = rot.transformOnAxis(state);
		if (axis != null) {
			if (transformationType.isScale()) {
				switch (axis) {
					case X -> {
						double distance = v.m_82507_(axis) - pivot.f_82470_;
						if (
							(transformationType == ETransformationType.SCALE_POSITIVE || transformationType == ETransformationType.SCALE_NEGATIVE) &&
							((distance > 0 && transformationType != ETransformationType.SCALE_POSITIVE) || (distance < 0 && transformationType != ETransformationType.SCALE_NEGATIVE))
						) break;
						double scaledDistance = distance * rot.getScaleForRotation(state);
						v = new Vec3(pivot.f_82470_ + scaledDistance, v.f_82480_, v.f_82481_);
					}
					case Z -> {
						double distance = v.m_82507_(axis) - pivot.f_82471_;
						if (
							(transformationType == ETransformationType.SCALE_POSITIVE || transformationType == ETransformationType.SCALE_NEGATIVE) &&
							((distance > 0 && transformationType != ETransformationType.SCALE_POSITIVE) || (distance < 0 && transformationType != ETransformationType.SCALE_NEGATIVE))
						) break;
						double scaledDistance = distance * rot.getScaleForRotation(state);
						v = new Vec3(v.f_82479_, v.f_82480_, pivot.f_82471_ + scaledDistance);
					}
					default -> throw new IllegalArgumentException("The scaling axis for block " + state.m_60734_() + " must be horizontal. " + axis + " is not allowed!");
				}
			} else if (transformationType == ETransformationType.TRANSLATE) {
				switch (axis) {
					case X -> {
						double angleRadians = Math.toRadians(rot.getRelativeYRotation(state));
						float h = (float)1 / (float)Math.cos(angleRadians);
						v = new Vec3(v.f_82479_ + state.m_61143_(HorizontalDirectionalBlock.f_54117_).m_122421_().m_122540_() * (1f - h), v.f_82480_, v.f_82481_);
					}
					case Z -> {
						double angleRadians = Math.toRadians(rot.getRelativeYRotation(state));
						float h = (float)1 / (float)Math.cos(angleRadians);
						v = new Vec3(v.f_82479_, v.f_82480_, v.f_82481_ + state.m_61143_(HorizontalDirectionalBlock.f_54117_).m_122421_().m_122540_() * (1f - h));
					}
					default -> throw new IllegalArgumentException("The scaling axis for block " + state.m_60734_() + " must be horizontal. " + axis + " is not allowed!");
				}
			}
		}
		
		v = v.m_82549_(verticalOffset);
		v = VecHelper.rotateCentered(v, rotationAngle, Axis.Y);
		v = v.m_82546_(verticalOffset);
		v = v.m_82520_(offset.f_82470_, 0, offset.f_82471_);
		return v;
	}

	/* Copy from: BakedQuadHelper */
	public static final VertexFormat FORMAT = DefaultVertexFormat.f_85811_;
	public static final int VERTEX_STRIDE = FORMAT.m_86017_();

	public static final int X_OFFSET = 0;
	public static final int Y_OFFSET = 1;
	public static final int Z_OFFSET = 2;

	public static BakedQuad clone(BakedQuad quad) {
		return new BakedQuad(Arrays.copyOf(quad.m_111303_(), quad.m_111303_().length),
			quad.m_111305_(), quad.m_111306_(), quad.m_173410_(), quad.m_111307_());
	}

	public static Vec3 getXYZ(int[] vertexData, int vertex) {
		float x = Float.intBitsToFloat(vertexData[vertex * VERTEX_STRIDE + X_OFFSET]);
        float y = Float.intBitsToFloat(vertexData[vertex * VERTEX_STRIDE + Y_OFFSET]);
        float z = Float.intBitsToFloat(vertexData[vertex * VERTEX_STRIDE + Z_OFFSET]);
        return new Vec3(x, y, z);
	}

	public static void setXYZ(int[] vertexData, int vertex, Vec3 xyz) {
		vertexData[vertex * VERTEX_STRIDE + X_OFFSET] = Float.floatToRawIntBits((float) xyz.f_82479_);
		vertexData[vertex * VERTEX_STRIDE + Y_OFFSET] = Float.floatToRawIntBits((float) xyz.f_82480_);
		vertexData[vertex * VERTEX_STRIDE + Z_OFFSET] = Float.floatToRawIntBits((float) xyz.f_82481_);
	}
}

