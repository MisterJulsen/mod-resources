package de.mrjulsen.paw.block;

import java.util.function.Supplier;

import de.mrjulsen.paw.block.abstractions.IHorizontalExtensionConnectable;
import de.mrjulsen.paw.block.abstractions.IHorizontalExtensionConnectable.EPostType;
import de.mrjulsen.paw.block.abstractions.IWeatheringBlock;
import de.mrjulsen.paw.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Direction.Axis;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition.Builder;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

public class CantileverBracketBlock extends CantileverBracketBaseBlock<CantileverBracketBlock> {
    
    public static final BooleanProperty UP = BooleanProperty.m_61465_("up");
    public static final BooleanProperty DOWN = BooleanProperty.m_61465_("down");

    public CantileverBracketBlock(Properties properties, IWeatheringBlock.WeatherData<CantileverBracketBlock> weatheringData) {
        super(properties.m_284180_(MapColor.f_283906_), weatheringData);

        this.m_49959_(m_49966_()
            .m_61124_(DOWN, false)
            .m_61124_(UP, false)
        );
    }

    @Override
    public ItemStack m_7397_(BlockGetter level, BlockPos pos, BlockState state) {
        return new ItemStack(ModBlocks.CANTILEVER_BRACKET.get(new ModBlocks.OxidizingKey(getWeatheringData().ageState(), getWeatheringData().isWaxed())).get());
    }

    @Override
    protected VoxelShape makeShape(ShapeContext c) {
        VoxelShape[] shapes = new VoxelShape[] { Shapes.m_83040_(), Shapes.m_83040_() };
        if (c.state().m_61143_(DOWN)) {
            shapes[0] = Block.m_49796_(6, 0, 6, 10, 8, 10);
        }
        if (c.state().m_61143_(UP)) {
            shapes[1] = Block.m_49796_(6, 8, 6, 10, 16, 10);
        }
        return Shapes.m_83124_(super.makeShape(c), shapes);
    }
    
    @Override
    protected void m_7926_(Builder<Block, BlockState> pBuilder) {
        super.m_7926_(pBuilder);
        pBuilder.m_61104_(DOWN, UP);
    }

    @Override
    public BlockState m_5573_(BlockPlaceContext context) {
        BlockState state = super.m_5573_(context);

        BlockPos supportPos = context.m_8083_().m_121945_(context.m_43719_().m_122424_());
        BlockState supportState = context.m_43725_().m_8055_(supportPos);
        boolean supportIsPost = supportState.m_60734_() instanceof IHorizontalExtensionConnectable conn && conn.postConnectionType(context.m_43725_(), supportState, supportPos, state, context.m_8083_()) == EPostType.LATTICE && context.m_43719_().m_122434_() != Axis.Y;
        
        if (supportIsPost) {
            state = ModBlocks.CANTILEVER_BRACKET_AT_POST.get(new ModBlocks.OxidizingKey(getWeatheringData().ageState(), getWeatheringData().isWaxed())).getDefaultState()
                .m_61124_(FACING, context.m_43719_())
                .m_61124_(ROTATION, supportState.m_61143_(ROTATION))
                .m_61124_(MULTIPART_SEGMENT, maxSegments(supportState))
            ;
        }
        return state;
    }

    @Override
    public BlockState m_7417_(BlockState state, Direction direction, BlockState neighborState, LevelAccessor level, BlockPos currentPos, BlockPos neighborPos) {
        if (direction == state.m_61143_(FACING).m_122424_()) {
            // TODO: Diagonal checken bei 45 Grad
            BlockPos supportPos = currentPos.m_121945_(direction);
            BlockState supportState = level.m_8055_(supportPos);
            boolean supportIsPost = supportState.m_60734_() instanceof IHorizontalExtensionConnectable conn && conn.postConnectionType(level, supportState, supportPos, state, currentPos) == EPostType.LATTICE;

            Direction facing = state.m_61143_(FACING);
            int rotation = state.m_61143_(ROTATION);
            int segment = state.m_61143_(MULTIPART_SEGMENT);
            
            if (supportIsPost && supportState.m_61143_(ROTATION) == rotation) {
                state = ModBlocks.CANTILEVER_BRACKET_AT_POST.get(new ModBlocks.OxidizingKey(getWeatheringData().ageState(), getWeatheringData().isWaxed())).getDefaultState()
                    .m_61124_(FACING, facing)
                    .m_61124_(ROTATION, rotation)
                    .m_61124_(MULTIPART_SEGMENT, segment)
                ;
            }
        } else if (direction.m_122434_() == Axis.Y) {
            BlockState belowState = level.m_8055_(currentPos.m_7495_());
            BlockState aboveState = level.m_8055_(currentPos.m_7494_());
            boolean aboveIsVertical = aboveState.m_60734_() instanceof CantileverBracketVerticalBlock;
            boolean belowIsVertical = belowState.m_60734_() instanceof CantileverBracketVerticalBlock;
            
            state = state
                .m_61124_(UP, aboveIsVertical)
                .m_61124_(DOWN, belowIsVertical)
            ;
        }
        return state;
    }
}
