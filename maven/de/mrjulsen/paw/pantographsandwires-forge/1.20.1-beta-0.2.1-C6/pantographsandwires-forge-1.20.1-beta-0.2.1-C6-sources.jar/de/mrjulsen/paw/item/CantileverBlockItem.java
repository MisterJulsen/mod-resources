package de.mrjulsen.paw.item;

import de.mrjulsen.paw.PantographsAndWires;
import de.mrjulsen.paw.block.abstractions.AbstractCantileverBlock;
import de.mrjulsen.paw.block.abstractions.AbstractCantileverBlock.ECantileverInsulatorsPlacement;
import de.mrjulsen.paw.block.abstractions.AbstractCantileverBlock.ECantileverRegistrationArmType;
import de.mrjulsen.paw.block.property.EInsulatorType;
import de.mrjulsen.paw.blockentity.CantileverBlockEntity;
import de.mrjulsen.paw.blockentity.CantileverBlockEntity.SubCantileverSetting;
import de.mrjulsen.paw.event.ClientWrapper;
import de.mrjulsen.mcdragonlib.util.TextUtils;
import de.mrjulsen.mcdragonlib.util.math.MathUtils;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

public class CantileverBlockItem<T extends AbstractCantileverBlock> extends BlockItem {

    private static final String KEY_TOO_SMALL_FOR_ADDITIONAL_CANTILEVERS = "block." + PantographsAndWires.MOD_ID + ".cantilever.too_small_for_multiple_cantilevers";

    private final EInsulatorType insulatorType;

    public CantileverBlockItem(T block, EInsulatorType insulatorType, Item.Properties properties) {
		super(block, properties);
        this.insulatorType = insulatorType;
	}

    @SuppressWarnings("unchecked")
    public AbstractCantileverBlock getCantilever() {
        return (T)m_40614_();
    }

    public EInsulatorType getInsulatorType() {
        return insulatorType;
    }

    @Override
    protected boolean m_7274_(BlockPos pos, Level level, Player player, ItemStack stack, BlockState state) {
        if (level.m_7702_(pos) instanceof CantileverBlockEntity be) {
            if (be.shouldNotUpdate()) {
                be.setDoNotUpdate(false);
                return false;
            }
        }
        return super.m_7274_(pos, level, player, stack, state);
    }

    @Override
    protected boolean m_7429_(BlockPlaceContext context, BlockState state) {
        Level level = context.m_43725_();
        if (!(context.m_43722_().m_41720_() instanceof CantileverBlockItem item)) {
            return false;
        }
        getNbt(context.m_43722_()); // To init the nbt data

        if (level.m_7702_(context.m_8083_()) instanceof CantileverBlockEntity be) {
            byte allowedCount = AbstractCantileverBlock.additionalCantileversCheck(be.getWidth(), be.getHeight(), be.getCatenaryHeight());
            int currentCount = be.getSubCantileverSettings().size();
            if (currentCount < allowedCount) {
                be.getSubCantileverSettings().add(getSubSettings(context.m_43722_()));
                be.update();
                be.setDoNotUpdate(true);
                return true;
            } else if (allowedCount < AbstractCantileverBlock.MAX_CANTILEVERS) {
                context.m_43723_().m_5661_(TextUtils.translate(KEY_TOO_SMALL_FOR_ADDITIONAL_CANTILEVERS).m_130940_(ChatFormatting.RED), true);
            }
        }
        return super.m_7429_(context, state);
    }

    public static CompoundTag getNbt(ItemStack stack) {        
        CompoundTag itemNbt = stack.m_41784_();
        CompoundTag nbt;
        if (itemNbt.m_128441_(f_150696_)) {
            nbt = itemNbt.m_128469_(f_150696_);
        } else {
            nbt = new CompoundTag();
            itemNbt.m_128365_(f_150696_, nbt);
        }

        // Validate and init values
        if (!nbt.m_128441_(CantileverBlockEntity.NBT_WIDTH)) {
            nbt.m_128350_(CantileverBlockEntity.NBT_WIDTH, CantileverBlockEntity.DEFAULT_WIDTH);
        } else {            
            nbt.m_128350_(CantileverBlockEntity.NBT_WIDTH, MathUtils.clamp(nbt.m_128457_(CantileverBlockEntity.NBT_WIDTH), AbstractCantileverBlock.MIN_WIDTH, AbstractCantileverBlock.MAX_WIDTH));
        }

        if (!nbt.m_128441_(CantileverBlockEntity.NBT_HEIGHT)) {
            nbt.m_128350_(CantileverBlockEntity.NBT_HEIGHT, CantileverBlockEntity.DEFAULT_HEIGHT);
        } else {            
            nbt.m_128350_(CantileverBlockEntity.NBT_HEIGHT, MathUtils.clamp(nbt.m_128457_(CantileverBlockEntity.NBT_HEIGHT), AbstractCantileverBlock.MIN_HEIGHT, AbstractCantileverBlock.MAX_HEIGHT));
        }

        if (!nbt.m_128441_(CantileverBlockEntity.NBT_Y_OFFSET)) {
            nbt.m_128350_(CantileverBlockEntity.NBT_Y_OFFSET, CantileverBlockEntity.DEFAULT_Y_OFFSET);
        } else {
            nbt.m_128350_(CantileverBlockEntity.NBT_Y_OFFSET, MathUtils.clamp(nbt.m_128457_(CantileverBlockEntity.NBT_Y_OFFSET), AbstractCantileverBlock.MIN_Y_OFFSET, AbstractCantileverBlock.MAX_HEIGHT));
        }

        if (!nbt.m_128441_(CantileverBlockEntity.NBT_CATENARY_HEIGHT)) {
            nbt.m_128350_(CantileverBlockEntity.NBT_CATENARY_HEIGHT, CantileverBlockEntity.DEFAULT_CATENARY_HEIGHT);
        } else {            
            nbt.m_128350_(CantileverBlockEntity.NBT_CATENARY_HEIGHT, MathUtils.clamp(nbt.m_128457_(CantileverBlockEntity.NBT_CATENARY_HEIGHT), AbstractCantileverBlock.MIN_HEIGHT, AbstractCantileverBlock.MAX_HEIGHT));
        }

        if (!nbt.m_128441_(CantileverBlockEntity.NBT_SUB_CANTILEVER_SETTINGS) || nbt.m_128435_(CantileverBlockEntity.NBT_SUB_CANTILEVER_SETTINGS) != Tag.f_178202_ || nbt.m_128437_(CantileverBlockEntity.NBT_SUB_CANTILEVER_SETTINGS, Tag.f_178203_).size() <= 0) {
            ListTag list = new ListTag();
            list.add(new SubCantileverSetting(
                    CantileverBlockEntity.DEFAULT_REGISTRATION_ARM_TYPE,
                    CantileverBlockEntity.DEFAULT_INSULATOR_PLACEMENT,
                    CantileverBlockEntity.DEFAULT_SHOW_BRACING
            ).toNbt());
            nbt.m_128365_(CantileverBlockEntity.NBT_SUB_CANTILEVER_SETTINGS, list);
        }

        return nbt;
    }

    public static boolean setNbt(ItemStack stack, de.mrjulsen.paw.data.CantileverSettingsData data) {
        if (stack.m_41720_() instanceof CantileverBlockItem) {
            CompoundTag nbt = getNbt(stack);
            nbt.m_128350_(CantileverBlockEntity.NBT_WIDTH, data.width());
            nbt.m_128350_(CantileverBlockEntity.NBT_Y_OFFSET, data.yOffset());
            nbt.m_128350_(CantileverBlockEntity.NBT_HEIGHT, data.height());
            nbt.m_128350_(CantileverBlockEntity.NBT_CATENARY_HEIGHT, data.catenaryHeight());

            ListTag list = new ListTag();
            list.add(new SubCantileverSetting(
                    data.cantileverType(),
                    data.insulatorPlacement(),
                    data.showBracing()
            ).toNbt());
            nbt.m_128365_(CantileverBlockEntity.NBT_SUB_CANTILEVER_SETTINGS, list);
            return true;
        } 
        return false;
    }

    private static SubCantileverSetting getSubSettings(ItemStack stack) {
        CompoundTag nbt = getNbt(stack);
        if (nbt.m_128441_(CantileverBlockEntity.NBT_SUB_CANTILEVER_SETTINGS) && nbt.m_128435_(CantileverBlockEntity.NBT_SUB_CANTILEVER_SETTINGS) == Tag.f_178202_) {
            return nbt.m_128437_(CantileverBlockEntity.NBT_SUB_CANTILEVER_SETTINGS, Tag.f_178203_)
                    .stream()
                    .map(c -> SubCantileverSetting.fromNbt((CompoundTag)c))
                    .findFirst()
                    .orElse(SubCantileverSetting.EMPTY);
        }
        return SubCantileverSetting.EMPTY;
    }

    public static float getWidth(ItemStack stack) {
        if (stack != null && stack.m_41720_() instanceof CantileverBlockItem) {
            return getNbt(stack).m_128457_(CantileverBlockEntity.NBT_WIDTH);
        }
        return CantileverBlockEntity.DEFAULT_WIDTH;
    }

    public static float getHeight(ItemStack stack) {
        if (stack != null && stack.m_41720_() instanceof CantileverBlockItem) {
            return getNbt(stack).m_128457_(CantileverBlockEntity.NBT_HEIGHT);
        }
        return CantileverBlockEntity.DEFAULT_HEIGHT;
    }

    public static float getYOffset(ItemStack stack) {
        if (stack != null && stack.m_41720_() instanceof CantileverBlockItem) {
            return getNbt(stack).m_128457_(CantileverBlockEntity.NBT_Y_OFFSET);
        }
        return CantileverBlockEntity.DEFAULT_Y_OFFSET;
    }

    public static boolean getShowBracing(ItemStack stack) {
        if (stack != null && stack.m_41720_() instanceof CantileverBlockItem) {
            return getSubSettings(stack).showBracing();
        }
        return CantileverBlockEntity.DEFAULT_SHOW_BRACING;
    }

    public static float getCatenaryHeight(ItemStack stack) {
        if (stack != null && stack.m_41720_() instanceof CantileverBlockItem) {
            return getNbt(stack).m_128457_(CantileverBlockEntity.NBT_CATENARY_HEIGHT);
        }
        return CantileverBlockEntity.DEFAULT_CATENARY_HEIGHT;
    }

    public static ECantileverRegistrationArmType getRegistrationArm(ItemStack stack) {
        if (stack != null && stack.m_41720_() instanceof CantileverBlockItem) {
            return getSubSettings(stack).registrationArm();
        }
        return CantileverBlockEntity.DEFAULT_REGISTRATION_ARM_TYPE;
    }

    public static ECantileverInsulatorsPlacement getInsulatorPlacement(ItemStack stack) {
        if (stack != null && stack.m_41720_() instanceof CantileverBlockItem) {
            return getSubSettings(stack).insulatorPlacement();
        }
        return CantileverBlockEntity.DEFAULT_INSULATOR_PLACEMENT;
    }

    @Override
    public InteractionResultHolder<ItemStack> m_7203_(Level level, Player player, InteractionHand usedHand) {
        ItemStack stack = player.m_21120_(usedHand);
        if (level.f_46443_) {
            ClientWrapper.showCantileverSettingsScreen(stack);
        }
        return new InteractionResultHolder<>(InteractionResult.SUCCESS, stack);
    }
}
