package de.mrjulsen.paw.block;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

public abstract class AbstractPlaceableHangingInsulatorBlock extends AbstractPlaceableInsulatorBlock {

    public AbstractPlaceableHangingInsulatorBlock(Properties properties) {
        super(properties);
    }

    @Override
    public BlockState m_5573_(BlockPlaceContext context) {
        BlockPos clickPos = context.m_8083_();
        Level level = context.m_43725_();
        BlockState state = super.m_5573_(context);
        BlockPos abovePos = clickPos.m_7494_();
        BlockState aboveState = level.m_8055_(abovePos);
        
        if (aboveState.m_60734_() instanceof PowerLineBracketBlock) {
            state = state
                .m_61124_(MULTIPART_SEGMENT, aboveState.m_61143_(MULTIPART_SEGMENT))
                .m_61124_(FACING, aboveState.m_61143_(FACING))
                .m_61124_(ROTATION, aboveState.m_61143_(ROTATION))
            ;
        }
        return state;
    }

    @Override
    public boolean m_7898_(BlockState state, LevelReader level, BlockPos pos) {
        BlockPos abovePos = pos.m_7494_();
        BlockState aboveState = level.m_8055_(abovePos);
        return m_49863_(level, abovePos, Direction.DOWN) || (aboveState.m_60734_() instanceof PowerLineBracketBlock);
    }

    @SuppressWarnings("deprecation")
    public BlockState m_7417_(BlockState state, Direction direction, BlockState neighborState, LevelAccessor level, BlockPos currentPos, BlockPos neighborPos) {
        return !this.m_7898_(state, level, currentPos) ? Blocks.f_50016_.m_49966_() : super.m_7417_(state, direction, neighborState, level, currentPos, neighborPos);
    }
}
