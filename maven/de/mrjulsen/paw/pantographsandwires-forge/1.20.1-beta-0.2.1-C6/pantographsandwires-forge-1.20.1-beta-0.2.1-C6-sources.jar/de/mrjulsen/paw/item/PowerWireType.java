package de.mrjulsen.paw.item;

import java.util.Optional;

import de.mrjulsen.paw.registry.ModItemTags;
import org.joml.Vector3d;
import org.joml.Vector3f;

import de.mrjulsen.paw.config.ModServerConfig;
import de.mrjulsen.paw.data.WireHitResult;
import de.mrjulsen.paw.registry.InsulatorWireDecoration;
import de.mrjulsen.paw.registry.ModItems;
import de.mrjulsen.paw.util.Const;
import de.mrjulsen.wires.graph.WireEdge;
import de.mrjulsen.wires.graph.WireGraph;
import de.mrjulsen.wires.graph.WireGraphManager;
import de.mrjulsen.wires.graph.WireNode;
import de.mrjulsen.wires.graph.data.WireConnectionData;
import de.mrjulsen.wires.graph.data.provider.BasicConnectorDataProvider;
import de.mrjulsen.wires.SegmentControl;
import de.mrjulsen.wires.Wire;
import de.mrjulsen.wires.WireBatch;
import de.mrjulsen.wires.WireBuilder;
import de.mrjulsen.wires.WireCreationContext;
import de.mrjulsen.wires.SegmentControl.Config;
import de.mrjulsen.wires.WireBuilder.CableType;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.BlockAndTintGetter;
import net.minecraft.world.level.Level;

public class PowerWireType extends PAWWireType {

	private static final float HANG_FAC = 0.025f;
	private static final float THICKNESS = Const.PIXEL;	

	public PowerWireType(ResourceLocation location) {
		super(location);
	}

	@Override
	public int getMaxLength() {
		return ModServerConfig.CATENARY_WIRE_MAX_LENGTH.get();
	}

	@Override
	public double getWireConsumptionMultiplier(int connectionLength) {
		return 1.0;
	}
	
	@Override
	public WireBatch buildWire(WireCreationContext context, BlockAndTintGetter level, WireConnectionData customData, WireEdge edge, WireNode nodeA, WireNode nodeB) {
		BasicConnectorDataProvider dataA = customData.connectorA().getAsTypeIfMatching(BasicConnectorDataProvider.class).orElse(null);
		BasicConnectorDataProvider dataB = customData.connectorB().getAsTypeIfMatching(BasicConnectorDataProvider.class).orElse(null);
		if (dataA == null || dataB == null) {
			return WireBatch.of();
		}

		Vector3d a = new Vector3d(nodeA.getPos()).add(dataA.getAttachOffset());
		Vector3d b = new Vector3d(nodeB.getPos()).add(dataB.getAttachOffset());

		double length = a.distance(b);
		Wire wire = WireBuilder.createWire("main", context, a, b, CableType.HANGING, THICKNESS, HANG_FAC * length, SegmentControl.create(Config.auto(), Config.fixed(1)));
		WireBatch batch = WireBatch.of(wire);
		return batch;
	}

	@Override
	public InteractionResult use(Level level, Player player, InteractionHand hand, WireHitResult hitResult) {
		if (!level.f_46443_) {
			WireGraph network = WireGraphManager.get(level, getGraphId(null));
			WireEdge a = network.getEdge(hitResult.getWireId().id());
			Vector3d hitPos = new Vector3d(hitResult.m_82450_().m_7096_(), hitResult.m_82450_().m_7098_(), hitResult.m_82450_().m_7094_());

			if (player.m_21120_(hand).m_150930_(Items.f_42574_)) {
				network.removeEdge(hitResult.getWireId().id(), hitPos, Optional.of(player));
			} else if (player.m_21120_(hand).m_204117_(ModItemTags.INSULATORS) && player.m_21120_(hand).m_41720_() instanceof BlockItem) {
				ItemStack stack = player.m_21120_(hand);
				InsulatorWireDecoration element = new InsulatorWireDecoration(stack.m_255036_(1));
				if (a.addDecoration(hitPos, "main", element)) {
					if (player == null || (!player.m_7500_() && !player.m_5833_())) {
						stack.m_41774_(1);
					}
				}
			}
		}
		return InteractionResult.SUCCESS;
	}
}
