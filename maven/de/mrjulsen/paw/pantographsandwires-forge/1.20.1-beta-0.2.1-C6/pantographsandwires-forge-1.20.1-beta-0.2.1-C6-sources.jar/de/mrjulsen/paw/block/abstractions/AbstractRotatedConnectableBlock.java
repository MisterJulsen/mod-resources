package de.mrjulsen.paw.block.abstractions;

import java.util.Objects;

import de.mrjulsen.paw.block.extended.BlockPlaceContextExtension;
import de.mrjulsen.paw.data.BlockModificationData;
import de.mrjulsen.mcdragonlib.config.ECachingPriority;
import de.mrjulsen.mcdragonlib.util.MapCache;
import de.mrjulsen.mcdragonlib.util.math.MathUtils;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Direction.Axis;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockAndTintGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition.Builder;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.phys.Vec2;

public abstract class AbstractRotatedConnectableBlock extends AbstractRotatableBlock {

    public static final class BasicRotatedConnectableBlock extends AbstractRotatedConnectableBlock {
        public BasicRotatedConnectableBlock(Properties properties) {
            super(properties);
        }
    }

    public static final int DEFAULT_SEGMENT = 1;
    public static final IntegerProperty MULTIPART_SEGMENT = createMultipartSegmentsProperty();

    private final MapCache<Vec2, BlockState, BlockState> offsetCache = createOffsetCache();

    public AbstractRotatedConnectableBlock(Properties properties) {
        super(properties.m_284180_(MapColor.f_283906_));
        this.m_49959_(m_49966_().m_61124_(MULTIPART_SEGMENT, DEFAULT_SEGMENT));
    }

    public static MapCache<Vec2, BlockState, BlockState> createOffsetCache() {
        return new MapCache<>((c) -> {
            int rawRotationIndex = signedRotationIndex(c);
            int rotationIndex    = Math.abs(rawRotationIndex) + DEFAULT_SEGMENT;
            int currentPart      = c.m_61143_(MULTIPART_SEGMENT);
            float multiplier     = (1f / (float) rotationIndex) * (MathUtils.clamp(currentPart, DEFAULT_SEGMENT, rotationIndex) - DEFAULT_SEGMENT);
            return switch (c.m_61143_(FACING)) {
                case WEST  -> new Vec2(0,  1).m_165903_(multiplier);
                case EAST  -> new Vec2(0, -1).m_165903_(multiplier);
                case SOUTH -> new Vec2(1,  0).m_165903_(multiplier);
                default    -> new Vec2(-1, 0).m_165903_(multiplier);
            };
        }, (state) -> Objects.hash(state.m_61148_().values().toArray(Object[]::new)), ECachingPriority.ALWAYS);
    }

    public static IntegerProperty createMultipartSegmentsProperty() {
        return IntegerProperty.m_61631_("multipart_segment", DEFAULT_SEGMENT, AbstractRotatableBlock.ROTATIONS);
    }

    @Override
    protected void m_7926_(Builder<Block, BlockState> pBuilder) {
        super.m_7926_(pBuilder);
        pBuilder.m_61104_(MULTIPART_SEGMENT);
    }

    protected int maxSegments(BlockState state) {
        int rotationIndex = Math.abs(signedRotationIndex(state)) + 1;
        if (rotationIndex >= ROTATIONS + 1) {
            rotationIndex = 1;
        }
        return rotationIndex;
    }

    @Override
    public BlockState m_5573_(BlockPlaceContext context) {
        BlockPlaceContextExtension ctxExt      = (BlockPlaceContextExtension)(Object) context;
        BlockState                 state        = super.m_5573_(context);
        BlockState                 clickedOnState = ctxExt.getPlacedOnState();
        Direction                  clickedFace  = context.m_43719_();

        if (canConnect(context.m_43725_(), state, context.m_8083_(), clickedOnState, ctxExt.getPlacedOnPos())
                && clickedOnState.m_61143_(FACING).m_122434_() == clickedFace.m_122434_()) {
            int rotationIndex = maxSegments(clickedOnState);
            state = state
                    .m_61124_(MULTIPART_SEGMENT,
                            clickedFace == clickedOnState.m_61143_(FACING)
                                    ? (clickedOnState.m_61143_(MULTIPART_SEGMENT) % rotationIndex) + 1
                                    : Math.abs((clickedOnState.m_61143_(MULTIPART_SEGMENT) - 2) % rotationIndex) + 1)
                    .m_61124_(FACING,   clickedOnState.m_61143_(FACING))
                    .m_61124_(ROTATION, clickedOnState.m_61143_(ROTATION));
        }

        return state;
    }

    protected boolean canConnect(Level level, BlockState state, BlockPos pos, BlockState otherState, BlockPos otherPos) {
        return state.m_60713_(otherState.m_60734_());
    }

    @Override
    public Vec2 getOffset(BlockState state) {
        return offsetCache.get(state, state);
    }

    @Override
    public Axis transformOnAxis(BlockState state) {
        return state.m_61143_(FACING).m_122434_();
    }

    @Override
    public BlockModificationData onPlaceOnRotatedBlock(BlockPlaceContext context, BlockState clickedState, BlockPos clickedBlockPos) {
        BlockModificationData value        = super.onPlaceOnRotatedBlock(context, clickedState, clickedBlockPos);
        int                   rotationValue = signedRotationIndex(clickedState);
        Direction             clickedFace  = context.m_43719_();
        boolean               clickedOnFront = clickedFace == clickedState.m_61143_(FACING);

        if (value == null && clickedFace != null && rotationValue != 0) {
            boolean segmentCondition = clickedState.m_61143_(MULTIPART_SEGMENT)
                    == AbstractRotatableBlock.ROTATIONS / 2 + (clickedOnFront ^ rotationValue < 0 ? 1 : 0);
            if (segmentCondition && clickedFace.m_122434_() == transformOnAxis(clickedState)) {
                return new BlockModificationData(
                        context.m_8083_().m_121945_(rotationValue > 0 ? clickedFace.m_122428_() : clickedFace.m_122427_()),
                        clickedFace
                );
            }
        }
        return value;
    }

    @Override
    public BlockModificationData onPlaceOnOtherRotatedBlock(BlockModificationData currentModification, BlockPlaceContext context, BlockState clickedState, BlockPos clickedBlockPos) {
        int       rotationValue = signedRotationIndex(clickedState);
        Direction clickedFace   = context.m_43719_();

        if (clickedFace != null && rotationValue < 0 && !(clickedState.m_60734_() instanceof AbstractRotatedConnectableBlock)) {
            return new BlockModificationData(context.m_8083_().m_121945_(clickedFace.m_122427_()), clickedFace);
        }
        return currentModification;
    }

    protected BlockPos relativeTo(BlockAndTintGetter level, BlockState state, BlockPos pos, Direction direction) {
        BlockPos result = pos.m_121945_(direction);
        if (!level.m_8055_(pos).m_60713_(state.m_60734_())) {
            return result;
        }

        int rot = signedRotationIndex(state);
        if (rot >= ROTATIONS) {
            result = result.m_121945_(direction.m_122428_());
        } else if (rot > 0 && state.m_61143_(MULTIPART_SEGMENT) == AbstractRotatableBlock.ROTATIONS / 2) {
            result = result.m_121945_(direction.m_122428_());
        } else if (rot < 0 && state.m_61143_(MULTIPART_SEGMENT) == AbstractRotatableBlock.ROTATIONS / 2 + 1) {
            result = result.m_121945_(direction.m_122427_());
        }
        return result;
    }
}