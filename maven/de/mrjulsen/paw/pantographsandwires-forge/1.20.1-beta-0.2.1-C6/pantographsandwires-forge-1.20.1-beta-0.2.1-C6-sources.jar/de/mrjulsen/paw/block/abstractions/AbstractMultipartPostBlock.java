package de.mrjulsen.paw.block.abstractions;

import de.mrjulsen.paw.block.property.EPostPart;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Direction.Axis;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition.Builder;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.phys.Vec2;

public abstract class AbstractMultipartPostBlock extends AbstractSimplePostBlock {

    public static final EnumProperty<EPostPart> PART = EnumProperty.m_61587_("part", EPostPart.class);

    public AbstractMultipartPostBlock(Properties properties) {
        super(properties);

        this.m_49959_(m_49966_()
            .m_61124_(PART, EPostPart.IN_BETWEEN)
        );
    }
    
    @Override
    protected void m_7926_(Builder<Block, BlockState> pBuilder) {
        super.m_7926_(pBuilder);
        pBuilder.m_61104_(PART);
    }

    @Override
    public BlockState m_5573_(BlockPlaceContext context) {        
        BlockState state = super.m_5573_(context);
        Level level = context.m_43725_();
        BlockPos clickPos = context.m_8083_();
        BlockState aboveState = level.m_8055_(clickPos.m_7494_());
        BlockState belowState = level.m_8055_(clickPos.m_7495_());

        if (aboveState.m_60734_().getClass().equals(this.getClass()) && belowState.m_60734_().getClass().equals(this.getClass())) {
            state = state
                .m_61124_(PART, EPostPart.IN_BETWEEN)
            ;
        } else if (belowState.m_60734_().getClass().equals(this.getClass())) {
            state = state
                .m_61124_(PART, EPostPart.TOP)
            ;
        } else {
            state = state
                .m_61124_(PART, EPostPart.BOTTOM)
            ;
        }
        return state;
    }

    @Override
    public BlockState m_7417_(BlockState state, Direction direction, BlockState neighborState, LevelAccessor level, BlockPos currentPos, BlockPos neighborPos) {
        if (direction.m_122434_() == Axis.Y) {            
            BlockState aboveState = level.m_8055_(currentPos.m_7494_());
            BlockState belowState = level.m_8055_(currentPos.m_7495_());

            if (aboveState.m_60734_().getClass().equals(this.getClass()) && belowState.m_60734_().getClass().equals(this.getClass())) {
                state = state
                    .m_61124_(PART, EPostPart.IN_BETWEEN)
                ;
            } else if (belowState.m_60734_().getClass().equals(this.getClass())) {
                state = state
                    .m_61124_(PART, EPostPart.TOP)
                ;
            } else {
                state = state
                    .m_61124_(PART, EPostPart.BOTTOM)
                ;
            }
        }
        return state;
    }

    @Override
    public Vec2 getRotationPivotPoint(BlockState state) {
        return Vec2.f_82462_;
    }
}
