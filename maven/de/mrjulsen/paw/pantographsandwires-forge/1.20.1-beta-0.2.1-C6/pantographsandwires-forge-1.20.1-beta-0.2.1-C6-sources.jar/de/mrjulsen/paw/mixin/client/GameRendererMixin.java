package de.mrjulsen.paw.mixin.client;

import java.util.Optional;

import org.joml.Vector3d;
import org.joml.Vector3f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import de.mrjulsen.mcdragonlib.DragonLib;
import de.mrjulsen.paw.data.WireHitResult;
import de.mrjulsen.paw.util.collision.RaycastHitResult;
import de.mrjulsen.paw.util.collision.RaycastUtils;
import de.mrjulsen.wires.graph.WireEdge;
import de.mrjulsen.wires.graph.NewWireCollision.WireBlockCollision;
import de.mrjulsen.wires.network.WireId;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

@Mixin(GameRenderer.class)
public class GameRendererMixin {
    
    @Inject(method = "pick", at = @At("TAIL"))
    public void paw$pick(float partialTicks, CallbackInfo ci) {
        Minecraft mc = Minecraft.m_91087_();
        Entity viewEntity = mc.m_91288_();
        if (viewEntity == null || mc.f_91073_ == null)
            return;

        Vec3 from = viewEntity.m_20299_(partialTicks);
        Vec3 look = viewEntity.m_20252_(partialTicks);
        Vec3 to = from.m_82549_(look.m_82490_(Minecraft.m_91087_().f_91072_.m_105286_()));

        Optional<RaycastHitResult> result = RaycastUtils.rayTrace(
            new Vector3d(from.f_82479_, from.f_82480_, from.f_82481_),
            new Vector3d(to.f_82479_, to.f_82480_, to.f_82481_),
            mc.f_91073_,
            DragonLib.BLOCK_PIXEL * 4,
            WireId::checkCollision
        );

        result.ifPresent(hit -> {
            float distanceSqr = (float)hit.m_82450_().m_82554_(from);
            double currentHitDistance = mc.f_91077_ != null ? from.m_82554_(mc.f_91077_.m_82450_()) : Integer.MAX_VALUE;

            if (distanceSqr < currentHitDistance) {
                WireBlockCollision c = (WireBlockCollision)hit.getHitData();
                WireEdge edge = c.getCollision().getGraph().getEdge(c.getCollision().getId());
                if (edge == null) {
                    return;
                }
                
                double posOnWire = c.getCollision().worldPosToWirePos(c.getWireName(), new Vector3d(hit.m_82450_().m_7096_(), hit.m_82450_().m_7098_(), hit.m_82450_().m_7094_()));
                mc.f_91077_ = new WireHitResult(
                    new Vec3(hit.m_82450_().m_7096_(), hit.m_82450_().m_7098_(), hit.m_82450_().m_7094_()),
                    posOnWire,
                    hit.getBlockPos(),
                    edge.getGraph().getId(),
                    new WireId(c.getCollision().getId(), c.getWireName(), edge.getType())
                );
            }
        });
    }
}
