package de.mrjulsen.wires.debug;

import java.util.Collection;
import java.util.Deque;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedDeque;

import net.minecraft.world.phys.Vec3;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Vector3d;
import org.joml.Vector3f;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;

import de.mrjulsen.mcdragonlib.util.Pair;
import de.mrjulsen.mcdragonlib.util.TextUtils;
import de.mrjulsen.wires.graph.NewWireCollision;
import de.mrjulsen.wires.graph.WireEdge;
import de.mrjulsen.wires.graph.WireGraphClient;
import de.mrjulsen.wires.graph.WireGraphClient.DebugWireData;
import de.mrjulsen.wires.graph.WireGraphManager;
import de.mrjulsen.wires.graph.WireNode;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.ChunkPos;

public class WireDebugRenderer {

    private static final Deque<Pair<Vector3f, Vector3f>> highlightedWires = new ConcurrentLinkedDeque<>();

    public static boolean enabled() {
        return Minecraft.m_91087_().m_91290_().m_114377_();
    }
    
    public static void renderWireCollisions(PoseStack poseStack) {
        if (!enabled()) {
            if (!highlightedWires.isEmpty()) highlightedWires.clear();
            return;
        }

        Vec3 camPos = Minecraft.m_91087_().f_91063_.m_109153_().m_90583_();
        Vector3d cameraPos = new Vector3d(camPos.m_7096_(), camPos.m_7098_(), camPos.m_7094_());
        Entity entity = Minecraft.m_91087_().f_91063_.m_109153_().m_90592_();
        ChunkPos chunkPos = entity.m_146902_();
  
        poseStack.m_85836_();
        poseStack.m_85837_(-cameraPos.x, -cameraPos.y, -cameraPos.z);
        
        MultiBufferSource.BufferSource mbs = Minecraft.m_91087_().m_91269_().m_110104_();

        for (WireGraphClient graph : WireGraphManager.getAllClient(Minecraft.m_91087_().f_91073_)) {           
            for (WireNode node : graph.getNodes()) {
                if (node == null) continue;
                if (node.getPos().distance(cameraPos) > 16) continue;
                renderNameTag(poseStack, mbs, LightTexture.f_173040_, node.getPos(), 0.2f, List.of(
                    TextUtils.text("ID: " + node.getId().toString()),
                    TextUtils.text("Graph: " + node.getGraph().getId().id()),
                    TextUtils.text("Type: " + node.getData().getRegistryType().id()),
                    TextUtils.text("Pos: " + node.getPos()),
                    TextUtils.text("Connections: " + node.getConnections().size())
                ));
            }
            for (WireEdge edge : graph.getEdges()) {
                if (edge == null) continue;
                if (!graph.hasNode(edge.getNodeAId()) || !graph.hasNode(edge.getNodeBId())) continue;
                if (edge.getCenterPos().distance(cameraPos) > 16) continue;
                renderNameTag(poseStack, mbs, LightTexture.f_173040_, graph.getNode(edge.getNodeAId()).getPos().add(graph.getNode(edge.getNodeBId()).getPos()).div(2), 0.2f, List.of(
                    TextUtils.text("ID: " + edge.getId()),
                    TextUtils.text("Graph: " + edge.getGraph().getId().id()),
                    TextUtils.text("Node Type[A]: " + edge.getWireConnectionData().connectorA().getRegistryType().id()).m_130940_(ChatFormatting.LIGHT_PURPLE),
                    TextUtils.text("Node Type[B]: " + edge.getWireConnectionData().connectorB().getRegistryType().id()).m_130940_(ChatFormatting.AQUA),
                    TextUtils.text("Wire Type: " + edge.getType().getRegistryId())
                ));
                
                for (DebugWireData wireData : graph.debug_getWireDataForEdge(edge.getId())) {
                    renderNameTag(poseStack, mbs, LightTexture.f_173040_, wireData.centerPos(), 0, List.of(
                        TextUtils.text(wireData.name()).m_130940_(ChatFormatting.GOLD)
                    ));
                }
            }

            VertexConsumer buffer = mbs.m_6299_(RenderType.m_110504_());            
            Collection<WireNode> nodes = graph.getNodes();
            synchronized (nodes) {                
                for (WireNode node : nodes) {
                    if (node.getPos().distance(cameraPos) > 256) continue;
                    renderDebugLine(poseStack, buffer, new Vector3d(node.getPos()).sub(0.25f, 0, 0), new Vector3d(node.getPos()).add(0.25f, 0, 0), 1, 1, 0, 1);
                    renderDebugLine(poseStack, buffer, new Vector3d(node.getPos()).sub(0, 0.25f, 0), new Vector3d(node.getPos()).add(0, 0.25f, 0), 1, 1, 0, 1);
                    renderDebugLine(poseStack, buffer, new Vector3d(node.getPos()).sub(0, 0, 0.25f), new Vector3d(node.getPos()).add(0, 0, 0.25f), 1, 1, 0, 1);
                }
            }            
            Collection<WireEdge> edges = graph.getEdges();
            synchronized (edges) {
                for (WireEdge edge : graph.getEdges()) {
                    if (edge.getCenterPos().distance(cameraPos) > 256) continue;
                    renderDebugLineGradient(poseStack, buffer, graph.getNode(edge.getNodeAId()).getPos(), graph.getNode(edge.getNodeBId()).getPos(), 1, 0, 1, 1, 0, 1, 1, 1);
                }
            }
            

            for (int a = -2; a <= 2; a++) {
                for (int b = -2; b <= 2; b++) {
                    ChunkPos relPos = new ChunkPos(chunkPos.f_45578_ + a, chunkPos.f_45579_ + b);
                    for (NewWireCollision collision : graph.getCollisionsInChunk(relPos)) {
                        if (collision == null) continue;
                        for (NewWireCollision.WireBlockCollision c : collision.getAllCollisions()) {
                            renderDebugLine(poseStack, buffer, new Vector3d(c.getAbsoluteInVector().x(), c.getAbsoluteInVector().y() + 0.01, c.getAbsoluteInVector().z()), new Vector3d(c.getAbsoluteOutVector().x(), c.getAbsoluteOutVector().y() + 0.01, c.getAbsoluteOutVector().z()), 1f, 0f, 0f, 1f);
                        }
                    }
                }
            }

            while (!highlightedWires.isEmpty()) {
                Pair<Vector3f, Vector3f> p = highlightedWires.pollFirst();
                renderDebugLine(poseStack, buffer, new Vector3d(p.getFirst()).sub(0, 0.01, 0), new Vector3d(p.getSecond()).sub(0, 0.01, 0), 0f, 1f, 0f, 1f);
            }         
        }

        poseStack.m_85849_();
    }

    public static void highlightWire(Vector3f a, Vector3f b) {
        if (!enabled()) return;
        highlightedWires.addLast(Pair.of(a, b));
    }

    public static void renderDebugLine(PoseStack poseStack, VertexConsumer consumer, Vector3d from, Vector3d to, float r, float g, float b, float a) {
        Matrix4f matrix4f = poseStack.m_85850_().m_252922_();
        Matrix3f matrix3f = poseStack.m_85850_().m_252943_();

        double dx = to.x() - from.x();
        double dy = to.y() - from.y();
        double dz = to.z() - from.z();
        double length = Math.sqrt(dx * dx + dy * dy + dz * dz);

        if (length > 0) {
            dx /= length;
            dy /= length;
            dz /= length;
        }

        consumer.m_252986_(matrix4f, (float) from.x(), (float) from.y(), (float) from.z()).m_85950_(r, g, b, a).m_252939_(matrix3f, (float)dx, (float)dy, (float)dz).m_5752_();
        consumer.m_252986_(matrix4f, (float) to.x(), (float) to.y(), (float) to.z()).m_85950_(r, g, b, a).m_252939_(matrix3f, (float)dx, (float)dy, (float)dz).m_5752_();
    }
    
    public static void renderDebugLineGradient(PoseStack poseStack, VertexConsumer consumer, Vector3d from, Vector3d to, float r1, float g1, float b1, float a1, float r2, float g2, float b2, float a2) {
        Matrix4f matrix4f = poseStack.m_85850_().m_252922_();
        Matrix3f matrix3f = poseStack.m_85850_().m_252943_();

        double dx = to.x() - from.x();
        double dy = to.y() - from.y();
        double dz = to.z() - from.z();
        double length = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);

        if (length > 0) {
            dx /= length;
            dy /= length;
            dz /= length;
        }

        consumer.m_252986_(matrix4f, (float) from.x(), (float) from.y(), (float) from.z()).m_85950_(r1, g1, b1, a1).m_252939_(matrix3f, (float)dx, (float)dy, (float)dz).m_5752_();
        consumer.m_252986_(matrix4f, (float) to.x(), (float) to.y(), (float) to.z()).m_85950_(r2, g2, b2, a2).m_252939_(matrix3f, (float)dx, (float)dy, (float)dz).m_5752_();
    }

    protected static void renderNameTag(PoseStack poseStack, MultiBufferSource buffer, int packedLight, Vector3d pos, float yOffset, List<Component> text) {
        Vec3 cameraPos = Minecraft.m_91087_().m_91288_().m_20182_();
        if (new Vector3d(cameraPos.m_7096_(), cameraPos.m_7098_(), cameraPos.m_7094_()).distance(pos) > 64) {
            return;
        }
        final float lineHeight = Minecraft.m_91087_().f_91062_.f_92710_ * 1.5f;
        poseStack.m_85836_();
        poseStack.m_85837_(pos.x(), pos.y() + yOffset, pos.z());
        poseStack.m_252781_(Minecraft.m_91087_().f_91063_.m_109153_().m_253121_());
        poseStack.m_85841_(-0.0125F, -0.0125F, 0.0125F);
        Matrix4f matrix4f = poseStack.m_85850_().m_252922_();

        for (int k = 0; k < text.size(); k++) {
            float y = lineHeight * k;
            Component txt = text.get(k);

            float opacity = Minecraft.m_91087_().f_91066_.m_92141_(0.25F);
            int backgroundColor = (int)(opacity * 255.0F) << 24;
            Font font = Minecraft.m_91087_().f_91062_;
            float x = (float)(-font.m_92852_(txt) / 2);

            font.m_272077_(txt, x, -(lineHeight * text.size()) + y, 553648127, false, matrix4f, buffer, Font.DisplayMode.SEE_THROUGH, backgroundColor, packedLight);
            font.m_272077_(txt, x, -(lineHeight * text.size()) + y, -1, false, matrix4f, buffer, Font.DisplayMode.NORMAL, 0, packedLight);
        }

        poseStack.m_85849_();
    }
}
