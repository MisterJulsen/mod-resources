package de.mrjulsen.paw.util;

import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;

public class ClientUtils {
    public static void renderDebugLine(PoseStack poseStack, VertexConsumer consumer, Vector3f from, Vector3f to, float r, float g, float b, float a) {
        Matrix4f matrix4f = poseStack.m_85850_().m_252922_();
        Matrix3f matrix3f = poseStack.m_85850_().m_252943_();

        float dx = to.x() - from.x();
        float dy = to.y() - from.y();
        float dz = to.z() - from.z();
        float length = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);

        if (length > 0) {
            dx /= length;
            dy /= length;
            dz /= length;
        }

        consumer.m_252986_(matrix4f, (float) from.x(), (float) from.y(), (float) from.z()).m_85950_(r, g, b, a).m_252939_(matrix3f, dx, dy, dz).m_5752_();
        consumer.m_252986_(matrix4f, (float) to.x(), (float) to.y(), (float) to.z()).m_85950_(r, g, b, a).m_252939_(matrix3f, dx, dy, dz).m_5752_();
    }

    public static void resetTranslation(PoseStack poseStack) {
        PoseStack.Pose currentPose = poseStack.m_85850_();
        Matrix4f matrix = currentPose.m_252922_();
        matrix.m30(0);
        matrix.m31(0);
        matrix.m32(0);
    }

    public static void resetRotation(PoseStack poseStack) {
        PoseStack.Pose currentPose = poseStack.m_85850_();
        Matrix4f matrix = currentPose.m_252922_();
    
        Vector3f translation = new Vector3f();
        matrix.getTranslation(translation);
        Vector3f scale = new Vector3f();
        matrix.getScale(scale);
        
        matrix.identity();
        matrix.translate(translation);
        matrix.scale(scale);
    }
    
    public static void resetScale(PoseStack poseStack) {
        PoseStack.Pose currentPose = poseStack.m_85850_();
        Matrix4f matrix = currentPose.m_252922_();

        Vector3f translation = new Vector3f();
        matrix.getTranslation(translation);
        Quaternionf rotation = new Quaternionf();
        matrix.getUnnormalizedRotation(rotation);

        matrix.identity();
        matrix.translate(translation);
        matrix.rotate(rotation);
    }
}
