package de.mrjulsen.paw.mixin;

import java.util.function.BiFunction;
import java.util.function.Function;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;

import de.mrjulsen.paw.config.ModCommonConfig;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.VoxelShape;

@Mixin(BlockGetter.class)
public interface BlockGetterMixin {

    default BlockGetter self() {
        return (BlockGetter)(Object)this;
    }

    @Shadow
    static <T, C> T traverseBlocks(Vec3 from, Vec3 to, C context, BiFunction<C, BlockPos, T> tester, Function<C, T> onFail) {
        throw new AssertionError();
    }

    @Shadow
    BlockState getBlockState(BlockPos pos);

    @Shadow
    FluidState getFluidState(BlockPos pos);

    @Shadow
    default BlockHitResult clipWithInteractionOverride(Vec3 startVec, Vec3 endVec, BlockPos pos, VoxelShape shape, BlockState state) {
        throw new AssertionError();
    }

    @Overwrite
    default BlockHitResult clip(ClipContext context) {
        if (!ModCommonConfig.SPEC.isLoaded() || !ModCommonConfig.ADVANCED_BLOCK_SELECTION.get()) {
            return self().m_45547_(context);
        }

        return (BlockHitResult)traverseBlocks(context.m_45702_(), context.m_45693_(), context, (clipContext, pos) -> {            
            BlockHitResult res = null;
            for (int x = -1; x <= 1; x++) {
                for (int z = -1; z <= 1; z++) {
                    BlockPos blockPos = pos.m_7918_(x, 0, z);
                    BlockState blockState = this.getBlockState(blockPos);
                    FluidState fluidState = this.getFluidState(blockPos);
                    Vec3 vec3 = clipContext.m_45702_();
                    Vec3 vec32 = clipContext.m_45693_();

                    VoxelShape voxelShape = clipContext.m_45694_(blockState, (BlockGetter)(Object)this, blockPos);
                    BlockHitResult blockHitResult = this.clipWithInteractionOverride(vec3, vec32, blockPos, voxelShape, blockState);
                    VoxelShape voxelShape2 = clipContext.m_45698_(fluidState, (BlockGetter)(Object)this, blockPos);
                    BlockHitResult blockHitResult2 = voxelShape2.m_83220_(vec3, vec32, blockPos);
                    double a = res == null ? Double.MAX_VALUE : clipContext.m_45702_().m_82557_(res.m_82450_());
                    double d = blockHitResult == null ? Double.MAX_VALUE : clipContext.m_45702_().m_82557_(blockHitResult.m_82450_());
                    double e = blockHitResult2 == null ? Double.MAX_VALUE : clipContext.m_45702_().m_82557_(blockHitResult2.m_82450_());

                    res = a <= d ? (a <= e ? res : blockHitResult2) : (d <= e ? blockHitResult : blockHitResult2);
                }
            }
            return res;
        }, (clipContext) -> {
            Vec3 vec3 = clipContext.m_45702_().m_82546_(clipContext.m_45693_());
            return BlockHitResult.m_82426_(clipContext.m_45693_(), Direction.m_122366_(vec3.f_82479_, vec3.f_82480_, vec3.f_82481_), new BlockPos((int)clipContext.m_45693_().f_82479_, (int)clipContext.m_45693_().f_82480_, (int)clipContext.m_45693_().f_82481_));
        });
    }
}
