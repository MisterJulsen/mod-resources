package de.mrjulsen.wires.util;

import net.minecraft.client.Minecraft;
import net.minecraft.world.level.Level;

public class ClientUtils {
    
    public static float getMultiplierByGraphicsMode() {
        return switch (Minecraft.m_91087_().f_91066_.m_232060_().m_231551_()) {
			case FAST -> 0.5F;
			case FABULOUS -> 2F;
            default -> 1F;
		};
    }

    public static Level level() {
        return Minecraft.m_91087_().f_91073_;
    }
}
