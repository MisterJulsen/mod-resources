package de.mrjulsen.wires.item;

import java.util.List;

import com.simibubi.create.foundation.recipe.ItemCopyingRecipe;
import de.mrjulsen.mcdragonlib.util.TextUtils;
import de.mrjulsen.paw.data.WireHitResult;
import de.mrjulsen.paw.data.WireSettingsData;
import de.mrjulsen.paw.event.ClientWrapper;
import de.mrjulsen.paw.registry.ModWireRegistry;
import de.mrjulsen.wires.IWireType;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.HitResult;

public class MultiWireItem extends AbstractWireItemBase implements ItemCopyingRecipe.SupportsItemCopying {

    public static final String NBT_TYPE = "SelectedSubtype";

    public MultiWireItem(Properties properties) {
        super(properties
            .m_41487_(1)
        );
    }

    @Override
    public IWireType getWireType(ItemStack stack) {
        return getSubType(stack).getWireType(stack);
    }
    
    public IWireItemBase getSubType(ItemStack stack) {
        IPawWireItemBase type = ModWireRegistry.WIRE_SUBTYPES_REGISTRY.load(stack.m_41784_().m_128469_(NBT_TYPE));
        return type == null ? ModWireRegistry.ENERGY_WIRE_ITEM_SUBTYPE.get() : type;
    }
    
    @Override
    public InteractionResult interactWithWire(Level level, Player player, InteractionHand hand, WireHitResult hit) {
        return getSubType(player.m_21120_(hand)).interactWithWire(level, player, hand, hit);
    }

    @Override
    public InteractionResult m_6225_(UseOnContext context) {
        getSubType(context.m_43722_()).useWireOn(context);
        return InteractionResult.SUCCESS;
    }

    @Override
    public void renderHelperOutline(ItemStack stack, Player player, HitResult hit) {
        getSubType(player.m_21120_(InteractionHand.MAIN_HAND)).renderHelperOutline(stack, player, hit);
    }

    public static boolean setNbt(ItemStack stack, WireSettingsData data) {
        if (stack.m_41720_() instanceof MultiWireItem) {
            data.toNbt(stack.m_41784_());
            return true;
        } 
        return false;
    }

    @Override
    public InteractionResultHolder<ItemStack> m_7203_(Level level, Player player, InteractionHand usedHand) {
        IPawWireItemBase item = (IPawWireItemBase)getSubType(player.m_21120_(usedHand));
        InteractionResultHolder<ItemStack> result = item.useWire(level, player, usedHand);
        if (result.m_19089_().m_19077_()) {
            return result;
        }
        if (!result.m_19089_().m_19077_() && player.m_6144_()) {
            IWireItemBase.clear(player, player.m_21120_(usedHand));
            return InteractionResultHolder.m_19096_(player.m_21120_(usedHand));
        }
        if (level.m_5776_()) {
            ClientWrapper.showWireTypeSelectionScreen(player.m_21120_(usedHand));
            return InteractionResultHolder.m_19096_(player.m_21120_(usedHand));
        }
        return result;
    }

    @Override
    public Component createHudInfoText(ItemStack stack, Player player, HitResult hit) {
        return getSubType(stack).createHudInfoText(stack, player, hit);
    }

    @Override
    public void m_7373_(ItemStack stack, Level player, List<Component> list, TooltipFlag flag) {
        super.m_7373_(stack, player, list, flag);
        list.add(TextUtils.text("Type: ").m_7220_(TextUtils.translate(((IPawWireItemBase)getSubType(stack)).getTranslationKey())));
        list.add(TextUtils.text("Amount: " + IPawWireItemBase.getRemainingWire(stack) + "m"));        
    }

    @Override
    public boolean m_142522_(ItemStack stack) {
        return true;
    }

    @Override
    public int m_142158_(ItemStack stack) {
        return (IPawWireItemBase.getRemainingWire(stack) * 13) / IPawWireItemBase.WIRE_LENGTH;
    }

    @Override
    public int m_142159_(ItemStack pStack) {
        return 0xFFFF0000;
    }
    
}
