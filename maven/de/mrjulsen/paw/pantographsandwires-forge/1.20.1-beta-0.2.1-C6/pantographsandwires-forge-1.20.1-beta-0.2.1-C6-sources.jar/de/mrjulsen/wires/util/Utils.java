package de.mrjulsen.wires.util;

import org.joml.Vector3d;
import org.joml.Vector3f;

import net.minecraft.core.BlockPos;
import net.minecraft.core.SectionPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.ChunkPos;

public final class Utils {

    public static ResourceLocation resLoc(String namespace, String path) {
        return new ResourceLocation(namespace, path);
    }

    public static ResourceLocation resLoc(String path) {
        return new ResourceLocation(path);
    }

    public static void putNbtBlockPos(CompoundTag compound, String name, BlockPos pos) {
        CompoundTag nbt = new CompoundTag();
        nbt.m_128405_("X", pos.m_123341_());
        nbt.m_128405_("Y", pos.m_123342_());
        nbt.m_128405_("Z", pos.m_123343_());
        compound.m_128365_(name, nbt);
    }

    public static SectionPos getNbtSectionPos(CompoundTag compound, String name) {
        CompoundTag nbt = compound.m_128469_(name);
        return SectionPos.m_123173_(nbt.m_128451_("X"), nbt.m_128451_("Y"), nbt.m_128451_("Z"));
    }
    
    public static void putNbtSectionPos(CompoundTag compound, String name, SectionPos pos) {
        CompoundTag nbt = new CompoundTag();
        nbt.m_128405_("X", pos.m_123341_());
        nbt.m_128405_("Y", pos.m_123342_());
        nbt.m_128405_("Z", pos.m_123343_());
        compound.m_128365_(name, nbt);
    }

    public static ChunkPos getNbtChunkPos(CompoundTag compound, String name) {
        CompoundTag nbt = compound.m_128469_(name);
        return new ChunkPos(nbt.m_128451_("X"), nbt.m_128451_("Z"));
    }
    
    public static void putNbtChunkPos(CompoundTag compound, String name, ChunkPos pos) {
        CompoundTag nbt = new CompoundTag();
        nbt.m_128405_("X", pos.f_45578_);
        nbt.m_128405_("Z", pos.f_45579_);
        compound.m_128365_(name, nbt);
    }

    public static BlockPos getNbtBlockPos(CompoundTag compound, String name) {
        CompoundTag nbt = compound.m_128469_(name);
        return new BlockPos(nbt.m_128451_("X"), nbt.m_128451_("Y"), nbt.m_128451_("Z"));
    }
    
    public static void putNbtVector3f(CompoundTag compound, String name, Vector3f vec) {
        CompoundTag nbt = new CompoundTag();
        nbt.m_128347_("X", vec.x());
        nbt.m_128347_("Y", vec.y());
        nbt.m_128347_("Z", vec.z());
        compound.m_128365_(name, nbt);
    }
    
    public static void putNbtVector3d(CompoundTag compound, String name, Vector3d vec) {
        CompoundTag nbt = new CompoundTag();
        nbt.m_128347_("X", vec.x());
        nbt.m_128347_("Y", vec.y());
        nbt.m_128347_("Z", vec.z());
        compound.m_128365_(name, nbt);
    }

    public static Vector3f getNbtVector3f(CompoundTag compound, String name) {
        CompoundTag nbt = compound.m_128469_(name);
        return new Vector3f((float)nbt.m_128459_("X"), (float)nbt.m_128459_("Y"), (float)nbt.m_128459_("Z"));
    }

    public static Vector3d getNbtVector3d(CompoundTag compound, String name) {
        CompoundTag nbt = compound.m_128469_(name);
        return new Vector3d(nbt.m_128459_("X"), nbt.m_128459_("Y"), nbt.m_128459_("Z"));
    }

    public boolean isSectionInChunk(SectionPos section, ChunkPos chunk) {
        return section.m_123341_() == chunk.f_45578_ && section.m_123343_() == chunk.f_45579_;
    }

    public ChunkPos getChunkOfSection(SectionPos section) {
        return new ChunkPos(section.m_123341_(), section.m_123343_());
    }

    
}
