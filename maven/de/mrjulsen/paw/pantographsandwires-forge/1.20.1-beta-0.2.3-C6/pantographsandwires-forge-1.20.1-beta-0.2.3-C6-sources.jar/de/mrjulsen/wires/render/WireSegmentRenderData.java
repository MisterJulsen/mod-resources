package de.mrjulsen.wires.render;

import java.util.*;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LightTexture;
import org.joml.Quaternionf;
import org.joml.Vector3d;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;

import de.mrjulsen.wires.decoration.WireDecorationData;
import de.mrjulsen.wires.decoration.WireDecorationRenderData;
import de.mrjulsen.wires.render.WireRenderPoint.VertexCorner;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.core.SectionPos;
import net.minecraft.world.level.BlockAndTintGetter;

public class WireSegmentRenderData {
    
    private final List<WireRenderPoint> points;
    private final List<WireDecorationRenderData> decorations;
    private double length;

    public WireSegmentRenderData() {
        this.points = new ArrayList<>();
        this.decorations = new ArrayList<>();
    }

    public double finish(TreeMap<Double, WireDecorationData> decorations, double lengthOffset) {
        this.decorations.clear();

        double oldLength = 0;
        this.length = 0;
        Vector3d a = new Vector3d(points.get(0).vertex(VertexCorner.CENTER));
        
        for (int i = 1; i < count(); i++) {
            Vector3d b = new Vector3d(points.get(i).vertex(VertexCorner.CENTER));
            Vector3d normal = new Vector3d(b).sub(a).normalize();
            oldLength = length;
            this.length += a.distance(b);
            
            Map.Entry<Double, WireDecorationData> entry = null;
            while (decorations != null && (entry = decorations.firstEntry()) != null) {
                double decoPos = entry.getKey() - lengthOffset;
                if (decoPos > oldLength && decoPos <= this.length) {
                    WireDecorationData deco = decorations.pollFirstEntry().getValue();
                    double localPos = decoPos - oldLength;
                    this.decorations.add(new WireDecorationRenderData(new Vector3d(a).add(new Vector3d(normal).mul(localPos)), normal, deco));
                } else {
                    break;
                }
            }
            a = b;
        }
        return this.length;
    }

    public void add(WireRenderPoint point) {
        this.points.add(point);
    }

    public WireRenderPoint getPoint(int index) {
        return points.get(index);
    }

    public int count() {
        return points.size();
    }

    public void render(BlockAndTintGetter level, SectionPos origin, VertexConsumer vertexConsumer, int color) {
        if (points.size() < 2) {
            return;
        }

        float u0 = WireRenderer.WIRE_TEXTURE.get().m_118409_();
        float v0 = WireRenderer.WIRE_TEXTURE.get().m_118411_();
        float u1 = WireRenderer.WIRE_TEXTURE.get().m_118410_();
        float v1 = WireRenderer.WIRE_TEXTURE.get().m_118412_();
        BlockPos originPos = origin.m_123249_();

        WireRenderPoint lastVertices = points.get(0);
        for (int i = 1; i < points.size(); i++) {
            WireRenderPoint vertices = points.get(i);
            Vector3d center = vertices.vertex(VertexCorner.CENTER);
            int light = getLight(originPos.m_7918_((int)center.x(), (int)center.y(), (int)center.z()), level);

            Vector3d vertex;
            vertex = lastVertices.vertex(VertexCorner.BOTTOM_LEFT);
            vertexConsumer.m_5483_(vertex.x(), vertex.y(), vertex.z()).m_193479_(color).m_7421_(u0, v0).m_85969_(light).m_86008_(OverlayTexture.f_118083_).m_5601_(0, 0, 0).m_5752_();
            vertex = lastVertices.vertex(VertexCorner.TOP_RIGHT);
            vertexConsumer.m_5483_(vertex.x(), vertex.y(), vertex.z()).m_193479_(color).m_7421_(u0, v1).m_85969_(light).m_86008_(OverlayTexture.f_118083_).m_5601_(0, 0, 0).m_5752_();
            
            vertex = vertices.vertex(VertexCorner.TOP_RIGHT);
            vertexConsumer.m_5483_(vertex.x(), vertex.y(), vertex.z()).m_193479_(color).m_7421_(u1, v1).m_85969_(light).m_86008_(OverlayTexture.f_118083_).m_5601_(0, 0, 0).m_5752_();
            vertex = vertices.vertex(VertexCorner.BOTTOM_LEFT);
            vertexConsumer.m_5483_(vertex.x(), vertex.y(), vertex.z()).m_193479_(color).m_7421_(u1, v0).m_85969_(light).m_86008_(OverlayTexture.f_118083_).m_5601_(0, 0, 0).m_5752_();

            // Opposite side
            vertex = lastVertices.vertex(VertexCorner.TOP_RIGHT);
            vertexConsumer.m_5483_(vertex.x(), vertex.y(), vertex.z()).m_193479_(color).m_7421_(u0, v0).m_85969_(light).m_86008_(OverlayTexture.f_118083_).m_5601_(0, 0, 0).m_5752_();
            vertex = lastVertices.vertex(VertexCorner.BOTTOM_LEFT);
            vertexConsumer.m_5483_(vertex.x(), vertex.y(), vertex.z()).m_193479_(color).m_7421_(u0, v1).m_85969_(light).m_86008_(OverlayTexture.f_118083_).m_5601_(0, 0, 0).m_5752_();
            
            vertex = vertices.vertex(VertexCorner.BOTTOM_LEFT);
            vertexConsumer.m_5483_(vertex.x(), vertex.y(), vertex.z()).m_193479_(color).m_7421_(u1, v1).m_85969_(light).m_86008_(OverlayTexture.f_118083_).m_5601_(0, 0, 0).m_5752_();
            vertex = vertices.vertex(VertexCorner.TOP_RIGHT);
            vertexConsumer.m_5483_(vertex.x(), vertex.y(), vertex.z()).m_193479_(color).m_7421_(u1, v0).m_85969_(light).m_86008_(OverlayTexture.f_118083_).m_5601_(0, 0, 0).m_5752_();


            
            vertex = lastVertices.vertex(VertexCorner.TOP_LEFT);
            vertexConsumer.m_5483_(vertex.x(), vertex.y(), vertex.z()).m_193479_(color).m_7421_(u0, v0).m_85969_(light).m_86008_(OverlayTexture.f_118083_).m_5601_(0, 0, 0).m_5752_();
            vertex = lastVertices.vertex(VertexCorner.BOTTOM_RIGHT);
            vertexConsumer.m_5483_(vertex.x(), vertex.y(), vertex.z()).m_193479_(color).m_7421_(u0, v1).m_85969_(light).m_86008_(OverlayTexture.f_118083_).m_5601_(0, 0, 0).m_5752_();
            
            vertex = vertices.vertex(VertexCorner.BOTTOM_RIGHT);
            vertexConsumer.m_5483_(vertex.x(), vertex.y(), vertex.z()).m_193479_(color).m_7421_(u1, v1).m_85969_(light).m_86008_(OverlayTexture.f_118083_).m_5601_(0, 0, 0).m_5752_();
            vertex = vertices.vertex(VertexCorner.TOP_LEFT);
            vertexConsumer.m_5483_(vertex.x(), vertex.y(), vertex.z()).m_193479_(color).m_7421_(u1, v0).m_85969_(light).m_86008_(OverlayTexture.f_118083_).m_5601_(0, 0, 0).m_5752_();
            
            // Opposite side
            vertex = lastVertices.vertex(VertexCorner.BOTTOM_RIGHT);
            vertexConsumer.m_5483_(vertex.x(), vertex.y(), vertex.z()).m_193479_(color).m_7421_(u0, v0).m_85969_(light).m_86008_(OverlayTexture.f_118083_).m_5601_(0, 0, 0).m_5752_();
            vertex = lastVertices.vertex(VertexCorner.TOP_LEFT);
            vertexConsumer.m_5483_(vertex.x(), vertex.y(), vertex.z()).m_193479_(color).m_7421_(u0, v1).m_85969_(light).m_86008_(OverlayTexture.f_118083_).m_5601_(0, 0, 0).m_5752_();
            
            vertex = vertices.vertex(VertexCorner.TOP_LEFT);
            vertexConsumer.m_5483_(vertex.x(), vertex.y(), vertex.z()).m_193479_(color).m_7421_(u1, v1).m_85969_(light).m_86008_(OverlayTexture.f_118083_).m_5601_(0, 0, 0).m_5752_();
            vertex = vertices.vertex(VertexCorner.BOTTOM_RIGHT);
            vertexConsumer.m_5483_(vertex.x(), vertex.y(), vertex.z()).m_193479_(color).m_7421_(u1, v0).m_85969_(light).m_86008_(OverlayTexture.f_118083_).m_5601_(0, 0, 0).m_5752_();

            lastVertices = vertices;
        }

        PoseStack poseStack = new PoseStack();
        for (WireDecorationRenderData deco : decorations) {
            poseStack.m_85836_();
            poseStack.m_85837_(deco.worldPos().x(), deco.worldPos().y(), deco.worldPos().z());
            poseStack.m_85836_();
            poseStack.m_252781_(getYawPitchQuaternion(deco.direction()));
            BlockPos decoPos = originPos.m_7918_((int)deco.worldPos().x(), (int)deco.worldPos().y(), (int)deco.worldPos().z());
            deco.data().getDecoration().getRenderer().render(poseStack, vertexConsumer, deco.worldPos(), deco.direction(), getLight(decoPos, level));
            poseStack.m_85849_();
            poseStack.m_85849_();
        }
    }

    private static int getLight(BlockPos pos, BlockAndTintGetter level) {
		try {
            return LevelRenderer.m_109541_(Objects.requireNonNullElse(Minecraft.m_91087_().f_91073_, level), pos);
        } catch (Exception e) {
            return LightTexture.f_173042_;
        }
	}

    

	public static Quaternionf getYawPitchQuaternion(Vector3d direction) {
        Vector3d dir = new Vector3d(direction).normalize();
		float yaw = (float) Math.atan2(-dir.x, -dir.z);
		float pitch = (float) Math.asin(dir.y);
		return new Quaternionf().rotateY(yaw).rotateX(pitch);
	}
}
