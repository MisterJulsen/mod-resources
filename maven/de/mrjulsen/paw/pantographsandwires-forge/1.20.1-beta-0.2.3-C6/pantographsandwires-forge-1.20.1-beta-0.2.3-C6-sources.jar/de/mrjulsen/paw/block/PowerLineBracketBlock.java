package de.mrjulsen.paw.block;

import java.util.Map;
import java.util.Objects;
import java.util.function.Supplier;

import de.mrjulsen.paw.block.abstractions.AbstractRotatedConnectableBlock;
import de.mrjulsen.paw.block.abstractions.IHorizontalExtensionConnectable;
import de.mrjulsen.paw.block.abstractions.IRotatableBlock;
import de.mrjulsen.paw.block.abstractions.IWeatheringBlock;
import de.mrjulsen.paw.block.abstractions.IHorizontalExtensionConnectable.EPostType;
import de.mrjulsen.paw.block.extended.BlockPlaceContextExtension;
import de.mrjulsen.paw.data.BlockModificationData;
import de.mrjulsen.paw.util.ModMath;
import de.mrjulsen.mcdragonlib.config.ECachingPriority;
import de.mrjulsen.mcdragonlib.util.MapCache;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Direction.Axis;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.util.StringRepresentable;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition.Builder;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.block.state.properties.Half;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.jetbrains.annotations.NotNull;

public class PowerLineBracketBlock extends AbstractRotatedConnectableBlock implements IWeatheringBlock<PowerLineBracketBlock> {

    public static enum EConnectionType implements StringRepresentable {
        NONE("none"),
        ON_POST("on_post"),
        ON_POST_EXTENSION("on_post_extension"),
        AT_POST("at_post");

        String name;

        EConnectionType(String name) {
            this.name = name;
        }

        @Override
        public String m_7912_() {
            return name;
        }
    }

    private static record TransformationShapeKey(ShapeKey shapeKey, Direction direction, int rotation, Half half, BlockState state) {
        @Override
        public final boolean equals(Object other) {
            if (other instanceof TransformationShapeKey o) {
                return shapeKey().equals(o.shapeKey()) && direction().equals(o.direction()) && rotation() == o.rotation() && half() == o.half();
            }
            return false;
        }
        @Override
        public final int hashCode() {
            return Objects.hash(shapeKey(), direction(), rotation(), half());
        }
    }
    private static record ShapeKey(EPostType postType, EConnectionType connectionType) {
        @Override
        public final int hashCode() {
            return Objects.hash(postType(), connectionType());
        }
    }

    private static final VoxelShape DEFAULT_SHAPE = Block.m_49796_(6.5, 0, 0, 9.5, 3, 16);
    private static final Map<ShapeKey, VoxelShape> BASE_SHAPES = Map.ofEntries(
        Map.entry(new ShapeKey(EPostType.FENCE, EConnectionType.ON_POST), Block.m_49796_(5, 0, 5, 11, 3, 11)),
        Map.entry(new ShapeKey(EPostType.FENCE, EConnectionType.ON_POST_EXTENSION), Shapes.m_83110_(Block.m_49796_(5, 0, 16, 11, 3, 21), Block.m_49796_(6.5, 0, 0, 9.5, 3, 16))),
        Map.entry(new ShapeKey(EPostType.FENCE, EConnectionType.AT_POST), Shapes.m_83110_(Block.m_49796_(5, 0, 16, 11, 3, 21), Block.m_49796_(6.5, 0, 0, 9.5, 3, 16))),
        
        Map.entry(new ShapeKey(EPostType.WALL, EConnectionType.ON_POST), Block.m_49796_(4, 0, 4, 12, 3, 12)),
        Map.entry(new ShapeKey(EPostType.WALL, EConnectionType.ON_POST_EXTENSION), Shapes.m_83110_(Block.m_49796_(4, 0, 12, 12, 3, 20), Block.m_49796_(6.5, 0, 0, 9.5, 3, 12))),
        Map.entry(new ShapeKey(EPostType.WALL, EConnectionType.AT_POST), Shapes.m_83110_(Block.m_49796_(4, 0, 12, 12, 3, 20), Block.m_49796_(6.5, 0, 0, 9.5, 3, 12))),

        Map.entry(new ShapeKey(EPostType.LATTICE, EConnectionType.ON_POST), Block.m_49796_(2, 0, 2, 14, 3, 14)),
        Map.entry(new ShapeKey(EPostType.LATTICE, EConnectionType.ON_POST_EXTENSION), Shapes.m_83110_(Block.m_49796_(2, 0, 5, 14, 3, 18), Block.m_49796_(6.5, 0, 0, 9.5, 3, 5))),
        Map.entry(new ShapeKey(EPostType.LATTICE, EConnectionType.AT_POST), Shapes.m_83110_(Block.m_49796_(2, 0, 5, 14, 3, 18), Block.m_49796_(6.5, 0, 0, 9.5, 3, 5)))
    );
    private static final MapCache<VoxelShape, TransformationShapeKey, TransformationShapeKey> shapesCache = new MapCache<>((key) -> {
        VoxelShape baseShape = key.shapeKey().postType() == EPostType.NONE || key.shapeKey().connectionType() == EConnectionType.NONE ? DEFAULT_SHAPE : BASE_SHAPES.get(key.shapeKey());
        Direction direction = key.direction();
        VoxelShape shape = ModMath.rotateShape(baseShape, Axis.Y, (int)direction.m_122424_().m_122435_());
        shape = ModMath.scaleShape(shape, direction.m_122434_(), key.state().m_60734_() instanceof IRotatableBlock rot ? rot.getScaleForRotation(key.state()) : 1, 0.5f);
        if (key.half() == Half.TOP) {
            shape = ModMath.moveShape(shape, new Vec3(0, 1f / 16f * 13, 0));
        }
        return shape;
    }, TransformationShapeKey::hashCode, ECachingPriority.ALWAYS);

    public static final EnumProperty<EConnectionType> CONNECTION_TYPE = EnumProperty.m_61587_("connection_type", EConnectionType.class);
    public static final EnumProperty<EPostType> POST_TYPE = EnumProperty.m_61587_("post_type", EPostType.class);
    public static final EnumProperty<Half> HALF = BlockStateProperties.f_61402_;

    private final IWeatheringBlock.WeatherData<PowerLineBracketBlock> weatheringData;

    
    public PowerLineBracketBlock(Properties properties, IWeatheringBlock.WeatherData<PowerLineBracketBlock> weatheringData) {
        super(properties
            .m_60955_()
        );

        this.weatheringData = weatheringData;

        this.m_49959_(this.m_49966_()
            .m_61124_(POST_TYPE, EPostType.NONE)
            .m_61124_(CONNECTION_TYPE, EConnectionType.NONE)
            .m_61124_(HALF, Half.BOTTOM)
        );
    }

    @Override
    protected void m_7926_(Builder<Block, BlockState> pBuilder) {
        super.m_7926_(pBuilder);
        pBuilder.m_61104_(CONNECTION_TYPE, POST_TYPE, HALF);
    }

    @Override
    public VoxelShape getBaseShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {        
        TransformationShapeKey key = new TransformationShapeKey(new ShapeKey(state.m_61143_(POST_TYPE), state.m_61143_(CONNECTION_TYPE)), state.m_61143_(FACING), normalizedPropertyRotationIndex(state), state.m_61143_(HALF), state);
        return shapesCache.get(key, key);
    }

    @Override
    public BlockState m_5573_(BlockPlaceContext context) {
        BlockPlaceContextExtension contextExt = (BlockPlaceContextExtension)(Object)context;
        Level level = context.m_43725_();
        BlockState state = super.m_5573_(context);
        BlockPos pos = context.m_8083_();
        BlockState supportState = contextExt.paw$getPlacedOnState();
        BlockPos supportPos = contextExt.paw$getPlacedOnPos();
        Direction clickedFace = context.m_43719_();

        if (supportState.m_60734_() instanceof PowerLineBracketBlock && supportState.m_61143_(FACING).m_122434_() == clickedFace.m_122434_()) {
            if (supportState.m_61143_(CONNECTION_TYPE) == EConnectionType.ON_POST) {
                state = state
                    .m_61124_(CONNECTION_TYPE, EConnectionType.ON_POST_EXTENSION)
                ;
            }
            state = state
                .m_61124_(FACING, clickedFace)
                .m_61124_(POST_TYPE, supportState.m_61143_(POST_TYPE))
                .m_61124_(HALF, supportState.m_61143_(HALF))
            ;
            
        } else if (supportState.m_60734_() instanceof IHorizontalExtensionConnectable connection) {
            state = state
                .m_61124_(POST_TYPE, connection.postConnectionType(level, supportState, supportPos, state, pos))
                .m_61124_(ROTATION, supportState.m_61143_(ROTATION))
                .m_61124_(HALF, context.m_43720_().f_82480_ - (double)pos.m_123342_() > 0.5f ? Half.TOP : Half.BOTTOM)
            ;
            if (clickedFace == Direction.UP) {
                state = state
                    .m_61124_(CONNECTION_TYPE, EConnectionType.ON_POST)
                    .m_61124_(FACING, supportState.m_61143_(FACING))
                ;
            } else if (clickedFace.m_122434_().m_122479_()) {
                int rotationValue = Math.abs(normalizedPropertyRotationIndex(supportState));
                state = state
                    .m_61124_(CONNECTION_TYPE, EConnectionType.AT_POST)
                    .m_61124_(FACING, clickedFace)
                    .m_61124_(MULTIPART_SEGMENT, rotationValue > 0 && rotationValue < ROTATIONS ? 2 : 1)
                ;
            }
        }

        return state;
    }

    @Override
    public BlockState m_7417_(BlockState state, Direction direction, BlockState neighborState, LevelAccessor level, BlockPos currentPos, BlockPos neighborPos) {
        return m_7898_(state, level, currentPos) ? state : Blocks.f_50016_.m_49966_();
    }

    @Override
    public boolean m_7898_(BlockState state, LevelReader level, BlockPos pos) {
        BlockPos supportPos = switch (state.m_61143_(CONNECTION_TYPE)) {
            case ON_POST -> pos.m_7495_();
            default -> relativeTo(level, state, pos, state.m_61143_(FACING).m_122424_());
        };
        BlockState supportState = level.m_8055_(supportPos);
        return (supportState.m_60734_() instanceof PowerLineBracketBlock && supportState.m_61143_(FACING).m_122434_() == state.m_61143_(FACING).m_122434_()) || supportState.m_60734_() instanceof IHorizontalExtensionConnectable;
    }

    @Override
    public BlockModificationData onPlaceOnOtherRotatedBlock(BlockModificationData currentModification, BlockPlaceContext context, BlockState clickedState, BlockPos clickedBlockPos) {
        Direction clickedFace = context.m_43719_();
        int rot = normalizedPropertyRotationIndex(clickedState);
        boolean oppositeFacing = 
            clickedState.m_60734_() instanceof PowerLineBracketBlock && 
            clickedState.m_61143_(CONNECTION_TYPE) == EConnectionType.ON_POST &&
            clickedState.m_61143_(FACING).m_122424_() == clickedFace &&
            rot < ROTATIONS
        ;

        if (oppositeFacing) {
            if (rot < 0)
                return new BlockModificationData(context.m_8083_().m_121945_(clickedFace.m_122427_()), clickedFace);
            return null;
        }
        return super.onPlaceOnOtherRotatedBlock(currentModification, context, clickedState, clickedBlockPos);
    }

    public void m_213898_(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        this.m_220947_(state, level, pos, random);
    }

    public boolean m_6724_(BlockState state) {
        return getNext().isPresent();
    }

    @Override
    public @NotNull IWeatheringBlock.WeatherData<PowerLineBracketBlock> getWeatheringData() {
        return weatheringData;
    }

    @Override
    public float m_142377_() {
        if (getWeatheringData().isWaxed()) return 0;
        return IWeatheringBlock.super.m_142377_();
    }
}
