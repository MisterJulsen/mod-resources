package de.mrjulsen.paw.block.abstractions;

import de.mrjulsen.paw.block.extended.BlockPlaceContextExtension;
import de.mrjulsen.wires.block.WireConnectorBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Direction.Axis;
import net.minecraft.tags.TagKey;
import net.minecraft.util.Mth;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec2;

public abstract class AbstractSupportedRotatableWireConnectorBlock<T extends WireConnectorBlockEntity> extends AbstractRotatableWireConnectorBlock<T> {

    public AbstractSupportedRotatableWireConnectorBlock(Properties properties) {
        super(properties);
    }

    @Override
    public BlockState m_5573_(BlockPlaceContext context) {
        BlockPlaceContextExtension ctxExt      = (BlockPlaceContextExtension)(Object) context;
        Direction                  direction   = context.m_43719_();
        BlockPos                   clickPos    = context.m_8083_().m_121945_(direction.m_122424_());
        Level                      level       = context.m_43725_();
        BlockState                 clickedState = level.m_8055_(clickPos);

        Direction targetDir          = direction;
        int       targetRotationIdx  = PROPERTY_BASE_ROTATION_INDEX;

        if (direction.m_122434_() != Axis.Y && clickedState.m_60734_() instanceof AbstractRotatableBlock) {
            targetDir         = direction;
            targetRotationIdx = clickedState.m_61143_(ROTATION);
        } else if (direction.m_122434_() != Axis.Y
                && canBePlacedAt(level, clickPos, clickedState, ctxExt.paw$getPlacedOnPos(), ctxExt.paw$getPlacedOnState(), context.m_43719_())) {
            targetDir         = context.m_43719_();
            targetRotationIdx = PROPERTY_BASE_ROTATION_INDEX;
        } else {
            int rot = Mth.m_14143_(
                    (180.0f + context.m_7074_()) * (float) TOTAL_ROTATION_STEPS / 360.0f + 0.5f)
                    & (TOTAL_ROTATION_STEPS - 1);
            final int stepsPerSide = TOTAL_ROTATION_STEPS / 4;
            targetDir         = Direction.m_122407_((rot + stepsPerSide / 2) / stepsPerSide);
            targetRotationIdx = stepsPerSide - 1 - ((rot + stepsPerSide / 2) % stepsPerSide);
        }

        return m_49966_()
                .m_61124_(FACING,   targetDir)
                .m_61124_(ROTATION, targetRotationIdx);
    }

    @SuppressWarnings("deprecation")
    @Override
    public BlockState m_7417_(BlockState state, Direction direction, BlockState neighborState, LevelAccessor level, BlockPos currentPos, BlockPos neighborPos) {
        return m_7898_(state, level, currentPos)
                ? super.m_7417_(state, direction, neighborState, level, currentPos, neighborPos)
                : Blocks.f_50016_.m_49966_();
    }

    @Override
    public boolean m_7898_(BlockState state, LevelReader level, BlockPos pos) {
        Direction  direction     = state.m_61143_(FACING);
        BlockPos   relativePos   = getSupportingBlockPos(state, level, pos);
        BlockState supportState  = level.m_8055_(relativePos);

        int supportRotation = supportState.m_60734_() instanceof AbstractRotatableBlock
                ? (int) getRelativeYRotation(supportState)
                : 0;

        return canBePlacedAt(level, pos, state, relativePos, supportState, direction.m_122424_())
                && supportRotation == (int) getRelativeYRotation(state);
    }

    @Override
    public Vec2 getOffset(BlockState state) {
        if (state.m_61143_(ROTATION) < PROPERTY_MAX_ROTATION_INDEX) {
            return Vec2.f_82462_;
        }
        return switch (state.m_61143_(FACING)) {
            case WEST  -> new Vec2(0, -1);
            case EAST  -> new Vec2(0,  1);
            case SOUTH -> new Vec2(-1, 0);
            default    -> new Vec2(1,  0);
        };
    }

    public BlockPos getSupportingBlockPos(BlockState selfState, LevelReader level, BlockPos selfPos) {
        return getSupportBlockPos(level, selfPos, selfState);
    }

    protected boolean allowSturdyFaceConnections() {
        return true;
    }

    protected boolean canBePlacedAt(LevelReader level, BlockPos pos, BlockState state, BlockPos otherPos, BlockState otherState, Direction direction) {
        return otherState.m_204336_(getSupportBlockTag())
                || (allowSturdyFaceConnections() && otherState.m_60783_(level, otherPos, direction));
    }

    protected abstract TagKey<Block> getSupportBlockTag();
}