package de.mrjulsen.paw.block;

import java.util.Objects;
import java.util.function.Supplier;

import de.mrjulsen.paw.block.abstractions.AbstractRotatedConnectableBlock;
import de.mrjulsen.paw.block.abstractions.IWeatheringBlock;
import de.mrjulsen.paw.block.extended.BlockPlaceContextExtension;
import de.mrjulsen.paw.registry.ModBlocks;
import de.mrjulsen.mcdragonlib.config.ECachingPriority;
import de.mrjulsen.mcdragonlib.util.MapCache;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Direction.Axis;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.jetbrains.annotations.NotNull;

public abstract class CantileverBracketBaseBlock<T extends CantileverBracketBaseBlock<T>> extends AbstractRotatedConnectableBlock implements IWeatheringBlock<T> {
    
    protected static final record ShapeContext(BlockGetter level, BlockPos pos, BlockState state, CollisionContext context) {}

    private final MapCache<VoxelShape, BlockState, ShapeContext> shapeContext = new MapCache<>(c -> makeShape(c), (state) -> Objects.hash(state.m_61148_().values().toArray(Object[]::new)), ECachingPriority.ALWAYS);
    
    protected final IWeatheringBlock.WeatherData<T> weatheringData;

    public CantileverBracketBaseBlock(Properties properties, IWeatheringBlock.WeatherData<T> weatheringData) {
        super(properties);
        this.weatheringData = weatheringData;
    }

    @Override
    public ItemStack m_7397_(BlockGetter level, BlockPos pos, BlockState state) {
        return new ItemStack(ModBlocks.CANTILEVER_BRACKET.get(new ModBlocks.OxidizingKey(getWeatheringData().ageState(), getWeatheringData().isWaxed())).get());
    }

    protected VoxelShape makeShape(ShapeContext c) {
        double stretch = 16d * ((1d / Math.cos(Math.abs(Math.toRadians(getRelativeYRotation(c.state()))))) - 1d);
        double halfStretch = stretch / 2;
        return switch (c.state().m_61143_(FACING)) {
            case SOUTH -> Block.m_49796_(6d, 6d, 0 - halfStretch, 10d, 10d, 16d + halfStretch);
            case WEST  -> Block.m_49796_(0 - halfStretch, 6d, 6d, 16d + halfStretch, 10d, 10d);
            case EAST  -> Block.m_49796_(0 - halfStretch, 6d, 6d, 16d + halfStretch, 10d, 10d);
            default    -> Block.m_49796_(6d, 6d, 0 - halfStretch, 10d, 10d, 16d + halfStretch);
        };
    }

    @Override
    public BlockState m_5573_(BlockPlaceContext context) {
        BlockPlaceContextExtension ctxExt = (BlockPlaceContextExtension)(Object)context;
        BlockState state = super.m_5573_(context);
        BlockState clickedOnState = ctxExt.paw$getPlacedOnState();
        Direction clickedFace = context.m_43719_();
        
        if ((clickedOnState.m_60734_() instanceof CantileverBracketBaseBlock || clickedOnState.m_60734_() instanceof CantileverBracketVerticalBlock) && clickedFace.m_122434_().m_122478_()) {
            state = ModBlocks.CANTILEVER_BRACKET_VERTICAL.get(new ModBlocks.OxidizingKey(getWeatheringData().ageState(), getWeatheringData().isWaxed())).getDefaultState()
                .m_61124_(CantileverBracketVerticalBlock.DIRECTION, clickedFace)
                .m_61124_(FACING, clickedOnState.m_61143_(FACING))
                .m_61124_(ROTATION, clickedOnState.m_61143_(ROTATION))
            ;
        }

        return state;
    }

    @Override
    protected boolean canConnect(Level level, BlockState state, BlockPos pos, BlockState otherState, BlockPos otherPos) {
        return otherState.m_60734_() instanceof CantileverBracketBaseBlock;
    }

    @Override
    public VoxelShape getBaseShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return shapeContext.get(new ShapeContext(level, pos, state, context), state);
    }

    @Override
    public Axis transformOnAxis(BlockState state) {
        return state.m_61143_(FACING).m_122434_();
    }

    public void m_213898_(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        this.m_220947_(state, level, pos, random);
    }

    public boolean m_6724_(BlockState state) {
        return getNext().isPresent();
    }

    @Override
    public @NotNull IWeatheringBlock.WeatherData<T> getWeatheringData() {
        return weatheringData;
    }

    @Override
    public float m_142377_() {
        if (getWeatheringData().isWaxed()) return 0;
        return IWeatheringBlock.super.m_142377_();
    }
}
