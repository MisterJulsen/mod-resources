package de.mrjulsen.paw.block;

import de.mrjulsen.paw.blockentity.MultiblockWireConnectorBlockEntity;
import de.mrjulsen.paw.item.CatenaryWireType;
import de.mrjulsen.paw.blockentity.IMultiblockBlockEntity;
import de.mrjulsen.paw.block.abstractions.AbstractSupportedRotatableWireConnectorBlock;
import de.mrjulsen.paw.block.abstractions.ICatenaryWireConnector;
import de.mrjulsen.paw.block.abstractions.IMultiblock;
import de.mrjulsen.paw.block.extended.BlockPlaceContextExtension;
import de.mrjulsen.paw.block.property.ECantileverConnectionType;
import de.mrjulsen.paw.registry.ModBlockEntities;
import de.mrjulsen.paw.registry.ModBlockTags;
import de.mrjulsen.paw.util.Const;
import de.mrjulsen.paw.util.ModMath;
import de.mrjulsen.wires.graph.data.provider.CantileverConnectorDataProvider;
import de.mrjulsen.wires.graph.data.provider.ConnectorDataProvider;
import de.mrjulsen.wires.item.CustomData;

import org.joml.Vector3f;

import de.mrjulsen.mcdragonlib.config.ECachingPriority;
import de.mrjulsen.mcdragonlib.util.MapCache;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos.MutableBlockPos;
import net.minecraft.core.Direction.Axis;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition.Builder;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

public class TensioningDeviceBlock extends AbstractSupportedRotatableWireConnectorBlock<MultiblockWireConnectorBlockEntity> implements ICatenaryWireConnector, IMultiblock {

    public static final int HEIGHT = 7;


    public static final BooleanProperty HELPER = BooleanProperty.m_61465_("helper");
    public static final EnumProperty<ECantileverConnectionType> CONNECTION = EnumProperty.m_61587_("connection", ECantileverConnectionType.class);

    private static final VoxelShape DEFAULT_SHAPE = Block.m_49796_(0.5d, 0, -0.25d, 15.5d, 16, 16);
    private static final MapCache<VoxelShape, BlockState, BlockState> shapesCache = new MapCache<>((state) -> {
        VoxelShape baseShape = ModMath.moveShape(DEFAULT_SHAPE, new Vec3(0, 0, Const.PIXEL * ((float)(16 - state.m_61143_(CONNECTION).getIndex()) / 2f)));
        Direction direction = state.m_61143_(FACING);
        VoxelShape shape = ModMath.rotateShape(baseShape, Axis.Y, (int)direction.m_122424_().m_122435_());
        return shape;
    }, BlockState::hashCode, ECachingPriority.ALWAYS);


    public TensioningDeviceBlock(Properties properties) {
        super(properties);
        m_49959_(this.m_49966_()
            .m_61124_(HELPER, false)
            .m_61124_(CONNECTION, ECantileverConnectionType.PX16)
        );
    }

    @Override
    protected void m_7926_(Builder<Block, BlockState> pBuilder) {        
        super.m_7926_(pBuilder);
        pBuilder.m_61104_(CONNECTION, HELPER);
    }

    @Override
    public RenderShape m_7514_(BlockState pState) {
        return pState.m_61143_(HELPER) ? RenderShape.INVISIBLE : RenderShape.MODEL;
    }

    @Override
    public BlockState m_5573_(BlockPlaceContext context) {
        BlockPlaceContextExtension ext = (BlockPlaceContextExtension)context;
        Level level = context.m_43725_();        
        MutableBlockPos refPos = new MutableBlockPos(ext.paw$getPlacedOnPos().m_123341_(), ext.paw$getPlacedOnPos().m_123342_(), ext.paw$getPlacedOnPos().m_123343_());

        BlockState refState = ext.paw$getPlacedOnState();
        ECantileverConnectionType refConnectionType = ECantileverConnectionType.getFirstForState(refState).orElse(ECantileverConnectionType.PX16);

        for (int i = 1; i < HEIGHT; i++) {
            refPos.m_122184_(0, -1, 0);
            BlockState supportState = level.m_8055_(refPos);
            ECantileverConnectionType connectionType = ECantileverConnectionType.getFirstForState(supportState).orElse(ECantileverConnectionType.PX16);
            if (refState.m_60734_() != supportState.m_60734_() && (refConnectionType != connectionType || (refConnectionType == ECantileverConnectionType.PX16 && !supportState.m_60783_(level, refPos, context.m_43719_())))) {
                return null;
            }
            BlockPos p = context.m_8083_().m_5484_(Direction.DOWN, i);
            if (!level.m_8055_(p).m_60629_(context) || level.m_151570_(p)) {
                return null;
            }
        }

        return super.m_5573_(context)
            .m_61124_(CONNECTION, ECantileverConnectionType.getFirstForState(ext.paw$getPlacedOnState()).orElse(ECantileverConnectionType.PX16))
        ;
    }

    @Override
    public void m_6402_(Level level, BlockPos pos, BlockState state, LivingEntity placer, ItemStack stack) {
        MutableBlockPos refPos = new MutableBlockPos(pos.m_123341_(), pos.m_123342_(), pos.m_123343_());
        for (int i = 1; i < HEIGHT; i++) {
            refPos.m_122184_(0, -1, 0);
            level.m_6933_(refPos, state.m_61124_(HELPER, true), 0, 0);
            if (level.m_7702_(refPos) instanceof MultiblockWireConnectorBlockEntity be) {
                be.setOffset(1, i, 1);
            }
        }
    }

    @Override
    public BlockState m_7417_(BlockState state, Direction direction, BlockState neighborState, LevelAccessor level, BlockPos currentPos, BlockPos neighborPos) {        
        return m_7898_(state, level, currentPos) ? super.m_7417_(state, direction, neighborState, level, currentPos, neighborPos) : Blocks.f_50016_.m_49966_();
    }

    @Override
    public boolean m_7898_(BlockState state, LevelReader level, BlockPos pos) {
        if (level.m_7702_(pos) instanceof IMultiblockBlockEntity be) {
            int yOffset = be.getYOffset();
            MutableBlockPos mPos = new MutableBlockPos(pos.m_123341_(), pos.m_123342_(), pos.m_123343_());
            mPos.m_122184_(0, 1, 0);
            boolean b1 = yOffset <= 0 || (level.m_8055_(mPos).m_60713_(this) && level.m_7702_(mPos) instanceof IMultiblockBlockEntity b && b.getYOffset() == yOffset - 1);
            mPos.m_122184_(0, -2, 0);
            boolean b2 = yOffset >= HEIGHT - 1 || (level.m_8055_(mPos).m_60713_(this) && level.m_7702_(mPos) instanceof IMultiblockBlockEntity b && b.getYOffset() == yOffset + 1);
            
            if (!b1 || !b2) return false;

            mPos.m_122184_(0, 1, 0);
            BlockPos refPos = getSupportBlockPos(level, mPos, state);
            BlockState refState = level.m_8055_(refPos);
            ECantileverConnectionType refConnectionType = ECantileverConnectionType.getFirstForState(refState).orElse(ECantileverConnectionType.PX16);
            for (int i = yOffset; i < HEIGHT - 1; i++) {
                mPos.m_122184_(0, -1, 0);
                BlockPos supportPos = getSupportBlockPos(level, mPos, state);
                BlockState supportState = level.m_8055_(supportPos);
                ECantileverConnectionType connectionType = ECantileverConnectionType.getFirstForState(supportState).orElse(ECantileverConnectionType.PX16);
                if (refState.m_60734_() != supportState.m_60734_() && (refConnectionType != connectionType || (refConnectionType == ECantileverConnectionType.PX16 && !supportState.m_60783_(level, supportPos, state.m_61143_(FACING).m_122424_())))) {
                    return false;
                }
            }
        }
        return super.m_7898_(state, level, pos);
    }

    @Override
    protected TagKey<Block> getSupportBlockTag() {
        return ModBlockTags.TENSIONING_DEVICE_CONNECTABLE;
    }

    @Override
    public VoxelShape getBaseShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return shapesCache.get(state, state);
    }

    @Override
    public Vec3 defaultWireAttachPoint(Level level, BlockPos pos, BlockState state, CustomData itemData, int index) {
        return new Vec3(Const.PIXEL * 3.5f - 0.5f, Const.PIXEL * 0.25, Const.PIXEL * 8.25f - 0.5f + (Const.PIXEL * (float)((16 - state.m_61143_(CONNECTION).getIndex()) / 2f)));
    }

    @Override
    public Vec3 tensionWireAttachPoint(Level level, BlockPos pos, BlockState state, CustomData itemData, int index) {
        return new Vec3(Const.PIXEL * 12.5f - 0.5f, Const.PIXEL * 10.25f, Const.PIXEL * 8.25f - 0.5f + (Const.PIXEL * (float)((16 - state.m_61143_(CONNECTION).getIndex()) / 2f)));
    }
    @Override
    public ConnectorDataProvider getConnectorData(Level level, BlockPos pos, CustomData customData, int connectionPointIndex) {
        Vector3f contactAttachPoint = transformWireAttachPoint(level, pos, level.m_8055_(pos), customData, connectionPointIndex, this::defaultWireAttachPoint).m_252839_();
        Vector3f tensionattachPoint = transformWireAttachPoint(level, pos, level.m_8055_(pos), customData, connectionPointIndex, this::tensionWireAttachPoint).m_252839_();
        CompoundTag customNbt = customData.getCommonData();
        customNbt.m_128379_(CatenaryWireType.NBT_SUPER_TIGHTENED, true);
        customData.setCommonData(customNbt);
        return new CantileverConnectorDataProvider(contactAttachPoint, tensionattachPoint);
    }

    @Override
    public Vec2 getRotationPivotPoint(BlockState state) {
        return new Vec2(0f, 1f);
    }

    @Override
    public Vec3 multiblockSize() {
        return new Vec3(1, HEIGHT, 1);
    }
    
    @Override
    public boolean canConnectWire(LevelReader level, BlockPos pos, BlockState state) {
        return !state.m_61143_(HELPER);
    }

    @Override
    public Class<MultiblockWireConnectorBlockEntity> getBlockEntityClass() {
        return MultiblockWireConnectorBlockEntity.class;
    }

    @Override
    public BlockEntityType<? extends MultiblockWireConnectorBlockEntity> getBlockEntityType() {
        return ModBlockEntities.MULTIBLOCK_WIRE_CONNECTOR_BLOCK_ENTITY.get();
    }
}
