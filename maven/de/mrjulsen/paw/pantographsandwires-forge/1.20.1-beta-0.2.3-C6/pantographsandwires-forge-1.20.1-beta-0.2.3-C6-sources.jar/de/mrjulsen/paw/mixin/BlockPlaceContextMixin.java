package de.mrjulsen.paw.mixin;

import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;

import de.mrjulsen.paw.block.extended.BlockPlaceContextExtension;
import net.minecraft.core.BlockPos;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.block.state.BlockState;

@Mixin(BlockPlaceContext.class)
public class BlockPlaceContextMixin implements BlockPlaceContextExtension {

    @Override
    public BlockPos paw$getPlacedOnPos() {
        BlockPlaceContext self = (BlockPlaceContext)(Object)this;
        return self.m_8083_().m_121945_(self.m_43719_().m_122424_());
    }

    @Override
    public BlockState paw$getPlacedOnState() {
        BlockPlaceContext self = (BlockPlaceContext)(Object)this;
        Level level = self.m_43725_();
        BlockPos clickedBlockPos = self.m_8083_().m_121945_(self.m_43719_().m_122424_());
        return level.m_8055_(clickedBlockPos);
    }    
}
