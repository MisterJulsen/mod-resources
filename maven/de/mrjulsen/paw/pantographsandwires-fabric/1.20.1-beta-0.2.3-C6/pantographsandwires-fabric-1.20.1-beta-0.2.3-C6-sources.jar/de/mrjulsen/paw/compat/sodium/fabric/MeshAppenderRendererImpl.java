package de.mrjulsen.paw.compat.sodium.fabric;

import it.unimi.dsi.fastutil.objects.ObjectIterator;
import it.unimi.dsi.fastutil.objects.Reference2ReferenceMap.Entry;
import it.unimi.dsi.fastutil.objects.Reference2ReferenceOpenHashMap;
import me.jellysquid.mods.sodium.client.render.chunk.compile.ChunkBuildBuffers;
import me.jellysquid.mods.sodium.client.render.chunk.terrain.material.DefaultMaterials;
import me.jellysquid.mods.sodium.client.render.chunk.terrain.material.Material;
import net.minecraft.class_1920;
import net.minecraft.class_1921;
import net.minecraft.class_4076;
import org.joml.Vector3f;
import org.joml.Vector3fc;

import de.mrjulsen.paw.fabric.compat.sodium.MeshAppender;
import de.mrjulsen.paw.fabric.compat.sodium.SinkingVertexBuilder;
import de.mrjulsen.paw.fabric.compat.sodium.SodiumCompatEvent;

/**
 * Ported fix for Embeddium
 */
public class MeshAppenderRendererImpl {
    private static final Vector3fc ZERO = new Vector3f();

    private static final ThreadLocal<Reference2ReferenceOpenHashMap<class_1921, SinkingVertexBuilder>> BUILDERS = ThreadLocal.withInitial(() -> {
        Reference2ReferenceOpenHashMap<class_1921, SinkingVertexBuilder> map = new Reference2ReferenceOpenHashMap<>();
        for(class_1921 layer : class_1921.method_22720()) {
            map.put(layer, new SinkingVertexBuilder());
        }
        return map;
    });

    public static void renderMeshAppenders(class_1920 world, class_4076 origin, ChunkBuildBuffers buffers) {
        Reference2ReferenceOpenHashMap<class_1921, SinkingVertexBuilder> builders = BUILDERS.get();

        for (var it = builders.reference2ReferenceEntrySet().fastIterator(); it.hasNext(); ) {
            var entry = it.next();

            entry.getValue().reset();
        }

        MeshAppender.Context context = new MeshAppender.Context(builders::get, world, origin, buffers);
        SodiumCompatEvent.CHUNK_MESHING_EVENT.invoker().render(context);

        for (var it = builders.reference2ReferenceEntrySet().fastIterator(); it.hasNext(); ) {
            var entry = it.next();
            var material = DefaultMaterials.forRenderLayer(entry.getKey());

            entry.getValue().flush(buffers.get(material), material, ZERO);
        }
    }
}