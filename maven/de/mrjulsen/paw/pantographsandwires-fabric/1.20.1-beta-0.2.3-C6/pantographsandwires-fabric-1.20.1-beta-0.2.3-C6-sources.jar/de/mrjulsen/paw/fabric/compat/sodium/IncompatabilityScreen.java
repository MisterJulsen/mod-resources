package de.mrjulsen.paw.fabric.compat.sodium;

import de.mrjulsen.mcdragonlib.util.TextUtils;
import de.mrjulsen.paw.PantographsAndWires;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5489;

public class IncompatabilityScreen extends class_437 {

    private final class_2561 subtitle = TextUtils.translate("gui." + PantographsAndWires.MOD_ID + ".sodium_error.subtitle");
    private final class_2561 description = TextUtils.translate("gui." + PantographsAndWires.MOD_ID + ".sodium_error.description");

    private class_5489 label;

    private final class_327 font = class_310.method_1551().field_1772;

    public IncompatabilityScreen() {
        super(TextUtils.translate("gui." + PantographsAndWires.MOD_ID + ".sodium_error.title").method_27692(class_124.field_1067));
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        label = class_5489.method_30890(field_22793, description, field_22789 / 2);

        class_4185 btnQuit = class_4185.method_46430(TextUtils.translate("menu.quit"), (b) -> {
            class_310.method_1551().method_1592();
        }).method_46434(field_22789 / 2 - 100, field_22790 - 50, 200, 20).method_46431();
        method_37063(btnQuit);
    }

    @Override
    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        method_25434(guiGraphics);
        guiGraphics.method_27535(field_22793, field_22785, field_22789 / 2, 60, 0xFFFFFFFF);
        guiGraphics.method_27535(field_22793, subtitle, field_22789 / 2, 80, 0xFFFF8080);
        label.method_30889(guiGraphics, field_22789 / 2, 120, field_22793.field_2000, 0xFFDBDBDB);
        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);
    }
}