package de.mrjulsen.paw.datagen.fabric;

import com.tterrag.registrate.providers.DataGenContext;
import com.tterrag.registrate.providers.RegistrateBlockstateProvider;
import com.tterrag.registrate.providers.RegistrateItemModelProvider;
import com.tterrag.registrate.providers.RegistrateTagsProvider;
import de.mrjulsen.mcdragonlib.util.DLUtils;
import de.mrjulsen.paw.PantographsAndWires;
import de.mrjulsen.paw.block.*;
import de.mrjulsen.paw.block.abstractions.AbstractMultipartPostBlock;
import de.mrjulsen.paw.block.abstractions.IHorizontalExtensionConnectable;
import de.mrjulsen.paw.block.abstractions.IWeatheringBlock;
import de.mrjulsen.paw.block.property.ECantileverConnectionType;
import de.mrjulsen.paw.block.property.EPostPart;
import de.mrjulsen.paw.datagen.ITagAppender;
import de.mrjulsen.paw.datagen.TagEntry;
import de.mrjulsen.paw.registry.MastMaterial;
import io.github.fabricators_of_create.porting_lib.models.generators.ConfiguredModel;
import io.github.fabricators_of_create.porting_lib.models.generators.ModelFile;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.function.Function;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1935;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_2760;

public class DataGenImpl {


    public static <T> void registerTags(RegistrateTagsProvider<T> provider, List<TagEntry<T>> registry) {
        for (TagEntry<T> entry : registry) {
            ITagAppender<T> appender = new TagAppender<>(provider.addTag(entry.key()));
            entry.populator().accept(appender);
        }
    }

    public static <T extends class_2248> void simpleHorizontalBlock(DataGenContext<class_2248, T> context, RegistrateBlockstateProvider provider, String existingModelPath) {
        provider.horizontalBlock(
                context.getEntry(),
                provider
                        .models()
                        .getExistingFile(
                                provider.modLoc(existingModelPath)
                        )
        );
    }

    public static <E extends class_1935, R extends E> void existingItemModel(DataGenContext<E, R> context, RegistrateItemModelProvider provider, String model) {
        provider.getExistingFile(DLUtils.resourceLocation(PantographsAndWires.MOD_ID, model));
    }

    public static <E extends class_1935, R extends E> void itemModel(DataGenContext<E, R> context, RegistrateItemModelProvider provider, String model) {
        provider.getBuilder(context.getName()).parent(new ModelFile.UncheckedModelFile(provider.modLoc(model)));
    }


    public static <T extends class_2248> void insulatorBlock(DataGenContext<class_2248, T> context, RegistrateBlockstateProvider provider, String baseModelPath, String baseModelName) {
        provider.horizontalBlock(context.getEntry(), state -> {
            String half = "";
            if (state.method_26204() instanceof InsulatorBlock) {
                half = "_" + switch (state.method_11654(InsulatorBlock.HALF)) {
                    case field_12619 -> "floor";
                    default -> "ceiling";
                };
            }
            String modelPath = baseModelPath + "/" + baseModelName + half;
            return provider
                    .models()
                    .getExistingFile(provider.modLoc(modelPath))
            ;
        });
    }

    public static void oxidizingItemModel(DataGenContext<class_1792, class_1747> context, RegistrateItemModelProvider provider, String prefix, String modelPath) {
        class_2248 block = context.getEntry().method_7711();
        String suffix = "normal";
        if (block instanceof IWeatheringBlock<?> weatheringBlock) {
            IWeatheringBlock.WeatherState state = weatheringBlock.getWeatheringData().ageState();
            suffix = state == IWeatheringBlock.WeatherState.UNAFFECTED ? suffix : state.getName();
        }
        String parentPath = modelPath + "/" + prefix + suffix;
        provider.getBuilder(context.getName()).parent(new ModelFile.UncheckedModelFile(provider.modLoc(parentPath)));
    }

    public static <T extends class_2248> void oxidizingMastBlock(DataGenContext<class_2248, T> context, RegistrateBlockstateProvider provider, MastMaterial material, String basePath, String baseModelName) {
        T block = context.getEntry();

        IWeatheringBlock.WeatherState weatherState = IWeatheringBlock.WeatherState.UNAFFECTED;
        if (block instanceof IWeatheringBlock<?> weatheringBlock) {
            weatherState = weatheringBlock.getWeatheringData().ageState();
        }
        final IWeatheringBlock.WeatherState fWeatherState = weatherState;

        provider.horizontalBlock(context.getEntry(), state -> {
            EPostPart part = EPostPart.IN_BETWEEN;
            if (state.method_26204() instanceof AbstractMultipartPostBlock) {
                part = state.method_11654(AbstractMultipartPostBlock.PART);
            }

            String modelPath = basePath + "/" +
                    (fWeatherState != IWeatheringBlock.WeatherState.UNAFFECTED ? fWeatherState.getName() : "normal") +
                    (part != EPostPart.IN_BETWEEN ? "_" + part.getName() : "")
            ;

            return provider
                    .models()
                    .withExistingParent(modelPath, DLUtils.resourceLocation(PantographsAndWires.MOD_ID, basePath + "/" + baseModelName + (part != EPostPart.IN_BETWEEN ? "_" + part.getName() : "")))
                    .texture("base", material.getTexture(fWeatherState))
                    .texture("particle", material.getTexture(fWeatherState))
                    ;
        });
    }

    public static <T extends class_2248> void tensioningDeviceBlock(DataGenContext<class_2248, T> context, RegistrateBlockstateProvider provider, String baseModelPath) {
        provider.horizontalBlock(context.getEntry(), state -> {
            ECantileverConnectionType connection = ECantileverConnectionType.PX16;
            if (state.method_26204() instanceof TensioningDeviceBlock) {
                connection = state.method_11654(TensioningDeviceBlock.CONNECTION);
            }

            String modelPath = baseModelPath + "/" + connection.getName();

            return provider
                    .models()
                    .getExistingFile(DLUtils.resourceLocation(PantographsAndWires.MOD_ID, modelPath))
                    ;
        });
    }

    public static <T extends class_2248> void powerLineBracketBlock(DataGenContext<class_2248, T> context, RegistrateBlockstateProvider provider, String basePath) {
        T block = context.getEntry();

        IWeatheringBlock.WeatherState weatherState = IWeatheringBlock.WeatherState.UNAFFECTED;
        if (block instanceof IWeatheringBlock<?> weatheringBlock) {
            weatherState = weatheringBlock.getWeatheringData().ageState();
        }
        final IWeatheringBlock.WeatherState fWeatherState = weatherState;

        provider.getVariantBuilder(block).forAllStates(state -> {
            class_2760 half = state.method_11654(PowerLineBracketBlock.HALF);
            IHorizontalExtensionConnectable.EPostType postType = state.method_11654(PowerLineBracketBlock.POST_TYPE);
            PowerLineBracketBlock.EConnectionType connectionType = state.method_11654(PowerLineBracketBlock.CONNECTION_TYPE);
            class_2350 facing = state.method_11654(PowerLineBracketBlock.FACING);

            String modelName = switch (connectionType) {
                case ON_POST -> switch (postType) {
                    case LATTICE -> "on_lattice";
                    case FENCE -> "on_fence";
                    default -> "on_wall";
                };
                case ON_POST_EXTENSION -> switch (postType) {
                    case LATTICE -> "on_lattice2";
                    case FENCE -> "on_fence2";
                    default -> "on_wall2";
                };
                case AT_POST -> switch (postType) {
                    case LATTICE -> "at_lattice";
                    case FENCE -> "at_fence";
                    default -> "at_wall";
                };
                default -> "";
            };


            String halfPath = half == class_2760.field_12617 ? "bottom" : "top";
            String s = modelName.isBlank() ? "" : "_" + modelName;
            String baseModel = basePath + "/" + halfPath + "/" + "power_line_bracket" + s;

            modelName += (modelName.isBlank() ? "" : "_") + (fWeatherState == IWeatheringBlock.WeatherState.UNAFFECTED ? "normal" : fWeatherState.getName());
            String fullModelPath = basePath + "/" + halfPath + "/" + modelName;

            int yRot = (int)facing.method_10144() + 180;

            ModelFile model = provider.models()
                    .withExistingParent(fullModelPath, DLUtils.resourceLocation(PantographsAndWires.MOD_ID, baseModel))
                    .texture("base", MastMaterial.METAL.getTexture(fWeatherState))
                    .texture("particle", MastMaterial.METAL.getTexture(fWeatherState))
            ;

            return ConfiguredModel.builder()
                    .modelFile(model)
                    .rotationY(yRot)
                    .build();
        });
    }

    public static <T extends class_2248> void registrationArm(DataGenContext<class_2248, T> context, RegistrateBlockstateProvider provider, String baseModel) {
        T block = context.getEntry();
        provider.getVariantBuilder(block).forAllStates(state -> {
            RegistrationArmBlock.State armState = state.method_11654(RegistrationArmBlock.REGISTRATION_ARM);
            boolean isMirrored = state.method_11654(RegistrationArmBlock.MIRRORED);
            return ConfiguredModel.builder()
                    .modelFile(provider.models().getExistingFile(provider.modLoc(baseModel + (armState == RegistrationArmBlock.State.ABOVE ? "_above" : ""))))
                    .rotationY(isMirrored ? 180 : 0)
                    .build();
        });
    }

    public static <T extends class_2248> void cantileverBracket(DataGenContext<class_2248, T> context, RegistrateBlockstateProvider provider) {
        T block = context.getEntry();

        Function<String, ModelFile> model = getCantileverBracketModelFile(provider, block, "");

        provider.getMultipartBuilder(block)
                // Base
                .part().modelFile(model.apply("base"))
                .addModel().condition(CantileverBracketBlock.FACING, class_2350.field_11043).end()
                .part().modelFile(model.apply("base"))
                .rotationY(90).addModel().condition(CantileverBracketBlock.FACING, class_2350.field_11034).end()
                .part().modelFile(model.apply("base"))
                .rotationY(180).addModel().condition(CantileverBracketBlock.FACING, class_2350.field_11035).end()
                .part().modelFile(model.apply("base"))
                .rotationY(270).addModel().condition(CantileverBracketBlock.FACING, class_2350.field_11039).end()

                // Crossing post
                .part().modelFile(model.apply("crossing_post_part"))
                .addModel().condition(CantileverBracketBlock.UP, true).end()
                .part().modelFile(model.apply("crossing_post_part"))
                .rotationX(180).addModel().condition(CantileverBracketBlock.DOWN, true).end()

                // T-Cross (down)
                .part().modelFile(model.apply("t_cross"))
                .addModel()
                .condition(CantileverBracketBlock.FACING, class_2350.field_11043)
                .condition(CantileverBracketBlock.UP, false)
                .condition(CantileverBracketBlock.DOWN, true).end()
                .part().modelFile(model.apply("t_cross"))
                .rotationY(90).addModel()
                .condition(CantileverBracketBlock.FACING, class_2350.field_11034)
                .condition(CantileverBracketBlock.UP, false)
                .condition(CantileverBracketBlock.DOWN, true).end()
                .part().modelFile(model.apply("t_cross"))
                .rotationY(180).addModel()
                .condition(CantileverBracketBlock.FACING, class_2350.field_11035)
                .condition(CantileverBracketBlock.UP, false)
                .condition(CantileverBracketBlock.DOWN, true).end()
                .part().modelFile(model.apply("t_cross"))
                .rotationY(270).addModel()
                .condition(CantileverBracketBlock.FACING, class_2350.field_11039)
                .condition(CantileverBracketBlock.UP, false)
                .condition(CantileverBracketBlock.DOWN, true).end()

                // T-Cross (up)
                .part().modelFile(model.apply("t_cross"))
                .rotationX(180).addModel()
                .condition(CantileverBracketBlock.FACING, class_2350.field_11043)
                .condition(CantileverBracketBlock.UP, true)
                .condition(CantileverBracketBlock.DOWN, false).end()
                .part().modelFile(model.apply("t_cross"))
                .rotationY(90).rotationX(180).addModel()
                .condition(CantileverBracketBlock.FACING, class_2350.field_11034)
                .condition(CantileverBracketBlock.UP, true)
                .condition(CantileverBracketBlock.DOWN, false).end()
                .part().modelFile(model.apply("t_cross"))
                .rotationY(180).rotationX(180).addModel()
                .condition(CantileverBracketBlock.FACING, class_2350.field_11035)
                .condition(CantileverBracketBlock.UP, true)
                .condition(CantileverBracketBlock.DOWN, false).end()
                .part().modelFile(model.apply("t_cross"))
                .rotationY(270).rotationX(180).addModel()
                .condition(CantileverBracketBlock.FACING, class_2350.field_11039)
                .condition(CantileverBracketBlock.UP, true)
                .condition(CantileverBracketBlock.DOWN, false).end()

                // Cross
                .part().modelFile(model.apply("cross"))
                .addModel()
                .condition(CantileverBracketBlock.FACING, class_2350.field_11043)
                .condition(CantileverBracketBlock.UP, true)
                .condition(CantileverBracketBlock.DOWN, true).end()
                .part().modelFile(model.apply("cross"))
                .rotationY(90).addModel()
                .condition(CantileverBracketBlock.FACING, class_2350.field_11034)
                .condition(CantileverBracketBlock.UP, true)
                .condition(CantileverBracketBlock.DOWN, true).end()
                .part().modelFile(model.apply("cross"))
                .rotationY(180).addModel()
                .condition(CantileverBracketBlock.FACING, class_2350.field_11035)
                .condition(CantileverBracketBlock.UP, true)
                .condition(CantileverBracketBlock.DOWN, true).end()
                .part().modelFile(model.apply("cross"))
                .rotationY(270).addModel()
                .condition(CantileverBracketBlock.FACING, class_2350.field_11039)
                .condition(CantileverBracketBlock.UP, true)
                .condition(CantileverBracketBlock.DOWN, true).end();
    }

    public static <T extends class_2248> void cantileverBracketAtPost(DataGenContext<class_2248, T> context, RegistrateBlockstateProvider provider) {
        T block = context.getEntry();

        Function<String, ModelFile> model = getCantileverBracketModelFile(provider, block, "_at_post");

        provider.getMultipartBuilder(block)
                // Base
                .part().modelFile(model.apply("base"))
                .addModel().condition(CantileverBracketBlock.FACING, class_2350.field_11043).end()
                .part().modelFile(model.apply("base"))
                .rotationY(90).addModel().condition(CantileverBracketBlock.FACING, class_2350.field_11034).end()
                .part().modelFile(model.apply("base"))
                .rotationY(180).addModel().condition(CantileverBracketBlock.FACING, class_2350.field_11035).end()
                .part().modelFile(model.apply("base"))
                .rotationY(270).addModel().condition(CantileverBracketBlock.FACING, class_2350.field_11039).end()

                // Bracket
                .part().modelFile(model.apply("bracket"))
                .addModel().condition(CantileverBracketBlock.FACING, class_2350.field_11043).end()
                .part().modelFile(model.apply("bracket"))
                .rotationY(90).addModel().condition(CantileverBracketBlock.FACING, class_2350.field_11034).end()
                .part().modelFile(model.apply("bracket"))
                .rotationY(180).addModel().condition(CantileverBracketBlock.FACING, class_2350.field_11035).end()
                .part().modelFile(model.apply("bracket"))
                .rotationY(270).addModel().condition(CantileverBracketBlock.FACING, class_2350.field_11039).end();
    }


    private static <T extends class_2248> @NotNull Function<String, ModelFile> getCantileverBracketModelFile(RegistrateBlockstateProvider provider, T block, String suffix) {
        final String basePath = "block/cantilever_bracket";

        IWeatheringBlock.WeatherState weatherState = IWeatheringBlock.WeatherState.UNAFFECTED;
        if (block instanceof IWeatheringBlock<?> weatheringBlock) {
            weatherState = weatheringBlock.getWeatheringData().ageState();
        }
        final IWeatheringBlock.WeatherState fWeatherState = weatherState;

        Function<String, ModelFile> model = (o) -> {
            String newName = o + suffix;
            return provider.models()
                    .withExistingParent(basePath + "/" + newName + "_" + (fWeatherState == IWeatheringBlock.WeatherState.UNAFFECTED ? "normal" : fWeatherState.getName()), provider.modLoc(basePath + "/" + o))
                    .texture("base", MastMaterial.METAL.getTexture(fWeatherState))
                    .texture("particle", MastMaterial.METAL.getTexture(fWeatherState))
            ;
        };
        return model;
    }
}
