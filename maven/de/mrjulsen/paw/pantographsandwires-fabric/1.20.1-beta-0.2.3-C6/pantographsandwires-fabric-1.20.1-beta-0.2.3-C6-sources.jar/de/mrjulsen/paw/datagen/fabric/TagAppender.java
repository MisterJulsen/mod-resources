package de.mrjulsen.paw.datagen.fabric;

import de.mrjulsen.paw.datagen.ITagAppender;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_6862;

public class TagAppender<T> implements ITagAppender<T> {

    private final FabricTagProvider<T>.FabricTagBuilder builder;

    public TagAppender(FabricTagProvider<T>.FabricTagBuilder builder) {
        this.builder = builder;
    }

    @Override
    public ITagAppender<T> add(T t) {
        builder.add(t);
        return this;
    }

    @Override
    public ITagAppender<T> add(T... ts) {
        builder.add(ts);
        return this;
    }

    @Override
    public ITagAppender<T> add(class_6862<T> tag) {
        builder.forceAddTag(tag);
        return this;
    }

    @Override
    public ITagAppender<T> add(class_6862<T>... tags) {
        builder.addTags(tags);
        return this;
    }

    @Override
    public ITagAppender<T> add(class_2960 id) {
        builder.add(id);
        return this;
    }

    @Override
    public ITagAppender<T> add(class_2960... ids) {
        builder.add(ids);
        return this;
    }

    @Override
    public ITagAppender<T> add(class_5321<T> key) {
        builder.method_46835(key);
        return this;
    }

    @Override
    public ITagAppender<T> add(class_5321<T>... keys) {
        builder.method_40565(keys);
        return this;
    }

    @Override
    public ITagAppender<T> addOptional(class_2960 id) {
        builder.method_35922(id);
        return this;
    }

    @Override
    public ITagAppender<T> addOptional(class_5321<T> key) {
        builder.addOptional(key);
        return this;
    }

    @Override
    public ITagAppender<T> addOptional(class_6862<T> tag) {
        builder.addOptionalTag(tag);
        return this;
    }

    @Override
    public ITagAppender<T> addOptionalTag(class_2960 id) {
        builder.method_35923(id);
        return this;
    }
}
