package de.mrjulsen.paw.fabric.compat.sodium;

import java.util.function.Function;
import me.jellysquid.mods.sodium.client.render.chunk.compile.ChunkBuildBuffers;
import net.minecraft.class_1920;
import net.minecraft.class_1921;
import net.minecraft.class_4076;
import net.minecraft.class_4588;

public interface MeshAppender {
    /**
     * Called to add appropriate geometry to the section.
     * @param context render context for this section
     */
    void render(Context context);

    /**
     * Section rendering context for a MeshAppender.
     * @param vertexConsumerProvider Provides access to {@link class_4588}s for each render layer. Any vertices
     *                               pumped into these vertex consumers will be added to the chunk's final mesh
     * @param blockRenderView The chunk section being rendered. You should only retrieve blocks using this, not the
     *                        client world
     * @param sectionOrigin The origin of the section in the world
     * @param sodiumBuildBuffers Provides access to the Sodium/Embeddium vertex writing APIs. Intended mainly for internal
     *                           use
     */
    record Context(Function<class_1921, class_4588> vertexConsumerProvider,
                   class_1920 blockRenderView,
                   class_4076 sectionOrigin,
                   ChunkBuildBuffers sodiumBuildBuffers) {}
}
