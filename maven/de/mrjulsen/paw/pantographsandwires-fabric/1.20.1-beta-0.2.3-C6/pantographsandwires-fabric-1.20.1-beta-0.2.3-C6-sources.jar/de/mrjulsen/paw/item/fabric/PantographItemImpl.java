package de.mrjulsen.paw.item.fabric;

import java.util.function.Consumer;
import java.util.function.Supplier;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_756;
import de.mrjulsen.paw.PantographsAndWires;
import de.mrjulsen.paw.item.PantographItem;
import software.bernie.geckolib.animatable.GeoItem;
import software.bernie.geckolib.animatable.client.RenderProvider;
import software.bernie.geckolib.model.DefaultedBlockGeoModel;
import software.bernie.geckolib.renderer.GeoItemRenderer;

public class PantographItemImpl extends PantographItem {
	private final Supplier<Object> renderProvider = GeoItem.makeRenderer(this);

	protected PantographItemImpl(class_2248 block, class_1793 properties, boolean expanded) {
		super(block, properties, expanded);
	}

	public static PantographItem create(class_2248 block, class_1793 properties, boolean expanded) {
        return new PantographItemImpl(block, properties, expanded);
	}

	@Override
	public void createRenderer(Consumer<Object> consumer) {
		consumer.accept(new RenderProvider() {
			private GeoItemRenderer<PantographItem> renderer = null;

			@Override
			public class_756 getCustomRenderer() {
				if (this.renderer == null)
					this.renderer = new GeoItemRenderer<>(new DefaultedBlockGeoModel<>(new class_2960(PantographsAndWires.MOD_ID, "pantograph")));

				return this.renderer;
			}
		});
	}

	@Override
	public Supplier<Object> getRenderProvider() {
		return this.renderProvider;
	}    
}
