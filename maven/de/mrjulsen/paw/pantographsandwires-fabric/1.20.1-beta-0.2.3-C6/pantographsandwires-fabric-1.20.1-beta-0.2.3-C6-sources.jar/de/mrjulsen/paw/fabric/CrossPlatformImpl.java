package de.mrjulsen.paw.fabric;

import com.jamieswhiteshirt.reachentityattributes.ReachEntityAttributes;
import com.simibubi.create.content.contraptions.Contraption;
import com.simibubi.create.content.contraptions.render.ClientContraption;
import de.mrjulsen.paw.PantographsAndWires;
import de.mrjulsen.paw.config.ModClientConfig;
import de.mrjulsen.paw.config.ModCommonConfig;
import de.mrjulsen.paw.config.ModServerConfig;
import de.mrjulsen.paw.mixin.ContraptionAccessor;
import dev.architectury.platform.Platform;
import dev.architectury.utils.Env;
import fuzs.forgeconfigapiport.impl.config.ForgeConfigRegistryImpl;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraftforge.fml.config.ModConfig;

public final class CrossPlatformImpl {

    public static void registerConfig() {
        if (Platform.getEnvironment() == Env.CLIENT) {
            ForgeConfigRegistryImpl.INSTANCE.register(PantographsAndWires.MOD_ID, ModConfig.Type.CLIENT, ModClientConfig.SPEC, PantographsAndWires.MOD_ID + "-client.toml");
        }
        ForgeConfigRegistryImpl.INSTANCE.register(PantographsAndWires.MOD_ID, ModConfig.Type.COMMON, ModCommonConfig.SPEC, PantographsAndWires.MOD_ID + "-common.toml");
        ForgeConfigRegistryImpl.INSTANCE.register(PantographsAndWires.MOD_ID, ModConfig.Type.SERVER, ModServerConfig.SPEC, PantographsAndWires.MOD_ID + "-server.toml");
    }

    public static double interactionRange(class_1657 player) {
        throw new AssertionError();
    }
    
    public static double reach(class_1657 p) {
		return ReachEntityAttributes.getReachDistance(p, p.method_7337() ? 5 : 4.5);
	}    

    public static class_2586 getClientContraptionBlockEntity(Contraption contraption, class_2338 localPos) {
        var maybeNullClientContraption = ((ContraptionAccessor)contraption).paw$clientContraption().getAcquire();
        if (maybeNullClientContraption == null) {
            return null;
        }
        return maybeNullClientContraption.getBlockEntity(localPos);
    }  
}
