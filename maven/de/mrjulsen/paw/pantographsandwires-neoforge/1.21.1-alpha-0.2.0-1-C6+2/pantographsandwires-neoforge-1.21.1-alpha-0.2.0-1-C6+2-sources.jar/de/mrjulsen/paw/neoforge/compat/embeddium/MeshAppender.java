package de.mrjulsen.paw.neoforge.compat.embeddium;

import java.util.function.Function;

import com.mojang.blaze3d.vertex.VertexConsumer;

import net.minecraft.client.renderer.RenderType;
import net.minecraft.core.SectionPos;
import net.minecraft.world.level.BlockAndTintGetter;
import org.embeddedt.embeddium.impl.render.chunk.compile.ChunkBuildBuffers;

public interface MeshAppender {
    /**
     * Called to add appropriate geometry to the section.
     * @param context render context for this section
     */
    void render(org.embeddedt.embeddium.api.MeshAppender.Context context);

    /**
     * Section rendering context for a MeshAppender.
     * @param vertexConsumerProvider Provides access to {@link VertexConsumer}s for each render layer. Any vertices
     *                               pumped into these vertex consumers will be added to the chunk's final mesh
     * @param blockRenderView The chunk section being rendered. You should only retrieve blocks using this, not the
     *                        client world
     * @param sectionOrigin The origin of the section in the world
     * @param sodiumBuildBuffers Provides access to the Sodium/Embeddium vertex writing APIs. Intended mainly for internal
     *                           use
     */
    record Context(Function<RenderType, VertexConsumer> vertexConsumerProvider,
                   BlockAndTintGetter blockRenderView,
                   SectionPos sectionOrigin,
                   ChunkBuildBuffers sodiumBuildBuffers) {}
}
