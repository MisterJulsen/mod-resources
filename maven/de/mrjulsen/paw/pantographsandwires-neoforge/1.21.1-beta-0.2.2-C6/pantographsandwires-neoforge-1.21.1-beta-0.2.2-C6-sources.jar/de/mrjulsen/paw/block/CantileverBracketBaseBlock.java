package de.mrjulsen.paw.block;

import java.util.Objects;
import java.util.function.Supplier;

import de.mrjulsen.paw.block.abstractions.AbstractRotatedConnectableBlock;
import de.mrjulsen.paw.block.abstractions.IWeatheringBlock;
import de.mrjulsen.paw.block.extended.BlockPlaceContextExtension;
import de.mrjulsen.paw.registry.ModBlocks;
import de.mrjulsen.mcdragonlib.config.ECachingPriority;
import de.mrjulsen.mcdragonlib.util.MapCache;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Direction.Axis;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.jetbrains.annotations.NotNull;

public abstract class CantileverBracketBaseBlock<T extends CantileverBracketBaseBlock<T>> extends AbstractRotatedConnectableBlock implements IWeatheringBlock<T> {
    
    protected static final record ShapeContext(BlockGetter level, BlockPos pos, BlockState state, CollisionContext context) {}

    private final MapCache<VoxelShape, BlockState, ShapeContext> shapeContext = new MapCache<>(c -> makeShape(c), (state) -> Objects.hash(state.getValues().values().toArray(Object[]::new)), ECachingPriority.ALWAYS);
    
    protected final IWeatheringBlock.WeatherData<T> weatheringData;

    public CantileverBracketBaseBlock(Properties properties, IWeatheringBlock.WeatherData<T> weatheringData) {
        super(properties);
        this.weatheringData = weatheringData;
    }

    @Override
    public ItemStack getCloneItemStack(BlockState state, HitResult target, LevelReader level, BlockPos pos, Player player) {
        return new ItemStack(ModBlocks.CANTILEVER_BRACKET.get(new ModBlocks.OxidizingKey(getWeatheringData().ageState(), getWeatheringData().isWaxed())).get());
    }

    protected VoxelShape makeShape(ShapeContext c) {
        double stretch = 16d * ((1d / Math.cos(Math.abs(Math.toRadians(getRelativeYRotation(c.state()))))) - 1d);
        double halfStretch = stretch / 2;
        return switch (c.state().getValue(FACING)) {
            case SOUTH -> Block.box(6d, 6d, 0 - halfStretch, 10d, 10d, 16d + halfStretch);
            case WEST  -> Block.box(0 - halfStretch, 6d, 6d, 16d + halfStretch, 10d, 10d);
            case EAST  -> Block.box(0 - halfStretch, 6d, 6d, 16d + halfStretch, 10d, 10d);
            default    -> Block.box(6d, 6d, 0 - halfStretch, 10d, 10d, 16d + halfStretch);
        };
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        BlockPlaceContextExtension ctxExt = (BlockPlaceContextExtension)(Object)context;
        BlockState state = super.getStateForPlacement(context);
        BlockState clickedOnState = ctxExt.paw$getPlacedOnState();
        Direction clickedFace = context.getClickedFace();
        
        if ((clickedOnState.getBlock() instanceof CantileverBracketBaseBlock || clickedOnState.getBlock() instanceof CantileverBracketVerticalBlock) && clickedFace.getAxis().isVertical()) {
            state = ModBlocks.CANTILEVER_BRACKET_VERTICAL.get(new ModBlocks.OxidizingKey(getWeatheringData().ageState(), getWeatheringData().isWaxed())).getDefaultState()
                .setValue(CantileverBracketVerticalBlock.DIRECTION, clickedFace)
                .setValue(FACING, clickedOnState.getValue(FACING))
                .setValue(ROTATION, clickedOnState.getValue(ROTATION))
            ;
        }

        return state;
    }

    @Override
    protected boolean canConnect(Level level, BlockState state, BlockPos pos, BlockState otherState, BlockPos otherPos) {
        return otherState.getBlock() instanceof CantileverBracketBaseBlock;
    }

    @Override
    public VoxelShape getBaseShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return shapeContext.get(new ShapeContext(level, pos, state, context), state);
    }

    @Override
    public Axis transformOnAxis(BlockState state) {
        return state.getValue(FACING).getAxis();
    }


    @Override
    protected void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        this.changeOverTime(state, level, pos, random);
    }

    @Override
    protected boolean isRandomlyTicking(BlockState state) {
        return getNext().isPresent();
    }

    @Override
    public @NotNull IWeatheringBlock.WeatherData<T> getWeatheringData() {
        return weatheringData;
    }

    @Override
    public float getChanceModifier() {
        if (getWeatheringData().isWaxed()) return 0;
        return IWeatheringBlock.super.getChanceModifier();
    }
}
